// AgroSense National & State Government Agriculture Schemes & Subsidies Database
// Comprehensive, verified repository of flagship agricultural subsidies across India

const SUBSIDY_CATEGORIES = exports.SUBSIDY_CATEGORIES = [
  { id: 'all', label: 'All Schemes', icon: 'layers' },
  { id: 'irrigation', label: 'Water & Irrigation', icon: 'droplet' },
  { id: 'solar', label: 'Solar & Clean Energy', icon: 'sun' },
  { id: 'insurance', label: 'Crop Insurance & Risk', icon: 'shield-check' },
  { id: 'machinery', label: 'Farm Machinery & Drones', icon: 'tractor' },
  { id: 'credit', label: 'Credit & Loans (KCC)', icon: 'credit-card' },
  { id: 'infrastructure', label: 'Post-Harvest & Polyhouse', icon: 'warehouse' },
  { id: 'soil_organic', label: 'Organic & Soil Health', icon: 'sprout' },
  { id: 'allied', label: 'Allied & Livestock', icon: 'paw-print' }
];

const GOVERNMENT_SUBSIDIES = exports.GOVERNMENT_SUBSIDIES = [
  {
    id: 'pmksy-pdmc',
    name: 'Per Drop More Crop (PDMC) — PMKSY Micro-Irrigation',
    shortName: 'PMKSY - Per Drop More Crop',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    category: 'irrigation',
    categoryLabel: 'Water & Irrigation',
    subsidyPct: '55% for Small/Marginal; 45% for Others',
    subsidyMaxAmount: 'Up to ₹55,000 / hectare (~₹22,000/acre)',
    farmerShare: '45% to 55% (often topped up by State subsidies up to 75%-80%)',
    badge: 'FLAGSHIP WATER SCHEME',
    badgeColor: 'emerald',
    summary: 'Comprehensive financial assistance for installing water-saving Drip irrigation laterals, micro-sprinklers, fertigation tanks, and automated filtration systems.',
    keyBenefits: [
      '40% to 50% water savings compared to traditional surface flooding',
      '20% to 30% reduction in fertilizer wastage via precise root-zone fertigation',
      '25% to 40% crop yield improvement with uniform moisture distribution',
      'Direct DBT transfer credited into farmer bank account or authorized OEM dealer'
    ],
    documentsRequired: [
      'Aadhaar Card of landholder',
      '7/12 Extract / Record of Rights (RoR) / Khatoni',
      'Water Source Proof (well, borewell, canal, or farm pond)',
      'Electricity Bill / Pump Connection Certificate',
      'Drip System Quotation from authorized and empanelled vendor'
    ],
    officialPortal: 'https://pmksy.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'pm-kusum',
    name: 'PM-KUSUM (Pradhan Mantri Kisan Urja Suraksha evam Utthaan Mahabhiyan)',
    shortName: 'PM-KUSUM Solar Pumps',
    ministry: 'Ministry of New and Renewable Energy (MNRE), Govt of India',
    category: 'solar',
    categoryLabel: 'Solar & Clean Energy',
    subsidyPct: '60% Combined Capital Subsidy (30% Central + 30% State)',
    subsidyMaxAmount: 'Up to ₹1,80,000 to ₹2,50,000 per pump',
    farmerShare: 'Only 10% cash upfront (30% bank loan financed)',
    badge: '60% SOLAR SUBSIDY',
    badgeColor: 'amber',
    summary: 'Subsidies for installing standalone off-grid DC/AC solar pumps (3HP, 5HP, 7.5HP) under Component-B and solarization of existing grid-connected electric pumps with net-metering export under Component-C.',
    keyBenefits: [
      '100% elimination of recurring diesel pump costs (saving ₹40,000 - ₹75,000/year)',
      'Daytime reliable 8-hour continuous irrigation power without night grid load shedding',
      'Additional income from exporting surplus solar electricity back to the DISCOM grid',
      '5-year comprehensive manufacturer warranty, remote telemetry, and repair insurance'
    ],
    documentsRequired: [
      'Aadhaar Card & Voter ID',
      'Land Ownership Record (7/12, 8-A / Jamabandi)',
      'Certificate of verified water source (borewell / dug well)',
      'Bank Account Passbook with IFSC code',
      'No-Objection Certificate (NOC) from Discom (for grid-connected pumps)'
    ],
    officialPortal: 'https://pmkusum.mnre.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'pmfby',
    name: 'Pradhan Mantri Fasal Bima Yojana (PMFBY)',
    shortName: 'PMFBY Crop Insurance',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    category: 'insurance',
    categoryLabel: 'Crop Insurance & Risk',
    subsidyPct: 'Govt Subsidizes up to 95% of Actuarial Premium',
    subsidyMaxAmount: 'Full Sum Insured based on Scale of Finance (₹25,000 - ₹85,000/acre)',
    farmerShare: 'Only 1.5% (Rabi), 2.0% (Kharif), 5.0% (Horticulture/Commercial)',
    badge: 'NATIONAL INSURANCE',
    badgeColor: 'blue',
    summary: 'Nationwide comprehensive crop insurance covering non-preventable natural risks (drought, flood, unseasonal rainfall, hailstorm, pest epidemics, post-harvest cyclonic damage).',
    keyBenefits: [
      'Extremely affordable uniform farmer premium rates (e.g. only ₹350 - ₹500/acre for wheat)',
      'Satellite & smartphone-based Crop Cutting Experiment (CCE) and transparent Yield Estimation',
      'Localized risk claim settlement within 72 hours of damage notification via Crop Insurance App',
      'Mid-season adversity relief when crop damage exceeds 50% normal'
    ],
    documentsRequired: [
      'Aadhaar Card',
      'Land Possession Certificate (LPC) or 7/12 Land Record',
      'Sowing Certificate issued by Patwari / Village Agriculture Officer',
      'Aadhaar-seeded Bank Account Passbook'
    ],
    officialPortal: 'https://pmfby.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'kcc-miss',
    name: 'Kisan Credit Card (KCC) with Modified Interest Subvention Scheme (MISS)',
    shortName: 'Kisan Credit Card (KCC)',
    ministry: 'Ministry of Agriculture & Farmers Welfare & RBI / NABARD',
    category: 'credit',
    categoryLabel: 'Credit & Loans (KCC)',
    subsidyPct: '3% Prompt Repayment Incentive + 1.5% Interest Subvention',
    subsidyMaxAmount: 'Crop loan limit up to ₹3,00,000 at effective 4% interest rate',
    farmerShare: 'Base rate 7% reduced to effective 4% per annum upon prompt repayment',
    badge: '4% CONCESSIONAL LOAN',
    badgeColor: 'purple',
    summary: 'Revolving institutional credit facility providing timely and adequate working capital for crop cultivation, fertilizer/seed purchase, post-harvest expenses, and farm asset maintenance.',
    keyBenefits: [
      'Concessional effective interest rate of just 4% per year (vs 12-18% informal moneylenders)',
      'Collateral-free crop loan limit up to ₹1,60,000',
      'Multi-year validity (5 years) with annual limit increase of 10%',
      'Extended to animal husbandry, dairy, and fisheries farmers'
    ],
    documentsRequired: [
      'KCC Application Form',
      'Aadhaar Card & PAN Card',
      'Land Records (7/12, Khatoni, Jamabandi)',
      'Crop Cultivation Sowing Declaration'
    ],
    officialPortal: 'https://myscheme.gov.in/schemes/kcc',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'smam-mechanization',
    name: 'Sub-Mission on Agricultural Mechanization (SMAM)',
    shortName: 'SMAM Farm Machinery Subsidy',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    category: 'machinery',
    categoryLabel: 'Farm Machinery & Drones',
    subsidyPct: '40% to 50% Subsidy for Individual Farmers; up to 80% for CHCs',
    subsidyMaxAmount: 'Up to ₹1,25,000 to ₹2,50,000 per implement; up to ₹10 Lakh for Custom Hiring',
    farmerShare: '50% to 60% of invoice price',
    badge: '50% MACHINERY REBATE',
    badgeColor: 'amber',
    summary: 'Promotes farm mechanization for small and marginal farmers across India, subsidizing tractors, power tillers, rotavators, laser land levelers, ridge seeders, and combine harvesters.',
    keyBenefits: [
      '40% to 50% capital subsidy on tractor-drawn implements and primary tillage machinery',
      'Special 50% rate for women, SC, ST, and small/marginal landholders',
      'Up to 80% subsidy for establishing village Custom Hiring Centers (CHCs)',
      'Enhances labor productivity and reduces cost of cultivation by 20%'
    ],
    documentsRequired: [
      'Aadhaar Card & Mobile Number',
      'Land Ownership Papers (7/12 / Patta / Khatoni)',
      'Bank Passbook Copy',
      'Quotation from empanelled agricultural machinery manufacturer',
      'Caste / Women Certificate (if claiming 50% priority rate)'
    ],
    officialPortal: 'https://agrimachinery.nic.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'kisan-drone',
    name: 'Kisan Drone Subsidy & NaMo Drone Didi Initiative',
    shortName: 'Kisan Drone Scheme',
    ministry: 'Ministry of Agriculture & Farmers Welfare & MoCA',
    category: 'machinery',
    categoryLabel: 'Farm Machinery & Drones',
    subsidyPct: '40% to 50% Subsidy for Small/Women/SC/ST; 75% for FPOs; 100% for ICAR/KVK',
    subsidyMaxAmount: 'Up to ₹4,00,000 to ₹5,00,000 for individual farmers; ₹7,50,000 for FPOs',
    farmerShare: '50% of drone unit cost (or service hiring from Drone Didi at ₹300-₹450/acre)',
    badge: 'DRONE TECHNOLOGY',
    badgeColor: 'cyan',
    summary: 'Financial assistance and technical training for procuring precision agriculture spray drones equipped with smart flow rate sensors, GPS telemetry, and obstacle avoidance radar for liquid fertilizers and crop protection.',
    keyBenefits: [
      '1 Acre sprayed in just 7 to 10 minutes (vs 3 hours manual knapsack labor)',
      '90% water saving (requires only 8-10 liters/acre vs 150 liters in knapsack sprayers)',
      '25% reduction in pesticide chemical consumption due to ultra-fine atomized droplet drift',
      'Completely prevents human toxicity exposure from direct chemical handling'
    ],
    documentsRequired: [
      'DGCA Drone Pilot Certificate / Training completion proof',
      'Farmer Registration ID & Aadhaar Card',
      'Land Records & FPO registration (if applying as group)',
      'Bank Account Details',
      'Proforma Invoice from DGCA Type-Certified Drone OEM'
    ],
    officialPortal: 'https://agrimachinery.nic.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'pm-kisan',
    name: 'Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)',
    shortName: 'PM-KISAN DBT Income Support',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    category: 'credit',
    categoryLabel: 'Credit & Loans (KCC)',
    subsidyPct: '100% Central Sector Grant via Direct Benefit Transfer (DBT)',
    subsidyMaxAmount: '₹6,000 per year (3 equal installments of ₹2,000 each)',
    farmerShare: 'Zero (Direct cash grant)',
    badge: 'DIRECT CASH DBT',
    badgeColor: 'emerald',
    summary: 'Direct income support program aimed at supplementing the financial needs of landholding farmers in procuring various inputs related to agriculture and allied activities as well as domestic needs.',
    keyBenefits: [
      'Guaranteed cash transfer directly into Aadhaar-seeded bank account',
      'Released three times a year (Period 1: Apr-Jul, Period 2: Aug-Nov, Period 3: Dec-Mar)',
      'Transparent tracking via PM-KISAN mobile app and e-KYC face recognition',
      'No middleman deduction; 100% funds transferred directly'
    ],
    documentsRequired: [
      'Aadhaar Card (mandatory e-KYC verified)',
      'Landholding Record showing ownership name',
      'Aadhaar-Seeded Bank Account Number & IFSC',
      'Active Mobile Number'
    ],
    officialPortal: 'https://pmkisan.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'midh-horticulture',
    name: 'Mission for Integrated Development of Horticulture (MIDH)',
    shortName: 'MIDH Polyhouse & Horticulture',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    category: 'infrastructure',
    categoryLabel: 'Post-Harvest & Polyhouse',
    subsidyPct: '50% Capital Subsidy for Polyhouses & Shade Nets; 40% for Orchards',
    subsidyMaxAmount: 'Up to ₹4,45,000 per 1,000 sq.m for naturally ventilated polyhouses',
    farmerShare: '50% self-finance or institutional term loan',
    badge: '50% POLYHOUSE GRANT',
    badgeColor: 'rose',
    summary: 'Holistic growth of the horticulture sector covering high-density fruit orchards, protected polyhouses, shade-net houses, plastic mulching, tissue culture plants, and mushroom spawn production.',
    keyBenefits: [
      '50% subsidy for naturally ventilated polyhouses (cost norm ₹890 - ₹1060 / sq.m)',
      '50% subsidy for shade-net houses, plastic tunnel mulch, and anti-hail/bird nets',
      'Year-round off-season vegetable (capsicum, tomato, cucumber) and exotic flower cultivation',
      '3x to 5x higher yield and premium export-grade produce quality'
    ],
    documentsRequired: [
      'Detailed Project Report (DPR) prepared by horticulturist',
      'Land Records (7/12, 8A, Patta) with minimum 10-year title proof',
      'Certified Irrigation Water Test and Soil Test Report',
      'Bank Sanction Letter for term loan portion',
      'Quotation from approved structural fabricator'
    ],
    officialPortal: 'https://midh.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'aif',
    name: 'Agriculture Infrastructure Fund (AIF)',
    shortName: 'AIF Post-Harvest Fund',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    category: 'infrastructure',
    categoryLabel: 'Post-Harvest & Polyhouse',
    subsidyPct: '3% Interest Subvention per annum up to ₹2 Crore for 7 Years',
    subsidyMaxAmount: 'Loans up to ₹2 Crore with CGTMSE Credit Guarantee Fee waived',
    farmerShare: 'Borrower pays base commercial rate minus 3.0% annual subvention',
    badge: '3% INTEREST SUBVENTION',
    badgeColor: 'indigo',
    summary: 'Financing facility for building post-harvest management infrastructure and community farming assets: cold storages, ripening chambers, sorting/grading packhouses, grain silos, and primary processing units.',
    keyBenefits: [
      '3% interest discount on bank loans up to ₹2 Crore for up to 7 years',
      'Credit guarantee coverage under CGTMSE without requiring third-party collateral',
      'Online single-window application process with fast-track bank approval',
      'Can be converged with other central capital subsidies (MIDH, PMKSY, MoFPI)'
    ],
    documentsRequired: [
      'Detailed Project Report (DPR) of post-harvest facility',
      'Land ownership papers or long-term registered lease deed (>10 years)',
      'KYC documents of applicant / FPO / PACS',
      'Proforma Invoices & Civil Construction estimates'
    ],
    officialPortal: 'https://agriinfra.dac.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'pkvy-organic',
    name: 'Paramparagat Krishi Vikas Yojana (PKVY) / Bhartiya Prakritik Krishi Paddhati',
    shortName: 'PKVY Organic Farming',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    category: 'soil_organic',
    categoryLabel: 'Organic & Soil Health',
    subsidyPct: '₹50,000 per Hectare over 3 Years (62% via direct DBT for inputs)',
    subsidyMaxAmount: '₹31,000 / hectare direct input assistance + ₹19,000 cluster certification',
    farmerShare: 'Farmer contributes labor and locally made bio-inputs (Jeevamrut, Beejamrut)',
    badge: 'ORGANIC INPUT GRANT',
    badgeColor: 'emerald',
    summary: 'Comprehensive program promoting certified organic and natural chemical-free farming in 20-hectare village clusters with Participatory Guarantee System (PGS-India) organic certification.',
    keyBenefits: [
      '₹31,000/ha credited directly via DBT for certified organic seeds, bio-fertilizers, vermicompost, and botanical extracts',
      'Free PGS-India Green and PGS-India Organic certification',
      'Financial aid for packaging, branding, and setting up organic farmers market kiosks',
      'Restores soil organic carbon, earthworm population, and microbiological vitality'
    ],
    documentsRequired: [
      'Aadhaar Card & Bank Account details',
      'Land Record (7/12, Patta)',
      'Village Cluster Membership application',
      'PGS-India Farmer Pledge for non-chemical cultivation'
    ],
    officialPortal: 'https://pgsindia-ncof.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'soil-health-card',
    name: 'Soil Health Card (SHC) & Micronutrient Assistance Scheme',
    shortName: 'Soil Health Card Scheme',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    category: 'soil_organic',
    categoryLabel: 'Organic & Soil Health',
    subsidyPct: '100% Free Soil Sampling & GPS Testing; 50% Subsidy on Soil Conditioners',
    subsidyMaxAmount: 'Free complete 12-parameter soil lab audit + ₹500/ha micronutrient kit',
    farmerShare: 'Zero for testing; 50% for subsidized gypsum/lime/zinc application',
    badge: '100% FREE TESTING',
    badgeColor: 'teal',
    summary: 'Provides comprehensive 12-parameter soil fertility cards (N, P, K, S, Zn, Fe, Cu, Mn, B, pH, EC, OC) along with customized dosage prescriptions to eliminate wasteful over-fertilization.',
    keyBenefits: [
      '100% free GPS-grid soil sampling every 2 years',
      'Prevents excessive urea dumping, cutting fertilizer bills by 15% to 25%',
      'Boosts fertilizer use efficiency and revives soil micro-ecology',
      'Subsidized supply of soil amendments (gypsum for sodic soil, agricultural lime for acidic soil)'
    ],
    documentsRequired: [
      'Land Record (7/12, Khatauni)',
      'Aadhaar Card & Mobile Number',
      'Geo-tagged farm coordinate location'
    ],
    officialPortal: 'https://soilhealth.dac.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'enwr-warehouse',
    name: 'e-NWR Subsidized Pledge Financing & Warehouse Receipt Scheme',
    shortName: 'e-NWR Mandi Pledge Loan',
    ministry: 'Warehousing Development and Regulatory Authority (WDRA)',
    category: 'credit',
    categoryLabel: 'Credit & Loans (KCC)',
    subsidyPct: 'Interest Subvention on Pledge Loans against e-NWRs',
    subsidyMaxAmount: 'Up to 75% of produce value at 7% subsidized interest rate for 6 months',
    farmerShare: 'Farmer repays loan upon selling produce at peak off-season mandi rates',
    badge: 'DISTRESS SALE PREVENTION',
    badgeColor: 'amber',
    summary: 'Prevents immediate harvest distress selling by allowing farmers to store produce in WDRA-accredited warehouses and receive an electronic Negotiable Warehouse Receipt (e-NWR) for instant bank pledge loans.',
    keyBenefits: [
      'Instant loan disbursement (70% - 75% of market value) directly to bank account within 24 hours',
      'Stored commodity insured against fire, flood, burglary, and pest infestation',
      'Avoids glut season price collapse, allowing farmer to sell 2-3 months later for 15%-25% higher returns',
      'Electronic transfer and trading of e-NWR on e-NAM digital exchange without moving physical bags'
    ],
    documentsRequired: [
      'e-NWR issued by WDRA-registered warehouse',
      'Aadhaar Card & PAN Card',
      'Bank Account Details',
      'Quality Assaying Certificate from warehouse'
    ],
    officialPortal: 'https://wdra.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'crm-stubble',
    name: 'Crop Residue Management (CRM) & Stubble Burning Prevention Scheme',
    shortName: 'CRM Stubble Machinery',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    category: 'machinery',
    categoryLabel: 'Farm Machinery & Drones',
    subsidyPct: '50% Subsidy for Individuals; 80% for Cooperatives / FPOs',
    subsidyMaxAmount: 'Up to ₹1,50,000 for Super Seeder; up to ₹12 Lakhs for CHC Machinery Banks',
    farmerShare: '50% for individual farmer; 20% for village panchayats and cooperatives',
    badge: 'CLEAN AIR & IN-SITU MULCH',
    badgeColor: 'green',
    summary: 'Promotes in-situ and ex-situ management of crop straw (paddy stubble, cotton stalks, sugarcane trash) using specialized implements like Happy Seeder, Super Seeder, Straw Chopper, and Baler.',
    keyBenefits: [
      '50% capital subsidy on Super Seeders and Zero-Till seed drills',
      'Eliminates stubble burning penalties and preserves soil organic carbon and friendly soil microbes',
      'Direct wheat sowing in standing paddy stubble without prior field plowing, saving ₹2,500/acre in diesel',
      'Retains soil moisture and suppresses weeds naturally through in-situ straw mulch'
    ],
    documentsRequired: [
      'Aadhaar Card & Mobile Number',
      'Land Records (Jamabandi / Fard / Patta)',
      'Bank Passbook Copy',
      'Quotation from approved agricultural machinery manufacturer'
    ],
    officialPortal: 'https://agrimachinery.nic.in',
    isStateSpecific: false,
    statesApplicable: 'Punjab, Haryana, UP, Rajasthan, MP, Maharashtra'
  },
  {
    id: 'nlm-livestock',
    name: 'National Livestock Mission (NLM) — Breed Development & Silage',
    shortName: 'NLM Livestock & Fodder',
    ministry: 'Ministry of Fisheries, Animal Husbandry and Dairying, Govt of India',
    category: 'allied',
    categoryLabel: 'Allied & Livestock',
    subsidyPct: '50% Capital Subsidy up to ₹50 Lakhs',
    subsidyMaxAmount: 'Up to ₹25 Lakhs (Sheep/Goat), ₹30 Lakhs (Poultry), ₹50 Lakhs (Fodder & Silage)',
    farmerShare: '50% self-financing or bank loan',
    badge: '50% CAPITAL SUBSIDY',
    badgeColor: 'orange',
    summary: 'Financial assistance for establishing rural sheep, goat, and poultry parent breeding farms, fodder seed production, and silage manufacturing units for integrated farm resilience.',
    keyBenefits: [
      '50% back-ended capital subsidy deposited into bank escrow account',
      'Generates regular daily and weekly farm cash flow balancing seasonal crop vulnerability',
      'High-yielding certified parent stock supplied from ICAR and State Veterinary Universities',
      'Supports green fodder silage baling units preserving feed for dry summer months'
    ],
    documentsRequired: [
      'Bank Sanction Letter for 50% project cost',
      'Detailed Project Report (DPR) vetted by veterinary officer',
      'Land Proof (minimum 1 to 2 acres owned or 10-year leased)',
      'Training Certificate in animal husbandry or poultry'
    ],
    officialPortal: 'https://nlm.udyamimitra.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'pmmsy-fisheries',
    name: 'Pradhan Mantri Matsya Sampada Yojana (PMMSY)',
    shortName: 'PMMSY Fish Ponds',
    ministry: 'Ministry of Fisheries, Animal Husbandry and Dairying, Govt of India',
    category: 'allied',
    categoryLabel: 'Allied & Livestock',
    subsidyPct: '40% Subsidy for General; 60% for SC/ST/Women Beneficiaries',
    subsidyMaxAmount: 'Up to ₹4,20,000 / hectare for new pond construction; ₹7,50,000 for Biofloc units',
    farmerShare: '40% to 60% (bank loan assisted)',
    badge: '60% FARM POND GRANT',
    badgeColor: 'sky',
    summary: 'Flagship scheme for sustainable fisheries development covering construction of new farm aquaculture ponds, Biofloc systems, recirculating aquaculture systems (RAS), and solar aerators.',
    keyBenefits: [
      'Dual-benefit farm pond (Shet Tale): harvests rainwater for field irrigation while raising profitable fish crops (Rohu, Katla, Tilapia)',
      '60% subsidy for SC/ST and women farmers; 40% for general farmers',
      'Generates additional ₹1.5 to ₹3.0 Lakh/year profit per acre of water area',
      'Subsidized input support (fish seed fingerlings, pelleted floating feed) for the first year'
    ],
    documentsRequired: [
      'Land Record (7/12, RoR, Patta) with pond demarcation',
      'Soil and Water Suitability Report',
      'Aadhaar Card & Caste Certificate (for 60% subsidy)',
      'Technical Project Plan approved by District Fisheries Officer'
    ],
    officialPortal: 'https://pmmsy.dof.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'mahadbt-krishi',
    name: 'MahaDBT Krishi Yojana & Magel Tyala Shet Tale (Maharashtra)',
    shortName: 'MahaDBT Farmer Schemes',
    ministry: 'Department of Agriculture, Government of Maharashtra',
    category: 'irrigation',
    categoryLabel: 'Water & Irrigation',
    subsidyPct: 'Up to 75% to 80% Subsidy (Combined PMKSY + State Top-up); 100% for SC/ST',
    subsidyMaxAmount: 'Up to ₹75,000 for Farm Pond (Shet Tale); ₹2,50,000 for New Dug Well',
    farmerShare: '15% to 25% for general category; 0% for Dr. Babasaheb Ambedkar Krishi Swavalamban',
    badge: 'STATE FLAGSHIP TOP-UP',
    badgeColor: 'emerald',
    summary: 'Comprehensive online single-window portal in Maharashtra offering composite subsidies for farm ponds (Shet Tale with plastic lining), new dug wells, in-well bore, micro-irrigation, and horticulture plantations.',
    keyBenefits: [
      '75% to 80% combined subsidy for drip & sprinkler systems (State top-up over Central PMKSY)',
      '₹50,000 to ₹75,000 direct grant for farm pond construction under Magel Tyala Shet Tale',
      '100% subsidy on new dug wells, electric pumps, and drip sets for SC/ST farmers under Dr. Babasaheb Ambedkar Krishi Swavalamban Yojana',
      'Paperless online lottery allotment with transparent SMS status notifications'
    ],
    documentsRequired: [
      'MahaDBT User Registration with Aadhaar biometric / OTP',
      '7/12 Extract with Digital Signature & 8-A Holding Sheet',
      'Caste Certificate (if applicable)',
      'Bank Passbook linked to Aadhaar',
      'Self-Declaration of not availing same benefit in last 7 years'
    ],
    officialPortal: 'https://mahadbt.maharashtra.gov.in',
    isStateSpecific: true,
    statesApplicable: 'Maharashtra'
  },
  {
    id: 'rkvy-raftaar',
    name: 'Rashtriya Krishi Vikas Yojana (RKVY-RAFTAAR) Agri-Startup Grants',
    shortName: 'RKVY-RAFTAAR Innovation',
    ministry: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    category: 'infrastructure',
    categoryLabel: 'Post-Harvest & Polyhouse',
    subsidyPct: '85% to 90% Grant-in-Aid for Agri-Entrepreneurs & FPO Value Addition',
    subsidyMaxAmount: 'Up to ₹5,00,000 (Idea/Pre-Seed Stage); Up to ₹25,00,000 (Seed/Prototype Stage)',
    farmerShare: '10% to 15% matching contribution',
    badge: '₹25 LAKH INNOVATION GRANT',
    badgeColor: 'violet',
    summary: 'Empowers farmer innovators, rural youth, and Farmer Producer Organizations to scale farm-gate food processing, direct-to-consumer marketing, organic branding, and IoT agricultural technology.',
    keyBenefits: [
      'Non-repayable 85% grant funding up to ₹25 Lakhs',
      'Incubation and technical mentorship at prestigious ICAR and State Agricultural Universities (SAUs)',
      'Funds primary processing, grading, cold chain, and mobile app marketplace development',
      'Enables farmers to transition from raw commodity producers to value-added branded food sellers'
    ],
    documentsRequired: [
      'Detailed Business Pitch Deck and Product Video',
      'Registration Certificate of Entity (FPO, LLP, Pvt Ltd, or Registered Partnership)',
      'Aadhaar & PAN of Founders / Farmer Directors',
      'Audited Financial Statements or Bank Account Statement'
    ],
    officialPortal: 'https://rkvy.nic.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  },
  {
    id: 'enam-modernization',
    name: 'e-NAM (National Agriculture Market) Digital Mandi Scheme',
    shortName: 'e-NAM Digital Trade',
    ministry: 'Ministry of Agriculture & Farmers Welfare & SFAC',
    category: 'credit',
    categoryLabel: 'Credit & Loans (KCC)',
    subsidyPct: '100% Free Digital Platform Access + Quality Assaying Subsidy',
    subsidyMaxAmount: '₹75 Lakhs grant per APMC mandi; ₹0 transaction fee for registered farmers',
    farmerShare: 'Zero transaction fee; free quality assaying and live online e-bidding',
    badge: 'PAN-INDIA MANDI ACCESS',
    badgeColor: 'sky',
    summary: 'Pan-India electronic trading portal networking existing APMC mandis to create a unified national market for agricultural commodities with transparent price discovery and online payments.',
    keyBenefits: [
      'Direct access to buyers across multiple states without local mandi cartel collusion',
      'Transparent digital electronic weighing and automated electronic assaying (NPK/Moisture/Grade)',
      'Real-time online bidding visible on farmer mobile phone',
      'Instant online payment credited directly into farmer bank account within 24 hours'
    ],
    documentsRequired: [
      'e-NAM Farmer Registration',
      'Aadhaar Card',
      'Bank Account Details & IFSC Code',
      'Lot Entry Slip generated at APMC Mandi gate'
    ],
    officialPortal: 'https://enam.gov.in',
    isStateSpecific: false,
    statesApplicable: 'All India'
  }
];

/**
 * Calculates a dynamic eligibility and recommendation match score for a given farm and scheme
 * @param {Object} scheme 
 * @param {Object} farm 
 * @returns {{ matchScore: number, matchReason: string, isHighlyRecommended: boolean }}
 */
function evaluateFarmSchemeEligibility(scheme, farm) {
  if (!farm || farm.id === 'unregistered') {
    return {
      matchScore: 80,
      matchReason: 'Standard eligibility criteria applicable upon farm registration',
      isHighlyRecommended: false
    };
  }

  let matchScore = 70;
  let reasons = [];

  const acres = Number(farm.sizeAcres) || 5;
  const isSmallMarginal = acres <= 5;
  const crop = (farm.currentCrop || '').toLowerCase();
  const irrigation = (farm.irrigationType || '').toLowerCase();
  const location = (farm.location || '').toLowerCase();
  const soil = farm.soil || {};

  // Acreage-based matching
  if (isSmallMarginal) {
    if (['pmksy-pdmc', 'smam-mechanization', 'kisan-drone', 'pm-kisan'].includes(scheme.id)) {
      matchScore += 20;
      reasons.push(`Small/Marginal landholding (${acres} Acres) qualifies for maximum 55% subsidy rate`);
    }
  }

  // Irrigation-based matching
  if (irrigation.includes('borewell') || irrigation.includes('well')) {
    if (scheme.id === 'pm-kusum') {
      matchScore += 28;
      reasons.push('Verified borewell/well source qualifies for 60% Solar Pump subsidy');
    }
  }
  if (irrigation.includes('drip') || irrigation.includes('sprinkler')) {
    if (scheme.id === 'pmksy-pdmc') {
      matchScore += 25;
      reasons.push('Micro-irrigation configuration qualifies for PDMC drip equipment rebate');
    }
  }

  // Crop-based matching
  if (crop.includes('wheat') || crop.includes('rice') || crop.includes('paddy') || crop.includes('soybean') || crop.includes('cotton')) {
    if (scheme.id === 'pmfby') {
      matchScore += 26;
      reasons.push(`${farm.currentCrop} is a notified crop eligible for 1.5% - 2% low premium insurance`);
    }
  }
  if (crop.includes('tomato') || crop.includes('chilli') || crop.includes('grape') || crop.includes('vegetable') || crop.includes('fruit')) {
    if (scheme.id === 'midh-horticulture') {
      matchScore += 25;
      reasons.push(`${farm.currentCrop} horticulture cultivation qualifies for 50% polyhouse/mulch grant`);
    }
  }

  // Soil health matching
  if (soil && (soil.nitrogen < 200 || soil.organicCarbon < 0.6)) {
    if (scheme.id === 'pkvy-organic' || scheme.id === 'soil-health-card') {
      matchScore += 22;
      reasons.push('Soil test indicates nutrient deficiency - eligible for organic bio-input & testing assistance');
    }
  }

  // Location/State matching
  if (location.includes('maharashtra') || location.includes('pune') || location.includes('nashik') || location.includes('solapur') || location.includes('baramati')) {
    if (scheme.id === 'mahadbt-krishi') {
      matchScore += 28;
      reasons.push('Maharashtra plot qualifies for MahaDBT Magel Tyala Shet Tale & state top-up subsidy');
    }
  }

  // Clamp score between 60 and 99
  matchScore = Math.min(Math.max(matchScore, 65), 99);
  const matchReason = reasons.length > 0 ? reasons.join(' • ') : 'Standard eligibility for registered agricultural landholders';

  return {
    matchScore,
    matchReason,
    isHighlyRecommended: matchScore >= 88
  };
}

/**
 * Calculators for equipment subsidies
 */
const SUBSIDY_CALCULATOR_PRESETS = exports.SUBSIDY_CALCULATOR_PRESETS = [
  {
    id: 'drip-system',
    name: 'Drip Irrigation System (Micro-Irrigation)',
    category: 'irrigation',
    schemeName: 'Per Drop More Crop (PDMC)',
    baseCostPerAcre: 52000,
    unitLabel: 'Acres',
    defaultUnits: 2.5,
    maxUnits: 12,
    subsidyPctSmall: 55,
    subsidyPctGeneral: 45,
    subsidyCap: 150000,
    description: 'Lateral drip lines, disc filters, venturi injector, pressure regulator, and installation.'
  },
  {
    id: 'solar-pump-5hp',
    name: '5HP Standalone Solar Agriculture Pump (DC/AC)',
    category: 'solar',
    schemeName: 'PM-KUSUM Component-B',
    baseCostPerAcre: 245000, // Fixed unit cost
    unitLabel: 'Solar Pump System (5HP)',
    isFixedUnit: true,
    defaultUnits: 1,
    maxUnits: 2,
    subsidyPctSmall: 60,
    subsidyPctGeneral: 60,
    subsidyCap: 150000,
    description: '5HP submersible solar pump, 4.8kWp solar PV panels, galvanized mounting structure, and controller.'
  },
  {
    id: 'farm-machinery-rotavator',
    name: 'Rotavator / Tractor Tillage Implement',
    category: 'machinery',
    schemeName: 'SMAM Sub-Mission on Agricultural Mechanization',
    baseCostPerAcre: 120000,
    unitLabel: 'Implement Unit',
    isFixedUnit: true,
    defaultUnits: 1,
    maxUnits: 2,
    subsidyPctSmall: 50,
    subsidyPctGeneral: 40,
    subsidyCap: 60000,
    description: '7-foot heavy-duty tractor rotavator with multi-speed gearbox and hardened boron steel blades.'
  },
  {
    id: 'kisan-drone-16l',
    name: 'Precision Agricultural Spray Drone (16-Liter)',
    category: 'machinery',
    schemeName: 'Kisan Drone & NaMo Drone Didi Initiative',
    baseCostPerAcre: 650000,
    unitLabel: 'Drone Unit',
    isFixedUnit: true,
    defaultUnits: 1,
    maxUnits: 1,
    subsidyPctSmall: 50,
    subsidyPctGeneral: 40,
    subsidyCap: 325000,
    description: 'DGCA type-certified agricultural hexacopter, terrain-following radar, RTK GPS, and 4 smart spray nozzles.'
  },
  {
    id: 'polyhouse-1000sqm',
    name: 'Naturally Ventilated Polyhouse (1,000 sq. meters)',
    category: 'infrastructure',
    schemeName: 'MIDH National Horticulture Mission',
    baseCostPerAcre: 920000,
    unitLabel: 'Polyhouse (1,000 m²)',
    isFixedUnit: true,
    defaultUnits: 1,
    maxUnits: 4,
    subsidyPctSmall: 50,
    subsidyPctGeneral: 50,
    subsidyCap: 460000,
    description: 'GI pipe tubular frame, 200-micron UV-stabilized anti-fog polyethylene film, side insect nets, and micro-sprinklers.'
  }
];

function calculateSubsidyEstimate({ presetId, units = 1, isSmallFarmer = true, isWomenOrSCST = false }) {
  const preset = SUBSIDY_CALCULATOR_PRESETS.find(p => p.id === presetId) || SUBSIDY_CALCULATOR_PRESETS[0];
  const numUnits = Number(units) || 1;
  const totalGrossCost = preset.isFixedUnit ? preset.baseCostPerAcre * numUnits : preset.baseCostPerAcre * numUnits;

  let effectiveRate = isSmallFarmer ? preset.subsidyPctSmall : preset.subsidyPctGeneral;
  if (isWomenOrSCST && effectiveRate < 55) {
    effectiveRate = 50; // Special priority rate
  }

  const rawSubsidy = (totalGrossCost * effectiveRate) / 100;
  const cappedSubsidy = preset.subsidyCap ? Math.min(rawSubsidy, preset.subsidyCap * numUnits) : rawSubsidy;
  const farmerOutOfePocket = totalGrossCost - cappedSubsidy;

  // Typical bank loan component (up to 70% of farmer out of pocket or 30% of total)
  const bankLoanAssistance = Math.round(totalGrossCost * 0.30);
  const netCashMargin = Math.max(0, farmerOutOfePocket - bankLoanAssistance);

  return {
    preset,
    units: numUnits,
    totalGrossCost: Math.round(totalGrossCost),
    subsidyRatePct: effectiveRate,
    subsidyAmount: Math.round(cappedSubsidy),
    bankLoanAmount: bankLoanAssistance,
    netFarmerShare: Math.round(farmerOutOfePocket),
    cashMarginRequired: netCashMargin
  };
}

/* Module Exports */
exports.evaluateFarmSchemeEligibility = evaluateFarmSchemeEligibility; exports.calculateSubsidyEstimate = calculateSubsidyEstimate;
