// AgroSense Horticultural & Fruit Crops Pathology Database
// Covers major orchard and plantation fruit crops: Banana, Mango, Apple, Grapes, Citrus, Pomegranate, Papaya, Guava

const fruitCropsList = exports.fruitCropsList = [
  {
    id: "fruit-01",
    cropKey: "banana",
    name: "Banana (केला / केळी)",
    category: "Fruits & Horticulture",
    icon: "🍌",
    commonName: "Banana",
    keyPests: "Black Sigatoka, Panama Wilt TR4, Banana Aphid",
    agronomicTip: "Desucker promptly leaving only 1 follower sucker per mother plant for optimal bunch filling."
  },
  {
    id: "fruit-02",
    cropKey: "mango",
    name: "Mango (आम / आंबा)",
    category: "Fruits & Horticulture",
    icon: "🥭",
    commonName: "Mango",
    keyPests: "Anthracnose, Powdery Mildew, Mango Hopper",
    agronomicTip: "Spray Paclobutrazol (Cultar) in collar basin during Sept-Oct to promote profuse flowering."
  },
  {
    id: "fruit-03",
    cropKey: "apple",
    name: "Apple (सेब / सफरचंद)",
    category: "Fruits & Horticulture",
    icon: "🍎",
    commonName: "Apple",
    keyPests: "Apple Scab, Powdery Mildew, San Jose Scale",
    agronomicTip: "Ensure 800-1100 chilling hours below 7°C for uniform bud break and fruit set."
  },
  {
    id: "fruit-04",
    cropKey: "grapes",
    name: "Grapes (अंगूर / द्राक्षे)",
    category: "Fruits & Horticulture",
    icon: "🍇",
    commonName: "Grapes",
    keyPests: "Downy Mildew, Powdery Mildew, Thrips",
    agronomicTip: "Perform scientific April back pruning and October forward pruning for quality bunch architecture."
  },
  {
    id: "fruit-05",
    cropKey: "citrus",
    name: "Citrus / Lemon / Orange (संतरा / नीबू / लिंबू)",
    category: "Fruits & Horticulture",
    icon: "🍋",
    commonName: "Citrus / Lemon",
    keyPests: "Citrus Canker, Citrus Greening (HLB), Leaf Miner",
    agronomicTip: "Provide Hasta bahar water-stress treatment in Oct-Nov to synchronize flowering."
  },
  {
    id: "fruit-06",
    cropKey: "pomegranate",
    name: "Pomegranate (अनार / डाळिंब)",
    category: "Fruits & Horticulture",
    icon: "🫐",
    commonName: "Pomegranate",
    keyPests: "Bacterial Blight (Telya), Anthracnose, Fruit Borer",
    agronomicTip: "Adopt Ambe Bahar flowering cycle and maintain strict orchard copper sanitation."
  },
  {
    id: "fruit-07",
    cropKey: "papaya",
    name: "Papaya (पपीता / पपई)",
    category: "Fruits & Horticulture",
    icon: "🍈",
    commonName: "Papaya",
    keyPests: "Papaya Ring Spot Virus (PRSV), Anthracnose, Mealybug",
    agronomicTip: "Plant ring-spot resistant hybrid varieties (Red Lady 786) with silver reflective mulch."
  },
  {
    id: "fruit-08",
    cropKey: "guava",
    name: "Guava (अमरूद / पेरू)",
    category: "Fruits & Horticulture",
    icon: "🍐",
    commonName: "Guava",
    keyPests: "Guava Wilt, Anthracnose, Fruit Fly",
    agronomicTip: "Follow meadow orchard system (1m x 2m) with canopy topping for heavy winter (Mrig) harvest."
  }
];

const fruitDiseases = exports.fruitDiseases = [
  // 1. BANANA DISEASES
  {
    id: "banana-sigatoka",
    crop: "Banana (केला / केळी)",
    cropKey: "banana",
    diseaseName: "Banana Sigatoka Leaf Spot (Pseudocercospora musae / fijiensis)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.50, necrotic: 0.28, chlorosis: 0.18, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Small pale yellow or brown linear streaks developing parallel to leaf veins",
      "Streaks enlarge into dark brown-black elliptical lesions with sunken greyish-white centers and yellow chlorotic halos",
      "Extensive leaf necrosis and premature leaf death reducing bunch size and causing pre-mature fruit ripening"
    ],
    whyThisHappens: {
      pathogenCause: "Pseudocercospora musae (Yellow Sigatoka) and Pseudocercospora fijiensis (Black Sigatoka), airborne ascospores and rain-splashed conidia penetrating stomata.",
      weatherTriggers: "High relative humidity (>85%), temperatures 24°C - 30°C, and prolonged leaf surface moisture exceeding 6 hours.",
      transmissionMode: "Airborne ascospores carried over long distances; conidia spread through rain splash within canopy.",
      riskFactors: "Poor field drainage, high density planting without de-suckering, overhead irrigation."
    },
    culturalMeasures: [
      "Regular de-leafing: cut and destroy severely infected leaves showing >50% necrotic spot area.",
      "Maintain wider spacing (2.1m x 2.1m) and prune suckers to improve sunlight penetration and air movement.",
      "Ensure proper ditch drainage to prevent waterlogging around root zone."
    ],
    biologicalControl: [
      "Foliar spray of Trichoderma harzianum (1% WP) @ 5g/L water mixed with 1 ml agricultural adjuvant.",
      "Spray mineral oil (Banole / horticultural oil) @ 10 ml/L to inhibit ascospore penetration."
    ],
    chemicalControl: [
      {
        chemical: "Propiconazole 25% EC (Tilt)",
        dosage: "1.0 ml / Liter of water",
        timing: "Apply at the onset of rainy season; alternate with mineral oil emulsion every 20 days."
      },
      {
        chemical: "Mancozeb 75% WP + Mineral Oil",
        dosage: "2.5 g / Liter water + 10 ml oil/L",
        timing: "Protective contact spray during high spore shower intervals."
      }
    ],
    preventiveCare: [
      "Plant certified tissue culture plantlets of resistant varieties (Grand Naine).",
      "Avoid excess nitrogen fertilizer that produces soft, easily penetrable leaf tissue."
    ],
    kvkHelpline: "ICAR National Research Centre for Banana (NRCB) Trichy Helpline: 1800-180-1551."
  },
  {
    id: "banana-panama-wilt",
    crop: "Banana (केला / केळी)",
    cropKey: "banana",
    diseaseName: "Banana Panama Wilt / Fusarium Wilt (Fusarium oxysporum f. sp. cubense)",
    pathogenType: "Fungal Vascular Pathogen",
    targetBiomarkers: { green: 0.38, necrotic: 0.22, chlorosis: 0.38, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Distinct yellowing of lower older leaf margins progressing inward toward the midrib",
      "Buckling of leaf petioles at pseudostem junction causing leaves to collapse in a skirt around stem",
      "Longitudinal splitting of the base of the pseudostem",
      "Discoloration of vascular strands (reddish-brown to black streaks) visible inside pseudostem"
    ],
    whyThisHappens: {
      pathogenCause: "Fusarium oxysporum f. sp. cubense (Race 1 and Tropical Race 4), a soil-borne vascular wilt fungus producing resilient chlamydospores that persist in soil for decades.",
      weatherTriggers: "Warm soil temperatures (25°C - 32°C) combined with soil moisture fluctuations.",
      transmissionMode: "Infected rhizome suckers, farm tools, flood irrigation water flowing between fields.",
      riskFactors: "Planting uncertified farmer-saved suckers, acid soils (pH < 6.0), root-knot nematode damage."
    },
    culturalMeasures: [
      "Immediately uproot and incinerate infected banana mats; drench the planting pit with lime.",
      "Maintain strict biosecurity: disinfect digging tools with 5% sodium hypochlorite.",
      "Switch to drip irrigation to prevent spore washdown along furrow channels."
    ],
    biologicalControl: [
      "Root dip and soil application of Pseudomonas fluorescens @ 10g/sucker + Trichoderma viride enriched in FYM @ 5 kg/pit.",
      "Apply bio-consortium (ICAR-FUSICONT) developed specifically for Fusarium TR4 bio-suppression."
    ],
    chemicalControl: [
      {
        chemical: "Carbendazim 50% WP (Bavistin)",
        dosage: "2.0 g / Liter of water",
        timing: "Pseudostem injection @ 2 ml of 2% solution + root zone drenching @ 3 Liters / plant."
      }
    ],
    preventiveCare: [
      "Strictly plant certified pathogen-free tissue-cultured plantlets.",
      "Rotate with sugarcane or paddy (submerged anaerobic rotation) for 2 years to starve chlamydospores."
    ],
    kvkHelpline: "Emergency Panama Wilt TR4 ICAR Task Force Helpline: 1800-180-1551."
  },
  {
    id: "banana-healthy",
    crop: "Banana (केला / केळी)",
    cropKey: "banana",
    diseaseName: "Banana Healthy Canopy (Nominal Baseline)",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.96, necrotic: 0.01, chlorosis: 0.03, powdery: 0, rust: 0 },
    symptoms: [
      "Massive vibrant emerald green paddle blades with unbroken cellular margins",
      "Strong erect petiole attachment to pseudostem with zero vascular discoloration",
      "Intact cuticular wax sheen providing natural biotic and abiotic stress resistance"
    ],
    whyThisHappens: {
      pathogenCause: "Pathogen-free certified tissue culture stock, robust root system, and balanced nutrition.",
      weatherTriggers: "Tropical warm sunny days (24°C - 32°C), adequate soil moisture, and good air circulation.",
      transmissionMode: "None. Maintain clean sucker management and organic mulching.",
      riskFactors: "Monitor for early Sigatoka streaks during monsoon spells."
    },
    culturalMeasures: [
      "Regular de-suckering leaving only 1 strong follower per mother plant.",
      "Apply 2 inches of dried sugarcane trash or banana foliage mulch."
    ],
    biologicalControl: [
      "Prophylactic foliar spray of Neem oil (10,000 ppm) @ 2 ml/L at monthly intervals."
    ],
    chemicalControl: [],
    preventiveCare: [
      "Balanced NPK fertilization (200g N, 60g P, 300g K per plant per year in split doses)."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  },

  // 2. MANGO DISEASES
  {
    id: "mango-anthracnose",
    crop: "Mango (आम / आंबा)",
    cropKey: "mango",
    diseaseName: "Mango Anthracnose & Blossom Blight (Colletotrichum gloeosporioides)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.52, necrotic: 0.32, chlorosis: 0.12, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Small dark brown to black circular lesions on young leaves which coalesce into irregular necrotic patches",
      "Infected leaves develop shot-holes as necrotic centers drop out in wind",
      "Blossom blight: black spots on flower panicles causing blossom drop and complete fruit failure",
      "Tear-stain dark streaks on developing and ripening mango fruits"
    ],
    whyThisHappens: {
      pathogenCause: "Colletotrichum gloeosporioides (Glomerella cingulata), surviving in infected twigs and old mummified fruits.",
      weatherTriggers: "Warm temperatures (25°C - 30°C) with persistent rains, heavy morning dews, and relative humidity >90%.",
      transmissionMode: "Water-splashed conidia from overhead canopies onto emerging tender leaf flushes and flowers.",
      riskFactors: "Dense unpruned orchard canopies, overlapping branches, cloudy wet flowering season."
    },
    culturalMeasures: [
      "Annual post-harvest pruning of diseased twigs, dead wood, and criss-cross branches in August-September.",
      "Collect and incinerate all fallen blighted leaves, flower panicles, and mummified fruits.",
      "Spray 1% Bordeaux mixture immediately after post-harvest pruning."
    ],
    biologicalControl: [
      "Foliar spray with Bacillus subtilis @ 5g/L or Trichoderma viride @ 5g/L before flowering."
    ],
    chemicalControl: [
      {
        chemical: "Copper Oxychloride 50% WP (Blitox)",
        dosage: "3.0 g / Liter of water",
        timing: "Protective spray at vegetative flush and early panicle emergence."
      },
      {
        chemical: "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        dosage: "1.0 ml / Liter of water",
        timing: "Systemic curative spray at pea-stage fruit development."
      }
    ],
    preventiveCare: [
      "Avoid overhead sprinkler irrigation in mango orchards.",
      "Dip harvested fruits in warm water (52°C for 5 minutes) to prevent post-harvest anthracnose rot."
    ],
    kvkHelpline: "ICAR Central Institute for Subtropical Horticulture (CISH) Lucknow: 1800-180-1551."
  },
  {
    id: "mango-powdery-mildew",
    crop: "Mango (आम / आंबा)",
    cropKey: "mango",
    diseaseName: "Mango Powdery Mildew (Oidium mangiferae)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.54, necrotic: 0.08, chlorosis: 0.12, powdery: 0.24, rust: 0.02 },
    symptoms: [
      "White superficial powdery fungal coating on tender leaves, flower panicles, and young fruitlets",
      "Infected leaves curl, distort, and drop prematurely",
      "Infested flower panicles dry out, turn purplish-brown, and shed blossoms before fruit set"
    ],
    whyThisHappens: {
      pathogenCause: "Oidium mangiferae, an obligate biotrophic fungus producing dry airborne conidia.",
      weatherTriggers: "Warm days (22°C - 28°C) paired with cool, humid nights (80% RH) during Feb-March flowering.",
      transmissionMode: "Airborne conidia carried by gentle breezes through the orchard canopy.",
      riskFactors: "Shaded dense orchard canopies, cloudy winter days during panicle emergence."
    },
    culturalMeasures: [
      "Open center pruning to allow maximum sunlight into interior branches.",
      "Prune and destroy mildew-infected lower panicles and shoot tips."
    ],
    biologicalControl: [
      "Spray Ampelomyces quisqualis (hyperparasite) @ 5g/L water."
    ],
    chemicalControl: [
      {
        chemical: "Wettable Sulphur 80% WP (Sulfex)",
        dosage: "2.5 - 3.0 g / Liter of water",
        timing: "First prophylactic spray when flower panicles are 3-5 inches long."
      },
      {
        chemical: "Hexaconazole 5% SC (Contaf)",
        dosage: "1.0 ml / Liter of water",
        timing: "Curative systemic spray at full bloom if white mildew appears."
      }
    ],
    preventiveCare: [
      "Do not apply sulphur sprays when ambient temperature exceeds 35°C (causes sulfur burn)."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  },
  {
    id: "mango-healthy",
    crop: "Mango (आम / आंबा)",
    cropKey: "mango",
    diseaseName: "Mango Healthy Canopy (Nominal Baseline)",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.95, necrotic: 0.02, chlorosis: 0.03, powdery: 0, rust: 0 },
    symptoms: [
      "Lush dark green leathery lanceolate leaves with glossy upper surface",
      "Intact foliar cuticular sheen with prominent pale yellow veins and zero necrotic spots",
      "Vigorous shoots and healthy reproductive panicle architecture"
    ],
    whyThisHappens: {
      pathogenCause: "Well-nourished orchard with balanced potassium and organic soil biology.",
      weatherTriggers: "Optimal subtropical climate with clear sunshine and disciplined seasonal pruning.",
      transmissionMode: "None.",
      riskFactors: "Maintain preventive vigilance during spring flowering."
    },
    culturalMeasures: [
      "Annual canopy center opening and ring basin irrigation."
    ],
    biologicalControl: [
      "Spray cold-pressed Neem oil (10,000 ppm) @ 2.5 ml/L during dormant winter flush."
    ],
    chemicalControl: [],
    preventiveCare: [
      "Apply micronutrient foliar spray (Zinc, Boron, Copper) @ 2g/L prior to flowering."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  },

  // 3. APPLE DISEASES
  {
    id: "apple-scab",
    crop: "Apple (सेब / सफरचंद)",
    cropKey: "apple",
    diseaseName: "Apple Scab (Venturia inaequalis)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.50, necrotic: 0.34, chlorosis: 0.12, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Olive-green to dull velvety black circular spots on upper surface of leaves",
      "Lesions become corky, raised, and scab-like as leaf matures, causing puckering and distortion",
      "Similar dark scab lesions on apple fruit skin leading to fruit cracking and malformation"
    ],
    whyThisHappens: {
      pathogenCause: "Venturia inaequalis (anamorph Spilocaea pomi), overwintering inside fallen dead leaves on orchard floor.",
      weatherTriggers: "Cool temperatures (15°C - 20°C) with persistent wetness from spring rains or heavy fog lasting >9 hours.",
      transmissionMode: "Primary ascospores shoot into air currents from pseudothecia in floor leaf litter; conidia splash during rains.",
      riskFactors: "Leaving un-composted fallen leaves on orchard floor, susceptible cultivars (Delicious group)."
    },
    culturalMeasures: [
      "Post-harvest orchard floor spray of 5% Urea solution in autumn to speed leaf litter breakdown.",
      "Prune apple trees into open modified central leader structure for fast leaf drying."
    ],
    biologicalControl: [
      "Foliar spray of Trichoderma harzianum @ 5g/L during green tip bud break."
    ],
    chemicalControl: [
      {
        chemical: "Mancozeb 75% WP",
        dosage: "2.5 g / Liter of water",
        timing: "Protective spray at silver tip to green tip stage."
      },
      {
        chemical: "Difenoconazole 25% EC (Score)",
        dosage: "0.5 ml / Liter of water",
        timing: "Curative kickback spray applied within 72 hours of rain infection period."
      }
    ],
    preventiveCare: [
      "Plant scab-resistant cultivars (e.g. Co-op 29, Prima, Priscilla, Florina).",
      "Monitor Mills Scab Infection Periods based on temperature and hours of leaf wetness."
    ],
    kvkHelpline: "ICAR Central Institute of Temperate Horticulture (CITH) Srinagar: 1800-180-1551."
  },
  {
    id: "apple-healthy",
    crop: "Apple (सेब / सफरचंद)",
    cropKey: "apple",
    diseaseName: "Apple Healthy Canopy (Nominal Baseline)",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.95, necrotic: 0.02, chlorosis: 0.03, powdery: 0, rust: 0 },
    symptoms: [
      "Glossy dark green ovate serrated leaves with clean white-pubescent lower surface",
      "Smooth uninterrupted leaf margins with zero olive scabs or rust spots",
      "Strong spur development and high spur-to-leaf ratio for optimal fruit load"
    ],
    whyThisHappens: {
      pathogenCause: "Pathogen-free certified rootstock (M9/MM106) with good orchard sanitary regime.",
      weatherTriggers: "Moderate temperate climate with ample winter chilling and sunny summer canopy.",
      transmissionMode: "None.",
      riskFactors: "Scout weekly for scab spores during spring bud break."
    },
    culturalMeasures: [
      "Maintain clean floor with regular grass mowing and mulching around tree basins."
    ],
    biologicalControl: [
      "Neem seed kernel extract (NSKE 5%) prophylactic spray after petal fall."
    ],
    chemicalControl: [],
    preventiveCare: [
      "Balanced annual application of compost, rock phosphate, and muriate of potash."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  },

  // 4. GRAPES DISEASES
  {
    id: "grapes-downy-mildew",
    crop: "Grapes (अंगूर / द्राक्षे)",
    cropKey: "grapes",
    diseaseName: "Grape Downy Mildew (Plasmopara viticola)",
    pathogenType: "Oomycete Pathogen",
    targetBiomarkers: { green: 0.48, necrotic: 0.28, chlorosis: 0.16, powdery: 0.06, rust: 0.02 },
    symptoms: [
      "Characteristic translucent 'oil spots' (pale yellow chlorotic lesions) on upper leaf surface",
      "Delicate white downy fungal cottony growth on the corresponding underside of the leaf during high humidity",
      "Lesions turn reddish-brown and necrotic; infected flower clusters turn dark brown, dry up, and shatter"
    ],
    whyThisHappens: {
      pathogenCause: "Plasmopara viticola, an aggressive obligate oomycete producing flagellated swimming zoospores.",
      weatherTriggers: "Temperature 18°C - 26°C with rainfall or leaf wetness >4 hours and relative humidity >85% (3-10 rule: 10mm rain, 10°C temp, 10cm shoot length).",
      transmissionMode: "Oospores in fallen leaves overwinter in soil; swimming zoospores splash onto lower foliage in rain.",
      riskFactors: "Poor vineyard canopy management, dense trailing unpruned shoots near ground, wet monsoon spells."
    },
    culturalMeasures: [
      "Shoot positioning and lateral canopy de-leafing around grape bunch zone to improve air circulation.",
      "Clear all fallen vine leaves from vineyard floor after annual October pruning."
    ],
    biologicalControl: [
      "Prophylactic foliar spray with Trichoderma viride @ 5g/L water."
    ],
    chemicalControl: [
      {
        chemical: "Metalaxyl 8% + Mancozeb 64% WP (Ridomil Gold)",
        dosage: "2.5 g / Liter of water",
        timing: "Curative systemic spray immediately after thunderstorm or cloudy wet spell."
      },
      {
        chemical: "Dimethomorph 50% WP (Acrobat)",
        dosage: "1.0 g / Liter of water",
        timing: "Translaminar oomycide spray; alternate with Mancozeb to prevent fungicide resistance."
      }
    ],
    preventiveCare: [
      "Apply 0.5% Bordeaux mixture immediately after forward pruning in October."
    ],
    kvkHelpline: "ICAR National Research Centre for Grapes (NRCG) Pune: 1800-180-1551."
  },
  {
    id: "grapes-healthy",
    crop: "Grapes (अंगूर / द्राक्षे)",
    cropKey: "grapes",
    diseaseName: "Grape Healthy Foliage (Nominal Baseline)",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.95, necrotic: 0.02, chlorosis: 0.03, powdery: 0, rust: 0 },
    symptoms: [
      "Broad vibrant green 3-to-5 lobed palmate leaves with intact serrated margins",
      "Complete absence of oily spots or powdery mycelial growth on either leaf surface",
      "Erect vigorous shoots with healthy tendrils and uniform bunch development"
    ],
    whyThisHappens: {
      pathogenCause: "Disciplined trellis architecture (Bower/Y-trellis) and proactive organic vineyard management.",
      weatherTriggers: "Warm sunny vineyard conditions with controlled drip fertigation and open canopy ventilation.",
      transmissionMode: "None.",
      riskFactors: "Inspect daily for oil spots following unseasonal rains."
    },
    culturalMeasures: [
      "Maintain shoot density of 35-40 shoots per meter of trellis wire."
    ],
    biologicalControl: [
      "Spray seaweed extract bio-stimulant @ 2 ml/L for foliar resilience."
    ],
    chemicalControl: [],
    preventiveCare: [
      "Soil application of potassium schoenite and magnesium sulphate during berry enlargement."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  },

  // 5. CITRUS DISEASES
  {
    id: "citrus-canker",
    crop: "Citrus / Lemon / Orange (संतरा / नीबू / लिंबू)",
    cropKey: "citrus",
    diseaseName: "Citrus Bacterial Canker (Xanthomonas citri subsp. citri)",
    pathogenType: "Bacterial Pathogen",
    targetBiomarkers: { green: 0.52, necrotic: 0.30, chlorosis: 0.16, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Raised corky blister-like lesions on leaves, twigs, and fruits",
      "Leaf lesions surrounded by a prominent oily or water-soaked margin and conspicuous yellow halo",
      "Corky lesions become rough, crater-like with sunken centers on both upper and lower leaf surfaces"
    ],
    whyThisHappens: {
      pathogenCause: "Xanthomonas citri subsp. citri, entering stomata and leaf wounds caused by Citrus Leaf Miner (Phyllocnistis citrella).",
      weatherTriggers: "Warm, rainy weather (25°C - 35°C) with strong wind-driven rains.",
      transmissionMode: "Splashing rain and windblown rain droplets carrying bacteria; contaminated pruning shears.",
      riskFactors: "Heavy citrus leaf miner infestation creating serpentine entry tunnels for bacteria."
    },
    culturalMeasures: [
      "Prune and burn canker-infected twigs during dormant winter period before spring flush.",
      "Install windbreak tree belts (Casuarina / Sesbania) along orchard borders to dampen wind-driven rains."
    ],
    biologicalControl: [
      "Spray cold-pressed Neem oil (10,000 ppm) @ 3 ml/L to control leaf miner vectors."
    ],
    chemicalControl: [
      {
        chemical: "Copper Oxychloride 50% WP + Streptomycin Sulphate (90:10)",
        dosage: "3.0 g + 0.1 g (100 ppm) per Liter water",
        timing: "Foliar spray at flush emergence and repeat after 15 days during rainy periods."
      }
    ],
    preventiveCare: [
      "Control leaf miners early using Imidacloprid 17.8% SL @ 0.5 ml/L on tender flushes."
    ],
    kvkHelpline: "ICAR Central Citrus Research Institute (CCRI) Nagpur: 1800-180-1551."
  },
  {
    id: "citrus-healthy",
    crop: "Citrus / Lemon / Orange (संतरा / नीबू / लिंबू)",
    cropKey: "citrus",
    diseaseName: "Citrus Healthy Foliage (Nominal Baseline)",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.96, necrotic: 0.01, chlorosis: 0.03, powdery: 0, rust: 0 },
    symptoms: [
      "Glossy dark green ovate-elliptic leaves with winged petioles and rich aromatic oil glands",
      "Intact waxy cuticular surface with zero corky canker craters or chlorotic mottling",
      "Turgid foliage with optimal iron and zinc levels and vigorous new flushes"
    ],
    whyThisHappens: {
      pathogenCause: "Certified disease-free budwood grafted on Phytophthora-resistant rootstock (Rangpur lime).",
      weatherTriggers: "Subtropical sunshine, well-drained loamy soil, and drip fertigation.",
      transmissionMode: "None.",
      riskFactors: "Control leaf miners and aphids proactively."
    },
    culturalMeasures: [
      "Paint tree trunks up to 1 meter with Bordeaux paste twice a year."
    ],
    biologicalControl: [
      "Apply mycorrhizal bio-fertilizers in root feeding zone."
    ],
    chemicalControl: [],
    preventiveCare: [
      "Foliar spray of Zinc Sulphate (0.5%) + Ferrous Sulphate (0.5%) on spring flush."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  },

  // 6. POMEGRANATE DISEASES
  {
    id: "pomegranate-bacterial-blight",
    crop: "Pomegranate (अनार / डाळिंब)",
    cropKey: "pomegranate",
    diseaseName: "Pomegranate Bacterial Blight / Telya (Xanthomonas axonopodis pv. punicae)",
    pathogenType: "Bacterial Pathogen",
    targetBiomarkers: { green: 0.48, necrotic: 0.34, chlorosis: 0.16, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Small water-soaked dark brown circular to angular spots with translucent greasy halos (Telya)",
      "Lesions turn black, brittle, and cause severe premature leaf drop (defoliation)",
      "Dark brown to black angular cankers on branches causing nodal dieback and branch breakages",
      "Characteristic 'L' or 'Y' shaped cracks on dark brown oily fruit spots"
    ],
    whyThisHappens: {
      pathogenCause: "Xanthomonas axonopodis pv. punicae, a destructive bacterium surviving in infected stem cankers and orchard debris.",
      weatherTriggers: "Warm temperatures (28°C - 35°C) with high humidity (>85%) during Mrig bahar monsoon showers.",
      transmissionMode: "Raindrop splash, infected pruning secateurs, and workers handling wet foliage.",
      riskFactors: "Taking Mrig Bahar crop in high rainfall endemic zones, unsterilized secateurs."
    },
    culturalMeasures: [
      "Prune and destroy infected branches 5 cm below the canker; paste cut wounds with 10% Bordeaux paste.",
      "Sterilize pruning tools in 10% sodium hypochlorite solution between every single tree.",
      "Switch flowering season to Hasta or Ambe Bahar to escape rainy season bacterial proliferation."
    ],
    biologicalControl: [
      "Spray bio-formulation of Bacillus subtilis @ 5g/L at 10-day intervals."
    ],
    chemicalControl: [
      {
        chemical: "Streptocycline (Streptomycin 90% + Tetracycline 10%) + Copper Oxychloride",
        dosage: "0.25 g + 2.5 g / Liter of water",
        timing: "Spray at first sign of greasy spot; repeat 3 times at 10-day intervals."
      },
      {
        chemical: "Bronopol 95% (2-bromo-2-nitropropane-1,3-diol)",
        dosage: "0.5 g / Liter of water",
        timing: "Curative bactericide spray during persistent rain spells."
      }
    ],
    preventiveCare: [
      "Plant certified tissue culture saplings (Bhagwa variety) free of bacterial blight.",
      "Drip fertigate with potassium and calcium to thicken leaf cell walls."
    ],
    kvkHelpline: "ICAR National Research Centre on Pomegranate (NRCP) Solapur: 1800-180-1551."
  },
  {
    id: "pomegranate-healthy",
    crop: "Pomegranate (अनार / डाळिंब)",
    cropKey: "pomegranate",
    diseaseName: "Pomegranate Healthy Canopy (Nominal Baseline)",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.96, necrotic: 0.01, chlorosis: 0.03, powdery: 0, rust: 0 },
    symptoms: [
      "Narrow glossy oblong-lanceolate leaves with vibrant olive-green chlorophyll",
      "Smooth clean leaf surface with zero greasy oily spots or branch cankers",
      "Abundant healthy hermaphrodite flowers and smooth spotless fruit development"
    ],
    whyThisHappens: {
      pathogenCause: "Certified nursery stock, drip irrigation, and strict orchard hygiene.",
      weatherTriggers: "Dry arid to semi-arid sunny climate with managed soil moisture.",
      transmissionMode: "None.",
      riskFactors: "Scout weekly for water-soaked spots during cloudy periods."
    },
    culturalMeasures: [
      "Maintain 4.5m x 3.0m spacing and keep orchard floor clean."
    ],
    biologicalControl: [
      "Foliar spray with Pseudomonas fluorescens @ 5g/L."
    ],
    chemicalControl: [],
    preventiveCare: [
      "Paste tree trunks with Copper Sulphate + Lime + Chlorpyrifos annually."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  }
];

const fruitHealthyReferenceModels = exports.fruitHealthyReferenceModels = {
  banana: {
    cropKey: "banana",
    cropName: "Banana (केला / केळी)",
    botanicalClass: "Monocotyledonae (Musaceae)",
    leafMorphology: "Enormous oblong-elliptic paddle blade with prominent rigid central midrib and pinnate-parallel lateral veins",
    marginType: "Entire smooth margin, naturally fraying cleanly along parallel transverse veins in wind",
    aspectRatioDescriptor: "Massive Paddle Blade (2.5 : 1 to 4.2 : 1)",
    typicalElongation: 3.2,
    marginRoughness: 22,
    greenTone: "Vivid Emerald Green (RGB 22, 163, 74)",
    realPhotoUrl: "images/healthy_crops/banana_healthy.jpg",
    realPhotoDescription: "Real farm photo of healthy Banana foliage displaying thick waxy cuticular sheen, vibrant chlorophyll, and intact central midrib.",
    healthyBiomarkers: { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: [
      "Massive unbroken photosynthetic lamina with uniform chlorophyll distribution",
      "Rigid ivory-green midrib with strong turgid petiole clasping pseudostem",
      "Zero chlorotic Sigatoka streaks, yellow halos, or Panama vascular discoloration"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refBanana" cx="45%" cy="30%" r="70%">
          <stop offset="0%" stop-color="#4ade80" />
          <stop offset="60%" stop-color="#16a34a" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,10 C 150,25 168,75 156,150 C 142,178 116,192 100,195 C 84,192 58,178 44,150 C 32,75 50,25 100,10 Z" fill="url(#refBanana)" stroke="#14532d" stroke-width="2"/>
      <path d="M 100,10 L 100,195" stroke="#ecfdf5" stroke-width="3" opacity="0.95"/>
      <path d="M 100,45 Q 130,40 152,48 M 100,45 Q 70,40 48,48" stroke="#dcfce7" stroke-width="1.2" opacity="0.6"/>
      <path d="M 100,85 Q 134,80 155,90 M 100,85 Q 66,80 45,90" stroke="#dcfce7" stroke-width="1.2" opacity="0.6"/>
      <path d="M 100,125 Q 130,120 150,132 M 100,125 Q 70,120 50,132" stroke="#dcfce7" stroke-width="1.2" opacity="0.6"/>
      <circle cx="85" cy="65" r="3.5" fill="rgba(255,255,255,0.45)"/>
    </svg>`
  },

  mango: {
    cropKey: "mango",
    cropName: "Mango (आम / आंबा)",
    botanicalClass: "Dicotyledonae (Anacardiaceae)",
    leafMorphology: "Simple leathery lanceolate to oblong-elliptic blade with prominent yellowish central midrib and arched lateral venation",
    marginType: "Entire, slightly undulating wavy margin",
    aspectRatioDescriptor: "Leathery Lanceolate (2.8 : 1 to 4.5 : 1)",
    typicalElongation: 3.4,
    marginRoughness: 24,
    greenTone: "Deep Glossy Olive-Green (RGB 21, 128, 61)",
    realPhotoUrl: "images/healthy_crops/mango_healthy.jpg",
    realPhotoDescription: "Real orchard photo of healthy Mango foliage with leathery cuticle, prominent venation, and zero anthracnose blemishes.",
    healthyBiomarkers: { green: 95, necrotic: 2, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: [
      "Glossy leathery cuticle with rich aromatic essential oil glands",
      "Clean undulating leaf margins with zero black anthracnose spots or powdery mildew",
      "Robust shoot development supporting healthy flower panicles"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refMango" cx="45%" cy="30%" r="70%">
          <stop offset="0%" stop-color="#4ade80" />
          <stop offset="55%" stop-color="#15803d" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,12 C 135,35 148,85 134,152 C 122,176 108,188 100,192 C 92,188 78,176 66,152 C 52,85 65,35 100,12 Z" fill="url(#refMango)" stroke="#166534" stroke-width="2"/>
      <path d="M 100,14 L 100,190" stroke="#fef08a" stroke-width="2.2" opacity="0.9"/>
      <path d="M 100,50 Q 120,44 132,54 M 100,50 Q 80,44 68,54" stroke="#dcfce7" stroke-width="1.2" opacity="0.6"/>
      <path d="M 100,95 Q 124,88 134,100 M 100,95 Q 76,88 66,100" stroke="#dcfce7" stroke-width="1.2" opacity="0.6"/>
      <path d="M 100,140 Q 118,134 126,145 M 100,140 Q 82,134 74,145" stroke="#dcfce7" stroke-width="1.2" opacity="0.6"/>
    </svg>`
  },

  apple: {
    cropKey: "apple",
    cropName: "Apple (सेब / सफरचंद)",
    botanicalClass: "Dicotyledonae (Rosaceae)",
    leafMorphology: "Simple ovate blade with pointed apex, rounded base, and fine serrated margins",
    marginType: "Serrated / Serrulate margin",
    aspectRatioDescriptor: "Ovate Serrate (1.4 : 1 to 2.2 : 1)",
    typicalElongation: 1.8,
    marginRoughness: 32,
    greenTone: "Forest Green (RGB 22, 101, 52)",
    realPhotoUrl: "images/healthy_crops/apple_healthy.jpg",
    realPhotoDescription: "Real macro orchard photo of healthy Apple leaf showing crisp serrated borders, fine pubescence, and zero scab lesions.",
    healthyBiomarkers: { green: 95, necrotic: 2, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: [
      "Crisp serrated border with puberulent lower surface",
      "Deep forest green chlorophyll with zero olive-green scab spots",
      "Strong spur connection with balanced leaf turgor"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refApple" cx="45%" cy="30%" r="70%">
          <stop offset="0%" stop-color="#86efac" />
          <stop offset="50%" stop-color="#16a34a" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,18 C 145,35 162,85 146,145 C 130,172 110,186 100,192 C 90,186 70,172 54,145 C 38,85 55,35 100,18 Z" fill="url(#refApple)" stroke="#166534" stroke-width="2"/>
      <path d="M 100,20 L 100,190" stroke="#dcfce7" stroke-width="2" opacity="0.85"/>
      <path d="M 100,60 Q 128,52 144,66 M 100,60 Q 72,52 56,66" stroke="#dcfce7" stroke-width="1.3" opacity="0.6"/>
      <path d="M 100,105 Q 130,96 142,112 M 100,105 Q 70,96 58,112" stroke="#dcfce7" stroke-width="1.3" opacity="0.6"/>
    </svg>`
  },

  grapes: {
    cropKey: "grapes",
    cropName: "Grapes (अंगूर / द्राक्षे)",
    botanicalClass: "Dicotyledonae (Vitaceae)",
    leafMorphology: "Broad palmately 3-to-5 lobed cordate leaf with acute lobes and dentate-serrate margins",
    marginType: "Dentate / Serrated lobed margin",
    aspectRatioDescriptor: "Palmate Cordate (1.0 : 1 to 1.4 : 1)",
    typicalElongation: 1.15,
    marginRoughness: 42,
    greenTone: "Bright Emerald Green (RGB 34, 197, 94)",
    realPhotoUrl: "images/healthy_crops/grapes_healthy.jpg",
    realPhotoDescription: "Real vineyard photo of healthy Grape vine foliage with distinct 5-lobed geometry, dentate margins, and zero downy/powdery mildew.",
    healthyBiomarkers: { green: 95, necrotic: 2, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: [
      "Distinct 3-to-5 lobed palmate geometry with deep basal sinus",
      "Zero translucent oily downy mildew patches or white powdery coat",
      "Vigorous shoot growth with healthy tendrils"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refGrapes" cx="50%" cy="40%" r="65%">
          <stop offset="0%" stop-color="#86efac" />
          <stop offset="50%" stop-color="#22c55e" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,20 C 130,15 155,35 155,65 C 175,80 180,115 160,140 C 145,155 125,160 100,185 C 75,160 55,155 40,140 C 20,115 25,80 45,65 C 45,35 70,15 100,20 Z" fill="url(#refGrapes)" stroke="#15803d" stroke-width="2"/>
      <path d="M 100,30 L 100,180" stroke="#dcfce7" stroke-width="2.5" opacity="0.8"/>
      <path d="M 100,75 L 145,55 M 100,75 L 55,55" stroke="#dcfce7" stroke-width="1.8" opacity="0.7"/>
      <path d="M 100,110 L 150,115 M 100,110 L 50,115" stroke="#dcfce7" stroke-width="1.8" opacity="0.7"/>
    </svg>`
  },

  citrus: {
    cropKey: "citrus",
    cropName: "Citrus / Lemon / Orange (संतरा / नीबू / लिंबू)",
    botanicalClass: "Dicotyledonae (Rutaceae)",
    leafMorphology: "Simple ovate-elliptic glossy blade with distinctive winged petiole and translucent pellucid oil glands",
    marginType: "Entire or weakly crenulate",
    aspectRatioDescriptor: "Glossy Winged Ovate (1.6 : 1 to 2.4 : 1)",
    typicalElongation: 1.9,
    marginRoughness: 24,
    greenTone: "Deep Glossy Emerald (RGB 16, 185, 129)",
    realPhotoUrl: "images/healthy_crops/citrus_healthy.jpg",
    realPhotoDescription: "Real macro photo of healthy Citrus leaf with glossy cuticular sheen, winged petiole, and zero canker blisters.",
    healthyBiomarkers: { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: [
      "Glossy cuticular surface with abundant aromatic oil glands",
      "Intact smooth margin with zero bacterial canker craters or leaf miner serpentine mines",
      "Distinctive winged petiole characteristic of Citrus species"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refCitrus" cx="45%" cy="30%" r="70%">
          <stop offset="0%" stop-color="#6ee7b7" />
          <stop offset="50%" stop-color="#10b981" />
          <stop offset="100%" stop-color="#064e3b" />
        </radialGradient>
      </defs>
      <path d="M 100,15 C 140,30 158,80 144,142 C 132,168 114,180 100,185 C 86,180 68,168 56,142 C 42,80 60,30 100,15 Z" fill="url(#refCitrus)" stroke="#047857" stroke-width="2"/>
      <path d="M 100,18 L 100,182" stroke="#d1fae5" stroke-width="2.2" opacity="0.85"/>
      <path d="M 100,55 Q 125,48 138,62 M 100,55 Q 75,48 62,62" stroke="#d1fae5" stroke-width="1.3" opacity="0.65"/>
      <path d="M 100,100 Q 128,92 138,108 M 100,100 Q 72,92 62,108" stroke="#d1fae5" stroke-width="1.3" opacity="0.65"/>
    </svg>`
  },

  pomegranate: {
    cropKey: "pomegranate",
    cropName: "Pomegranate (अनार / डाळिंब)",
    botanicalClass: "Dicotyledonae (Lythraceae)",
    leafMorphology: "Narrow glossy oblong-lanceolate leaves arranged opposite or in whorls on spiny twigs",
    marginType: "Entire smooth margin",
    aspectRatioDescriptor: "Narrow Oblong-Lanceolate (2.2 : 1 to 3.5 : 1)",
    typicalElongation: 2.8,
    marginRoughness: 22,
    greenTone: "Lustrous Olive-Green (RGB 22, 163, 74)",
    realPhotoUrl: "images/healthy_crops/pomegranate_healthy.jpg",
    realPhotoDescription: "Real farm photo of healthy Pomegranate foliage showing lustrous narrow leaves, spotless margins, and zero Telya bacterial blight spots.",
    healthyBiomarkers: { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: [
      "Lustrous narrow oblong-lanceolate foliage with smooth margin",
      "Zero oily water-soaked spots (Telya) or nodal stem cankers",
      "Healthy flowering and unblemished fruit set"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refPom" cx="45%" cy="30%" r="70%">
          <stop offset="0%" stop-color="#86efac" />
          <stop offset="50%" stop-color="#16a34a" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,16 C 130,35 142,85 132,150 C 122,174 110,186 100,190 C 90,186 78,174 68,150 C 58,85 70,35 100,16 Z" fill="url(#refPom)" stroke="#15803d" stroke-width="2"/>
      <path d="M 100,18 L 100,188" stroke="#dcfce7" stroke-width="2" opacity="0.85"/>
      <path d="M 100,55 Q 120,48 128,60 M 100,55 Q 80,48 72,60" stroke="#dcfce7" stroke-width="1.2" opacity="0.6"/>
      <path d="M 100,105 Q 122,98 128,112 M 100,105 Q 78,98 72,112" stroke="#dcfce7" stroke-width="1.2" opacity="0.6"/>
    </svg>`
  }
};
