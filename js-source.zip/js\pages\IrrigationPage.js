// AgroSense Smart Irrigation Recommendation Page Component

import { calculateIrrigationRecommendation } from '../services/irrigationService.js';
import { renderGenericXAIExplanationCard } from '../components/XAIExplanationCard.js';
import { translations } from '../data/translations.js';

export function renderIrrigationPage(state) {
  const t = translations[state.lang] || translations.en;
  const farm = state.activeFarm;
  const pulseActive = state.irrigationPulseActive || { active: false, minutesLeft: 20 };
  const soilMoisture = (state.customSoil ? state.customSoil.moisture : farm.soil.moisture) + (pulseActive.active ? 3 : 0);

  const rec = calculateIrrigationRecommendation(soilMoisture, farm.currentCrop, "Vegetative", state.weatherData ? state.weatherData.forecast : null);

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="droplet" class="w-6 h-6 text-blue-400"></i>
            ${t.nav ? t.nav.irrigation : 'Smart Irrigation'} & Water Management
          </h1>
          <p class="text-xs text-gray-400">FAO-56 Penman-Monteith ET0 water duty matching, soil moisture thresholds & rain delay rules</p>
        </div>
        <span class="prototype-badge">FAO-56 ET0 MODEL</span>
      </div>

      <!-- Water Status Banner -->
      <div class="glass-card-accent p-6 flex flex-wrap items-center justify-between gap-6">
        <div class="space-y-1">
          <span class="text-xs font-bold text-emerald-400 uppercase tracking-wider">CURRENT SOIL WATER STATUS</span>
          <h2 class="text-3xl font-extrabold text-white font-mono">${pulseActive.active ? 'ACTIVE DRIP PULSE IN PROGRESS' : rec.waterStatus}</h2>
          <p class="text-xs text-gray-300">Soil Moisture Reading: <b class="text-blue-300 font-mono">${soilMoisture.toFixed(1)}%</b> (Target Optimal: ${rec.targetMoisture}%)</p>
        </div>

        <div class="p-4 rounded-xl bg-emerald-950/80 border border-emerald-700/50 space-y-1 max-w-lg">
          <span class="text-xs font-bold text-amber-300 uppercase tracking-wider block">Smart Recommendation:</span>
          <p class="text-xs text-gray-200 leading-relaxed font-semibold">
            ${pulseActive.active 
              ? '💧 20-Minute Drip Pulse active on Solenoid Valve Zone A. Delivering 450 Liters/Acre water duty.' 
              : rec.actionText}
          </p>
        </div>
      </div>

      <!-- FAO-56 PENMAN-MONTEITH ET0 MATHEMATICAL XAI ATTRIBUTION CARD -->
      ${renderGenericXAIExplanationCard(
        "FAO-56 Penman-Monteith Water Balance XAI Model",
        "Why is recommended pulse volume set to " + rec.recommendedVolumeLiters + " Liters / Acre?",
        rec.xaiAttribution.waterBalanceEquation,
        rec.xaiAttribution.factors
      )}

      <!-- VISUAL IRRIGATION PIPELINE DIAGRAM -->
      <div class="glass-card p-6 space-y-4">
        <h3 class="text-xs font-bold text-emerald-400 uppercase tracking-wider text-center">DECISION PIPELINE FLOW</h3>
        <div class="grid grid-cols-1 sm:grid-cols-5 gap-3 text-center">
          ${rec.pipelineVisual.map((node, idx) => `
            <div class="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40 space-y-1">
              <i data-lucide="${node.icon}" class="w-5 h-5 mx-auto text-emerald-400"></i>
              <span class="text-[10px] font-bold text-gray-400 uppercase block">${node.step}</span>
              <span class="text-xs font-bold text-white block truncate font-mono">${node.status}</span>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Quick Action Controls -->
      <div class="glass-card p-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <h4 class="text-sm font-bold text-white">Drip Irrigation Pulse Solenoid Override</h4>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold ${pulseActive.active ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40 animate-pulse' : 'bg-gray-800 text-gray-400'}">
              ${pulseActive.active ? '● SOLENOID VALVE OPEN' : '○ SOLENOID VALVE IDLE'}
            </span>
          </div>
          <p class="text-xs text-gray-400 mt-1">Connected Drip Irrigation Solenoid Valve (Zone A - 5 Acres Vertisol Plot)</p>
        </div>
        <button id="trigger-drip-pulse-btn" class="px-5 py-2.5 rounded-xl font-bold text-xs shadow-lg transition cursor-pointer flex items-center gap-2 ${
          pulseActive.active
            ? 'bg-amber-600 hover:bg-amber-500 text-white'
            : 'bg-blue-600 hover:bg-blue-500 text-white'
        }">
          <i data-lucide="${pulseActive.active ? 'pause-circle' : 'play-circle'}" class="w-4 h-4"></i>
          ${pulseActive.active ? 'Stop Active Drip Pulse' : (t.initiatePulse || 'Initiate 20-Min Drip Pulse')}
        </button>
      </div>
    </div>
  `;
}

export function initIrrigationHooks(state, setState) {
  const pulseBtn = document.getElementById('trigger-drip-pulse-btn');
  if (pulseBtn) {
    pulseBtn.addEventListener('click', () => {
      const curPulse = state.irrigationPulseActive || { active: false, minutesLeft: 20 };
      const nextActive = !curPulse.active;

      const newActivities = state.farmActivities ? [...state.farmActivities] : [];
      if (nextActive) {
        newActivities.unshift({
          date: new Date().toISOString().split('T')[0],
          category: 'Irrigation',
          title: 'Initiated 20-Min Drip Pulse',
          details: 'Applied 20-minute targeted drip pulse cycle (Zone A - Vertisol Plot)',
          cost: '₹350'
        });
      }

      setState({
        irrigationPulseActive: { active: nextActive, minutesLeft: 20 },
        farmActivities: newActivities
      });
    });
  }
}
