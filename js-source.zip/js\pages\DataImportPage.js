// AgroSense Farm Data Import & Data Quality Audit Page Component

import { parseCSVAndAuditQuality } from '../services/dataQualityService.js';

export function renderDataImportPage(state) {
  const audit = state.csvAudit || null;

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="file-spreadsheet" class="w-6 h-6 text-emerald-400"></i>
            Farm Dataset CSV Import & Data Quality Audit
          </h1>
          <p class="text-xs text-gray-400">Upload agricultural CSV datasets for validation, missing value repair & outlier detection</p>
        </div>
        <span class="prototype-badge">DATA QUALITY PANEL</span>
      </div>

      <!-- CSV File Drag & Drop Box -->
      <div class="glass-card p-6 space-y-4 text-center border-2 border-dashed border-emerald-700/50 hover:border-emerald-400 transition">
        <div class="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto">
          <i data-lucide="upload" class="w-6 h-6"></i>
        </div>
        <div>
          <h3 class="text-sm font-bold text-white">Upload Soil, Weather, or Sensor CSV Dataset</h3>
          <p class="text-xs text-gray-400 mt-1">Supports UTF-8 CSV files up to 50MB</p>
        </div>
        <div class="flex items-center justify-center gap-3">
          <button id="load-sample-csv-btn" class="px-4 py-2 rounded-xl bg-emerald-900/60 border border-emerald-700/40 text-emerald-300 text-xs font-bold hover:bg-emerald-800/60">
            Load Sample Soil Dataset (Pune Vertisol CSV)
          </button>
        </div>
      </div>

      <!-- Data Quality Audit Panel (If dataset loaded) -->
      ${audit ? `
        <div class="space-y-6">
          <!-- Audit Metrics Grid -->
          <div class="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div class="glass-card p-4 space-y-1">
              <span class="text-xs font-bold text-gray-400">Dataset Dimensions</span>
              <div class="text-xl font-bold text-white font-mono">${audit.totalRows} Rows x ${audit.totalColumns} Cols</div>
            </div>

            <div class="glass-card p-4 space-y-1">
              <span class="text-xs font-bold text-gray-400">Data Completeness</span>
              <div class="text-xl font-bold text-emerald-400 font-mono">${audit.completenessPercentage}%</div>
            </div>

            <div class="glass-card p-4 space-y-1">
              <span class="text-xs font-bold text-gray-400">Missing Values Detected</span>
              <div class="text-xl font-bold text-amber-400 font-mono">${audit.missingValuesCount} Cells</div>
            </div>

            <div class="glass-card p-4 space-y-1">
              <span class="text-xs font-bold text-gray-400">Outlier / Duplicate Rows</span>
              <div class="text-xl font-bold text-red-400 font-mono">${audit.duplicateRowsCount} Dup / ${audit.outlierValuesCount} Outliers</div>
            </div>
          </div>

          <!-- Sample Table -->
          <div class="glass-card p-6 overflow-x-auto">
            <h3 class="text-sm font-bold text-white mb-3">Dataset Preview (First 10 Records)</h3>
            <table class="w-full text-left border-collapse text-xs">
              <thead>
                <tr class="border-b border-emerald-800/60 text-gray-400">
                  ${audit.columns.map(col => `<th class="p-2.5">${col}</th>`).join('')}
                </tr>
              </thead>
              <tbody class="divide-y divide-emerald-950/60">
                ${audit.sampleRows.map(row => `
                  <tr>
                    ${audit.columns.map(col => `<td class="p-2.5 text-gray-200 font-mono">${row[col] !== null ? row[col] : '<span class="text-amber-400">NULL</span>'}</td>`).join('')}
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      ` : `
        <div class="glass-card p-8 text-center text-xs text-gray-400">
          Click "Load Sample Soil Dataset" above to inspect data validation output.
        </div>
      `}
    </div>
  `;
}
