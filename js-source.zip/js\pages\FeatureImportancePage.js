// AGROSENSE FEATURE IMPORTANCE & EXPLAINABLE AI (XAI) PAGE (/#/feature-importance)

import { getFeatureImportances } from '../ml/fodsMLEngine.js';

export function renderFeatureImportancePage(state) {
  const importances = getFeatureImportances();

  return `
    <div class="space-y-8 max-w-7xl mx-auto py-2">
      <!-- Page Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-extrabold text-white tracking-tight">Feature Importance & Explainable AI (XAI)</h1>
            <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">GINI IMPURITY ANALYSIS</span>
          </div>
          <p class="text-xs text-gray-400 mt-1">Quantifying feature contribution weights derived from 100 Random Forest Decision Trees ($I_G = 1 - \\sum p_i^2$)</p>
        </div>
      </div>

      <!-- Horizontal Feature Importance Chart Cards -->
      <div class="glass-card p-6 space-y-6">
        <h3 class="text-sm font-bold text-white flex items-center gap-2">
          <i data-lucide="sliders" class="w-4 h-4 text-emerald-400"></i>
          Relative Feature Contribution Breakdown
        </h3>

        <div class="space-y-4">
          ${importances.map(item => `
            <div class="space-y-1">
              <div class="flex items-center justify-between text-xs">
                <span class="font-bold text-white">${item.feature}</span>
                <span class="font-mono font-extrabold text-emerald-400">${item.percentage} (${item.importance})</span>
              </div>

              <!-- Bar Track -->
              <div class="w-full h-3 bg-gray-900 rounded-full overflow-hidden border border-gray-800">
                <div class="h-full bg-gradient-to-r from-emerald-600 to-teal-400 rounded-full" style="width: ${item.importance * 300}%"></div>
              </div>

              <p class="text-[11px] text-gray-400 font-sans">${item.desc}</p>
            </div>
          `).map(s => s).join('')}
        </div>
      </div>

      <!-- Mathematical Foundation Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="glass-card p-6 space-y-3 border-l-4 border-l-emerald-500">
          <h4 class="text-sm font-bold text-white">Gini Impurity Equation ($I_G$)</h4>
          <p class="text-xs text-gray-300">Measures the probability of incorrectly classifying a randomly chosen element from the dataset if it were randomly labeled according to the distribution of labels in the subset.</p>
          <div class="p-3 rounded-xl bg-gray-950 font-mono text-emerald-400 text-xs text-center border border-gray-800">
            I_G(p) = 1 - \\sum_{i=1}^{J} p_i^2
          </div>
        </div>

        <div class="glass-card p-6 space-y-3 border-l-4 border-l-teal-500">
          <h4 class="text-sm font-bold text-white">Mean Decrease Impurity (MDI)</h4>
          <p class="text-xs text-gray-300">Computed by averaging the decrease in node impurity weighted by the probability of reaching that node across all 100 decision trees in the Random Forest ensemble.</p>
          <div class="p-3 rounded-xl bg-gray-950 font-mono text-teal-300 text-xs text-center border border-gray-800">
            \\text{Importance}(X_m) = \\sum_{t \\in T} P(t) \\cdot \\Delta I_G(t, X_m)
          </div>
        </div>
      </div>
    </div>
  `;
}
