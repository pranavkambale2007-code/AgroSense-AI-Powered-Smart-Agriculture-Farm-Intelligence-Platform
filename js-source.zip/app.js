// AGROSENSE MAIN APPLICATION ENGINE & ROUTER

const { renderNavbar } = require('js/components/Navbar.js');
const { renderSidebar } = require('js/components/Sidebar.js');
const { generateAICopilotResponse, calculateCropSuitability } = require('js/services/aiEngine.js');
const { classifyLeafImage } = require('js/services/diseaseService.js');
const { parseCSVAndAuditQuality } = require('js/services/dataQualityService.js');
const { fetchLiveOrDemoWeather } = require('js/services/weatherService.js');

// Active Core Pages & Hooks
const { renderLandingPage } = require('js/pages/LandingPage.js');
const { renderOnboardingPage, initOnboardingHooks } = require('js/pages/OnboardingPage.js');
const { renderThreeDFarmCanvas, initThreeDFarmCanvas } = require('js/components/ThreeDFarmCanvas.js');
const { renderFarmMapPage, initFarmMapHooks } = require('js/pages/FarmMapPage.js');
const { renderSoilIntelligencePage, initSoilHooks } = require('js/pages/SoilIntelligencePage.js');
const { renderCropRecommendationPage, initCropRecommendationHooks } = require('js/pages/CropRecommendationPage.js');
const { renderCropComparePage, initCropCompareHooks } = require('js/pages/CropComparePage.js');
const { renderWeatherPage } = require('js/pages/WeatherPage.js');
const { renderWeatherRiskPage, initWeatherRiskHooks } = require('js/pages/WeatherRiskPage.js');
const { renderPlantDiseasePage, initPlantDiseaseHooks } = require('js/pages/PlantDiseasePage.js');
const { renderSatelliteCropHealthPage, initSatelliteCropHealthHooks } = require('js/pages/SatelliteCropHealthPage.js');
const { renderSustainabilityDashboardPage, initSustainabilityHooks } = require('js/pages/SustainabilityDashboardPage.js');
const { renderGovernmentSubsidiesPage, initGovernmentSubsidiesHooks } = require('js/pages/GovernmentSubsidiesPage.js');
const { renderCropGrowthPage, initCropGrowthHooks } = require('js/pages/CropGrowthPage.js');
const { renderFarmLogPage, initFarmLogHooks } = require('js/pages/FarmLogPage.js');
const { renderAICopilotPage, initAICopilotHooks } = require('js/pages/AICopilotPage.js');
const { renderProfitabilityPage, initProfitabilityHooks } = require('js/pages/ProfitabilityPage.js');
const { renderFarmHistoryPage, initFarmHistoryHooks } = require('js/pages/FarmHistoryPage.js');

// Data Science Module Pages
const { renderDataVisualizationCenterPage, initDataVisualizationCenterHooks } = require('js/pages/DataVisualizationCenterPage.js');
const { renderDatasetPage } = require('js/pages/DatasetPage.js');
const { renderDataCleaningPage, initDataCleaningHooks } = require('js/pages/DataCleaningPage.js');
const { renderEDAPage, initEDAHooks } = require('js/pages/EDAPage.js');
const { renderMLModelsPage, initMLModelsHooks } = require('js/pages/MLModelsPage.js');
const { renderFeatureImportancePage } = require('js/pages/FeatureImportancePage.js');
const { renderWhatIfSimulatorPage, initWhatIfHooks } = require('js/pages/WhatIfSimulatorPage.js');
const { renderDataImportPage } = require('js/pages/DataImportPage.js');

const { emptyFarmTemplate } = require('js/services/geoService.js');

class AgroSenseApp {
  constructor() {
    let initialFarms = [];
    try {
      const stored = localStorage.getItem('agrosense_farms');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          initialFarms = parsed.filter(f => 
            !/^farm-(0[1-9]|1[0-5])$/.test(f.id) && 
            !f.name?.toLowerCase().includes('demo') &&
            f.id !== 'unregistered'
          );
          localStorage.setItem('agrosense_farms', JSON.stringify(initialFarms));
        }
      }
    } catch (e) {}

    let initialActive = initialFarms.length > 0 ? initialFarms[0] : emptyFarmTemplate;
    try {
      const storedActiveId = localStorage.getItem('agrosense_active_farm_id');
      if (storedActiveId && initialFarms.length > 0) {
        const found = initialFarms.find(f => f.id === storedActiveId);
        if (found) initialActive = found;
      }
    } catch (e) {}

    let currentRoute = this.getRouteFromHash();
    if (initialFarms.length === 0 && (currentRoute === '/' || currentRoute === '/dashboard')) {
      currentRoute = '/onboarding';
      window.location.hash = '#/onboarding';
    } else if (currentRoute === '/' || currentRoute === '/dashboard') {
      currentRoute = '/3d-farm';
      window.location.hash = '#/3d-farm';
    }

    let initialNotifications = [
      {
        id: 'notif-1',
        category: 'Weather Risk',
        title: 'Rain Storm Warning (18.5mm)',
        message: 'Hyperlocal forecast predicts heavy rainfall in 24 hours. Hold off on nitrogen top-dressing and chemical sprays.',
        type: 'warning',
        time: '15 mins ago',
        read: false,
        route: '/weather'
      },
      {
        id: 'notif-2',
        category: 'Soil Chemistry',
        title: 'Nitrogen Deficit in Active Plot',
        message: 'Active plot soil report indicates Nitrogen at 185 kg/ha (-95 kg/ha deficit). Split-dose top-dressing recommended.',
        type: 'alert',
        time: '2 hours ago',
        read: false,
        route: '/soil'
      },
      {
        id: 'notif-3',
        category: 'Crop Pathology',
        title: 'High Humidity Fungal Risk',
        message: 'Canopy relative humidity reached 74% at 24.5°C. Spore germination index elevated for foliar rust.',
        type: 'warning',
        time: '5 hours ago',
        read: false,
        route: '/risk'
      },
      {
        id: 'notif-4',
        category: 'Crop Selection',
        title: 'Agronomic Suitability Updated',
        message: 'Wheat HD-2967 evaluated at 94% optimal suitability match for current winter soil and moisture parameters.',
        type: 'info',
        time: 'Yesterday',
        read: true,
        route: '/crop-recommendation'
      },
      {
        id: 'notif-5',
        category: 'Govt Schemes',
        title: 'PM-KUSUM Subsidy Portal Open',
        message: 'State agricultural portal is currently accepting subsidy claims for solar pump installations (up to 60%).',
        type: 'success',
        time: '2 days ago',
        read: true,
        route: '/subsidies'
      }
    ];

    try {
      const storedNotifs = localStorage.getItem('agrosense_notifications');
      if (storedNotifs) {
        const parsed = JSON.parse(storedNotifs);
        if (Array.isArray(parsed) && parsed.length > 0) {
          initialNotifications = parsed;
        }
      }
    } catch (e) {}

    let initialProfitParams = {
      acres: 5,
      crop: "Wheat",
      costItems: [
        { id: "cost-1", category: "Seeds & Sowing", costPerAcre: 3500 },
        { id: "cost-2", category: "Fertilizer & Soil Nutrition", costPerAcre: 6200 },
        { id: "cost-3", category: "Labor & Field Operations", costPerAcre: 12000 },
        { id: "cost-4", category: "Irrigation & Energy", costPerAcre: 4500 },
        { id: "cost-5", category: "Pesticides & Crop Protection", costPerAcre: 3800 },
        { id: "cost-6", category: "Machinery, Fuel & Rent", costPerAcre: 2500 }
      ],
      expectedYieldPerAcre: 22,
      expectedPricePerUnit: 2275
    };

    try {
      const storedProfit = localStorage.getItem('agrosense_profit_params');
      if (storedProfit) {
        const parsed = JSON.parse(storedProfit);
        if (parsed && typeof parsed === 'object') {
          initialProfitParams = { ...initialProfitParams, ...parsed };
        }
      }
    } catch (e) {}

    this.state = {
      route: currentRoute,
      lang: 'en',
      farms: initialFarms,
      activeFarm: initialActive,
      customSoil: null,
      selectedCropRec: null,
      selectedCropId: 'wheat',
      cropCategoryFilter: 'All',
      cropSearchQuery: '',
      weatherData: null,
      diseaseResult: { ...classifyLeafImage(null, 'wheat-leaf-rust'), isInitialPreview: true },
      diseaseImageSrc: null,
      selectedCropHint: 'all',
      sensorTimeframe: '24h',
      csvAudit: null,
      knowledgeSearchQuery: '',
      whatIfInput: { N: 90, P: 42, K: 43, temp: 24, humidity: 80, ph: 6.5, rainfall: 220, moisture: 45 },
      isNotificationsOpen: false,
      notificationFilter: 'all',
      notifications: initialNotifications,
      sidebarOpen: false,

      // Persistent feature state
      farmActivities: [
        { id: '1', date: "2026-11-15", category: "Sowing", title: "Wheat HD-2967 Sowing", details: "Sown using seed drill with 40kg/acre seed rate", cost: "₹4,200" },
        { id: '2', date: "2026-12-02", category: "Irrigation", title: "First Drip Pulse Irrigation", details: "Applied 2.5 hours drip pulse cycle after emergence", cost: "₹450" },
        { id: '3', date: "2026-12-18", category: "Fertilizer", title: "Urea Top-Dressing", details: "Applied 25kg Urea split dose per acre", cost: "₹1,850" },
        { id: '4', date: "2026-12-28", category: "Weeding", title: "Inter-row Weeding", details: "Manual weeding & hoeing operation", cost: "₹2,500" }
      ],
      farmHistory: [
        { id: '1', season: "Kharif 2026", crop: "Soybean (JS-335)", yield: "18.5 Qtl / Acre", grossIncome: "₹4,12,000", soilScore: "82/100", waterUsed: "3.2 ML" },
        { id: '2', season: "Rabi 2025-26", crop: "Wheat (HD-2967)", yield: "22.0 Qtl / Acre", grossIncome: "₹4,85,000", soilScore: "79/100", waterUsed: "4.1 ML" },
        { id: '3', season: "Kharif 2025", crop: "Cotton (Bt-II)", yield: "11.2 Qtl / Acre", grossIncome: "₹6,80,000", soilScore: "76/100", waterUsed: "5.4 ML" }
      ],
      cropGrowthStage: { index: 2, das: 65, expectedYield: "45.0 Qtl/Ha" },
      profitParams: initialProfitParams,
      vizFilter: { crop: 'All', season: 'All', state: 'All', soil: 'All', irrigation: 'All', statsCol: 'Yield_Tonnes_Ha' },
      selectedCompareCropIds: ['c-01', 'c-02', 'c-04', 'p-08']
    };

    this.init();
  }

  getRouteFromHash() {
    const hash = window.location.hash.slice(1);
    return hash || '/3d-farm';
  }

  async init() {
    window.addEventListener('hashchange', () => {
      this.state.route = this.getRouteFromHash();
      this.render();
    });

    // Immediate initial render for instant paint
    this.render();

    this.state.weatherData = await fetchLiveOrDemoWeather();
    this.render();
  }

  setState(newState) {
    this.state = { ...this.state, ...newState };
    this.render();
  }

  render() {
    const appEl = document.getElementById('app');
    if (!appEl) return;

    const route = this.state.route;

    let pageHtml = '';
    let pageHook = null;

    switch (route) {
      case '/':
        if (this.state.farms.length === 0) {
          pageHtml = renderOnboardingPage(this.state);
          pageHook = (state) => initOnboardingHooks(state, this.setState.bind(this));
        } else {
          pageHtml = renderThreeDFarmCanvas('three-d-farm-canvas', this.state);
          pageHook = () => initThreeDFarmCanvas('three-d-farm-canvas', this.state);
        }
        break;
      case '/landing':
        pageHtml = renderLandingPage(this.state);
        break;
      case '/onboarding':
        pageHtml = renderOnboardingPage(this.state);
        pageHook = (state) => initOnboardingHooks(state, this.setState.bind(this));
        break;
      case '/3d-farm':
        pageHtml = renderThreeDFarmCanvas('three-d-farm-canvas', this.state);
        pageHook = () => initThreeDFarmCanvas('three-d-farm-canvas', this.state);
        break;
      case '/farm-map':
        pageHtml = renderFarmMapPage(this.state);
        pageHook = initFarmMapHooks;
        break;
      case '/crop-monitor':
        pageHtml = renderCropGrowthPage(this.state);
        pageHook = (state) => initCropGrowthHooks(state, this.setState.bind(this));
        break;
      case '/farm-log':
        pageHtml = renderFarmLogPage(this.state);
        pageHook = (state) => initFarmLogHooks(state, this.setState.bind(this));
        break;
      case '/crop-recommendation':
        pageHtml = renderCropRecommendationPage(this.state);
        pageHook = (state) => initCropRecommendationHooks(state, this.setState.bind(this));
        break;
      case '/crop-compare':
        pageHtml = renderCropComparePage(this.state);
        pageHook = (state) => initCropCompareHooks(state, this.setState.bind(this));
        break;
      case '/soil':
        pageHtml = renderSoilIntelligencePage(this.state);
        pageHook = (state) => initSoilHooks(state, this.setState.bind(this));
        break;
      case '/disease':
      case '/plant-disease':
        pageHtml = renderPlantDiseasePage(this.state);
        pageHook = (state) => initPlantDiseaseHooks(state, this.setState.bind(this));
        break;
      case '/satellite':
      case '/satellite-crop-health':
        pageHtml = renderSatelliteCropHealthPage(this.state);
        pageHook = (state) => initSatelliteCropHealthHooks(state, this.setState.bind(this));
        break;
      case '/sustainability':
      case '/sustainability-impact':
        pageHtml = renderSustainabilityDashboardPage(this.state);
        pageHook = (state) => initSustainabilityHooks(state, this.setState.bind(this));
        break;
      case '/profitability':
        pageHtml = renderProfitabilityPage(this.state);
        pageHook = (state) => initProfitabilityHooks(state, this.setState.bind(this));
        break;
      case '/history':
        pageHtml = renderFarmHistoryPage(this.state);
        pageHook = (state) => initFarmHistoryHooks(state, this.setState.bind(this));
        break;
      case '/weather':
        pageHtml = renderWeatherPage(this.state);
        break;
      case '/risk':
        pageHtml = renderWeatherRiskPage(this.state);
        pageHook = (state) => initWeatherRiskHooks(state, this.setState.bind(this));
        break;
      case '/subsidies':
        pageHtml = renderGovernmentSubsidiesPage(this.state);
        pageHook = (state) => initGovernmentSubsidiesHooks(state, this.setState.bind(this));
        break;
      case '/ai-assistant':
        pageHtml = renderAICopilotPage(this.state);
        pageHook = (state) => initAICopilotHooks(state, this.setState.bind(this));
        break;
      case '/visualization-center':
        pageHtml = renderDataVisualizationCenterPage(this.state);
        pageHook = (state) => initDataVisualizationCenterHooks(state, this.setState.bind(this));
        break;
      case '/dataset':
        pageHtml = renderDatasetPage(this.state);
        break;
      case '/data-cleaning':
        pageHtml = renderDataCleaningPage(this.state);
        pageHook = (state) => initDataCleaningHooks(state, this.setState.bind(this));
        break;
      case '/eda':
        pageHtml = renderEDAPage(this.state);
        pageHook = initEDAHooks;
        break;
      case '/ml-models':
        pageHtml = renderMLModelsPage(this.state);
        pageHook = initMLModelsHooks;
        break;
      case '/feature-importance':
        pageHtml = renderFeatureImportancePage(this.state);
        break;
      case '/what-if':
        pageHtml = renderWhatIfSimulatorPage(this.state);
        pageHook = (state) => initWhatIfHooks(state, this.setState.bind(this));
        break;
      case '/import-data':
        pageHtml = renderDataImportPage(this.state);
        break;

      // Clean redirect for removed routes
      case '/dashboard':
      case '/decision-center':
      case '/analytics':
      case '/irrigation':
      case '/sensors':
      case '/crop-risk':
      case '/knowledge':
      case '/market':
      case '/sustainability':
      case '/regional-analytics':
      case '/national-dashboard':
      case '/admin':
      case '/admin/models':
      case '/reports':
      case '/documentation':
      case '/fods-concepts':
      case '/architecture':
      case '/audit':
      case '/judge-audit':
      default:
        pageHtml = renderThreeDFarmCanvas('three-d-farm-canvas', this.state);
        pageHook = () => initThreeDFarmCanvas('three-d-farm-canvas', this.state);
        break;
    }

    appEl.innerHTML = `
      <div class="h-screen w-screen overflow-hidden flex flex-col bg-[#060d0a]">
        <!-- Navbar -->
        ${renderNavbar(this.state, this.setState.bind(this))}

        <div class="flex-1 min-h-0 flex overflow-hidden relative">
          <!-- Sidebar -->
          ${renderSidebar(this.state)}

          <!-- Main Content View Area -->
          <main id="main-content-view" class="flex-1 min-w-0 min-h-0 overflow-y-auto overflow-x-hidden p-4 sm:p-6 lg:p-8 custom-scrollbar">
            ${pageHtml}
          </main>
        </div>

        <!-- Floating Copilot Quick Launcher Button -->
        <a href="#/ai-assistant" id="btn-floating-copilot" class="fixed bottom-6 right-6 z-40 px-4 py-3 rounded-full bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 hover:from-emerald-500 hover:to-teal-400 text-white font-bold text-xs sm:text-sm shadow-2xl shadow-emerald-950/80 flex items-center gap-2.5 border-2 border-emerald-300/40 hover:scale-105 active:scale-95 transition-all text-decoration-none group" title="Open Farm Copilot">
          <div class="relative">
            <i data-lucide="bot" class="w-5 h-5 group-hover:rotate-12 transition transform"></i>
            <span class="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 border-2 border-[#060d0a] animate-pulse"></span>
          </div>
          <span class="hidden sm:inline">Farm Copilot</span>
          <span class="px-2 py-0.5 rounded-full bg-emerald-950 text-[10px] text-emerald-300 border border-emerald-400/40 font-mono">Live</span>
        </a>
      </div>
    `;

    if (typeof lucide !== 'undefined' && lucide.createIcons) {
      lucide.createIcons();
    }

    this.attachEventListeners();

    if (pageHook) {
      setTimeout(() => pageHook(this.state), 100);
    }
  }

  attachEventListeners() {
    // Universal Add Farm Action Handler (Navbar, Sidebar, Maps)
    const triggerAddFarm = (e) => {
      if (e) e.preventDefault();

      const newBlankFarm = {
        ...emptyFarmTemplate,
        id: `farm-${Date.now()}`,
        name: '',
        farmerName: '',
        location: 'Pune District, Maharashtra',
        currentCrop: 'Wheat (HD-2967)',
        boundaryPolygon: []
      };

      this.setState({
        activeFarm: newBlankFarm,
        customSoil: null,
        selectedCropRec: null,
        route: '/onboarding'
      });

      if (window.location.hash !== '#/onboarding') {
        window.location.hash = '#/onboarding';
      } else {
        this.render();
      }
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    document.querySelectorAll('.btn-add-farm-action, #btn-nav-add-farm, #btn-sidebar-add-farm, #btn-farm-map-add, #btn-dash-add-farm').forEach(btn => {
      btn.addEventListener('click', triggerAddFarm);
    });

    // Farm Selector
    const farmSelect = document.getElementById('farm-selector');
    if (farmSelect) {
      farmSelect.addEventListener('change', (e) => {
        if (e.target.value === '__add_new_farm__') {
          triggerAddFarm(e);
          return;
        }
        const found = this.state.farms.find(f => f.id === e.target.value);
        if (found) {
          try {
            localStorage.setItem('agrosense_active_farm_id', found.id);
          } catch (err) {}
          this.setState({ activeFarm: found, customSoil: null, selectedCropRec: null, satelliteAnalysis: null, satelliteLoading: false });
        }
      });
    }

    // Toggle Mobile Sidebar Menu
    const toggleSidebarBtn = document.getElementById('toggle-sidebar-btn');
    if (toggleSidebarBtn) {
      toggleSidebarBtn.addEventListener('click', () => {
        this.setState({ sidebarOpen: !this.state.sidebarOpen });
      });
    }

    // Trigger incoming notification simulation
    const triggerNotifBtn = document.getElementById('btn-trigger-test-notif');
    if (triggerNotifBtn) {
      triggerNotifBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        this.receiveIncomingNotification();
      });
    }

    // Crop Category Filter Buttons
    document.querySelectorAll('.crop-cat-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const cat = btn.getAttribute('data-crop-cat');
        this.setState({ cropCategoryFilter: cat });
      });
    });

    // Crop Search Input
    const cropSearchInput = document.getElementById('crop-search-input');
    if (cropSearchInput) {
      cropSearchInput.addEventListener('input', (e) => {
        this.setState({ cropSearchQuery: e.target.value });
      });
    }

    // Crop Recommendation Selection
    document.querySelectorAll('.crop-rec-card').forEach(card => {
      card.addEventListener('click', (e) => {
        const cropId = card.getAttribute('data-crop-id');
        this.setState({ selectedCropId: cropId });
      });
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const app = new AgroSenseApp();
  window.agroSenseApp = app;
  window.agrosenseApp = app;
});
