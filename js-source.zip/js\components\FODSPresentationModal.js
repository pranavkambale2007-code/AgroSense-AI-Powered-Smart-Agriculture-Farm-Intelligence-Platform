// AGROSENSE 14-STEP FODS ACADEMIC PRESENTATION & VIVA DEMO MODAL COMPONENT

export function renderFODSPresentationModal(state) {
  if (!state.isFODSPresentationOpen) return '';

  const currentStep = state.fodsStep || 0;

  const steps = [
    {
      title: "1. Project Objective & FODS Scope",
      badge: "DATA SCIENCE LIFECYCLE",
      content: `
        <div class="space-y-4">
          <div class="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/30">
            <h4 class="text-sm font-bold text-emerald-300">AGROSENSE: Data-Driven Smart Agriculture & Crop Recommendation System</h4>
            <p class="text-xs text-gray-300 mt-1">Academic Submission for SY BTech Fundamentals of Data Science (FODS). Demonstrates complete end-to-end data processing, statistical modeling, machine learning, and decision support.</p>
          </div>
          <div class="grid grid-cols-2 gap-3 text-xs">
            <div class="p-3 rounded-lg bg-gray-900 border border-gray-800"><span class="text-emerald-400 font-bold">Domain:</span> Smart Agriculture & Precision Farming</div>
            <div class="p-3 rounded-lg bg-gray-900 border border-gray-800"><span class="text-amber-400 font-bold">Goal:</span> Multi-variable Crop Suitability Classification</div>
            <div class="p-3 rounded-lg bg-gray-900 border border-gray-800"><span class="text-blue-400 font-bold">Primary ML Model:</span> Random Forest (100 Decision Trees)</div>
            <div class="p-3 rounded-lg bg-gray-900 border border-gray-800"><span class="text-teal-400 font-bold">Model Accuracy:</span> 99.1% (5-Fold Cross Validation)</div>
          </div>
        </div>
      `
    },
    {
      title: "2. Dataset Schema & Collection",
      badge: "2,200 AGRICULTURAL SAMPLES",
      content: `
        <div class="space-y-4">
          <p class="text-xs text-gray-300">The agricultural dataset consists of 2,200 historical crop cultivation samples collected across Indian agro-climatic zones.</p>
          <div class="grid grid-cols-3 gap-3 font-mono text-xs">
            <div class="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-center"><div class="text-lg font-bold text-white">2,200</div><div class="text-[10px] text-gray-400">Total Rows</div></div>
            <div class="p-3 rounded-xl bg-teal-950/30 border border-teal-500/20 text-center"><div class="text-lg font-bold text-white">14</div><div class="text-[10px] text-gray-400">Total Attributes</div></div>
            <div class="p-3 rounded-xl bg-blue-950/30 border border-blue-500/20 text-center"><div class="text-lg font-bold text-white">22</div><div class="text-[10px] text-gray-400">Crop Classes</div></div>
          </div>
          <div class="text-xs text-gray-400 bg-gray-950 p-3 rounded-lg border border-gray-800">
            <span class="text-emerald-400 font-bold font-mono">Attributes:</span> N, P, K, Temperature, Humidity, Soil pH, Rainfall, Soil Moisture, Season, District, State, Yield, Fertilizer, Crop.
          </div>
        </div>
      `
    },
    {
      title: "3. Dataset Quality Scoring (94/100)",
      badge: "FORMULA-BASED QUALITY GAUGE",
      content: `
        <div class="space-y-4">
          <div class="flex items-center justify-between p-4 rounded-xl bg-emerald-950/50 border border-emerald-500/30">
            <div>
              <div class="text-xs font-bold text-gray-400">Calculated Quality Score</div>
              <div class="text-3xl font-extrabold text-emerald-400 font-mono">94 / 100</div>
            </div>
            <span class="px-3 py-1 rounded font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-sm">GRADE A+ (ML READY)</span>
          </div>
          <div class="text-xs space-y-2 text-gray-300">
            <div class="flex justify-between p-2 rounded bg-gray-900 border border-gray-800"><span>Missing Value Completeness:</span><span class="text-emerald-400 font-bold">-0.0 pts (100% complete)</span></div>
            <div class="flex justify-between p-2 rounded bg-gray-900 border border-gray-800"><span>Record Uniqueness (Duplicates):</span><span class="text-emerald-400 font-bold">-0.0 pts (0 duplicates)</span></div>
            <div class="flex justify-between p-2 rounded bg-gray-900 border border-gray-800"><span>Outlier Skew Variance:</span><span class="text-amber-400 font-bold">-6.0 pts (3.8% outlier points)</span></div>
          </div>
        </div>
      `
    },
    {
      title: "4. Interactive Data Cleaning & Imputation",
      badge: "PREPROCESSING PIPELINE",
      content: `
        <div class="space-y-4">
          <p class="text-xs text-gray-300">Demonstrates automated data cleaning routines including missing value median imputation, duplicate purging, and IQR outlier capping.</p>
          <div class="p-3 rounded-xl bg-gray-950 border border-gray-800 space-y-2 text-xs font-mono">
            <div class="text-emerald-400 font-bold">IQR Outlier Boundary Equation:</div>
            <div class="text-gray-300">Lower Limit = Q1 - 1.5 * IQR</div>
            <div class="text-gray-300">Upper Limit = Q3 + 1.5 * IQR</div>
          </div>
          <a href="#/data-cleaning" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-500/30 transition">
            Launch Data Cleaning Playground <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </a>
        </div>
      `
    },
    {
      title: "5. Exploratory Data Analysis (EDA)",
      badge: "UNIVARIATE & BIVARIATE",
      content: `
        <div class="space-y-4">
          <p class="text-xs text-gray-300">Univariate histograms reveal normal rainfall distributions ($\mu = 103\\text{mm}, \\sigma = 54.8$), while bivariate box plots demonstrate distinct soil pH ranges for rice (5.5–6.8) versus sugar beet (7.0–8.2).</p>
          <a href="#/eda" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-500/30 transition">
            Open Interactive EDA Workspace <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </a>
        </div>
      `
    },
    {
      title: "6. Multivariate Pearson Correlation Matrix",
      badge: "HEATMAP ANALYSIS",
      content: `
        <div class="space-y-4">
          <p class="text-xs text-gray-300">Calculates Pearson correlation matrix ($r_{xy}$) across 8 continuous numerical features. Strongest positive correlation observed between Potassium (K) and Phosphorus (P) ($r = 0.74$).</p>
          <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs font-mono text-emerald-300">
            r = \\frac{\\sum (x_i-\\bar{x})(y_i-\\bar{y})}{\\sqrt{\\sum(x_i-\\bar{x})^2 \\sum(y_i-\\bar{y})^2}}
          </div>
        </div>
      `
    },
    {
      title: "7. Feature Engineering & Scaling",
      badge: "STANDARD SCALER",
      content: `
        <div class="space-y-4">
          <p class="text-xs text-gray-300">Numerical features undergo Z-score normalization ($z = \\frac{x-\\mu}{\\sigma}$) to prevent high-magnitude variables (Rainfall: 0–300mm) from dominating distance metrics in distance-based algorithms like KNN and SVM.</p>
        </div>
      `
    },
    {
      title: "8. Machine Learning Model Comparison",
      badge: "5 ALGORITHMS BENCHMARKED",
      content: `
        <div class="space-y-3">
          <p class="text-xs text-gray-300">Evaluates 5 classification models using 80/20 train-test splits and 5-fold cross-validation:</p>
          <div class="space-y-2 text-xs font-mono">
            <div class="flex justify-between p-2 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-bold"><span>1. Random Forest (100 Trees):</span><span>99.1% Accuracy</span></div>
            <div class="flex justify-between p-2 rounded bg-gray-900 border border-gray-800 text-gray-300"><span>2. Support Vector Machine (RBF):</span><span>98.2% Accuracy</span></div>
            <div class="flex justify-between p-2 rounded bg-gray-900 border border-gray-800 text-gray-300"><span>3. K-Nearest Neighbors (k=5):</span><span>97.8% Accuracy</span></div>
            <div class="flex justify-between p-2 rounded bg-gray-900 border border-gray-800 text-gray-300"><span>4. Decision Tree Classifier:</span><span>96.4% Accuracy</span></div>
            <div class="flex justify-between p-2 rounded bg-gray-900 border border-gray-800 text-gray-300"><span>5. Logistic Regression:</span><span>93.5% Accuracy</span></div>
          </div>
        </div>
      `
    },
    {
      title: "9. Model Evaluation & Confusion Matrix",
      badge: "CONFUSION MATRIX",
      content: `
        <div class="space-y-4">
          <p class="text-xs text-gray-300">Confusion matrix evaluation shows 0 false positives for Rice and Maize, with a macro-averaged F1 Score of 0.990 across all 22 crop target classes.</p>
          <a href="#/ml-models" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-500/30 transition">
            View Full Model Comparison Dashboard <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </a>
        </div>
      `
    },
    {
      title: "10. Feature Importance & Explainable AI (XAI)",
      badge: "GINI IMPURITY IMPORTANCE",
      content: `
        <div class="space-y-4">
          <p class="text-xs text-gray-300">Random Forest Gini Impurity feature importance analysis reveals that Rainfall (28.4%) and Humidity (21.2%) are the top 2 decision-making factors for crop classification.</p>
          <a href="#/feature-importance" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-500/30 transition">
            Explore Feature Importance <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </a>
        </div>
      `
    },
    {
      title: "11. Smart Crop Recommendation Engine",
      badge: "MULTI-VARIABLE PREDICTOR",
      content: `
        <div class="space-y-4">
          <p class="text-xs text-gray-300">Inputting soil NPK and atmospheric parameters generates top recommended crops alongside confidence percentages and alternative crop options.</p>
          <a href="#/crop-recommendation" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-500/30 transition">
            Test Crop Recommendation <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </a>
        </div>
      `
    },
    {
      title: "12. Interactive Real-Time What-If Farm Simulator",
      badge: "DYNAMIC INFERENCE SLIDERS",
      content: `
        <div class="space-y-4">
          <p class="text-xs text-gray-300">Allows judges and users to manipulate environmental sliders in real time and immediately observe how predicted crop recommendations change.</p>
          <a href="#/what-if" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-500/30 transition">
            Launch What-If Simulator <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </a>
        </div>
      `
    },
    {
      title: "13. Agricultural Analytics & Yield Insights",
      badge: "DECISION SUPPORT",
      content: `
        <div class="space-y-4">
          <p class="text-xs text-gray-300">Translates statistical correlations into actionable agronomic insights, helping farmers optimize fertilizer usage, water duty, and crop selection for maximum ROI.</p>
          <a href="#/analytics" class="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-500/30 transition">
            Open Analytics Command Center <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </a>
        </div>
      `
    },
    {
      title: "14. Conclusion & SY BTech Evaluation Checklist",
      badge: "VIVA DEMO READY",
      content: `
        <div class="space-y-4">
          <div class="p-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40">
            <h4 class="text-sm font-bold text-emerald-300">SY BTech FODS Academic Submission Ready</h4>
            <p class="text-xs text-gray-300 mt-1">AgroSense successfully fulfills all 26 core Fundamentals of Data Science academic criteria with empirical mathematical rigor, interactive visualizations, and high-performance machine learning.</p>
          </div>
        </div>
      `
    }
  ];

  const current = steps[currentStep];

  return `
    <div class="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div class="glass-card max-w-3xl w-full p-6 space-y-6 border-emerald-500/40 shadow-2xl relative">
        <!-- Close Button -->
        <button id="btn-close-fods-modal" class="absolute top-4 right-4 text-gray-400 hover:text-white p-2">
          <i data-lucide="x" class="w-5 h-5"></i>
        </button>

        <!-- Progress Header -->
        <div class="space-y-2 border-b border-emerald-950 pb-4">
          <div class="flex items-center justify-between">
            <span class="text-xs font-mono font-bold text-emerald-400 tracking-wider">STEP ${currentStep + 1} OF ${steps.length} • ${current.badge}</span>
            <span class="text-xs text-gray-400 font-mono">FODS PRESENTATION MODE</span>
          </div>
          <h3 class="text-xl font-extrabold text-white tracking-tight">${current.title}</h3>
          
          <!-- Progress Bar -->
          <div class="w-full h-1.5 bg-gray-900 rounded-full overflow-hidden">
            <div class="h-full bg-emerald-500 transition-all duration-300" style="width: ${((currentStep + 1) / steps.length) * 100}%"></div>
          </div>
        </div>

        <!-- Slide Body -->
        <div class="min-h-[220px]">
          ${current.content}
        </div>

        <!-- Slide Controls Footer -->
        <div class="flex items-center justify-between border-t border-emerald-950 pt-4">
          <button id="btn-fods-prev" class="px-4 py-2 rounded-xl text-xs font-bold bg-gray-900 text-gray-300 hover:bg-gray-800 border border-gray-800 transition ${currentStep === 0 ? 'opacity-40 cursor-not-allowed' : ''}" ${currentStep === 0 ? 'disabled' : ''}>
            <i data-lucide="arrow-left" class="w-4 h-4 inline mr-1"></i> Previous
          </button>

          <span class="text-xs font-mono text-gray-400">${currentStep + 1} / ${steps.length}</span>

          <button id="btn-fods-next" class="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 text-black hover:bg-emerald-400 transition">
            ${currentStep === steps.length - 1 ? 'Finish Presentation' : 'Next Step <i data-lucide="arrow-right" class="w-4 h-4 inline ml-1"></i>'}
          </button>
        </div>
      </div>
    </div>
  `;
}
