// AgroSense Weather Intelligence Page Component

const { fetchLiveOrDemoWeather } = require('js/services/weatherService.js');

function renderWeatherPage(state) {
  const weather = state.weatherData || {
    isLiveApi: false,
    sourceLabel: "Demo Weather Mode (Prototype Data)",
    temp: 26.8,
    humidity: 68,
    windSpeed: 12.4,
    windDirection: "NW (315°)",
    solarRadiation: 785,
    et0: 4.8,
    dewPoint: 19.5,
    uvIndex: 7,
    pressure: 1012,
    vpd: 1.15,
    condition: "Partly Cloudy",
    rainProb: 25,
    forecast: [
      { day: "Today", maxTemp: 28, minTemp: 19, rainProb: 25, rainSum: 0.5, condition: "Partly Cloudy" },
      { day: "Tomorrow", maxTemp: 31, minTemp: 20, rainProb: 65, rainSum: 14.2, condition: "Heavy Rain" },
      { day: "Wed", maxTemp: 29, minTemp: 18, rainProb: 30, rainSum: 2.0, condition: "Light Rain" },
      { day: "Thu", maxTemp: 32, minTemp: 21, rainProb: 10, rainSum: 0, condition: "Sunny" },
      { day: "Fri", maxTemp: 34, minTemp: 22, rainProb: 5, rainSum: 0, condition: "Heat Stress" },
      { day: "Sat", maxTemp: 33, minTemp: 21, rainProb: 15, rainSum: 0, condition: "Clear" },
      { day: "Sun", maxTemp: 30, minTemp: 19, rainProb: 20, rainSum: 0, condition: "Partly Cloudy" }
    ],
    hourly: [
      { time: "06:00", temp: 20, humidity: 85 },
      { time: "09:00", temp: 24, humidity: 72 },
      { time: "12:00", temp: 28, humidity: 62 },
      { time: "15:00", temp: 29, humidity: 58 },
      { time: "18:00", temp: 26, humidity: 68 },
      { time: "21:00", temp: 22, humidity: 78 }
    ]
  };

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="cloud-sun" class="w-6 h-6 text-emerald-400"></i>
            Agricultural Weather Intelligence
          </h1>
          <p class="text-xs text-gray-400">Microclimate forecasts, ET0 evapotranspiration rates, solar radiation, and agricultural action advisories</p>
        </div>
        <div class="flex items-center gap-2">
          <span class="prototype-badge">${weather.sourceLabel}</span>
        </div>
      </div>

      <!-- Current Weather Overview Header -->
      <div class="glass-card-accent p-6 flex flex-wrap items-center justify-between gap-6">
        <div class="flex items-center gap-5">
          <div class="w-16 h-16 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center">
            <i data-lucide="cloud-sun" class="w-9 h-9"></i>
          </div>
          <div>
            <div class="text-3xl font-extrabold text-white font-mono">${weather.temp}°C</div>
            <p class="text-sm font-semibold text-emerald-300">${weather.condition} • ${state.activeFarm ? state.activeFarm.location : 'Pune Region'}</p>
            <p class="text-xs text-gray-400 mt-1">Humidity: ${weather.humidity}% | Wind: ${weather.windSpeed} km/h | Rain Prob: ${weather.rainProb}%</p>
          </div>
        </div>

        <!-- Agriculture Specific Interpretation Box -->
        <div class="p-4 rounded-xl bg-emerald-950/80 border border-emerald-700/50 space-y-1.5 max-w-lg">
          <span class="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
            <i data-lucide="zap" class="w-4 h-4 text-amber-400"></i>
            Agricultural Action Advisory:
          </span>
          <p class="text-xs text-gray-200 leading-relaxed">
            "Moderate rainfall (14.2mm) predicted for tomorrow. Evapotranspiration ET0 is 4.8 mm/day. Delay planned drip pulse irrigation to prevent nitrogen leaching."
          </p>
        </div>
      </div>

      <!-- KEY AGRICULTURAL MICROCLIMATE FACTORS MATRIX -->
      <div class="glass-card p-6 space-y-4">
        <h3 class="text-sm font-extrabold text-white flex items-center gap-2">
          <i data-lucide="sun-medium" class="w-4 h-4 text-amber-400"></i>
          Key Agronomic Microclimate Factors & ET0 Metrics
        </h3>

        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 text-center font-mono text-xs">
          <div class="p-3.5 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span class="text-[10px] text-gray-400 uppercase font-sans block">Evapotranspiration</span>
            <div class="text-base font-extrabold text-blue-300">${weather.et0 || 4.8} <span class="text-[10px] font-normal">mm/day</span></div>
            <span class="text-[9px] text-emerald-400 block font-sans">FAO-56 ET0</span>
          </div>

          <div class="p-3.5 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span class="text-[10px] text-gray-400 uppercase font-sans block">Solar Radiation</span>
            <div class="text-base font-extrabold text-amber-300">${weather.solarRadiation || 785} <span class="text-[10px] font-normal">W/m²</span></div>
            <span class="text-[9px] text-amber-400 block font-sans">Photosynthetic PAR</span>
          </div>

          <div class="p-3.5 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span class="text-[10px] text-gray-400 uppercase font-sans block">VPD Deficit</span>
            <div class="text-base font-extrabold text-teal-300">${weather.vpd || 1.15} <span class="text-[10px] font-normal">kPa</span></div>
            <span class="text-[9px] text-teal-400 block font-sans">Stomatal Conductance</span>
          </div>

          <div class="p-3.5 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span class="text-[10px] text-gray-400 uppercase font-sans block">Dew Point</span>
            <div class="text-base font-extrabold text-purple-300">${weather.dewPoint || 19.5} <span class="text-[10px] font-normal">°C</span></div>
            <span class="text-[9px] text-purple-400 block font-sans">Foliar Condensation</span>
          </div>

          <div class="p-3.5 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span class="text-[10px] text-gray-400 uppercase font-sans block">UV Index</span>
            <div class="text-base font-extrabold text-pink-300">${weather.uvIndex || 7} <span class="text-[10px] font-normal">Very High</span></div>
            <span class="text-[9px] text-pink-400 block font-sans">Sunburn Risk</span>
          </div>

          <div class="p-3.5 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span class="text-[10px] text-gray-400 uppercase font-sans block">Wind Vector</span>
            <div class="text-base font-extrabold text-emerald-300">${weather.windDirection || 'NW (315°)'}</div>
            <span class="text-[9px] text-emerald-400 block font-sans">${weather.windSpeed || 12.4} km/h</span>
          </div>

          <div class="p-3.5 rounded-xl bg-gray-900 border border-gray-800 space-y-1">
            <span class="text-[10px] text-gray-400 uppercase font-sans block">Barometric Pres.</span>
            <div class="text-base font-extrabold text-orange-300">${weather.pressure || 1012} <span class="text-[10px] font-normal">hPa</span></div>
            <span class="text-[9px] text-orange-400 block font-sans">Atmospheric Pressure</span>
          </div>
        </div>
      </div>

      <!-- 7-Day Forecast Cards -->
      <div class="space-y-3">
        <h3 class="text-sm font-bold text-white uppercase tracking-wider">7-Day Agricultural Forecast</h3>
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          ${weather.forecast.map((f, idx) => `
            <div class="glass-card p-3.5 text-center space-y-2 ${idx === 1 ? 'border-amber-400 bg-amber-950/20' : ''}">
              <span class="text-xs font-bold text-gray-300 block">${f.day}</span>
              <div class="py-1">
                <i data-lucide="${f.rainProb > 50 ? 'cloud-rain' : f.maxTemp > 32 ? 'sun' : 'cloud-sun'}" class="w-7 h-7 mx-auto ${f.rainProb > 50 ? 'text-blue-400' : 'text-amber-400'}"></i>
              </div>
              <div class="text-sm font-bold text-white font-mono">${f.maxTemp}° / ${f.minTemp}°</div>
              <div class="text-[11px] font-semibold text-emerald-400">${f.rainProb}% Rain</div>
              <span class="text-[10px] text-gray-400 block truncate">${f.condition}</span>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

/* Module Exports */
exports.renderWeatherPage = renderWeatherPage;
