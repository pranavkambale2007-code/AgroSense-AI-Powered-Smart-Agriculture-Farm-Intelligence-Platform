// AgroSense Model Management & API Test Harness Component (/admin/models)

const { CropRecommendationContract,
  SoilAnalysisContract,
  DiseaseDetectionContract,
  IrrigationContract,
  WeatherRiskContract,
  FarmHealthScoreContract } = require('js/ml/interfaces.js');

function renderModelManagementPage(state) {
  const models = [
    {
      id: "model-crop-rec",
      name: "Crop Recommendation Engine",
      type: "XAI Multi-Factor Model / RandomForest ML",
      status: "Local Mathematical Engine Active",
      version: "v2.4.1",
      accuracy: "94.2%",
      endpoint: "/api/v1/recommend/crop",
      contract: CropRecommendationContract,
      samplePayload: JSON.stringify({ nitrogen: 185, phosphorus: 34, potassium: 310, ph: 7.2, temperature: 24.5, moisture: 32.4 }, null, 2)
    },
    {
      id: "model-soil-chem",
      name: "Soil Chemistry Bio-Availability Model",
      type: "NPK Fixation Math & pH Penalty Engine",
      status: "Local Mathematical Engine Active",
      version: "v2.0.0",
      accuracy: "98.0%",
      endpoint: "/api/v1/soil/analyze",
      contract: SoilAnalysisContract,
      samplePayload: JSON.stringify({ nitrogen: 185, phosphorus: 34, potassium: 310, ph: 7.2, organicCarbon: 0.58 }, null, 2)
    },
    {
      id: "model-disease-vision",
      name: "Plant Disease AI Vision Classifier",
      type: "MobileNet / ResNet Vision Pipeline",
      status: "Demo Vision Classifier Active",
      version: "v1.8.0",
      accuracy: "91.8%",
      endpoint: "/api/v1/vision/leaf-screen",
      contract: DiseaseDetectionContract,
      samplePayload: JSON.stringify({ cropContext: "Wheat", sampleId: "disease-01" }, null, 2)
    },
    {
      id: "model-irrigation-et0",
      name: "FAO-56 Penman-Monteith ET0 Engine",
      type: "Hargreaves / Penman-Monteith Solver",
      status: "Mathematical ET0 Solver Active",
      version: "v3.1.0",
      accuracy: "96.5%",
      endpoint: "/api/v1/irrigation/schedule",
      contract: IrrigationContract,
      samplePayload: JSON.stringify({ currentSoilMoisturePct: 32.4, cropType: "Wheat", growthStage: "Vegetative", tempC: 26.8, windSpeedKmH: 12.4 }, null, 2)
    }
  ];

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Header -->
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="cpu" class="w-6 h-6 text-emerald-400"></i>
            ML Microservice Interface Registry & API Test Harness
          </h1>
          <p class="text-xs text-gray-400">Pluggable REST/gRPC ML adapters allowing real trained models to replace internal agronomic engines without touching the frontend</p>
        </div>
        <span class="prototype-badge font-mono">MODULAR ML ADAPTER ARCHITECTURE</span>
      </div>

      <!-- Model Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        ${models.map(m => `
          <div class="glass-card p-6 space-y-4">
            <div class="flex items-center justify-between">
              <div>
                <h3 class="text-base font-bold text-white">${m.name}</h3>
                <p class="text-xs text-gray-400">${m.type}</p>
              </div>
              <span class="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                ${m.status}
              </span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs">
              <div class="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
                <span class="text-gray-400 block text-[10px]">Model Version</span>
                <span class="font-mono font-bold text-white">${m.version}</span>
              </div>
              <div class="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
                <span class="text-gray-400 block text-[10px]">Validation Score</span>
                <span class="font-mono font-bold text-emerald-400">${m.accuracy}</span>
              </div>
            </div>

            <!-- API Interface Schema Box -->
            <div class="p-3 rounded-xl bg-gray-950/80 border border-emerald-950 text-xs space-y-2">
              <div class="flex items-center justify-between text-[11px]">
                <span class="font-bold text-amber-300 font-mono">${m.endpoint}</span>
                <span class="text-gray-400">REST JSON Adapter</span>
              </div>
              
              <!-- Code Payload Preview -->
              <pre class="p-2.5 rounded-lg bg-black text-[10px] text-emerald-400 font-mono overflow-x-auto max-h-32 border border-emerald-950">${m.samplePayload}</pre>
            </div>

            <button class="test-ml-adapter-btn w-full py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs shadow-md transition" data-model-id="${m.id}">
              ⚡ Test Live Payload via ML Adapter
            </button>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

/* Module Exports */
exports.renderModelManagementPage = renderModelManagementPage;
