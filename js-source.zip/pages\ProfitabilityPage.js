// AgroSense Dynamic Crop Profitability & Financial Matrix Page Component
// Supports adding, editing, and deleting cost matrix categories and expenditure items in real time

const { calculateCropProfitability } = require('js/services/marketService.js');

const standardBenchmarkCostItems = exports.standardBenchmarkCostItems = [
  { id: "cost-1", category: "Seeds & Sowing", costPerAcre: 3500 },
  { id: "cost-2", category: "Fertilizer & Soil Nutrition", costPerAcre: 6200 },
  { id: "cost-3", category: "Labor & Field Operations", costPerAcre: 12000 },
  { id: "cost-4", category: "Irrigation & Energy", costPerAcre: 4500 },
  { id: "cost-5", category: "Pesticides & Crop Protection", costPerAcre: 3800 },
  { id: "cost-6", category: "Machinery, Fuel & Rent", costPerAcre: 2500 }
];

function renderProfitabilityPage(state) {
  const p = state.profitParams || {};
  const acres = Number(p.acres) || (state.activeFarm ? state.activeFarm.sizeAcres : 5);
  const crop = p.crop || (state.activeFarm ? state.activeFarm.currentCrop : "Wheat");
  
  // Dynamic cost matrix: use custom items or fall back to standard benchmarks
  const costItems = (Array.isArray(p.costItems) && p.costItems.length > 0)
    ? p.costItems
    : standardBenchmarkCostItems;

  const expectedYieldPerAcre = Number(p.expectedYieldPerAcre) || 22;
  const expectedPricePerUnit = Number(p.expectedPricePerUnit) || 2275;

  const result = calculateCropProfitability({
    farmSizeAcres: acres,
    costItems: costItems,
    expectedYieldPerAcre: expectedYieldPerAcre,
    expectedPricePerUnit: expectedPricePerUnit
  });

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-extrabold text-white flex items-center gap-2">
            <i data-lucide="calculator" class="w-6 h-6 text-emerald-400"></i>
            Crop Profitability & Financial Projections
          </h1>
          <p class="text-xs text-gray-400">Calculate Gross Margin, Cost of Production per Acre & Projected Return on Investment (ROI)</p>
        </div>
        <div class="flex items-center gap-2">
          <span class="prototype-badge">DYNAMIC FINANCIAL MATRIX</span>
          <button id="btn-reset-cost-matrix" class="px-3 py-1.5 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800/40 text-emerald-300 text-xs font-bold transition cursor-pointer flex items-center gap-1.5" title="Reset cost items to standard ICAR benchmarks">
            <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
            Reset to Benchmarks
          </button>
        </div>
      </div>

      <!-- INTERACTIVE PRODUCTION PARAMETERS -->
      <div class="glass-card p-5 border border-emerald-800/40 rounded-2xl bg-[#091812]/90 space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-2">
            <i data-lucide="sliders" class="w-3.5 h-3.5"></i>
            Farm & Production Parameters
          </h3>
          <span class="text-[11px] text-gray-400 font-mono">Live Sync Active</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
          <div class="space-y-1">
            <label class="block text-gray-400 font-bold">Land Size (Acres)</label>
            <input type="number" id="profit-acres" value="${acres}" min="1" max="500" class="w-full bg-gray-900/90 border border-emerald-700/60 rounded-xl px-3 py-2 text-white font-mono font-bold focus:outline-none focus:border-emerald-400" />
          </div>

          <div class="space-y-1">
            <label class="block text-gray-400 font-bold">Cultivated Crop</label>
            <input type="text" id="profit-crop-name" value="${crop}" class="w-full bg-gray-900/90 border border-emerald-700/60 rounded-xl px-3 py-2 text-white font-semibold focus:outline-none focus:border-emerald-400" placeholder="e.g. Wheat, Cotton, Soybean" />
          </div>

          <div class="space-y-1">
            <label class="block text-gray-400 font-bold">Expected Yield (Qtl / Acre)</label>
            <input type="number" id="profit-yield" value="${expectedYieldPerAcre}" step="0.5" min="1" class="w-full bg-gray-900/90 border border-emerald-700/60 rounded-xl px-3 py-2 text-emerald-300 font-mono font-extrabold focus:outline-none focus:border-emerald-400" />
          </div>

          <div class="space-y-1">
            <label class="block text-gray-400 font-bold">Market Price (₹ / Quintal)</label>
            <input type="number" id="profit-price" value="${expectedPricePerUnit}" step="50" min="100" class="w-full bg-gray-900/90 border border-emerald-700/60 rounded-xl px-3 py-2 text-amber-300 font-mono font-extrabold focus:outline-none focus:border-emerald-400" />
          </div>
        </div>
      </div>

      <!-- Financial Summary Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- Total Cost -->
        <div class="glass-card p-5 space-y-1 border-l-4 border-l-red-500 rounded-2xl bg-[#091812]/90">
          <span class="text-xs font-bold text-gray-400">Total Input Cost (${acres} Acres)</span>
          <div class="text-2xl font-black text-white font-mono">₹${result.summary.totalCostOverall.toLocaleString()}</div>
          <p class="text-[11px] text-gray-400 font-mono">₹${Math.round(result.summary.totalCostPerAcre).toLocaleString()} / Acre</p>
        </div>

        <!-- Revenue -->
        <div class="glass-card p-5 space-y-1 border-l-4 border-l-blue-500 rounded-2xl bg-[#091812]/90">
          <span class="text-xs font-bold text-gray-400">Estimated Gross Revenue</span>
          <div class="text-2xl font-black text-blue-300 font-mono">₹${result.summary.totalRevenueOverall.toLocaleString()}</div>
          <p class="text-[11px] text-gray-400 font-mono">${expectedYieldPerAcre * acres} Qtl @ ₹${expectedPricePerUnit.toLocaleString()}</p>
        </div>

        <!-- Net Profit -->
        <div class="glass-card-accent p-5 space-y-1 border-l-4 border-l-emerald-500 rounded-2xl bg-[#0b241b]">
          <span class="text-xs font-bold text-emerald-300">Estimated Net Profit</span>
          <div class="text-2xl font-black ${result.summary.isProfitable ? 'text-emerald-400' : 'text-red-400'} font-mono">
            ₹${result.summary.grossMarginOverall.toLocaleString()}
          </div>
          <p class="text-[11px] text-emerald-300 font-semibold font-mono">
            ₹${Math.round(result.summary.grossMarginPerAcre).toLocaleString()} Net Profit / Acre
          </p>
        </div>

        <!-- Projected ROI -->
        <div class="glass-card p-5 space-y-1 border-l-4 border-l-amber-500 rounded-2xl bg-[#091812]/90">
          <span class="text-xs font-bold text-gray-400">Projected Return on Investment (ROI)</span>
          <div class="text-2xl font-black text-amber-300 font-mono">${result.summary.roiPercentage > 0 ? '+' : ''}${result.summary.roiPercentage}%</div>
          <p class="text-[11px] ${result.summary.isProfitable ? 'text-emerald-400' : 'text-red-400'} font-semibold">
            ${result.summary.isProfitable ? 'Net Profitable Scenario' : 'Deficit / Loss Scenario'}
          </p>
        </div>
      </div>

      <!-- INPUT COST MATRIX BREAKDOWN (MANUALLY ADDED, CHANGE, AND DELETE) -->
      <div class="glass-card p-6 border border-emerald-800/40 rounded-2xl bg-[#091812]/90 space-y-5">
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-emerald-950/80 pb-4">
          <div>
            <h3 class="text-sm font-extrabold text-white flex items-center gap-2">
              <i data-lucide="table-properties" class="w-4 h-4 text-emerald-400"></i>
              Input Cost Matrix Breakdown
            </h3>
            <p class="text-xs text-gray-400 mt-0.5">Manually add, change amounts, edit category names, and delete expenditure items</p>
          </div>
          <span class="text-[11px] font-mono font-bold text-emerald-400 bg-emerald-950/80 px-2.5 py-1 rounded-xl border border-emerald-800/40">
            ${costItems.length} Categories • ₹${result.summary.totalCostPerAcre.toLocaleString()}/Acre
          </span>
        </div>

        <!-- Add New Cost Item Quick Form -->
        <div class="p-4 rounded-xl bg-black/40 border border-emerald-800/40 space-y-3">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
              <i data-lucide="plus-circle" class="w-3.5 h-3.5 text-emerald-400"></i>
              Add New Custom Cost Category
            </span>
            <span class="text-[10px] text-gray-500 font-mono">Appends to Cost Matrix</span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
            <div class="sm:col-span-6">
              <input type="text" id="new-cost-category" placeholder="Cost Category Name (e.g. Mulching Sheet, Organic Compost, Transport)" class="w-full bg-gray-900 border border-emerald-700/60 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400" />
            </div>
            <div class="sm:col-span-3">
              <div class="relative">
                <span class="absolute left-3 top-2 text-gray-400 text-xs font-mono">₹</span>
                <input type="number" id="new-cost-amount" placeholder="Cost (₹/Acre)" step="100" min="0" class="w-full bg-gray-900 border border-emerald-700/60 rounded-xl pl-7 pr-3 py-2 text-xs text-white placeholder-gray-500 font-mono font-bold focus:outline-none focus:border-emerald-400" />
              </div>
            </div>
            <div class="sm:col-span-3">
              <button id="btn-add-cost-item" class="w-full py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-md transition flex items-center justify-center gap-1.5 cursor-pointer">
                <i data-lucide="plus" class="w-4 h-4"></i>
                <span>Add Cost Item</span>
              </button>
            </div>
          </div>

          <!-- Quick Preset Chips -->
          <div class="flex flex-wrap items-center gap-1.5 pt-1 text-[11px]">
            <span class="text-gray-500 text-[10px] uppercase font-mono mr-1">Quick Add:</span>
            <button class="quick-preset-btn px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800/40 text-emerald-300 text-[11px] font-medium transition cursor-pointer" data-cat="Mulching Sheet & Clips" data-cost="2200">
              + Mulching (₹2,200)
            </button>
            <button class="quick-preset-btn px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800/40 text-emerald-300 text-[11px] font-medium transition cursor-pointer" data-cat="Organic Compost & FYM" data-cost="3500">
              + Organic Compost (₹3,500)
            </button>
            <button class="quick-preset-btn px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800/40 text-emerald-300 text-[11px] font-medium transition cursor-pointer" data-cat="Soil Health Testing" data-cost="650">
              + Soil Testing (₹650)
            </button>
            <button class="quick-preset-btn px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800/40 text-emerald-300 text-[11px] font-medium transition cursor-pointer" data-cat="Mandi Transport & Loading" data-cost="1600">
              + Mandi Transport (₹1,600)
            </button>
            <button class="quick-preset-btn px-2.5 py-1 rounded-lg bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-800/40 text-emerald-300 text-[11px] font-medium transition cursor-pointer" data-cat="Micro-Nutrients Spray" data-cost="1400">
              + Micro-Nutrients (₹1,400)
            </button>
          </div>
        </div>

        <!-- Editable Cost Matrix Table -->
        <div class="overflow-x-auto">
          <table class="w-full text-left border-collapse text-xs">
            <thead>
              <tr class="border-b border-emerald-800/60 bg-[#07130e] text-gray-400 uppercase tracking-wider font-extrabold text-[11px]">
                <th class="p-3 w-8">#</th>
                <th class="p-3">Cost Category (Click to Edit)</th>
                <th class="p-3 w-40">Cost per Acre (₹)</th>
                <th class="p-3 w-44">Total Farm Cost (${acres} Ac)</th>
                <th class="p-3 w-44">Share of Cost (%)</th>
                <th class="p-3 w-16 text-center">Action</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-emerald-950/60">
              ${result.costBreakdown.map((item, idx) => `
                <tr class="hover:bg-emerald-950/30 transition group">
                  <td class="p-3 text-gray-500 font-mono text-[11px]">${idx + 1}</td>
                  
                  <!-- Editable Category Name -->
                  <td class="p-3">
                    <input type="text" data-id="${item.id}" class="cost-item-cat-input w-full max-w-sm bg-transparent hover:bg-gray-900/80 focus:bg-gray-900 border border-transparent hover:border-emerald-800/50 focus:border-emerald-400 rounded-lg px-2.5 py-1 text-xs text-white font-semibold transition" value="${item.category}" title="Edit category name" />
                  </td>

                  <!-- Editable Cost per Acre -->
                  <td class="p-3">
                    <div class="flex items-center gap-1.5">
                      <span class="text-gray-400 font-mono text-xs">₹</span>
                      <input type="number" step="50" min="0" data-id="${item.id}" class="cost-item-val-input w-28 bg-gray-900/90 border border-emerald-700/60 focus:border-emerald-400 rounded-lg px-2.5 py-1 text-xs text-emerald-300 font-mono font-bold transition shadow-inner" value="${item.costPerAcre}" title="Edit cost per acre" />
                    </div>
                  </td>

                  <!-- Calculated Total Cost -->
                  <td class="p-3 font-mono font-extrabold text-white text-xs">
                    ₹${item.cost.toLocaleString()}
                  </td>

                  <!-- Percentage & Progress Bar -->
                  <td class="p-3">
                    <div class="space-y-1">
                      <div class="flex justify-between text-[11px] font-mono text-gray-300">
                        <span>${item.percentage}%</span>
                      </div>
                      <div class="w-full h-1.5 rounded-full bg-gray-900 overflow-hidden">
                        <div class="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full" style="width: ${item.percentage}%"></div>
                      </div>
                    </div>
                  </td>

                  <!-- Delete Action -->
                  <td class="p-3 text-center">
                    <button class="btn-delete-cost-item p-1.5 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-500/20 border border-transparent hover:border-red-500/30 transition cursor-pointer" data-id="${item.id}" title="Delete this expenditure item">
                      <i data-lucide="trash-2" class="w-4 h-4"></i>
                    </button>
                  </td>
                </tr>
              `).join('')}

              ${result.costBreakdown.length === 0 ? `
                <tr>
                  <td colspan="6" class="p-8 text-center space-y-2">
                    <p class="text-xs text-gray-300 font-semibold">No Cost Categories in Matrix</p>
                    <p class="text-[11px] text-gray-500">All cost items were removed. Add a new item above or reset to standard benchmarks.</p>
                  </td>
                </tr>
              ` : ''}
            </tbody>

            <!-- Total Summary Footer Row -->
            <tfoot class="border-t-2 border-emerald-800/80 bg-[#07130e] font-bold text-xs">
              <tr>
                <td class="p-3 text-gray-400">Total</td>
                <td class="p-3 text-white">Aggregated Input Expenditure</td>
                <td class="p-3 text-emerald-300 font-mono">₹${result.summary.totalCostPerAcre.toLocaleString()} / Acre</td>
                <td class="p-3 text-white font-mono text-sm font-black">₹${result.summary.totalCostOverall.toLocaleString()}</td>
                <td class="p-3 text-emerald-400 font-mono">100% Allocated</td>
                <td class="p-3"></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  `;
}

function initProfitabilityHooks(state, setState) {
  const p = state.profitParams || {};
  let currentCostItems = (Array.isArray(p.costItems) && p.costItems.length > 0)
    ? [...p.costItems]
    : [...standardBenchmarkCostItems];

  const updateState = (newCostItems = null, otherUpdates = {}) => {
    const updatedCostItems = newCostItems !== null ? newCostItems : currentCostItems;
    const acres = Number(document.getElementById('profit-acres')?.value) || (Number(p.acres) || 5);
    const crop = document.getElementById('profit-crop-name')?.value || (p.crop || "Wheat");
    const expectedYieldPerAcre = Number(document.getElementById('profit-yield')?.value) || (Number(p.expectedYieldPerAcre) || 22);
    const expectedPricePerUnit = Number(document.getElementById('profit-price')?.value) || (Number(p.expectedPricePerUnit) || 2275);

    const newProfitParams = {
      acres,
      crop,
      costItems: updatedCostItems,
      expectedYieldPerAcre,
      expectedPricePerUnit,
      ...otherUpdates
    };

    try {
      localStorage.setItem('agrosense_profit_params', JSON.stringify(newProfitParams));
    } catch (e) {}

    if (setState) {
      setState({ profitParams: newProfitParams });
    } else if (window.agroSenseApp && window.agroSenseApp.setState) {
      window.agroSenseApp.setState({ profitParams: newProfitParams });
    }
  };

  // 1. Change existing cost category name
  document.querySelectorAll('.cost-item-cat-input').forEach(input => {
    input.addEventListener('change', (e) => {
      const id = e.target.getAttribute('data-id');
      const newName = e.target.value.trim() || 'Custom Expense';
      const updated = currentCostItems.map(item => 
        item.id === id ? { ...item, category: newName } : item
      );
      updateState(updated);
    });
  });

  // 2. Change existing cost amount (₹/Acre)
  document.querySelectorAll('.cost-item-val-input').forEach(input => {
    input.addEventListener('change', (e) => {
      const id = e.target.getAttribute('data-id');
      const newCost = Math.max(0, Number(e.target.value) || 0);
      const updated = currentCostItems.map(item => 
        item.id === id ? { ...item, costPerAcre: newCost } : item
      );
      updateState(updated);
    });
  });

  // 3. Delete cost category
  document.querySelectorAll('.btn-delete-cost-item').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.getAttribute('data-id');
      const updated = currentCostItems.filter(item => item.id !== id);
      updateState(updated);
    });
  });

  // 4. Manually add new cost item
  const addBtn = document.getElementById('btn-add-cost-item');
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      const catInput = document.getElementById('new-cost-category');
      const costInput = document.getElementById('new-cost-amount');
      const cat = catInput?.value.trim() || 'Custom Farm Operation';
      const cost = Math.max(0, Number(costInput?.value) || 0);

      if (cost <= 0 && !catInput?.value.trim()) {
        if (catInput) catInput.focus();
        return;
      }

      const newItem = {
        id: `cost-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        category: cat,
        costPerAcre: cost
      };

      const updated = [...currentCostItems, newItem];
      updateState(updated);
    });
  }

  // 5. Quick Preset Chips
  document.querySelectorAll('.quick-preset-btn').forEach(chip => {
    chip.addEventListener('click', () => {
      const cat = chip.getAttribute('data-cat') || 'Extra Operation';
      const cost = Number(chip.getAttribute('data-cost')) || 1000;
      const newItem = {
        id: `cost-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        category: cat,
        costPerAcre: cost
      };
      const updated = [...currentCostItems, newItem];
      updateState(updated);
    });
  });

  // 6. Reset to standard ICAR benchmarks
  const resetBtn = document.getElementById('btn-reset-cost-matrix');
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      updateState([...standardBenchmarkCostItems]);
    });
  }

  // 7. General parameter input changes (Acres, Yield, Price)
  ['profit-acres', 'profit-crop-name', 'profit-yield', 'profit-price'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('change', () => {
        updateState();
      });
    }
  });
}

/* Module Exports */
exports.renderProfitabilityPage = renderProfitabilityPage; exports.initProfitabilityHooks = initProfitabilityHooks;
