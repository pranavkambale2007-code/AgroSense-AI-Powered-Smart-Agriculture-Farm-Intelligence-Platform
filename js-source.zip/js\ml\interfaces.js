/**
 * AGROSENSE STANDARDIZED ML MICROSERVICE INTERFACE CONTRACTS
 * These interface definitions allow real ML trained models (RandomForest, ResNet/MobileNet,
 * FAO-56 Penman-Monteith ET0, XGBoost risk classifier) to replace demo/local engines
 * without altering any frontend UI code or component API.
 */

/**
 * 1. Crop Recommendation Model Contract
 */
export const CropRecommendationContract = {
  requestSchema: {
    nitrogen: "number (kg/ha)",
    phosphorus: "number (kg/ha)",
    potassium: "number (kg/ha)",
    ph: "number (3.0 - 10.0)",
    temperature: "number (°C)",
    humidity: "number (%)",
    rainfall: "number (mm)",
    soilType: "string",
    irrigationType: "string"
  },
  responseSchema: {
    recommendations: [
      {
        cropId: "string",
        cropName: "string",
        suitabilityScore: "number (0 - 100)",
        confidenceInterval: "number (%)",
        xaiShapleyAttribution: {
          soilScore: "number (+ pts)",
          tempScore: "number (+ pts)",
          rainScore: "number (+ pts)",
          phScore: "number (+ pts)",
          moistureScore: "number (+ pts)"
        },
        agronomicRationale: "array of strings"
      }
    ],
    modelVersion: "string",
    executionTimeMs: "number"
  }
};

/**
 * 2. Soil Analysis Model Contract
 */
export const SoilAnalysisContract = {
  requestSchema: {
    nitrogen: "number",
    phosphorus: "number",
    potassium: "number",
    ph: "number",
    organicCarbon: "number",
    electricalConductivity: "number",
    moisture: "number"
  },
  responseSchema: {
    soilHealthScore: "number (0 - 100)",
    bioAvailabilityIndex: "number (0.0 - 1.0)",
    baseScore: "100",
    penalties: [
      { parameter: "string", penaltyPoints: "number", reason: "string" }
    ],
    nutrientSufficiency: {
      nitrogenStatus: "Deficient | Optimal | High",
      phosphorusStatus: "Low | Optimal | High",
      potassiumStatus: "Low | Optimal | High",
      phStatus: "Acidic | Optimal | Alkaline"
    },
    recommendedAmendments: "array of strings"
  }
};

/**
 * 3. Plant Disease Computer Vision Screening Contract
 */
export const DiseaseDetectionContract = {
  requestSchema: {
    imageTensorOrBase64: "string | Blob",
    cropContext: "string"
  },
  responseSchema: {
    predictions: [
      {
        diseaseName: "string",
        pathogenCategory: "Fungal | Bacterial | Viral | Physiological",
        probability: "number (0.0 - 1.0)",
        confidencePct: "number (0 - 100)",
        symptomsDetected: "array of strings"
      }
    ],
    expertDisclaimer: "string",
    modelVersion: "string"
  }
};

/**
 * 4. Smart Irrigation & ET0 Water Balance Contract
 */
export const IrrigationContract = {
  requestSchema: {
    currentSoilMoisturePct: "number",
    cropType: "string",
    cropGrowthStage: "string",
    ambientTemperature: "number",
    windSpeedKmH: "number",
    relativeHumidityPct: "number",
    forecastRainfall24hMm: "number"
  },
  responseSchema: {
    et0EvapotranspirationMmDay: "number",
    cropCoefficientKc: "number",
    cropWaterRequirementEtcMmDay: "number",
    soilWaterDeficitPct: "number",
    waterStatus: "Optimal | Dry | Waterlogged",
    recommendedPulseVolumeLitersPerAcre: "number",
    recommendedPulseDurationMinutes: "number",
    actionRationale: "string"
  }
};

/**
 * 5. Weather Microclimate Risk Engine Contract
 */
export const WeatherRiskContract = {
  requestSchema: {
    hourlyTemperature: "array of numbers",
    hourlyHumidity: "array of numbers",
    forecastRainSumMm: "number",
    maxWindSpeedKmH: "number"
  },
  responseSchema: {
    risks: [
      {
        riskId: "string",
        title: "string",
        riskLevel: "LOW | MEDIUM | HIGH | CRITICAL",
        mathematicalIndex: "number (0.0 - 1.0)",
        triggerFormula: "string",
        expectedImpact: "string",
        mitigationAction: "string"
      }
    ]
  }
};

/**
 * 6. Farm Health Scoring Engine Contract
 */
export const FarmHealthScoreContract = {
  requestSchema: {
    soilScore: "number (0 - 100)",
    cropVigorScore: "number (0 - 100)",
    waterAdequacyScore: "number (0 - 100)",
    weatherSafetyScore: "number (0 - 100)",
    diseaseHealthScore: "number (0 - 100)"
  },
  responseSchema: {
    compositeScore: "number (0 - 100)",
    scoreFormula: "S_farm = 0.25*S_soil + 0.25*S_crop + 0.20*S_water + 0.15*S_weather + 0.15*S_disease",
    weightAttribution: {
      soilContribution: "number (max 25)",
      cropContribution: "number (max 25)",
      waterContribution: "number (max 20)",
      weatherContribution: "number (max 15)",
      diseaseContribution: "number (max 15)"
    },
    statusCategory: "Optimal | Healthy | Requires Attention | Critical"
  }
};
