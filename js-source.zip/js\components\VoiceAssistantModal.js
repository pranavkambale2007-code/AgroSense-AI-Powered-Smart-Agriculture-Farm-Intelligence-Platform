// AgroSense Voice Assistant Modal Component with Web Speech Audio Synthesis

export function renderVoiceAssistantModal(state) {
  if (!state.isVoiceModalOpen) return '';

  return `
    <div class="modal-overlay">
      <div class="modal-content border border-emerald-500/40 bg-[#091512]">
        <!-- Title Header -->
        <div class="flex items-center justify-between pb-4 border-b border-emerald-900/60">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center">
              <i data-lucide="mic" class="w-5 h-5 animate-pulse text-emerald-300"></i>
            </div>
            <div>
              <h3 class="text-lg font-bold text-white">🎤 Ask AgroSense Voice Assistant</h3>
              <p class="text-xs text-gray-400">Personalized for ${state.activeFarm.name}</p>
            </div>
          </div>
          <button id="close-voice-modal-btn" class="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-emerald-900/50">
            <i data-lucide="x" class="w-5 h-5"></i>
          </button>
        </div>

        <!-- Body & Voice Wave Animation -->
        <div class="py-6 space-y-5">
          <div class="flex flex-col items-center justify-center p-6 rounded-2xl bg-emerald-950/40 border border-emerald-800/40 text-center">
            <button id="start-speech-recognition-btn" class="w-20 h-20 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-400 text-white flex items-center justify-center shadow-xl shadow-emerald-900/50 hover:scale-110 active:scale-95 transition transform border-4 border-emerald-300/30">
              <i data-lucide="mic" class="w-10 h-10"></i>
            </button>
            <p id="voice-status-text" class="text-xs font-semibold text-emerald-400 mt-4">Tap Microphone to Speak or Type Query Below</p>
          </div>

          <!-- Suggested Quick Questions -->
          <div>
            <h4 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Suggested Quick Questions:</h4>
            <div class="flex flex-wrap gap-2">
              <button class="voice-prompt-chip px-3 py-1.5 rounded-lg bg-emerald-900/40 border border-emerald-700/40 text-xs text-emerald-300 hover:bg-emerald-800/60 transition">
                "What should I prioritize on my farm today?"
              </button>
              <button class="voice-prompt-chip px-3 py-1.5 rounded-lg bg-emerald-900/40 border border-emerald-700/40 text-xs text-emerald-300 hover:bg-emerald-800/60 transition">
                "Which crop is suitable for my soil?"
              </button>
              <button class="voice-prompt-chip px-3 py-1.5 rounded-lg bg-emerald-900/40 border border-emerald-700/40 text-xs text-emerald-300 hover:bg-emerald-800/60 transition">
                "Why is my soil nitrogen low?"
              </button>
            </div>
          </div>

          <!-- Input Fallback -->
          <div class="flex gap-2">
            <input id="voice-text-input" type="text" placeholder="Or type your agriculture query here..." class="flex-1 bg-gray-900/80 border border-emerald-700/50 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400" />
            <button id="send-voice-query-btn" class="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs">
              Ask AI
            </button>
          </div>

          <!-- AI Response Area with Audio Playback -->
          <div id="voice-response-area" class="hidden p-4 rounded-xl bg-emerald-950/70 border border-emerald-700/40 text-xs space-y-3">
            <!-- Dynamically populated -->
          </div>
        </div>
      </div>
    </div>
  `;
}
