// AgroSense Farm Decision Center Page Component (Most Important Action Dashboard)

function renderDecisionCenterPage(state) {
  const farm = state.activeFarm;

  const priorities = [
    {
      priorityNum: 1,
      title: "Weather Risk Mitigation",
      level: "HIGH PRIORITY",
      badgeColor: "bg-red-500/20 text-red-300 border-red-500/40",
      why: "Moderate rain (14.2mm) predicted for tomorrow evening.",
      what: "Delay scheduled drip irrigation. Inspect drainage channels to avoid standing water.",
      when: "Within next 12 hours",
      icon: "cloud-lightning"
    },
    {
      priorityNum: 2,
      title: "Soil Nitrogen Amendment",
      level: "HIGH PRIORITY",
      badgeColor: "bg-amber-500/20 text-amber-300 border-amber-500/40",
      why: "Nitrogen reading (185 kg/ha) is below recommended range for Wheat at 65 DAS stage.",
      what: "Apply split-dose urea top-dressing as per local agricultural officer guidance.",
      when: "Post-rain event (in 48 hours)",
      icon: "test-tube"
    },
    {
      priorityNum: 3,
      title: "Soil Moisture & Irrigation",
      level: "OPTIMAL",
      badgeColor: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
      why: "Soil moisture is currently optimal at 32.4%.",
      what: "Maintain standard soil probe telemetry monitoring.",
      when: "Ongoing",
      icon: "droplet"
    },
    {
      priorityNum: 4,
      title: "Fungal Spore Screening",
      level: "MONITORING",
      badgeColor: "bg-amber-500/20 text-amber-300 border-amber-500/40",
      why: "Humidity at 68% with cool night temps creates initial rust spores risk.",
      what: "Scout leaf undersides in Zone A & upload leaf photo if spots appear.",
      when: "Daily morning walk",
      icon: "scan-line"
    },
    {
      priorityNum: 5,
      title: "APMC Market Intelligence",
      level: "OPPORTUNITY",
      badgeColor: "bg-teal-500/20 text-teal-300 border-teal-500/40",
      why: "Wheat mandi price in Pune APMC increased by +2.4% to ₹2,275 / Qtl.",
      what: "Review e-NAM registered scientific warehouse options for post-harvest storage.",
      when: "Prior to harvest window",
      icon: "line-chart"
    }
  ];

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="compass" class="w-6 h-6 text-amber-400"></i>
            Farm Decision Center — Today's Action Plan
          </h1>
          <p class="text-xs text-gray-400">Synthesized daily farm actions prioritized by risk impact for ${farm.name}</p>
        </div>
        <span class="prototype-badge font-mono">PRIORITY ACTION ENGINE</span>
      </div>

      <!-- Priority Action Cards -->
      <div class="space-y-4">
        ${priorities.map(p => `
          <div class="glass-card p-6 space-y-4 border-l-4 ${p.level.includes('HIGH') ? 'border-l-red-500' : p.level.includes('OPTIMAL') ? 'border-l-emerald-500' : 'border-l-amber-500'}">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-3">
                <div class="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center font-extrabold text-sm">
                  #${p.priorityNum}
                </div>
                <div>
                  <h3 class="text-base font-bold text-white">${p.title}</h3>
                  <p class="text-xs text-gray-400">Target Category</p>
                </div>
              </div>
              <span class="px-3 py-1 rounded-full text-xs font-black font-mono tracking-wider border ${p.badgeColor}">${p.level}</span>
            </div>

            <!-- WHY? WHAT? WHEN? Breakdown -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div class="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40 space-y-1">
                <span class="font-extrabold text-amber-300 uppercase tracking-wider block text-[10px]">WHY IS THIS ACTION NEEDED?</span>
                <p class="text-gray-200 leading-relaxed">${p.why}</p>
              </div>

              <div class="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40 space-y-1">
                <span class="font-extrabold text-emerald-300 uppercase tracking-wider block text-[10px]">WHAT ACTION SHOULD I TAKE?</span>
                <p class="text-gray-200 leading-relaxed font-semibold">${p.what}</p>
              </div>

              <div class="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40 space-y-1">
                <span class="font-extrabold text-blue-300 uppercase tracking-wider block text-[10px]">RECOMMENDED TIMEFRAME</span>
                <p class="text-blue-200 font-mono font-bold">${p.when}</p>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

/* Module Exports */
exports.renderDecisionCenterPage = renderDecisionCenterPage;
