// AgroSense APMC Mandi Market Intelligence & Profitability Service

import { demoMandiPrices } from '../data/demoData.js';

export function getMandiPrices(cropFilter = 'All', stateFilter = 'All') {
  return demoMandiPrices.filter(item => {
    const matchCrop = cropFilter === 'All' || item.crop.toLowerCase().includes(cropFilter.toLowerCase());
    const matchState = stateFilter === 'All' || item.state.toLowerCase() === stateFilter.toLowerCase();
    return matchCrop && matchState;
  });
}

export function calculateCropProfitability(inputs) {
  const {
    farmSizeAcres = 5,
    costItems = null,
    seedCost = 3500,
    fertilizerCost = 6200,
    laborCost = 12000,
    irrigationCost = 4500,
    pesticideCost = 3800,
    otherExpenses = 2500,
    expectedYieldPerAcre = 20, // Quintals or Tonnes
    expectedPricePerUnit = 2275 // ₹ per unit
  } = inputs;

  let totalCostPerAcre = 0;
  let costBreakdown = [];

  if (Array.isArray(costItems) && costItems.length > 0) {
    totalCostPerAcre = costItems.reduce((acc, item) => acc + (Number(item.costPerAcre) || 0), 0);
    const totalCostOverall = totalCostPerAcre * farmSizeAcres;
    costBreakdown = costItems.map(item => {
      const perAcre = Number(item.costPerAcre) || 0;
      const totalItemCost = perAcre * farmSizeAcres;
      const percentage = totalCostOverall > 0 ? Math.round((totalItemCost / totalCostOverall) * 100) : 0;
      return {
        id: item.id || `cost-${Math.random()}`,
        category: item.category || 'Other Expense',
        costPerAcre: perAcre,
        cost: totalItemCost,
        percentage
      };
    });
  } else {
    totalCostPerAcre = seedCost + fertilizerCost + laborCost + irrigationCost + pesticideCost + otherExpenses;
    const totalCostOverall = totalCostPerAcre * farmSizeAcres;
    costBreakdown = [
      { id: "cost-1", category: "Seeds & Sowing", costPerAcre: seedCost, cost: seedCost * farmSizeAcres, percentage: totalCostOverall > 0 ? Math.round(((seedCost * farmSizeAcres) / totalCostOverall) * 100) : 0 },
      { id: "cost-2", category: "Fertilizer & Soil Amendments", costPerAcre: fertilizerCost, cost: fertilizerCost * farmSizeAcres, percentage: totalCostOverall > 0 ? Math.round(((fertilizerCost * farmSizeAcres) / totalCostOverall) * 100) : 0 },
      { id: "cost-3", category: "Labor & Field Operations", costPerAcre: laborCost, cost: laborCost * farmSizeAcres, percentage: totalCostOverall > 0 ? Math.round(((laborCost * farmSizeAcres) / totalCostOverall) * 100) : 0 },
      { id: "cost-4", category: "Irrigation & Energy", costPerAcre: irrigationCost, cost: irrigationCost * farmSizeAcres, percentage: totalCostOverall > 0 ? Math.round(((irrigationCost * farmSizeAcres) / totalCostOverall) * 100) : 0 },
      { id: "cost-5", category: "Pesticides & Crop Protection", costPerAcre: pesticideCost, cost: pesticideCost * farmSizeAcres, percentage: totalCostOverall > 0 ? Math.round(((pesticideCost * farmSizeAcres) / totalCostOverall) * 100) : 0 },
      { id: "cost-6", category: "Machinery, Fuel & Rent", costPerAcre: otherExpenses, cost: otherExpenses * farmSizeAcres, percentage: totalCostOverall > 0 ? Math.round(((otherExpenses * farmSizeAcres) / totalCostOverall) * 100) : 0 }
    ];
  }

  const totalCostOverall = totalCostPerAcre * farmSizeAcres;
  const expectedRevenuePerAcre = expectedYieldPerAcre * expectedPricePerUnit;
  const totalRevenueOverall = expectedRevenuePerAcre * farmSizeAcres;

  const grossMarginOverall = totalRevenueOverall - totalCostOverall;
  const grossMarginPerAcre = grossMarginOverall / farmSizeAcres;
  const roiPercentage = totalCostOverall > 0 ? ((grossMarginOverall / totalCostOverall) * 100).toFixed(1) : 0;

  return {
    farmSizeAcres,
    costBreakdown,
    summary: {
      totalCostPerAcre,
      totalCostOverall,
      totalRevenueOverall,
      grossMarginOverall,
      grossMarginPerAcre,
      roiPercentage,
      isProfitable: grossMarginOverall > 0,
      disclaimer: "Estimated financial projection based on dynamic user cost inputs and market indicators."
    }
  };
}
