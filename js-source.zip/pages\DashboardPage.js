// AgroSense Main Farm Intelligence Dashboard Component with Bar Graph & Pie Chart Data Visualizations

const { translations } = require('js/data/translations.js');
const { renderFarmMapContainer, initLeafletMap } = require('js/components/FarmMap.js');
const { calculateCompositeFarmHealthScore } = require('js/services/farmHealthService.js');
const { renderGenericXAIExplanationCard } = require('js/components/XAIExplanationCard.js');
const { drawBarChart, drawPieChart } = require('js/components/AnalyticsCharts.js');

function renderDashboardPage(state) {
  const t = translations[state.lang] || translations.en;
  const farm = state.activeFarm;

  const healthResult = calculateCompositeFarmHealthScore(farm, state.weatherData);
  const hasRegisteredFarms = Array.isArray(state.farms) && state.farms.length > 0;

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      ${!hasRegisteredFarms ? `
      <!-- Zero State Registration Call to Action Banner -->
      <div class="p-6 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border-2 border-emerald-500/50 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div class="flex items-center gap-4">
          <div class="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center shrink-0">
            <i data-lucide="map-pin" class="w-8 h-8 text-emerald-400"></i>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-xl font-bold text-white">No Farm Registered Yet</h2>
              <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">SETUP REQUIRED</span>
            </div>
            <p class="text-xs text-gray-300 mt-1">Plot your 4 farm boundary corners on the satellite map to calibrate soil telemetry, live weather risk detection, and APMC mandi price tracking.</p>
          </div>
        </div>
        <a href="#/onboarding" id="btn-dash-add-farm" class="btn-add-farm-action shrink-0 px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-extrabold text-sm hover:from-emerald-400 hover:to-teal-400 transition shadow-lg flex items-center gap-2 text-decoration-none cursor-pointer">
          <i data-lucide="crosshair" class="w-4 h-4"></i>
          <span>Plot 4 Points & Register Farm</span>
        </a>
      </div>
      ` : ''}

      <!-- Top Title Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-bold text-white tracking-tight">${farm.name}</h1>
            ${hasRegisteredFarms ? `
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">REGISTERED FARM</span>
            ` : `
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">NO FARM REGISTERED</span>
            `}
          </div>
          <p class="text-xs text-gray-400 mt-0.5">${farm.location} • ${farm.sizeAcres} Acres • ${farm.soilType} • Crop: <span class="text-emerald-400 font-semibold">${farm.currentCrop}</span></p>
        </div>

        <div class="flex items-center gap-2">
          <a href="#/decision-center" class="px-4 py-2 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500/30 text-xs font-bold transition flex items-center gap-1.5 text-decoration-none">
            <i data-lucide="compass" class="w-4 h-4 text-amber-400"></i>
            Today's Priority Actions →
          </a>
        </div>
      </div>

      <!-- MAIN ANSWER BANNER: "How is my farm today?" -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Farm Health Score Card -->
        <div class="glass-card-accent p-6 flex flex-col justify-between space-y-4">
          <div class="flex items-center gap-6">
            <div class="gauge-container">
              <svg class="gauge-svg" width="130" height="130">
                <circle class="gauge-circle-bg" cx="65" cy="65" r="54" stroke-width="12" fill="transparent"></circle>
                <circle class="gauge-circle-fill" cx="65" cy="65" r="54" stroke-width="12" fill="transparent" stroke="#10b981" style="stroke-dashoffset: ${339.29 * (1 - healthResult.compositeScore / 100)};"></circle>
              </svg>
              <div class="gauge-score-label">
                <span class="gauge-score-num">${healthResult.compositeScore}</span>
                <span class="gauge-score-denom">/100</span>
              </div>
            </div>
            <div class="space-y-1.5">
              <span class="text-[11px] font-bold tracking-wider text-emerald-300 uppercase">COMPOSITE INDEX</span>
              <h2 class="text-xl font-extrabold text-white">Farm Health Score</h2>
              <p class="text-xs text-emerald-400/90 font-medium">Weighted combination of Soil, Crop, Water, Weather & Disease safety.</p>
              <div class="pt-1">
                <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">Optimal State</span>
              </div>
            </div>
          </div>

          <div class="p-2.5 rounded-lg bg-gray-950/80 border border-emerald-900 font-mono text-[10px] text-gray-300 text-center">
            ${healthResult.formulaString}
          </div>
        </div>

        <!-- AI Crop Selection & Soil-Rainfall Prediction Model Banner -->
        <a href="#/crop-recommendation" class="lg:col-span-3 glass-card p-4 rounded-2xl border border-emerald-500/40 bg-gradient-to-r from-emerald-950/90 via-[#07241a] to-teal-950/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-decoration-none group hover:border-emerald-400 transition shadow-lg">
          <div class="flex items-center gap-3.5">
            <div class="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-400 to-green-600 flex items-center justify-center text-slate-950 font-black shadow-md shadow-emerald-500/30 group-hover:scale-105 transition">
              <i data-lucide="sparkles" class="w-5 h-5 fill-slate-950"></i>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="text-sm font-black text-white font-['Outfit']">🔮 AI Crop Selection Prediction Model</span>
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">NEW</span>
              </div>
              <p class="text-xs text-gray-300 mt-0.5">Input your soil fertility, NPK contents, pH, and expected rainfall to get custom high-yielding crop predictions.</p>
            </div>
          </div>
          <div class="shrink-0 flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-extrabold text-xs group-hover:bg-emerald-400 transition shadow">
            <span>Run Prediction</span>
            <i data-lucide="arrow-right" class="w-4 h-4"></i>
          </div>
        </a>

        <!-- Today's Farm Summary Cards -->
        <div class="lg:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-4">
          <!-- Soil Health Card -->
          <a href="#/soil" class="glass-card p-4 space-y-2 text-decoration-none group hover:border-emerald-400 transition">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-gray-400">${t.soilHealth}</span>
              <i data-lucide="test-tube" class="w-4 h-4 text-emerald-400"></i>
            </div>
            <div class="text-lg font-bold text-white font-mono">${farm.soil.soilScore}/100</div>
            <p class="text-[11px] text-amber-400 font-medium">N: 185 (Low) | pH: 7.2</p>
          </a>

          <!-- Crop Health Card -->
          <a href="#/crop-monitor" class="glass-card p-4 space-y-2 text-decoration-none group hover:border-emerald-400 transition">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-gray-400">${t.cropHealth}</span>
              <i data-lucide="sprout" class="w-4 h-4 text-emerald-400"></i>
            </div>
            <div class="text-lg font-bold text-emerald-300 font-mono">Vegetative</div>
            <p class="text-[11px] text-gray-400 font-medium">Day 65 after sowing</p>
          </a>

          <!-- Weather Risk Card -->
          <a href="#/risk" class="glass-card p-4 space-y-2 text-decoration-none group hover:border-amber-400 transition">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-gray-400">${t.weatherRisk}</span>
              <i data-lucide="cloud-sun" class="w-4 h-4 text-amber-400"></i>
            </div>
            <div class="text-lg font-bold text-emerald-400 font-mono">Low Risk</div>
            <p class="text-[11px] text-gray-400 font-medium">15% rain probability</p>
          </a>

          <!-- Water Status Card -->
          <a href="#/irrigation" class="glass-card p-4 space-y-2 text-decoration-none group hover:border-emerald-400 transition">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-gray-400">${t.waterStatus}</span>
              <i data-lucide="droplet" class="w-4 h-4 text-blue-400"></i>
            </div>
            <div class="text-lg font-bold text-blue-300 font-mono">${farm.waterStatus}</div>
            <p class="text-[11px] text-gray-400 font-medium">Soil Moisture: ${farm.soil.moisture}%</p>
          </a>

          <!-- Disease Risk Card -->
          <a href="#/disease" class="glass-card p-4 space-y-2 text-decoration-none group hover:border-amber-400 transition">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-gray-400">${t.diseaseRisk}</span>
              <i data-lucide="scan-line" class="w-4 h-4 text-amber-400"></i>
            </div>
            <div class="text-lg font-bold text-amber-300 font-mono">Moderate</div>
            <p class="text-[11px] text-gray-400 font-medium">Humidity 68% (Rust Risk)</p>
          </a>

          <!-- Market Status Card -->
          <a href="#/market" class="glass-card p-4 space-y-2 text-decoration-none group hover:border-emerald-400 transition">
            <div class="flex items-center justify-between">
              <span class="text-xs font-semibold text-gray-400">${t.marketStatus}</span>
              <i data-lucide="line-chart" class="w-4 h-4 text-emerald-400"></i>
            </div>
            <div class="text-lg font-bold text-emerald-300 font-mono">₹2,275 / Qtl</div>
            <p class="text-[11px] text-emerald-400 font-medium">+2.4% Pune Mandi</p>
          </a>
        </div>
      </div>

      <!-- DATA VISUALIZATIONS: BAR GRAPH & PIE CHART GRID -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Bar Graph Card: Soil Nutrient Balance -->
        <div class="glass-card p-6 space-y-3">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <i data-lucide="bar-chart-3" class="w-5 h-5 text-emerald-400"></i>
              <h3 class="text-sm font-bold text-white">Soil Nutrient Balance (Bar Graph)</h3>
            </div>
            <span class="text-[10px] text-gray-400 font-mono">N, P, K vs Ideal</span>
          </div>
          <div class="h-56 w-full relative">
            <canvas id="dashboard-bar-chart" class="w-full h-full"></canvas>
          </div>
          <p class="text-[11px] text-gray-400">Nitrogen is 34% below ideal threshold (280 kg/ha).</p>
        </div>

        <!-- Pie Chart Card: Farm Input Cost Distribution -->
        <div class="glass-card p-6 space-y-3">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <i data-lucide="pie-chart" class="w-5 h-5 text-amber-400"></i>
              <h3 class="text-sm font-bold text-white">Farm Resource Allocation (Pie Chart)</h3>
            </div>
            <span class="text-[10px] text-gray-400 font-mono">Input Cost %</span>
          </div>
          <div class="h-56 w-full relative">
            <canvas id="dashboard-pie-chart" class="w-full h-full"></canvas>
          </div>
          <p class="text-[11px] text-gray-400">Labor & Fertilizers comprise 55% of total input budget.</p>
        </div>
      </div>

      <!-- EXPLAINABLE AI (XAI) MATHEMATICAL ATTRIBUTION CARD FOR FARM HEALTH -->
      ${renderGenericXAIExplanationCard(
        "Farm Health Mathematical XAI Breakdown",
        "Why is Farm Health Score calculated at " + healthResult.compositeScore + "/100?",
        healthResult.formulaString,
        healthResult.attributions.map(attr => ({
          label: attr.component,
          value: `+${attr.pointsEarned} / ${attr.maxPoints} pts`,
          note: `${attr.note} (Raw Score: ${attr.rawScore}/100 × ${attr.weightPct}% weight)`
        }))
      )}

      <!-- INTERACTIVE FARM MAP CONTAINER -->
      <div>
        ${renderFarmMapContainer(farm)}
      </div>
    </div>
  `;
}

function initDashboardHooks(state) {
  initLeafletMap(state.activeFarm);

  // Draw Bar Chart: Soil Nutrient Balance
  drawBarChart(
    'dashboard-bar-chart',
    ['Nitrogen (N)', 'Phosphorus (P)', 'Potassium (K)', 'Organic Carbon'],
    [185, 34, 310, 58], // OC scaled x100 for graph visibility
    ['#f59e0b', '#3b82f6', '#10b981', '#14b8a6'],
    350
  );

  // Draw Pie Chart: Resource Allocation
  drawPieChart(
    'dashboard-pie-chart',
    ['Labor & Operations', 'Fertilizer', 'Irrigation & Power', 'Seeds & Sowing', 'Crop Protection'],
    [35, 20, 18, 15, 12],
    ['#f59e0b', '#10b981', '#3b82f6', '#14b8a6', '#8b5cf6']
  );
}

/* Module Exports */
exports.renderDashboardPage = renderDashboardPage; exports.initDashboardHooks = initDashboardHooks;
