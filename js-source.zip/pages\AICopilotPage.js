// AgroSense AI Farm Copilot Page (Multi-Hazard Meteorological & Agronomic Reasoning)
// Real-time context grounding: Soil Telemetry, 6 Weather Hazards, 5-Stage Crop Lifecycle & Vernacular Audio

const { generateAICopilotResponse } = require('js/services/aiEngine.js');
const { evaluateAdvancedWeatherRisks } = require('js/services/weatherService.js');
const { cropLifecycleDatabase } = require('js/data/cropLifecycleData.js');

// Markdown-to-HTML parser for formatted Copilot responses
function formatMarkdownResponse(text) {
  if (!text) return '';
  let html = text
    // Escape standard HTML tags
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    // Headers
    .replace(/^### (.*$)/gim, '<h4 class="text-sm font-bold text-amber-300 mt-2.5 mb-1.5 flex items-center gap-1.5">$1</h4>')
    .replace(/^#### (.*$)/gim, '<h5 class="text-xs font-bold text-emerald-300 mt-2 mb-1">$1</h5>')
    // Horizontal Rule
    .replace(/^---+$/gim, '<hr class="border-t border-emerald-900/60 my-2.5">')
    // Blockquotes
    .replace(/^> (.*$)/gim, '<blockquote class="border-l-2 border-emerald-500/60 pl-3 py-1 my-1.5 bg-emerald-950/40 text-emerald-200 text-xs italic rounded-r">$1</blockquote>')
    // Bold & Italics
    .replace(/\*\*(.*?)\*\*/g, '<strong class="text-white font-semibold">$1</strong>')
    .replace(/\*(.*?)\*/g, '<em class="text-emerald-200">$1</em>')
    // Code ticks
    .replace(/`([^`]+)`/g, '<code class="px-1.5 py-0.5 rounded bg-gray-900 border border-emerald-800/60 text-emerald-300 font-mono text-[11px]">$1</code>')
    // Unordered lists
    .replace(/^\s*[-•]\s+(.*$)/gim, '<li class="text-xs text-gray-200 leading-relaxed ml-3 list-disc">$1</li>')
    // Ordered lists
    .replace(/^\s*(\d+)\.\s+(.*$)/gim, '<li class="text-xs text-gray-200 leading-relaxed ml-3 list-decimal">$1</li>');

  // Wrap loose <li> in <ul>
  html = html.replace(/(<li.*<\/li>)/gms, '<ul class="space-y-1 my-1">$1</ul>');

  // Parse Markdown Tables
  html = html.replace(/(?:^|\n)(\|.+?\|\n\|[-:\s|]+\|\n(?:\|.+?\|\n?)+)/g, (match) => {
    const lines = match.trim().split('\n');
    if (lines.length < 2) return match;
    const headers = lines[0].split('|').map(s => s.trim()).filter(s => s !== '');
    const rows = lines.slice(2).map(line => line.split('|').map(s => s.trim()).filter(s => s !== ''));
    
    let tableHtml = '<div class="overflow-x-auto my-3 rounded-xl border border-emerald-900/60 shadow-inner"><table class="min-w-full text-xs text-left divide-y divide-emerald-900/50">';
    tableHtml += '<thead class="bg-[#0b241c] text-emerald-300 font-semibold tracking-wider"><tr>';
    headers.forEach(h => {
      tableHtml += `<th class="px-3 py-2 border-b border-emerald-800/60 font-bold">${h}</th>`;
    });
    tableHtml += '</tr></thead><tbody class="divide-y divide-emerald-950/60 bg-gray-950/60">';
    rows.forEach((r, idx) => {
      tableHtml += `<tr class="${idx % 2 === 0 ? 'bg-transparent' : 'bg-emerald-950/20'} hover:bg-emerald-900/30 transition">`;
      r.forEach(cell => {
        tableHtml += `<td class="px-3 py-2 text-gray-200 border-r last:border-r-0 border-emerald-950/50">${cell}</td>`;
      });
      tableHtml += '</tr>';
    });
    tableHtml += '</tbody></table></div>';
    return tableHtml;
  });

  // Convert double line breaks into paragraphs
  return html.split('\n\n').map(p => {
    if (p.startsWith('<h') || p.startsWith('<blockquote') || p.startsWith('<ul') || p.startsWith('<div') || p.startsWith('<hr')) return p;
    return `<p class="text-xs text-gray-200 leading-relaxed my-1.5">${p}</p>`;
  }).join('');
}

function renderAICopilotPage(state) {
  const farm = state.activeFarm || {
    name: "Registered Farm Plot",
    location: "Pune, Maharashtra",
    acres: 5,
    currentCrop: "Wheat (HD-2967)",
    soilType: "Medium Black Soil",
    irrigationType: "Drip",
    soil: { ph: 7.0, nitrogen: 240, phosphorus: 45, potassium: 180, temperature: 26, moisture: 38, soilScore: 78 }
  };

  // Determine Crop Key
  const cropStr = ((farm.currentCrop || '') + ' ' + (state.selectedCropId || '')).toLowerCase();
  let cropKey = 'wheat';
  if (cropStr.includes('tomato')) cropKey = 'tomato';
  else if (cropStr.includes('chilli') || cropStr.includes('pepper')) cropKey = 'chilli';
  else if (cropStr.includes('maize') || cropStr.includes('corn')) cropKey = 'maize';
  else if (cropStr.includes('potato')) cropKey = 'potato';
  else if (cropStr.includes('rice') || cropStr.includes('paddy')) cropKey = 'rice';
  else if (cropStr.includes('cotton')) cropKey = 'cotton';
  else if (cropStr.includes('groundnut') || cropStr.includes('peanut')) cropKey = 'groundnut';

  const cropData = cropLifecycleDatabase[cropKey] || cropLifecycleDatabase.wheat;
  const weatherRisk = evaluateAdvancedWeatherRisks(state.weatherData, cropKey);
  const spray = weatherRisk.sprayWindow;
  const topHazard = weatherRisk.topPriorityHazard;

  return `
    <div class="space-y-6 max-w-7xl mx-auto pb-12">
      <!-- Hero Top Banner -->
      <div class="relative overflow-hidden rounded-2xl bg-[#0d1e17] border border-emerald-800/60 p-6 shadow-lg">
        <div class="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-2 mb-2 flex-wrap">
              <span class="px-3 py-1 rounded-full text-[11px] font-bold tracking-wider uppercase bg-emerald-950/80 text-emerald-300 border border-emerald-600/40 flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                Agronomic Decision Support Active
              </span>
              <span class="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-blue-950/60 text-blue-300 border border-blue-600/40">
                ICAR & KVK Agronomy Guidelines
              </span>
              <span class="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-amber-950/60 text-amber-300 border border-amber-600/40">
                Weather Hazard Matrix Integrated
              </span>
            </div>
            <h1 class="text-2xl sm:text-3xl font-bold text-white tracking-tight flex items-center gap-3">
              <span>AgroSense Farm Decision Copilot</span>
            </h1>
            <p class="text-xs sm:text-sm text-gray-300 mt-1 max-w-2xl">
              Multilingual agricultural decision co-pilot. Grounded directly in your live soil NPK, 6-hazard weather forecasts, 5-stage crop growth stages, and APMC Mandi price benchmarks.
            </p>
          </div>

          <!-- Quick Navigation Actions -->
          <div class="flex items-center gap-2 shrink-0">
            <a href="#/risk" class="px-3.5 py-2 rounded-xl bg-amber-600/20 hover:bg-amber-600/30 border border-amber-500/40 text-amber-300 text-xs font-bold transition flex items-center gap-1.5">
              <i data-lucide="shield-alert" class="w-4 h-4"></i>
              Weather Risk Center
            </a>
            <a href="#/crop-monitor" class="px-3.5 py-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold transition flex items-center gap-1.5">
              <i data-lucide="calendar-clock" class="w-4 h-4"></i>
              Crop Monitor
            </a>
          </div>
        </div>
      </div>

      <!-- Main 12-Column Responsive Workspace Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        <!-- LEFT 4 COLS: Telemetry Context & Live Hazards Stream -->
        <div class="lg:col-span-4 space-y-5">
          
          <!-- Farm & Telemetry Badge Card -->
          <div class="rounded-2xl bg-[#081712] border border-emerald-900/60 p-5 shadow-lg space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-emerald-950">
              <div class="flex items-center gap-2.5">
                <div class="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center font-bold">
                  <i data-lucide="map-pin" class="w-4 h-4"></i>
                </div>
                <div>
                  <h3 class="text-xs font-bold text-white">${farm.name}</h3>
                  <p class="text-[11px] text-gray-400">${farm.location || 'Maharashtra, India'} • ${farm.acres || 5} Acres</p>
                </div>
              </div>
              <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950 text-emerald-400 border border-emerald-800">
                ACTIVE
              </span>
            </div>

            <!-- Monitored Crop & Stage Indicator -->
            <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 space-y-2">
              <div class="flex items-center justify-between text-xs">
                <span class="text-gray-400 font-medium">Monitored Crop:</span>
                <span class="text-emerald-300 font-bold">${cropData.cropName}</span>
              </div>
              <div class="flex items-center justify-between text-xs">
                <span class="text-gray-400 font-medium">Growth Phase:</span>
                <span class="text-amber-300 font-bold">Stage 3/5: Flowering (DAS 65)</span>
              </div>
              <!-- Progress Bar -->
              <div class="w-full bg-gray-900 rounded-full h-1.5 overflow-hidden mt-1">
                <div class="bg-gradient-to-r from-emerald-500 to-amber-400 h-1.5 rounded-full" style="width: 58%"></div>
              </div>
              <p class="text-[10px] text-gray-400 flex items-center justify-between">
                <span>Total Cycle: ${cropData.totalDurationDays} Days</span>
                <span class="text-emerald-400">Harvest in ~45 Days</span>
              </p>
            </div>

            <!-- Real-time Soil Telemetry -->
            <div>
              <div class="flex items-center justify-between text-xs font-bold text-gray-300 uppercase tracking-wider mb-2">
                <span>Soil Telemetry Sensors</span>
                <span class="text-[10px] text-emerald-400 font-mono">Live LoRaWAN</span>
              </div>
              <div class="grid grid-cols-2 gap-2 text-xs">
                <div class="p-2.5 rounded-xl bg-gray-900/60 border border-emerald-950/80">
                  <div class="text-[10px] text-gray-400">Nitrogen (N)</div>
                  <div class="text-sm font-bold text-emerald-300 mt-0.5">${farm.soil?.nitrogen || 240} <span class="text-[10px] text-gray-500 font-normal">kg/ha</span></div>
                  <div class="text-[9px] text-emerald-400">Optimal Range</div>
                </div>
                <div class="p-2.5 rounded-xl bg-gray-900/60 border border-emerald-950/80">
                  <div class="text-[10px] text-gray-400">Phosphorus (P)</div>
                  <div class="text-sm font-bold text-amber-300 mt-0.5">${farm.soil?.phosphorus || 45} <span class="text-[10px] text-gray-500 font-normal">kg/ha</span></div>
                  <div class="text-[9px] text-amber-400">Moderate</div>
                </div>
                <div class="p-2.5 rounded-xl bg-gray-900/60 border border-emerald-950/80">
                  <div class="text-[10px] text-gray-400">Potassium (K)</div>
                  <div class="text-sm font-bold text-teal-300 mt-0.5">${farm.soil?.potassium || 180} <span class="text-[10px] text-gray-500 font-normal">kg/ha</span></div>
                  <div class="text-[9px] text-teal-400">High Adequate</div>
                </div>
                <div class="p-2.5 rounded-xl bg-gray-900/60 border border-emerald-950/80">
                  <div class="text-[10px] text-gray-400">Soil Moisture / pH</div>
                  <div class="text-sm font-bold text-blue-300 mt-0.5">${farm.soil?.moisture || 38}% <span class="text-xs text-purple-300 font-normal">| ${farm.soil?.ph || 7.0} pH</span></div>
                  <div class="text-[9px] text-blue-400">Wapsa Condition</div>
                </div>
              </div>
            </div>
          </div>

          <!-- Live Weather Threat & Spray Status Card -->
          <div class="rounded-2xl bg-[#081712] border border-amber-900/40 p-5 shadow-lg space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-emerald-950">
              <div class="flex items-center gap-2">
                <i data-lucide="cloud-lightning" class="w-4 h-4 text-amber-400"></i>
                <h3 class="text-xs font-bold text-white uppercase tracking-wider">Meteorological Risk Status</h3>
              </div>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold ${
                weatherRisk.compositeLevel === 'SEVERE' ? 'bg-red-500/20 text-red-300 border border-red-500/40' :
                weatherRisk.compositeLevel === 'HIGH' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              }">
                ${weatherRisk.compositeLevel} RISK (${weatherRisk.compositeRiskScore}/100)
              </span>
            </div>

            <!-- Spray Safety Window Pill -->
            <div class="p-3 rounded-xl ${
              spray.status === 'SAFE' ? 'bg-emerald-950/50 border border-emerald-500/40' :
              spray.status === 'CAUTION' ? 'bg-amber-950/50 border border-amber-500/40' :
              'bg-red-950/50 border border-red-500/40'
            } flex items-center justify-between">
              <div>
                <div class="text-[10px] uppercase font-bold text-gray-400">Pesticide Spray Safety</div>
                <div class="text-xs font-bold ${
                  spray.status === 'SAFE' ? 'text-emerald-300' :
                  spray.status === 'CAUTION' ? 'text-amber-300' : 'text-red-300'
                }">${spray.statusBadge}</div>
              </div>
              <div class="text-right">
                <div class="text-[10px] text-gray-400">Recommended Window</div>
                <div class="text-xs font-bold text-white">${spray.bestWindow}</div>
              </div>
            </div>

            <!-- Top Active Hazard Alert -->
            <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800 space-y-1.5">
              <div class="flex items-center justify-between text-xs font-bold text-white">
                <span class="flex items-center gap-1.5">
                  <span class="text-sm">⚠️</span> ${topHazard.title}
                </span>
                <span class="text-[10px] text-amber-400 font-mono">${topHazard.riskScore}/100</span>
              </div>
              <p class="text-[11px] text-gray-300">${topHazard.cropVulnerability}</p>
              <div class="pt-1 flex items-center justify-between text-[10px] border-t border-gray-800">
                <span class="text-emerald-400 font-medium">${topHazard.mitigationAction.slice(0, 45)}...</span>
                <a href="#/risk" class="text-amber-400 hover:text-amber-300 font-bold underline">Details ↗</a>
              </div>
            </div>

            <!-- Verified Agronomic Reference Citations -->
            <div class="pt-2 border-t border-emerald-950 flex flex-wrap gap-1.5 text-[10px] text-gray-400">
              <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-900">ICAR-CRIDA</span>
              <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-900">IMD Agromet (AAS)</span>
              <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-900">CIBRC Spray Standards</span>
            </div>
          </div>
        </div>

        <!-- RIGHT 8 COLS: Full AI Copilot Conversational Engine -->
        <div class="lg:col-span-8 flex flex-col h-[740px] rounded-3xl bg-[#07130f] border border-emerald-800/50 shadow-2xl overflow-hidden">
          
          <!-- Chat Console Header -->
          <div class="px-5 py-4 bg-[#091b15] border-b border-emerald-900/60 flex items-center justify-between flex-wrap gap-3">
            <div class="flex items-center gap-3">
              <div class="relative">
                <div class="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 text-white flex items-center justify-center font-bold shadow-lg shadow-emerald-900/50">
                  <i data-lucide="bot" class="w-5 h-5"></i>
                </div>
                <span class="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 border-2 border-[#091b15]"></span>
              </div>
              <div>
                <h3 class="text-sm font-bold text-white flex items-center gap-2">
                  <span>AgroSense Farm Copilot</span>
                  <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">ONLINE</span>
                </h3>
                <p class="text-[11px] text-gray-400">Reasoning over ${farm.name} telemetry & local agrometeorological risks</p>
              </div>
            </div>

            <!-- Language Switcher & Controls -->
            <div class="flex items-center gap-2">
              <span class="px-2.5 py-1 rounded-xl bg-emerald-950/80 border border-emerald-700/50 text-emerald-300 text-xs font-mono font-bold">
                Language: English
              </span>

              <button id="copilot-clear-history-btn" class="p-2 rounded-xl text-gray-400 hover:text-white hover:bg-emerald-950 transition border border-transparent hover:border-emerald-800" title="Clear Conversation">
                <i data-lucide="rotate-ccw" class="w-4 h-4"></i>
              </button>
            </div>
          </div>

          <!-- Quick Action Prompts Bar -->
          <div class="px-4 py-2.5 bg-[#081511] border-b border-emerald-950/80 overflow-x-auto flex items-center gap-2 no-scrollbar">
            <span class="text-[11px] text-gray-500 font-bold shrink-0 uppercase tracking-wider flex items-center gap-1">
              <i data-lucide="sparkles" class="w-3.5 h-3.5 text-amber-400"></i> Prompts:
            </span>
            <button class="copilot-chip shrink-0 px-3 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800/60 hover:border-emerald-500 text-xs text-emerald-300 hover:bg-emerald-900/60 transition" data-prompt="What agricultural dataset is used in AgroSense and how is its schema structured?">
              📊 ICAR Agronomic Dataset
            </button>
            <button class="copilot-chip shrink-0 px-3 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800/60 hover:border-emerald-500 text-xs text-emerald-300 hover:bg-emerald-900/60 transition" data-prompt="What machine learning models are benchmarked and which has the highest accuracy?">
              🤖 ML Model Benchmarks
            </button>
            <button class="copilot-chip shrink-0 px-3 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800/60 hover:border-emerald-500 text-xs text-emerald-300 hover:bg-emerald-900/60 transition" data-prompt="What government subsidies are available for solar pumps and drip irrigation?">
              🏛️ Govt Subsidies
            </button>
            <button class="copilot-chip shrink-0 px-3 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800/60 hover:border-emerald-500 text-xs text-emerald-300 hover:bg-emerald-900/60 transition" data-prompt="Check spray safety window and rain risk for my crop today">
              🌧️ Spray & Rain Risk
            </button>
            <button class="copilot-chip shrink-0 px-3 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800/60 hover:border-emerald-500 text-xs text-emerald-300 hover:bg-emerald-900/60 transition" data-prompt="Calculate top dressing fertilizer doses of Urea and DAP for my soil">
              🧪 Top-Dressing Fertilizer
            </button>
            <button class="copilot-chip shrink-0 px-3 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800/60 hover:border-emerald-500 text-xs text-emerald-300 hover:bg-emerald-900/60 transition" data-prompt="What is the local Mandi price and optimal selling time for my harvest?">
              🏛️ Mandi Selling Strategy
            </button>
            <button class="copilot-chip shrink-0 px-3 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800/60 hover:border-emerald-500 text-xs text-emerald-300 hover:bg-emerald-900/60 transition" data-prompt="Recommend foliar disease control and 15L knapsack spray dosage">
              🐛 Foliar Disease Doctor
            </button>
            <button class="copilot-chip shrink-0 px-3 py-1 rounded-lg bg-emerald-950/60 border border-emerald-800/60 hover:border-emerald-500 text-xs text-emerald-300 hover:bg-emerald-900/60 transition" data-prompt="What are optimal irrigation intervals for my crop stage?">
              💧 Irrigation Intervals
            </button>
          </div>

          <!-- Chat Messages Thread Area -->
          <div id="copilot-chat-thread" class="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 custom-scrollbar">
            <!-- Initial Welcome Message from Copilot -->
            <div class="flex items-start gap-3">
              <div class="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 flex items-center justify-center shrink-0 mt-0.5">
                <i data-lucide="bot" class="w-4 h-4"></i>
              </div>
              <div class="flex-1 max-w-2xl bg-emerald-950/40 border border-emerald-800/50 rounded-2xl rounded-tl-sm p-4 text-xs text-gray-200 shadow-md space-y-2.5">
                <div class="flex items-center justify-between pb-1.5 border-b border-emerald-900/60">
                  <span class="font-bold text-emerald-300 flex items-center gap-1.5">
                    <span>🌾 AgroSense AI Copilot</span>
                    <span class="text-[10px] text-gray-400 font-normal">just now</span>
                  </span>
                  <span class="text-[10px] text-emerald-400 font-mono">ICAR Verified</span>
                </div>
                <p class="leading-relaxed">
                  Welcome! I am your <strong>AgroSense AI Farm Copilot</strong>. I am continuously monitoring your farm <strong>${farm.name}</strong>, tracking:
                </p>
                <div class="grid grid-cols-2 gap-2 text-[11px] p-2 rounded-xl bg-gray-900/80 border border-emerald-950">
                  <div>🌱 <strong>Crop</strong>: ${cropData.cropName}</div>
                  <div>🧪 <strong>Soil NPK</strong>: ${farm.soil?.nitrogen || 240}-${farm.soil?.phosphorus || 45}-${farm.soil?.potassium || 180}</div>
                  <div>🌧️ <strong>Weather Threat</strong>: ${weatherRisk.compositeLevel} (${weatherRisk.compositeRiskScore}/100)</div>
                  <div>🚜 <strong>Spray Safety</strong>: ${spray.statusBadge}</div>
                </div>
                <p class="leading-relaxed text-gray-300">
                  Ask me any question in English regarding pesticide spray timing, fertilizer top-dressing doses, crop diseases, irrigation intervals, or Mandi market rates!
                </p>
                <div class="pt-2 flex items-center justify-between border-t border-emerald-900/50">
                  <button class="copilot-audio-btn px-2.5 py-1 rounded-lg bg-emerald-900/50 hover:bg-emerald-800 text-[11px] text-emerald-300 flex items-center gap-1.5 transition" data-speech="Welcome! I am your AgroSense AI Farm Copilot. Ask me any question regarding pesticide spray timing, fertilizer doses, crop diseases, or Mandi rates.">
                    <i data-lucide="volume-2" class="w-3.5 h-3.5"></i> Listen to Audio
                  </button>
                  <span class="text-[10px] text-gray-500">AgroSense Bio-Reasoning Engine</span>
                </div>
              </div>
            </div>
          </div>

          <!-- Chat Input & Voice Bar -->
          <div class="p-4 bg-[#091b15] border-t border-emerald-900/60 space-y-2">
            <!-- Listening / Status Indicator -->
            <div id="copilot-voice-status" class="hidden flex items-center justify-between px-3 py-1.5 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs">
              <span class="flex items-center gap-2">
                <span class="w-2 h-2 rounded-full bg-red-500"></span>
                <span id="copilot-voice-status-text">Listening... Speak now</span>
              </span>
              <button id="copilot-voice-cancel-btn" class="text-gray-400 hover:text-white text-[11px]">Cancel</button>
            </div>

            <!-- Composer Row -->
            <div class="flex items-center gap-2">
              <!-- STT Microphone Button -->
              <button id="copilot-mic-btn" type="button" class="w-11 h-11 rounded-2xl bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/60 text-emerald-300 hover:text-white flex items-center justify-center transition shadow-md shrink-0 cursor-pointer active:scale-95" title="Speech to Text (Microphone)">
                <i data-lucide="mic" class="w-5 h-5"></i>
              </button>

              <!-- Text Input -->
              <input 
                id="copilot-input-field" 
                type="text" 
                placeholder="Ask about spray window, fertilizer doses, disease symptoms, mandi price..." 
                class="flex-1 bg-gray-900/90 border border-emerald-700/60 focus:border-emerald-400 rounded-2xl px-4 py-3 text-xs sm:text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-emerald-400 transition" 
                autocomplete="off"
              />

              <!-- Send Button -->
              <button id="copilot-send-btn" type="button" class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white flex items-center justify-center transition shadow-lg shadow-emerald-900/50 shrink-0 cursor-pointer active:scale-95">
                <i data-lucide="send" class="w-5 h-5"></i>
              </button>
            </div>

            <!-- Grounding & RAG Footer Tagline -->
            <div class="flex items-center justify-between text-[11px] text-gray-500 px-1 pt-1">
              <span>Grounding: 10 Major Crops • 6 Weather Hazards • 15L Knapsack Dosing</span>
              <span class="hidden sm:inline">Press <kbd class="px-1.5 py-0.5 rounded bg-gray-900 border border-gray-700 text-gray-400 text-[10px]">Enter</kbd> to send</span>
            </div>
          </div>

        </div>

      </div>
    </div>
  `;
}

/**
 * Initializes Interactive Hooks for AICopilotPage
 */
function initAICopilotHooks(state, setState) {
  const chatThread = document.getElementById('copilot-chat-thread');
  const inputField = document.getElementById('copilot-input-field');
  const sendBtn = document.getElementById('copilot-send-btn');
  const micBtn = document.getElementById('copilot-mic-btn');
  const langSelect = document.getElementById('copilot-language-select');
  const clearBtn = document.getElementById('copilot-clear-history-btn');
  const voiceStatus = document.getElementById('copilot-voice-status');
  const voiceStatusText = document.getElementById('copilot-voice-status-text');
  const voiceCancelBtn = document.getElementById('copilot-voice-cancel-btn');

  // Set selected language if state has one
  if (langSelect && state.lang) {
    if (state.lang === 'hi' || state.lang === 'mr') {
      langSelect.value = state.lang;
    }
  }

  // Text-To-Speech Audio Synthesis Helper
  const speakText = (text, lang = 'en') => {
    if (!('speechSynthesis' in window)) {
      alert("Text-to-Speech is not supported in this browser.");
      return;
    }
    window.speechSynthesis.cancel(); // cancel any active speech

    // Clean markdown symbols for natural TTS speech
    const cleanStr = text
      .replace(/[*#`_>•]/g, ' ')
      .replace(/http\S+/g, '')
      .replace(/\s+/g, ' ')
      .trim();

    const utterance = new SpeechSynthesisUtterance(cleanStr);
    
    // Attempt language voice matching
    if (lang === 'hi' || /[\u0900-\u097F]/.test(cleanStr)) {
      utterance.lang = 'hi-IN';
    } else if (lang === 'mr') {
      utterance.lang = 'mr-IN';
    } else {
      utterance.lang = 'en-IN';
    }

    utterance.rate = 0.95; // Farmer friendly cadence
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  // Attach Speech Audio Button Handlers
  const attachAudioButtonListeners = () => {
    document.querySelectorAll('.copilot-audio-btn').forEach(btn => {
      btn.onclick = () => {
        const speech = btn.getAttribute('data-speech');
        const lang = langSelect ? langSelect.value : 'en';
        speakText(speech, lang);
      };
    });

    document.querySelectorAll('.copilot-copy-btn').forEach(btn => {
      btn.onclick = () => {
        const copyText = btn.getAttribute('data-copy');
        if (copyText && navigator.clipboard) {
          navigator.clipboard.writeText(copyText).then(() => {
            const orig = btn.innerHTML;
            btn.innerHTML = '<span>✔ Copied!</span>';
            setTimeout(() => { btn.innerHTML = orig; }, 2000);
          });
        }
      };
    });
  };

  attachAudioButtonListeners();

  // Handle Query Submission
  const handleSendQuery = (customQuery = null) => {
    const query = (customQuery || (inputField ? inputField.value : '')).trim();
    if (!query) return;

    if (inputField) inputField.value = '';

    // Append User Message Bubble
    const userBubble = document.createElement('div');
    userBubble.className = "flex items-start justify-end gap-3";
    userBubble.innerHTML = `
      <div class="max-w-xl bg-gradient-to-r from-emerald-700 to-teal-800 text-white rounded-2xl rounded-tr-sm p-4 text-xs shadow-md">
        <div class="flex items-center justify-between pb-1 border-b border-emerald-600/60 mb-1.5 text-[10px] text-emerald-200">
          <span class="font-bold">Farmer Query</span>
          <span>just now</span>
        </div>
        <p class="leading-relaxed font-medium">${query.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</p>
      </div>
      <div class="w-8 h-8 rounded-xl bg-emerald-600/30 border border-emerald-500/50 text-emerald-300 flex items-center justify-center shrink-0 mt-0.5">
        <i data-lucide="user" class="w-4 h-4"></i>
      </div>
    `;
    chatThread.appendChild(userBubble);
    chatThread.scrollTop = chatThread.scrollHeight;

    // Show Typing Indicator
    const typingIndicator = document.createElement('div');
    typingIndicator.id = 'copilot-typing-bubble';
    typingIndicator.className = "flex items-start gap-3";
    typingIndicator.innerHTML = `
      <div class="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 flex items-center justify-center shrink-0 mt-0.5">
        <i data-lucide="bot" class="w-4 h-4 animate-spin"></i>
      </div>
      <div class="bg-emerald-950/40 border border-emerald-800/50 rounded-2xl rounded-tl-sm p-3.5 text-xs text-gray-300 flex items-center gap-2">
        <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
        <span>Evaluating farm telemetry, weather hazard matrix & ICAR protocols...</span>
      </div>
    `;
    chatThread.appendChild(typingIndicator);
    chatThread.scrollTop = chatThread.scrollHeight;

    if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();

    // Process Copilot Response with realistic processing delay
    setTimeout(() => {
      const activeLang = langSelect ? langSelect.value : 'en';
      const aiResponse = generateAICopilotResponse(query, state.activeFarm, state.weatherData, activeLang);

      // Remove typing bubble
      const typingEl = document.getElementById('copilot-typing-bubble');
      if (typingEl) typingEl.remove();

      // Formatted Response Bubble
      const formattedHtml = formatMarkdownResponse(aiResponse.text);
      const rawTextForSpeech = aiResponse.text;

      const botBubble = document.createElement('div');
      botBubble.className = "flex items-start gap-3";
      botBubble.innerHTML = `
        <div class="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 flex items-center justify-center shrink-0 mt-0.5">
          <i data-lucide="bot" class="w-4 h-4"></i>
        </div>
        <div class="flex-1 max-w-2xl bg-emerald-950/50 border border-emerald-800/60 rounded-2xl rounded-tl-sm p-4 text-xs text-gray-200 shadow-md space-y-3">
          <div class="flex items-center justify-between pb-1.5 border-b border-emerald-900/60">
            <span class="font-bold text-emerald-300 flex items-center gap-1.5">
              <span>🌾 AgroSense AI Copilot</span>
            </span>
            <div class="flex items-center gap-2">
              <button class="copilot-copy-btn text-gray-400 hover:text-white text-[11px] flex items-center gap-1 transition" data-copy="${encodeURIComponent(rawTextForSpeech)}">
                <i data-lucide="copy" class="w-3.5 h-3.5"></i> Copy
              </button>
              <span class="text-[10px] text-emerald-400 font-mono">ICAR Validated</span>
            </div>
          </div>

          <div class="copilot-response-content space-y-2 leading-relaxed">
            ${formattedHtml}
          </div>

          <!-- Verified Sources Grounding -->
          ${aiResponse.sources && aiResponse.sources.length > 0 ? `
            <div class="pt-2 border-t border-emerald-900/60">
              <span class="text-[10px] text-gray-400 uppercase font-bold tracking-wider block mb-1">Verified RAG Knowledge Grounding:</span>
              <div class="flex flex-wrap gap-1.5">
                ${aiResponse.sources.map(s => `
                  <a href="${s.url || '#/knowledge'}" target="_blank" class="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-400 border border-emerald-800/80 hover:border-emerald-500 transition">
                    📖 ${s.title} (${s.organization})
                  </a>
                `).join('')}
              </div>
            </div>
          ` : ''}

          <!-- Audio Read Aloud Button -->
          <div class="pt-2 flex items-center justify-between border-t border-emerald-900/40">
            <button class="copilot-audio-btn px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition cursor-pointer" data-speech="${rawTextForSpeech.replace(/"/g, '&quot;')}">
              <i data-lucide="volume-2" class="w-4 h-4"></i> Listen to Audio Advice
            </button>
            <span class="text-[10px] text-gray-500">AgroSense Multimodal AI</span>
          </div>

          <!-- Suggested Dynamic Follow-Up Inquiries -->
          ${aiResponse.followUpPrompts && aiResponse.followUpPrompts.length > 0 ? `
            <div class="pt-2 border-t border-emerald-900/60">
              <span class="text-[10px] text-amber-300 font-bold uppercase tracking-wider block mb-1.5 flex items-center gap-1">
                <i data-lucide="sparkles" class="w-3 h-3 text-amber-400"></i> Suggested Follow-Up Inquiries:
              </span>
              <div class="flex flex-wrap gap-1.5">
                ${aiResponse.followUpPrompts.map(fp => `
                  <button type="button" class="copilot-followup-chip text-left px-2.5 py-1 rounded-lg bg-emerald-950/70 hover:bg-emerald-900 border border-emerald-800/80 hover:border-emerald-500 text-[11px] text-emerald-300 hover:text-white transition cursor-pointer flex items-center gap-1" data-prompt="${fp.replace(/"/g, '&quot;')}">
                    <span class="text-amber-400 font-bold">↳</span> <span>${fp}</span>
                  </button>
                `).join('')}
              </div>
            </div>
          ` : ''}
        </div>
      `;

      // Wire up follow-up chips
      botBubble.querySelectorAll('.copilot-followup-chip').forEach(btn => {
        btn.onclick = () => {
          const prompt = btn.getAttribute('data-prompt');
          if (prompt) handleSendQuery(prompt);
        };
      });

      chatThread.appendChild(botBubble);
      chatThread.scrollTop = chatThread.scrollHeight;

      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
      attachAudioButtonListeners();
    }, 450);
  };

  // Wire Click and Key Events
  if (sendBtn) {
    sendBtn.onclick = () => handleSendQuery();
  }

  if (inputField) {
    inputField.onkeypress = (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleSendQuery();
      }
    };
  }

  // Quick Action Prompt Chips
  document.querySelectorAll('.copilot-chip').forEach(chip => {
    chip.onclick = () => {
      const p = chip.getAttribute('data-prompt');
      if (p) handleSendQuery(p);
    };
  });

  // Clear Chat History
  if (clearBtn) {
    clearBtn.onclick = () => {
      if (confirm("Reset conversation with AgroSense Farm Copilot?")) {
        // Re-render page
        window.location.reload();
      }
    };
  }

  // Web Speech API: Speech-to-Text Recognition Hook
  let recognition = null;
  const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (SpeechRec && micBtn) {
    recognition = new SpeechRec();
    recognition.continuous = false;
    recognition.interimResults = false;

    micBtn.onclick = () => {
      try {
        const lang = langSelect ? langSelect.value : 'en';
        if (lang === 'hi') recognition.lang = 'hi-IN';
        else if (lang === 'mr') recognition.lang = 'mr-IN';
        else recognition.lang = 'en-IN';

        if (voiceStatus) voiceStatus.classList.remove('hidden');
        if (voiceStatusText) voiceStatusText.textContent = `Listening in ${lang.toUpperCase()}... Speak your question now`;
        micBtn.classList.add('bg-red-600', 'text-white', 'animate-pulse');

        recognition.start();
      } catch (err) {
        console.warn("Speech recognition already active or error:", err);
      }
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      if (voiceStatus) voiceStatus.classList.add('hidden');
      micBtn.classList.remove('bg-red-600', 'text-white', 'animate-pulse');
      if (transcript && transcript.trim()) {
        handleSendQuery(transcript);
      }
    };

    recognition.onerror = (event) => {
      console.warn("Speech recognition error:", event.error);
      if (voiceStatus) voiceStatus.classList.add('hidden');
      micBtn.classList.remove('bg-red-600', 'text-white', 'animate-pulse');
    };

    recognition.onend = () => {
      if (voiceStatus) voiceStatus.classList.add('hidden');
      micBtn.classList.remove('bg-red-600', 'text-white', 'animate-pulse');
    };

    if (voiceCancelBtn) {
      voiceCancelBtn.onclick = () => {
        try { recognition.abort(); } catch (e) {}
        if (voiceStatus) voiceStatus.classList.add('hidden');
        micBtn.classList.remove('bg-red-600', 'text-white', 'animate-pulse');
      };
    }
  } else if (micBtn) {
    micBtn.onclick = () => {
      alert("Speech recognition is not supported in this browser. Please type your query in the text box.");
    };
  }
}

/* Module Exports */
exports.renderAICopilotPage = renderAICopilotPage; exports.initAICopilotHooks = initAICopilotHooks;
