// AgroSense National & State Agriculture Schemes & Subsidy Command Center
// Personalized scheme matching, live subsidy calculator, documents checklist & official portals

const { GOVERNMENT_SUBSIDIES,
  SUBSIDY_CATEGORIES,
  SUBSIDY_CALCULATOR_PRESETS,
  evaluateFarmSchemeEligibility,
  calculateSubsidyEstimate } = require('js/data/subsidiesData.js');

let currentCategory = 'all';
let currentSearchQuery = '';
let showRecommendedOnly = false;
let currentCalculatorState = {
  presetId: 'drip-system',
  units: 2.5,
  isSmallFarmer: true,
  isWomenOrSCST: false
};

function renderGovernmentSubsidiesPage(state) {
  const farm = state.activeFarm || {
    name: 'My Agricultural Plot',
    sizeAcres: 5.0,
    currentCrop: 'Wheat (HD-2967)',
    irrigationType: 'Drip Irrigation & Borewell',
    location: 'Pune District, Maharashtra'
  };

  // Evaluate all schemes with farm context
  const schemesWithMatch = GOVERNMENT_SUBSIDIES.map(scheme => {
    const evaluation = evaluateFarmSchemeEligibility(scheme, farm);
    return {
      ...scheme,
      ...evaluation
    };
  }).sort((a, b) => b.matchScore - a.matchScore);

  const highMatchCount = schemesWithMatch.filter(s => s.isHighlyRecommended).length;

  // Filter schemes based on active category and search query
  const filteredSchemes = schemesWithMatch.filter(s => {
    const matchesCategory = currentCategory === 'all' || s.category === currentCategory;
    const matchesRecommended = !showRecommendedOnly || s.isHighlyRecommended;
    const query = currentSearchQuery.toLowerCase().trim();
    const matchesQuery = !query || 
      s.name.toLowerCase().includes(query) ||
      s.shortName.toLowerCase().includes(query) ||
      s.categoryLabel.toLowerCase().includes(query) ||
      s.summary.toLowerCase().includes(query) ||
      s.keyBenefits.some(b => b.toLowerCase().includes(query));

    return matchesCategory && matchesRecommended && matchesQuery;
  });

  // Calculate default subsidy estimate
  const calcResult = calculateSubsidyEstimate(currentCalculatorState);

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">

      <!-- Top Title Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
              <i data-lucide="building-2" class="w-6 h-6 text-emerald-400"></i>
              Government Agriculture Schemes & Subsidy Center
            </h1>
            <span class="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              18 SCHEMES VERIFIED
            </span>
          </div>
          <p class="text-xs text-gray-400 mt-1">
            Personalized DBT subsidy matching, equipment cost estimator, and verified ministry portals for <b class="text-white">${farm.name}</b> (${farm.sizeAcres || 5} Acres • ${farm.irrigationType || 'Drip'} • ${farm.location || 'India'})
          </p>
        </div>

        <div class="flex items-center gap-2 flex-wrap">
          <div class="px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-700/40 text-right">
            <span class="text-[10px] text-gray-400 block">Personalized Matches</span>
            <span class="text-sm font-bold text-emerald-400 font-mono">${highMatchCount} High Fit</span>
          </div>
          <a href="#/copilot" class="px-3.5 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/30 text-xs font-bold transition flex items-center gap-1.5 text-decoration-none">
            <i data-lucide="bot" class="w-4 h-4 text-emerald-400"></i>
            Ask AI Copilot →
          </a>
        </div>
      </div>

      <!-- INTERACTIVE SUBSIDY CALCULATOR WIDGET -->
      <div class="glass-card p-5 border border-emerald-500/40 bg-gradient-to-br from-emerald-950/50 via-slate-900/90 to-teal-950/40 shadow-xl rounded-2xl space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-900/40 pb-3">
          <div class="flex items-center gap-2.5">
            <div class="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <i data-lucide="calculator" class="w-5 h-5"></i>
            </div>
            <div>
              <h2 class="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <span>Interactive Equipment Subsidy & Loan Estimator</span>
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">INSTANT DBT</span>
              </h2>
              <p class="text-xs text-gray-400">Calculate exact government grant amount, bank loan financing, and net farmer out-of-pocket cash.</p>
            </div>
          </div>
          <span class="text-xs font-mono text-emerald-400/90 bg-emerald-950/80 px-2.5 py-1 rounded-lg border border-emerald-800/50">
            Scheme: <b id="calc-scheme-name">${calcResult.preset.schemeName}</b>
          </span>
        </div>

        <!-- Calculator Form Controls & Live Output Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <!-- Inputs (5 cols) -->
          <div class="lg:col-span-5 space-y-3">
            <div>
              <label class="block text-xs font-semibold text-gray-300 mb-1">Select Equipment / Infrastructure Asset</label>
              <select id="calc-asset-select" class="w-full bg-gray-900 border border-emerald-700/50 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400 transition">
                ${SUBSIDY_CALCULATOR_PRESETS.map(p => `
                  <option value="${p.id}" ${p.id === currentCalculatorState.presetId ? 'selected' : ''}>${p.name}</option>
                `).join('')}
              </select>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-xs font-semibold text-gray-300 mb-1" id="calc-units-label">Farm Size (${calcResult.preset.unitLabel})</label>
                <input type="number" id="calc-units-input" min="0.5" max="${calcResult.preset.maxUnits}" step="0.5" value="${currentCalculatorState.units}" class="w-full bg-gray-900 border border-emerald-700/50 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400 transition" />
              </div>
              <div>
                <label class="block text-xs font-semibold text-gray-300 mb-1">Farmer Category</label>
                <select id="calc-category-select" class="w-full bg-gray-900 border border-emerald-700/50 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400 transition">
                  <option value="small" ${currentCalculatorState.isSmallFarmer ? 'selected' : ''}>Small / Marginal (&lt;5 Acres) - 55% Rate</option>
                  <option value="general" ${!currentCalculatorState.isSmallFarmer && !currentCalculatorState.isWomenOrSCST ? 'selected' : ''}>General (&gt;5 Acres) - 45% Rate</option>
                  <option value="priority" ${currentCalculatorState.isWomenOrSCST ? 'selected' : ''}>Women / SC / ST / FPO - Priority</option>
                </select>
              </div>
            </div>

            <p class="text-[11px] text-gray-400 leading-relaxed italic" id="calc-desc">
              ${calcResult.preset.description}
            </p>
          </div>

          <!-- Output Cards (7 cols) -->
          <div class="lg:col-span-7 grid grid-cols-2 sm:grid-cols-4 gap-3" id="calc-results-container">
            <!-- Card 1: Gross Cost -->
            <div class="glass-card p-3 rounded-xl border border-gray-800/80 bg-gray-950/60 flex flex-col justify-between">
              <span class="text-[10px] text-gray-400 uppercase tracking-wider">Gross Equipment Cost</span>
              <div>
                <div class="text-base font-extrabold text-white font-mono" id="calc-gross-cost">₹${calcResult.totalGrossCost.toLocaleString('en-IN')}</div>
                <span class="text-[10px] text-gray-500">100% Invoice Value</span>
              </div>
            </div>

            <!-- Card 2: Govt Subsidy -->
            <div class="glass-card p-3 rounded-xl border border-emerald-600/50 bg-emerald-950/30 flex flex-col justify-between">
              <span class="text-[10px] text-emerald-300 uppercase tracking-wider font-semibold">Government Subsidy</span>
              <div>
                <div class="text-base font-black text-emerald-400 font-mono" id="calc-subsidy-amount">₹${calcResult.subsidyAmount.toLocaleString('en-IN')}</div>
                <span class="text-[10px] font-bold text-emerald-400" id="calc-subsidy-rate">${calcResult.subsidyRatePct}% Capital Grant (DBT)</span>
              </div>
            </div>

            <!-- Card 3: Bank Loan Support -->
            <div class="glass-card p-3 rounded-xl border border-blue-600/40 bg-blue-950/20 flex flex-col justify-between">
              <span class="text-[10px] text-blue-300 uppercase tracking-wider font-semibold">Bank Loan (MISS)</span>
              <div>
                <div class="text-base font-extrabold text-blue-300 font-mono" id="calc-loan-amount">₹${calcResult.bankLoanAmount.toLocaleString('en-IN')}</div>
                <span class="text-[10px] text-blue-400">30% at Concessional 4%</span>
              </div>
            </div>

            <!-- Card 4: Net Farmer Cash Share -->
            <div class="glass-card p-3 rounded-xl border border-amber-600/50 bg-amber-950/30 flex flex-col justify-between">
              <span class="text-[10px] text-amber-300 uppercase tracking-wider font-semibold">Farmer Cash Share</span>
              <div>
                <div class="text-base font-black text-amber-400 font-mono" id="calc-net-cash">₹${calcResult.cashMarginRequired.toLocaleString('en-IN')}</div>
                <span class="text-[10px] font-bold text-amber-300">Only ~10-15% Upfront</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- FILTER CONTROLS: Category Chips & Search Bar -->
      <div class="space-y-3">
        <!-- Search & Recommended Toggle Bar -->
        <div class="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <!-- Search input -->
          <div class="relative flex-1">
            <i data-lucide="search" class="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"></i>
            <input type="text" id="scheme-search-input" value="${currentSearchQuery}" placeholder="Search schemes by name, keyword (e.g. drip, solar pump, drone, KCC, insurance)..." class="w-full bg-gray-900/90 border border-emerald-800/50 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400 transition" />
            ${currentSearchQuery ? `
              <button type="button" id="btn-clear-search" class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white text-xs">✕</button>
            ` : ''}
          </div>

          <!-- Highly Recommended Toggle -->
          <div class="flex items-center gap-2 shrink-0">
            <button type="button" id="btn-toggle-recommended" class="px-3.5 py-2.5 rounded-xl border ${showRecommendedOnly ? 'bg-emerald-500 text-slate-950 font-bold border-emerald-400' : 'bg-gray-900/90 text-gray-300 border-emerald-800/50 hover:border-emerald-500'} text-xs transition flex items-center gap-1.5">
              <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
              <span>Highly Recommended Only (${highMatchCount})</span>
            </button>
          </div>
        </div>

        <!-- Category Horizontal Scroll / Wrap Chips -->
        <div class="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
          ${SUBSIDY_CATEGORIES.map(cat => {
            const isSelected = currentCategory === cat.id;
            const count = cat.id === 'all' 
              ? GOVERNMENT_SUBSIDIES.length 
              : GOVERNMENT_SUBSIDIES.filter(s => s.category === cat.id).length;

            return `
              <button type="button" class="scheme-category-chip shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 ${
                isSelected 
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-md shadow-emerald-500/20' 
                  : 'bg-gray-900/80 text-gray-300 border border-emerald-900/60 hover:border-emerald-500/80 hover:text-white'
              }" data-category="${cat.id}">
                <i data-lucide="${cat.icon}" class="w-3.5 h-3.5"></i>
                <span>${cat.label}</span>
                <span class="px-1.5 py-0.2 rounded text-[10px] ${isSelected ? 'bg-slate-950/20 text-slate-950 font-mono' : 'bg-emerald-950 text-emerald-400 font-mono'}">${count}</span>
              </button>
            `;
          }).join('')}
        </div>
      </div>

      <!-- RESULTS COUNT -->
      <div class="flex items-center justify-between text-xs text-gray-400 px-1">
        <span>Showing <b>${filteredSchemes.length}</b> of ${GOVERNMENT_SUBSIDIES.length} schemes</span>
        ${currentSearchQuery || currentCategory !== 'all' || showRecommendedOnly ? `
          <button type="button" id="btn-reset-filters" class="text-emerald-400 hover:underline">Reset Filters</button>
        ` : ''}
      </div>

      <!-- SCHEME CARDS GRID -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        ${filteredSchemes.map(s => {
          const matchColor = s.matchScore >= 90 ? 'emerald' : s.matchScore >= 80 ? 'blue' : 'gray';
          return `
            <div class="glass-card p-6 space-y-4 border border-emerald-900/50 hover:border-emerald-500/50 transition-all flex flex-col justify-between group shadow-lg">
              
              <div class="space-y-3">
                <!-- Top Badges Row -->
                <div class="flex items-center justify-between gap-2 flex-wrap">
                  <div class="flex items-center gap-1.5">
                    <span class="px-2.5 py-0.5 rounded text-[10px] font-bold bg-${matchColor}-500/20 text-${matchColor}-300 border border-${matchColor}-500/30 flex items-center gap-1">
                      <i data-lucide="${s.matchScore >= 90 ? 'check-circle' : 'activity'}" class="w-3 h-3"></i>
                      ${s.matchScore}% MATCH
                    </span>
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-gray-800/80 text-gray-300 border border-gray-700/60 uppercase">
                      ${s.categoryLabel}
                    </span>
                    ${s.isStateSpecific ? `
                      <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        ${s.statesApplicable}
                      </span>
                    ` : ''}
                  </div>

                  <span class="text-xs font-mono font-black text-amber-400 bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/40">
                    ${s.subsidyPct}
                  </span>
                </div>

                <!-- Scheme Title -->
                <div>
                  <h3 class="text-base font-bold text-white group-hover:text-emerald-300 transition leading-snug">
                    ${s.name}
                  </h3>
                  <p class="text-[11px] text-emerald-400/90 font-medium mt-0.5">
                    ${s.ministry}
                  </p>
                </div>

                <!-- Match Reasoning for Active Farm -->
                <div class="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-900/70 text-xs text-gray-300 flex items-start gap-2">
                  <i data-lucide="sparkles" class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"></i>
                  <div>
                    <span class="font-semibold text-emerald-300 text-[11px] block">Farm Profile Match Context:</span>
                    <span class="text-[11px] text-gray-300">${s.matchReason}</span>
                  </div>
                </div>

                <!-- Summary Description -->
                <p class="text-xs text-gray-300 leading-relaxed">
                  ${s.summary}
                </p>

                <!-- Key Benefits List -->
                <div class="space-y-1.5 pt-1">
                  <span class="text-[11px] font-bold text-gray-400 uppercase tracking-wider block">Key Scheme Benefits:</span>
                  ${s.keyBenefits.map(b => `
                    <div class="flex items-start gap-1.5 text-xs text-gray-300">
                      <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5"></i>
                      <span>${b}</span>
                    </div>
                  `).join('')}
                </div>

                <!-- Financial Max Cap & Share -->
                <div class="grid grid-cols-2 gap-2 pt-2 border-t border-emerald-950/60 text-[11px]">
                  <div>
                    <span class="text-gray-400 block">Maximum Assistance:</span>
                    <b class="text-white font-mono">${s.subsidyMaxAmount}</b>
                  </div>
                  <div>
                    <span class="text-gray-400 block">Farmer Contribution:</span>
                    <b class="text-amber-300 font-mono">${s.farmerShare}</b>
                  </div>
                </div>

                <!-- Expandable Required Documents Accordion -->
                <details class="group/docs text-xs pt-1">
                  <summary class="cursor-pointer text-emerald-400 hover:text-emerald-300 font-semibold flex items-center justify-between select-none py-1">
                    <span class="flex items-center gap-1">
                      <i data-lucide="file-text" class="w-3.5 h-3.5"></i> Required Documents Checklist (${s.documentsRequired.length})
                    </span>
                    <span class="text-[10px] text-gray-400 group-open/docs:rotate-180 transition">▼</span>
                  </summary>
                  <div class="mt-2 p-3 rounded-lg bg-gray-950/80 border border-emerald-900/60 space-y-1.5">
                    ${s.documentsRequired.map(doc => `
                      <div class="flex items-center gap-1.5 text-[11px] text-gray-300">
                        <i data-lucide="circle-dot" class="w-3 h-3 text-emerald-400 shrink-0"></i>
                        <span>${doc}</span>
                      </div>
                    `).join('')}
                  </div>
                </details>
              </div>

              <!-- Card Action Footer -->
              <div class="flex items-center justify-between pt-4 border-t border-emerald-950/60 text-xs mt-4">
                <span class="text-[11px] text-gray-400 flex items-center gap-1">
                  <i data-lucide="shield-check" class="w-3.5 h-3.5 text-emerald-400"></i> Govt Verified
                </span>
                <a href="${s.officialPortal}" target="_blank" rel="noopener noreferrer" class="px-3.5 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 font-bold transition flex items-center gap-1.5 text-decoration-none shadow">
                  <span>Apply on Official Portal</span>
                  <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                </a>
              </div>

            </div>
          `;
        }).join('')}
      </div>

      <!-- FAQ & HELPLINE ACCORDION CARD -->
      <div class="glass-card p-6 border border-emerald-800/40 rounded-2xl space-y-4">
        <div class="flex items-center justify-between border-b border-emerald-900/40 pb-3">
          <div class="flex items-center gap-2.5">
            <div class="w-9 h-9 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <i data-lucide="phone-call" class="w-5 h-5"></i>
            </div>
            <div>
              <h3 class="text-sm font-bold text-white">Government Kisan Call Center & Grievance Helplines</h3>
              <p class="text-xs text-gray-400">Free 24x7 toll-free support across 22 regional Indian languages.</p>
            </div>
          </div>
          <span class="px-2.5 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">TOLL-FREE 1800-180-1551</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div class="p-3.5 rounded-xl bg-gray-950/60 border border-emerald-900/50 space-y-1">
            <span class="text-gray-400 block text-[10px] uppercase font-mono">National Kisan Call Center</span>
            <b class="text-white text-sm block">1800-180-1551</b>
            <p class="text-[11px] text-gray-400">Direct agronomic advice, fertilizer availability, and scheme tracking.</p>
          </div>
          <div class="p-3.5 rounded-xl bg-gray-950/60 border border-emerald-900/50 space-y-1">
            <span class="text-gray-400 block text-[10px] uppercase font-mono">PM-KISAN Helpline</span>
            <b class="text-white text-sm block">155261 / 011-24300606</b>
            <p class="text-[11px] text-gray-400">Aadhaar e-KYC verification and pending installment clearance.</p>
          </div>
          <div class="p-3.5 rounded-xl bg-gray-950/60 border border-emerald-900/50 space-y-1">
            <span class="text-gray-400 block text-[10px] uppercase font-mono">PMFBY Crop Insurance Desk</span>
            <b class="text-white text-sm block">14447</b>
            <p class="text-[11px] text-gray-400">Intimate localized crop loss within 72 hours for prompt surveyor visit.</p>
          </div>
        </div>
      </div>

    </div>
  `;
}

/**
 * Initializes DOM interactive hooks for the Government Subsidies page
 */
function initGovernmentSubsidiesHooks(state, setState) {
  // Re-run Lucide icons
  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    window.lucide.createIcons();
  }

  // 1. Category Chips Clicking
  const categoryChips = document.querySelectorAll('.scheme-category-chip');
  categoryChips.forEach(chip => {
    chip.addEventListener('click', () => {
      currentCategory = chip.getAttribute('data-category');
      reRenderSubsidiesPage(state, setState);
    });
  });

  // 2. Search Input Keyup
  const searchInput = document.getElementById('scheme-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentSearchQuery = e.target.value;
      reRenderSubsidiesPage(state, setState);
    });
  }

  // 3. Clear Search Button
  const btnClearSearch = document.getElementById('btn-clear-search');
  if (btnClearSearch) {
    btnClearSearch.addEventListener('click', () => {
      currentSearchQuery = '';
      reRenderSubsidiesPage(state, setState);
    });
  }

  // 4. Toggle Highly Recommended Only
  const btnToggleRecommended = document.getElementById('btn-toggle-recommended');
  if (btnToggleRecommended) {
    btnToggleRecommended.addEventListener('click', () => {
      showRecommendedOnly = !showRecommendedOnly;
      reRenderSubsidiesPage(state, setState);
    });
  }

  // 5. Reset Filters
  const btnResetFilters = document.getElementById('btn-reset-filters');
  if (btnResetFilters) {
    btnResetFilters.addEventListener('click', () => {
      currentCategory = 'all';
      currentSearchQuery = '';
      showRecommendedOnly = false;
      reRenderSubsidiesPage(state, setState);
    });
  }

  // 6. Interactive Subsidy Calculator Event Handlers
  const assetSelect = document.getElementById('calc-asset-select');
  const unitsInput = document.getElementById('calc-units-input');
  const categorySelect = document.getElementById('calc-category-select');

  function updateCalculatorView() {
    if (!assetSelect || !unitsInput || !categorySelect) return;

    const presetId = assetSelect.value;
    const units = parseFloat(unitsInput.value) || 1;
    const catVal = categorySelect.value;
    const isSmall = catVal === 'small';
    const isPriority = catVal === 'priority';

    currentCalculatorState = {
      presetId,
      units,
      isSmallFarmer: isSmall || isPriority,
      isWomenOrSCST: isPriority
    };

    const calcResult = calculateSubsidyEstimate(currentCalculatorState);

    // Update outputs
    const grossEl = document.getElementById('calc-gross-cost');
    const subsidyEl = document.getElementById('calc-subsidy-amount');
    const rateEl = document.getElementById('calc-subsidy-rate');
    const loanEl = document.getElementById('calc-loan-amount');
    const cashEl = document.getElementById('calc-net-cash');
    const schemeNameEl = document.getElementById('calc-scheme-name');
    const descEl = document.getElementById('calc-desc');
    const unitsLabelEl = document.getElementById('calc-units-label');

    if (grossEl) grossEl.textContent = `₹${calcResult.totalGrossCost.toLocaleString('en-IN')}`;
    if (subsidyEl) subsidyEl.textContent = `₹${calcResult.subsidyAmount.toLocaleString('en-IN')}`;
    if (rateEl) rateEl.textContent = `${calcResult.subsidyRatePct}% Capital Grant (DBT)`;
    if (loanEl) loanEl.textContent = `₹${calcResult.bankLoanAmount.toLocaleString('en-IN')}`;
    if (cashEl) cashEl.textContent = `₹${calcResult.cashMarginRequired.toLocaleString('en-IN')}`;
    if (schemeNameEl) schemeNameEl.textContent = calcResult.preset.schemeName;
    if (descEl) descEl.textContent = calcResult.preset.description;
    if (unitsLabelEl) unitsLabelEl.textContent = `Farm Size (${calcResult.preset.unitLabel})`;
  }

  if (assetSelect) assetSelect.addEventListener('change', updateCalculatorView);
  if (unitsInput) unitsInput.addEventListener('input', updateCalculatorView);
  if (categorySelect) categorySelect.addEventListener('change', updateCalculatorView);
}

function reRenderSubsidiesPage(state, setState) {
  const container = document.getElementById('app-main-content');
  if (container) {
    container.innerHTML = renderGovernmentSubsidiesPage(state);
    initGovernmentSubsidiesHooks(state, setState);
  }
}

/* Module Exports */
exports.renderGovernmentSubsidiesPage = renderGovernmentSubsidiesPage; exports.initGovernmentSubsidiesHooks = initGovernmentSubsidiesHooks;
