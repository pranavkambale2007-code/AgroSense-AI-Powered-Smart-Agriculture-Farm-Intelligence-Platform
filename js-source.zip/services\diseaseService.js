// AgroSense Computer Vision Plant Disease Classifier Service
// Real-time leaf pathology screening, biomarker extraction, dynamic lesion localization & multi-tiered farmer solutions

const {
  plantDiseaseDatabase,
  demoLeafSamples,
  getSampleDataUrl,
  analyzeLeafImage,
  getWhyThisHappens,
  healthyCropReferenceModels,
  diseaseVernacularDictionary,
  SUPPORTED_CROP_REGISTRY,
  PLANTVILLAGE_CLASSES,
  loadPlantVillageModel,
  initDiseaseModel,
  getModelStatus,
  subscribeModelStatus,
  MODEL_STATUS,
  initCropModel,
  getCropModelStatus,
  subscribeCropModelStatus,
  detectCropFromImage,
  CROP_MODEL_STATUS,
  SUPPORTED_CROP_CLASSES
} = require('js/ml/plantDiseaseModel.js');

function getPlantDiseaseById(id) {
  return plantDiseaseDatabase.find(d => d.id === id) || plantDiseaseDatabase[0];
}

/**
 * Classify a leaf image synchronously (for initial page load or preset specimen view)
 * Note: Real uploaded images must always use the async analyzeLeafImage() pipeline.
 */
function classifyLeafImage(imageSource = null, selectedSampleId = null, cropHint = 'all') {
  const normalizedCrop = cropHint && cropHint !== 'all' ? (SUPPORTED_CROP_REGISTRY[cropHint] ? cropHint : (cropHint.toLowerCase().replace(/[^a-z0-9_]/g, ''))) : 'all';

  // Unsupported crop check
  if (normalizedCrop !== 'all' && !SUPPORTED_CROP_REGISTRY[normalizedCrop]) {
    return {
      isValidImage: false,
      status: 'UNSUPPORTED_CROP',
      errorType: 'unsupported-crop',
      validationError: 'Disease detection for this crop is not supported by the current model.',
      cropRecognition: {
        cropKey: normalizedCrop,
        cropName: normalizedCrop,
        confidence: 0,
        isSupported: false
      },
      topCandidates: [],
      imageSrc: null,
      fileName: null
    };
  }

  let matchedDisease = null;
  let dataUrl = null;

  if (selectedSampleId) {
    let diseaseId = selectedSampleId;
    if (selectedSampleId === 'disease-01') diseaseId = 'maize-common-rust';
    if (selectedSampleId === 'disease-02') diseaseId = 'tomato-early-blight';
    if (selectedSampleId === 'disease-03') diseaseId = 'maize-healthy';

    const sample = demoLeafSamples.find(s => s.id === selectedSampleId || s.diseaseId === selectedSampleId || s.diseaseId === diseaseId);
    matchedDisease = plantDiseaseDatabase.find(d => d.id === (sample?.diseaseId || diseaseId)) || plantDiseaseDatabase[0];
    dataUrl = sample ? getSampleDataUrl(sample.svg) : null;
  } else {
    // Default initial preview: Maize healthy baseline (supported crop)
    matchedDisease = plantDiseaseDatabase.find(d => d.id === 'maize-healthy') || plantDiseaseDatabase[0];
    dataUrl = 'images/healthy_crops/maize_healthy.jpg';
  }

  const isHealthy = matchedDisease.pathogenType.toLowerCase().includes('healthy');
  const targetCropKey = matchedDisease.cropKey;
  const healthyRef = healthyCropReferenceModels[targetCropKey] || healthyCropReferenceModels.maize || healthyCropReferenceModels.tomato;

  const observedBiomarkers = {
    greenPercentage: Math.round((matchedDisease.targetBiomarkers?.green || 0.85) * 100),
    necroticPercentage: Math.round((matchedDisease.targetBiomarkers?.necrotic || 0.05) * 100),
    chlorosisPercentage: Math.round((matchedDisease.targetBiomarkers?.chlorosis || 0.05) * 100),
    powderyPercentage: Math.round((matchedDisease.targetBiomarkers?.powdery || 0) * 100),
    rustPercentage: Math.round((matchedDisease.targetBiomarkers?.rust || 0.05) * 100)
  };

  const greenDeficit = Math.max(0, (healthyRef.healthyBiomarkers?.green || 96) - observedBiomarkers.greenPercentage);
  const pathogenSpread = Math.round(((matchedDisease.targetBiomarkers?.necrotic || 0) + (matchedDisease.targetBiomarkers?.chlorosis || 0) + (matchedDisease.targetBiomarkers?.powdery || 0) + (matchedDisease.targetBiomarkers?.rust || 0)) * 100);

  const cropRecognition = {
    cropKey: targetCropKey,
    cropName: matchedDisease.crop,
    confidence: isHealthy ? 98.4 : 92.0,
    isReliable: true,
    isAmbiguous: false,
    evidenceTags: [healthyRef.botanicalClass || 'Agricultural Crop', healthyRef.marginType || 'Standard Foliar Border'],
    topAlternatives: [{ cropKey: targetCropKey, cropName: matchedDisease.crop, confidence: isHealthy ? 98.4 : 92.0 }],
    botanicalClass: healthyRef.botanicalClass,
    leafMorphology: healthyRef.leafMorphology,
    marginType: healthyRef.marginType,
    aspectRatioDescriptor: healthyRef.aspectRatioDescriptor,
    runnerUp: null
  };

  const healthyBaseline = {
    cropKey: targetCropKey,
    cropName: matchedDisease.crop,
    botanicalClass: healthyRef.botanicalClass,
    leafMorphology: healthyRef.leafMorphology,
    marginType: healthyRef.marginType,
    aspectRatioDescriptor: healthyRef.aspectRatioDescriptor,
    svg: healthyRef.svg,
    realPhotoUrl: healthyRef.realPhotoUrl || 'images/healthy_crops/maize_healthy.jpg',
    realPhotoDescription: healthyRef.realPhotoDescription || 'Natural healthy foliage displaying intact cuticle and complete chlorophyll density.',
    healthyBiomarkers: healthyRef.healthyBiomarkers,
    healthyTraits: healthyRef.healthyTraits,
    observedBiomarkers,
    deviationAnalysis: {
      greenDeficit,
      necroticSpread: observedBiomarkers.necroticPercentage,
      chlorosisSpread: observedBiomarkers.chlorosisPercentage,
      powderySpread: observedBiomarkers.powderyPercentage,
      rustSpread: observedBiomarkers.rustPercentage,
      pathogenSpread,
      healthStatus: (isHealthy || pathogenSpread < 6) ? 'Nominal (Healthy Baseline Foliage)' : 'Pathological Tissue Loss'
    }
  };

  const vernacularInfo = diseaseVernacularDictionary[matchedDisease.id] || {
    commonName: matchedDisease.diseaseName.split('(')[0].trim(),
    scientificName: matchedDisease.diseaseName.includes('(') ? matchedDisease.diseaseName.match(/\\((.*?)\\)/)?.[1] || '' : '',
    vernacularName: matchedDisease.diseaseName,
    vernacularHindi: '',
    vernacularMarathi: ''
  };

  const topCandidates = [
    {
      id: matchedDisease.id,
      name: matchedDisease.diseaseName,
      commonName: vernacularInfo.commonName,
      scientificName: vernacularInfo.scientificName,
      vernacularName: vernacularInfo.vernacularName,
      crop: matchedDisease.crop,
      prob: isHealthy ? 98.4 : 92.0,
      category: matchedDisease.pathogenType,
      status: "Curated Specimen Baseline"
    }
  ];

  return {
    isValidImage: true,
    ...matchedDisease,
    commonName: vernacularInfo.commonName,
    scientificName: vernacularInfo.scientificName,
    vernacularName: vernacularInfo.vernacularName,
    vernacularHindi: vernacularInfo.vernacularHindi || '',
    vernacularMarathi: vernacularInfo.vernacularMarathi || '',
    primarySymptom: vernacularInfo.primarySymptom || '',
    confidence: isHealthy ? 98.4 : 92.0,
    severity: isHealthy ? "None (Healthy)" : "Moderate",
    imageSrc: dataUrl,
    cropRecognition,
    healthyBaseline,
    whyThisHappens: matchedDisease.whyThisHappens || getWhyThisHappens(matchedDisease.id, matchedDisease),
    recommendedActions: [
      ...(matchedDisease.culturalMeasures ? matchedDisease.culturalMeasures.slice(0, 1) : []),
      ...(matchedDisease.chemicalControl && matchedDisease.chemicalControl[0] ? [`Chemical: ${matchedDisease.chemicalControl[0].chemical} @ ${matchedDisease.chemicalControl[0].dosage}`] : []),
      ...(matchedDisease.biologicalControl ? matchedDisease.biologicalControl.slice(0, 1) : [])
    ],
    biomarkers: observedBiomarkers,
    boundingBox: null, // No fake bounding boxes
    topCandidates,
    isInitialPreview: true,
    screeningMode: "AgroSense Curated Specimen Baseline (Upload for Real-Time Inference)",
    disclaimer: "AI computer vision screening advisory — confirm with your local Krishi Vigyan Kendra (KVK) agronomist before chemical treatment."
  };
}

exports.analyzeLeafImage = analyzeLeafImage;
exports.plantDiseaseDatabase = plantDiseaseDatabase;
exports.demoLeafSamples = demoLeafSamples;
exports.getSampleDataUrl = getSampleDataUrl;
exports.getWhyThisHappens = getWhyThisHappens;
exports.healthyCropReferenceModels = healthyCropReferenceModels;
exports.diseaseVernacularDictionary = diseaseVernacularDictionary;
exports.getPlantDiseaseById = getPlantDiseaseById;
exports.classifyLeafImage = classifyLeafImage;
exports.SUPPORTED_CROP_REGISTRY = SUPPORTED_CROP_REGISTRY;
exports.PLANTVILLAGE_CLASSES = PLANTVILLAGE_CLASSES;
exports.loadPlantVillageModel = loadPlantVillageModel;
exports.initDiseaseModel = initDiseaseModel;
exports.getModelStatus = getModelStatus;
exports.subscribeModelStatus = subscribeModelStatus;
exports.MODEL_STATUS = MODEL_STATUS;
exports.initCropModel = initCropModel;
exports.getCropModelStatus = getCropModelStatus;
exports.subscribeCropModelStatus = subscribeCropModelStatus;
exports.detectCropFromImage = detectCropFromImage;
exports.CROP_MODEL_STATUS = CROP_MODEL_STATUS;
exports.SUPPORTED_CROP_CLASSES = SUPPORTED_CROP_CLASSES;
