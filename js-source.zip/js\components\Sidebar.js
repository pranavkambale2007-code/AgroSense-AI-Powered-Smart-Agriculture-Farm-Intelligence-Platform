// AgroSense Collapsible Navigation Sidebar Component

import { translations } from '../data/translations.js';

export function renderSidebar(state) {
  const t = translations[state.lang] || translations.en;
  const currentRoute = state.route || '/crop-recommendation';

  // Strict priority order matching AgroSense specification
  const menuGroups = [
    {
      groupTitle: "1. AI & CROP DECISIONS",
      items: [
        { route: '/crop-recommendation', label: t.nav?.cropRec || 'AI Crop Selection Model', icon: 'sparkles', highlight: true },
        { route: '/soil', label: t.nav?.soil || 'Soil Intelligence', icon: 'test-tube' },
        { route: '/crop-compare', label: t.nav?.cropCompare || 'Crop Comparison', icon: 'columns-4' },
        { route: '/profitability', label: t.nav?.profitability || 'Profitability Calculator', icon: 'calculator' }
      ]
    },
    {
      groupTitle: "2. WEATHER & RISK MANAGEMENT",
      items: [
        { route: '/weather', label: t.nav?.weather || 'Weather Intelligence', icon: 'cloud-sun' },
        { route: '/risk', label: t.nav?.riskEngine || 'Weather Risk Engine', icon: 'shield-alert', highlight: true }
      ]
    },
    {
      groupTitle: "3. CROP HEALTH & MONITORING",
      items: [
        { route: '/disease', label: t.nav?.disease || 'Plant Disease Screening', icon: 'scan-line' },
        { route: '/crop-monitor', label: t.nav?.growthMonitor || 'Crop Lifecycle & Mandi Monitor', icon: 'calendar-clock', highlight: true },
        { route: '/history', label: t.nav?.history || 'Farm History', icon: 'history' }
      ]
    },
    {
      groupTitle: "4. SMART FARM MANAGEMENT",
      items: [
        { route: '/3d-farm', label: t.nav?.threeDFarm || '3D Farm Simulator', icon: 'box', highlight: true },
        { route: '/farm-map', label: t.nav?.map || 'Farm Map & Zones', icon: 'map' },
        { route: '/farm-log', label: t.nav?.farmLog || 'Farm Activity Log', icon: 'clipboard-list' }
      ]
    },
    {
      groupTitle: "5. FARMER ASSISTANCE",
      items: [
        { route: '/ai-assistant', label: t.nav?.aiAssistant || 'AI Farmer Copilot', icon: 'bot' },
        { route: '/subsidies', label: t.nav?.subsidies || 'Govt Schemes & Subsidies', icon: 'building-2' }
      ]
    }
  ];

  return `
    <aside id="app-sidebar" class="w-64 min-w-[16rem] max-w-[16rem] shrink-0 h-full overflow-y-auto overflow-x-hidden border-r border-emerald-950/60 bg-[#081310] flex flex-col justify-between custom-scrollbar p-3 select-none ${state.sidebarOpen ? 'flex fixed inset-y-0 left-0 top-[64px] z-50 h-[calc(100vh-64px)] shadow-2xl' : 'hidden lg:flex'}">
      <!-- Quick Onboarding Banner -->
      <a href="#/onboarding" id="btn-sidebar-add-farm" class="btn-add-farm-action block mb-4 p-3 rounded-xl bg-gradient-to-r from-emerald-900/60 to-teal-950/80 border border-emerald-500/30 hover:border-emerald-400 transition text-decoration-none group cursor-pointer">
        <div class="flex items-center justify-between">
          <span class="text-xs font-bold text-emerald-300">Add / Edit Farm</span>
          <i data-lucide="plus-circle" class="w-4 h-4 text-emerald-400 group-hover:rotate-90 transition transform"></i>
        </div>
        <p class="text-[11px] text-gray-400 mt-1">Configure soil, GPS boundary & crops</p>
      </a>

      <!-- Menu Navigation Groups in Strict Priority Order -->
      <div class="space-y-4 flex-1">
        ${menuGroups.map(group => `
          <div>
            <h4 class="text-[10px] font-extrabold tracking-wider text-emerald-400/80 uppercase px-3 mb-1.5 font-mono">${group.groupTitle}</h4>
            <div class="space-y-0.5">
              ${group.items.map(item => {
                const isActive = currentRoute === item.route;
                return `
                  <a href="#${item.route}" class="flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition text-decoration-none ${
                    isActive 
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm' 
                      : item.highlight
                        ? 'text-amber-300 hover:bg-amber-950/30 border border-amber-500/20'
                        : 'text-gray-400 hover:bg-emerald-950/50 hover:text-emerald-300'
                  }">
                    <i data-lucide="${item.icon}" class="w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-gray-500'}"></i>
                    <span>${item.label}</span>
                  </a>
                `;
              }).join('')}
            </div>
          </div>
        `).join('')}
      </div>

      <!-- Footer Info -->
      <div class="mt-auto shrink-0 pt-4 border-t border-emerald-950/80 px-3 text-[11px] text-gray-500">
        <div class="flex items-center justify-between font-mono">
          <span>AgroSense Enterprise</span>
          <span class="text-emerald-400 font-semibold">v2.5.4 LTS</span>
        </div>
        <p class="text-[10px] text-gray-500 mt-1">ICAR & AgMIP Agronomic Standards</p>
        <div class="flex items-center gap-2 mt-2 pt-2 border-t border-emerald-950/40 text-[10px] text-gray-600 font-mono">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Engine: Active (Node.js & Canvas PBR)</span>
        </div>
      </div>
    </aside>
  `;
}
