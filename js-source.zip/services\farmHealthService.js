// AgroSense Composite Farm Health Score Mathematical Engine

const { analyzeSoilHealth } = require('js/services/soilService.js');
const { calculateIrrigationRecommendation } = require('js/services/irrigationService.js');
const { evaluateWeatherRisks } = require('js/services/weatherService.js');

function calculateCompositeFarmHealthScore(farm, weatherData = null) {
  if (!farm || !farm.soil || farm.id === 'unregistered') {
    return {
      compositeScore: 0,
      formulaString: "S_farm = (0.25 × S_soil) + (0.25 × S_crop) + (0.20 × S_water) + (0.15 × S_weather) + (0.15 × S_disease)",
      attributions: [
        { component: "Soil Health Index", rawScore: 0, weightPct: 25, pointsEarned: 0, maxPoints: 25, note: "Awaiting Soil Analysis" },
        { component: "Crop Growth Vigor", rawScore: 0, weightPct: 25, pointsEarned: 0, maxPoints: 25, note: "No Active Crop Configured" },
        { component: "Water & Irrigation", rawScore: 0, weightPct: 20, pointsEarned: 0, maxPoints: 20, note: "Awaiting Soil Moisture Telemetry" },
        { component: "Weather Risk Safety", rawScore: 0, weightPct: 15, pointsEarned: 0, maxPoints: 15, note: "Awaiting GPS Coordinates" },
        { component: "Disease Safety Index", rawScore: 0, weightPct: 15, pointsEarned: 0, maxPoints: 15, note: "No Disease Scans Recorded" }
      ]
    };
  }

  // 1. Soil Sub-Score (0 - 100)
  const soilAnalysis = analyzeSoilHealth(farm.soil);
  const S_soil = soilAnalysis.overallScore;

  // 2. Crop Growth Sub-Score (0 - 100)
  // Evaluates days after sowing vs stage health
  const S_crop = 88; // Vegetative healthy growth stage

  // 3. Water & Irrigation Sub-Score (0 - 100)
  const irrigationRec = calculateIrrigationRecommendation(farm.soil.moisture, farm.currentCrop, "Vegetative", weatherData ? weatherData.forecast : null);
  let S_water = 90;
  if (irrigationRec.waterStatus.includes('Dry')) S_water = 65;
  else if (irrigationRec.waterStatus.includes('Over-irrigated')) S_water = 60;

  // 4. Weather Safety Sub-Score (0 - 100)
  const weatherRisks = evaluateWeatherRisks(weatherData || { humidity: farm.soil.humidity, forecast: [{ rainProb: 15, maxTemp: 28 }] });
  const hasHighWeatherRisk = weatherRisks.some(r => r.level === 'HIGH');
  const S_weather = hasHighWeatherRisk ? 68 : 92;

  // 5. Disease Safety Sub-Score (0 - 100)
  const S_disease = farm.diseaseRisk === 'High' ? 62 : farm.diseaseRisk === 'Medium' ? 78 : 94;

  // Mathematical Weight Attribution Formula
  const w_soil = 0.25;
  const w_crop = 0.25;
  const w_water = 0.20;
  const w_weather = 0.15;
  const w_disease = 0.15;

  const soilContrib = parseFloat((S_soil * w_soil).toFixed(1));
  const cropContrib = parseFloat((S_crop * w_crop).toFixed(1));
  const waterContrib = parseFloat((S_water * w_water).toFixed(1));
  const weatherContrib = parseFloat((S_weather * w_weather).toFixed(1));
  const diseaseContrib = parseFloat((S_disease * w_disease).toFixed(1));

  const compositeScore = Math.round(soilContrib + cropContrib + waterContrib + weatherContrib + diseaseContrib);

  return {
    compositeScore,
    formulaString: "S_farm = (0.25 × S_soil) + (0.25 × S_crop) + (0.20 × S_water) + (0.15 × S_weather) + (0.15 × S_disease)",
    attributions: [
      { component: "Soil Health Index", rawScore: S_soil, weightPct: 25, pointsEarned: soilContrib, maxPoints: 25, note: `N: ${farm.soil.nitrogen} kg/ha (pH ${farm.soil.ph})` },
      { component: "Crop Growth Vigor", rawScore: S_crop, weightPct: 25, pointsEarned: cropContrib, maxPoints: 25, note: "Day 65 Vegetative Stage" },
      { component: "Water & Irrigation", rawScore: S_water, weightPct: 20, pointsEarned: waterContrib, maxPoints: 20, note: `Moisture: ${farm.soil.moisture}% (${farm.waterStatus})` },
      { component: "Weather Risk Safety", rawScore: S_weather, weightPct: 15, pointsEarned: weatherContrib, maxPoints: 15, note: hasHighWeatherRisk ? "Rain Warning Active" : "Clear Weather Window" },
      { component: "Disease Safety Index", rawScore: S_disease, weightPct: 15, pointsEarned: diseaseContrib, maxPoints: 15, note: `Risk: ${farm.diseaseRisk}` }
    ]
  };
}

/* Module Exports */
exports.calculateCompositeFarmHealthScore = calculateCompositeFarmHealthScore;
