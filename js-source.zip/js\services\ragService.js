// AgroSense RAG (Retrieval-Augmented Generation) Knowledge Service

import { knowledgeDocuments } from '../data/knowledgeBase.js';

export function searchKnowledgeBase(query = "") {
  if (!query || query.trim() === "") return knowledgeDocuments;

  const q = query.toLowerCase();
  return knowledgeDocuments.filter(doc => 
    doc.title.toLowerCase().includes(q) ||
    doc.category.toLowerCase().includes(q) ||
    doc.organization.toLowerCase().includes(q) ||
    doc.content.toLowerCase().includes(q) ||
    doc.keywords.some(kw => kw.toLowerCase().includes(q))
  );
}

export function filterKnowledgeByCategory(category = "All") {
  if (category === "All") return knowledgeDocuments;
  return knowledgeDocuments.filter(doc => doc.category.toLowerCase() === category.toLowerCase());
}
