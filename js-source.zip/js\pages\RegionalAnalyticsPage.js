// AgroSense Regional Agriculture Analytics Page Component

export function renderRegionalAnalyticsPage(state) {
  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="map-pin" class="w-6 h-6 text-emerald-400"></i>
            Regional Agriculture Analytics Hierarchy
          </h1>
          <p class="text-xs text-gray-400">India → Maharashtra State → Pune District → Haveli Block → Farm Level</p>
        </div>
        <span class="prototype-badge">STATE & DISTRICT LAYER</span>
      </div>

      <!-- Regional Overview Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div class="glass-card p-5 space-y-2">
          <span class="text-xs font-bold text-gray-400">District Crop Distribution</span>
          <div class="text-xl font-bold text-white font-mono">Wheat 42% | Sugarcane 35%</div>
          <p class="text-xs text-gray-400">Pune District Agricultural Census 2026</p>
        </div>

        <div class="glass-card p-5 space-y-2">
          <span class="text-xs font-bold text-gray-400">District Soil Deficit Trend</span>
          <div class="text-xl font-bold text-amber-300 font-mono">62% Farms Low Nitrogen</div>
          <p class="text-xs text-amber-400 font-medium">Vertisol N-management priority region</p>
        </div>

        <div class="glass-card p-5 space-y-2">
          <span class="text-xs font-bold text-gray-400">District Water Table Status</span>
          <div class="text-xl font-bold text-blue-300 font-mono">Moderate (16.4m avg)</div>
          <p class="text-xs text-blue-400 font-medium">Drip adoption rate: 74%</p>
        </div>
      </div>
    </div>
  `;
}
