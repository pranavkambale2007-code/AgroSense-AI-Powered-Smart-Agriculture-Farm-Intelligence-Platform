const expandedAllCropLifecycles = exports.expandedAllCropLifecycles = {
  "sugarcane": {
    "cropKey": "sugarcane",
    "cropName": "Sugarcane",
    "vernacularName": "गन्ना / ऊस",
    "season": "Annual / Spring / Autumn",
    "totalDurationDays": 360,
    "optimalSowingWindow": "October – November (Autumn) / February – March (Spring)",
    "seedRate": "25,000 – 30,000 two-budded setts / Acre",
    "seedTreatment": "Carbendazim 50% WP @ 1g/L water sett dip for 15 mins + Trichoderma viride",
    "spacing": "90 – 120 cm row-to-row in furrows",
    "soilPrep": "Deep subsoiling to 45 cm, followed by 2 discings and ridger furrows; 10 tonnes FYM/acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 35",
      "title": "Sett Planting & Germination",
      "description": "Plant healthy disease-free two-bud setts end-to-end in deep furrows.",
      "keyActions": [
        "Dip setts in fungicide and insecticide solution before placement.",
        "Cover setts with 5 cm soil and compact lightly.",
        "Give immediate light germination irrigation."
      ],
      "warning": "Never use setts infected with Red Rot or Smut; ensure buds are viable."
    },
    "irrigationSchedule": [
      {
        "stageName": "Germination Phase",
        "das": 10,
        "dasRange": "DAS 7 – 12",
        "waterVolume": "55,000 Liters / Acre",
        "importance": "Critical",
        "guidance": "Essential for bud sprouting."
      },
      {
        "stageName": "Formative / Tillering",
        "das": 60,
        "dasRange": "DAS 55 – 65",
        "waterVolume": "60,000 Liters / Acre",
        "importance": "Critical",
        "guidance": "Moisture deficit reduces millable cane number."
      },
      {
        "stageName": "Grand Growth Stage",
        "das": 150,
        "dasRange": "DAS 140 – 160",
        "waterVolume": "65,000 Liters / Acre",
        "importance": "High",
        "guidance": "Peak internode elongation phase; irrigate every 10-12 days."
      },
      {
        "stageName": "Maturity & Sugar Accumulation",
        "das": 300,
        "dasRange": "DAS 290 – 310",
        "waterVolume": "45,000 Liters / Acre",
        "importance": "Moderate",
        "guidance": "Gradually taper off irrigation. Stop 20 days prior to crushing."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Early Shoot Borer)",
        "das": 35,
        "dasRange": "DAS 30 – 40",
        "targetProblem": "Early Shoot Borer (Chilo infuscatellus)",
        "chemical": "Chlorantraniliprole 18.5% SC (Coragen)",
        "dosagePer15L": "7.5 ml per 15L Knapsack Pump",
        "phi": "60 Days",
        "weatherRule": "Apply in furrow base during cool hours."
      },
      {
        "sprayNumber": "Spray 2 (Internode Borer & Pyrilla)",
        "das": 120,
        "dasRange": "DAS 110 – 130",
        "targetProblem": "Sugarcane Pyrilla & Whitefly",
        "chemical": "Imidacloprid 17.8% SL",
        "dosagePer15L": "5 ml per 15L Knapsack Pump",
        "phi": "45 Days",
        "weatherRule": "Thorough under-leaf canopy spray."
      },
      {
        "sprayNumber": "Spray 3 (Red Rot & Smut Prophylactic)",
        "das": 180,
        "dasRange": "DAS 170 – 190",
        "targetProblem": "Red Rot & Rust",
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosagePer15L": "15 ml per 15L Knapsack Pump",
        "phi": "30 Days",
        "weatherRule": "Spray after de-trashing dry lower senescent leaves."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 330 – 360",
      "maturityIndicators": [
        "Leaves turn yellow and dry up from bottom",
        "Brix refractometer reading reaches 18-20% sugar",
        "Canes produce metallic sound when tapped",
        "Buds at nodes swell and eye turns firm"
      ],
      "harvestingMethod": "Cut flush with ground level using sharp cane-cutting billhooks to maximize sucrose recovery.",
      "postHarvestDrying": "Deliver to sugar mill within 24 hours of cutting to prevent inversion of sucrose.",
      "storageWarning": "Stale cane loses 0.5-1.0% sugar recovery per day of transport delay."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹340 / Qtl (Fair & Remunerative Price FRP)",
      "currentMandiRate": "₹350 – ₹410 / Quintal (Sugar Mill Gate / Gur Mandi)",
      "bestSellingWindow": "November to March (Peak sugar recovery crushing season)",
      "gradingChecklist": [
        "High Brix Sugar Content (>19%)",
        "Fresh harvest (<24 hours cut-to-crush)",
        "Zero mud, binding roots, or dry tops",
        "Clean internodes free from Red Rot vascular discoloration"
      ],
      "nearbyMandis": [
        {
          "name": "Kolhapur Sugar Hub (Maharashtra)",
          "distance": "Primary Mill Zone",
          "rate": "₹385/Qtl"
        },
        {
          "name": "Muzaffarnagar Gur Mandi (UP)",
          "distance": "Largest Jaggery Market",
          "rate": "₹4,100/Qtl (Gur)"
        },
        {
          "name": "Belagavi APMC / Sugar Complex",
          "distance": "Karnataka Gateway",
          "rate": "₹370/Qtl"
        },
        {
          "name": "Pune APMC Jaggery Yard",
          "distance": "Regional Yard",
          "rate": "₹3,950/Qtl (Gur)"
        }
      ],
      "mandiTips": "Supplying directly to local cooperative sugar mills with bonded indent passes ensures prompt DBT bank settlement."
    }
  },
  "mustard": {
    "cropKey": "mustard",
    "cropName": "Mustard / Rapeseed",
    "vernacularName": "सरसों / मोहरी",
    "season": "Rabi (Winter)",
    "totalDurationDays": 130,
    "optimalSowingWindow": "10 October – 30 October (Soil temp ~25°C)",
    "seedRate": "1.5 – 2.0 kg / Acre (Line sowing)",
    "seedTreatment": "Trichoderma viride @ 6 g/kg + Thiamethoxam 70% WS @ 3 g/kg seed",
    "spacing": "45 cm row-to-row × 15 cm plant-to-plant",
    "soilPrep": "Fine, friable, firm seedbed; 3 tonnes FYM + 40 kg Urea + 50 kg SSP + 15 kg Zinc Sulphate",
    "sowingDetails": {
      "dasRange": "DAS 0 – 7",
      "title": "Seed Sowing & Thinning",
      "description": "Drill seeds at shallow 2.5–3 cm depth in moist soil; thin out crowded seedlings at 15–20 DAS.",
      "keyActions": [
        "Sow when temperature drops below 28°C.",
        "Use Single Super Phosphate (SSP) to supply essential Sulphur (18%) for high oil synthesis.",
        "Perform first thinning at 15 DAS maintaining 15 cm spacing."
      ],
      "warning": "Avoid deep sowing (>4 cm) which prevents tiny mustard seeds from emerging."
    },
    "irrigationSchedule": [
      {
        "stageName": "Rosette / Pre-Flowering",
        "das": 30,
        "dasRange": "DAS 28 – 35",
        "waterVolume": "40,000 Liters / Acre",
        "importance": "Critical",
        "guidance": "Vital for secondary branch formation."
      },
      {
        "stageName": "Pod Formation (Siliqua)",
        "das": 65,
        "dasRange": "DAS 60 – 70",
        "waterVolume": "35,000 Liters / Acre",
        "importance": "Critical",
        "guidance": "Increases number of seeds per pod and oil percentage."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Mustard Aphids / Chepa)",
        "das": 45,
        "dasRange": "DAS 40 – 50",
        "targetProblem": "Mustard Aphid (Lipaphis erysimi)",
        "chemical": "Dimethoate 30% EC or Thiamethoxam 25% WG",
        "dosagePer15L": "25 ml or 5 g per 15L Knapsack Pump",
        "phi": "21 Days",
        "weatherRule": "Spray in the afternoon when aphids congregate on top branches."
      },
      {
        "sprayNumber": "Spray 2 (White Rust & Alternaria)",
        "das": 70,
        "dasRange": "DAS 65 – 75",
        "targetProblem": "White Rust (Albugo candida) & Blight",
        "chemical": "Mancozeb 75% WP + Metalaxyl",
        "dosagePer15L": "35 g per 15L Knapsack Pump",
        "phi": "25 Days",
        "weatherRule": "Spray immediately if morning foggy weather prevails."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 115 – 130",
      "maturityIndicators": [
        "75-80% pods (siliquae) turn golden straw yellow",
        "Seeds inside pods turn hard, glossy brown/black",
        "Foliage dries and drops naturally"
      ],
      "harvestingMethod": "Harvest early morning when pods are moist with dew to avoid seed shattering loss.",
      "postHarvestDrying": "Sun dry sheaves on tarpaulin for 4-5 days before threshing; dry clean seeds to 8% moisture.",
      "storageWarning": "Moisture >9% causes fungal heating, rancidity, and sharp drop in oil quality."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹5,650 / Qtl (Government MSP)",
      "currentMandiRate": "₹5,400 – ₹6,100 / Quintal (APMC Oilseed Yard)",
      "bestSellingWindow": "March to May (Post-harvest peak arrivals)",
      "gradingChecklist": [
        "Oil Content > 40-42%",
        "Seed Moisture strictly ≤ 8%",
        "Foreign matter / dust < 1%",
        "Zero mouldy or immature green seeds"
      ],
      "nearbyMandis": [
        {
          "name": "Alwar APMC Mandi (Rajasthan)",
          "distance": "National Mustard Trading Hub",
          "rate": "₹5,950/Qtl"
        },
        {
          "name": "Bharatpur Oilseed Mandi",
          "distance": "Eastern Rajasthan Hub",
          "rate": "₹5,880/Qtl"
        },
        {
          "name": "Morena APMC (Madhya Pradesh)",
          "distance": "Chambal Mustard Center",
          "rate": "₹5,800/Qtl"
        },
        {
          "name": "Hisar Grain Market (Haryana)",
          "distance": "Northern Hub",
          "rate": "₹5,750/Qtl"
        }
      ],
      "mandiTips": "Clean seeds with an air-screen cleaner before selling; oil mills pay up to ₹150/qtl bonus for certified >41% oil content."
    }
  },
  "soybean": {
    "cropKey": "soybean",
    "cropName": "Soybean",
    "vernacularName": "सोयाबीन",
    "season": "Kharif (Monsoon)",
    "totalDurationDays": 100,
    "optimalSowingWindow": "15 June – 5 July (After onset of monsoon, minimum 75 mm rain)",
    "seedRate": "25 – 30 kg / Acre (Line sowing)",
    "seedTreatment": "Carboxin + Thiram (Vitavax Power) @ 2g/kg seed + Bradyrhizobium japonicum culture @ 200g/10kg seed",
    "spacing": "45 cm row-to-row × 7.5 cm plant-to-plant; depth 3-4 cm",
    "soilPrep": "Well-drained deep vertisol or fertile loam; apply 2 tonnes FYM + 25 kg Urea + 60 kg SSP + 20 kg MOP",
    "sowingDetails": {
      "dasRange": "DAS 0 – 6",
      "title": "Seed Sowing & Rhizobium Inoculation",
      "description": "Drill inoculated seeds into moist, well-aerated seedbed at uniform 3-4 cm depth.",
      "keyActions": [
        "Ensure soil has received at least 75-100 mm rainfall before sowing.",
        "Inoculate seeds with Bradyrhizobium culture in shade 1 hour before sowing.",
        "Calibrate tractor seed drill to avoid seed breakage (fragile seed coat)."
      ],
      "warning": "Never sow in dry soil; moisture stress immediately after sowing ruins germination."
    },
    "irrigationSchedule": [
      {
        "stageName": "Flowering Phase",
        "das": 35,
        "dasRange": "DAS 35 – 42",
        "waterVolume": "45,000 Liters / Acre",
        "importance": "Critical",
        "guidance": "If dry spell occurs during flowering, provide life-saving protective irrigation."
      },
      {
        "stageName": "Pod Development & Grain Filling",
        "das": 65,
        "dasRange": "DAS 60 – 70",
        "waterVolume": "45,000 Liters / Acre",
        "importance": "Critical",
        "guidance": "Moisture deficit at pod-fill reduces test weight and grain oil/protein."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Girdle Beetle & Stem Fly)",
        "das": 25,
        "dasRange": "DAS 20 – 30",
        "targetProblem": "Girdle Beetle & Semilooper",
        "chemical": "Chlorantraniliprole 18.5% SC",
        "dosagePer15L": "7.5 ml per 15L Knapsack Pump",
        "phi": "28 Days",
        "weatherRule": "Spray on clear weather; check petiole ring cuts."
      },
      {
        "sprayNumber": "Spray 2 (Rust & Anthracnose)",
        "das": 55,
        "dasRange": "DAS 50 – 60",
        "targetProblem": "Soybean Rust (Phakopsora pachyrhizi)",
        "chemical": "Hexaconazole 5% EC",
        "dosagePer15L": "20 ml per 15L Knapsack Pump",
        "phi": "30 Days",
        "weatherRule": "Spray under-surface of leaves where rust pustules originate."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 95 – 105",
      "maturityIndicators": [
        "90% of leaves turn golden yellow and drop to ground",
        "Pods turn light brown / greyish straw color",
        "Seeds rattle inside pods when shaken"
      ],
      "harvestingMethod": "Harvest with sickle or multi-crop combine when seed moisture is 14-16% to avoid pod shattering.",
      "postHarvestDrying": "Sun dry pods for 2-3 days; thresh at slow drum speed (400-500 RPM) to prevent seed cracking.",
      "storageWarning": "Store clean grain at ≤10% moisture in moisture-proof gunny bags on wooden crates."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹4,892 / Qtl (Government MSP)",
      "currentMandiRate": "₹4,600 – ₹5,150 / Quintal (Mandi Spot Rate)",
      "bestSellingWindow": "October to December (Immediately after post-monsoon harvest)",
      "gradingChecklist": [
        "Uniform yellow seed coat without green or purple staining",
        "Moisture Content ≤ 10%",
        "Broken / Split seeds < 2%",
        "High protein (>38%) and oil (>18%) index"
      ],
      "nearbyMandis": [
        {
          "name": "Indore APMC Mandi (Madhya Pradesh)",
          "distance": "Asia's Largest Soybean Terminal",
          "rate": "₹4,950/Qtl"
        },
        {
          "name": "Latur Grain Market (Maharashtra)",
          "distance": "Marathwada Soybean Hub",
          "rate": "₹4,880/Qtl"
        },
        {
          "name": "Kota Grain Mandi (Rajasthan)",
          "distance": "Hadoti Agri Center",
          "rate": "₹4,820/Qtl"
        },
        {
          "name": "Akola Cotton & Oilseed APMC",
          "distance": "Vidarbha Trading Market",
          "rate": "₹4,790/Qtl"
        }
      ],
      "mandiTips": "Avoid selling during peak October glut; holding dry grade-A soybean until December-January often yields ₹300-400/qtl price gains."
    }
  },
  "chickpea": {
    "cropKey": "chickpea",
    "cropName": "Chickpea / Desi Chana",
    "vernacularName": "चना / हरभरा",
    "season": "Rabi (Winter)",
    "totalDurationDays": 110,
    "optimalSowingWindow": "15 October – 10 November",
    "seedRate": "30 – 35 kg / Acre (Desi Chana); 45 kg / Acre (Kabuli)",
    "seedTreatment": "Carbendazim + Mancozeb (Saaf) @ 2.5 g/kg seed + Rhizobium & PSB culture",
    "spacing": "30 cm row-to-row × 10 cm plant-to-plant",
    "soilPrep": "Rough cloddy seedbed; apply 2 tonnes FYM + 20 kg DAP + 15 kg Potash + 10 kg Sulphur at sowing",
    "sowingDetails": {
      "dasRange": "DAS 0 – 8",
      "title": "Seed Sowing & Depth Calibration",
      "description": "Sow in cloddy, well-aerated seedbed at 6-8 cm depth to reach residual soil moisture.",
      "keyActions": [
        "Sow deep (6-8 cm) to place seed in moist soil layer and reduce wilt incidence.",
        "Inoculate seed with Mesorhizobium ciceri culture in shade.",
        "Perform nipping / topping of terminal shoots at 30-35 DAS to induce profuse lateral branching."
      ],
      "warning": "Never sow chickpea in fine powdery soil or waterlogged fields (causes severe collar rot)."
    },
    "irrigationSchedule": [
      {
        "stageName": "Pre-Flowering / Branching",
        "das": 45,
        "dasRange": "DAS 40 – 48",
        "waterVolume": "35,000 Liters / Acre",
        "importance": "Critical",
        "guidance": "Promotes branching and flower bud formation."
      },
      {
        "stageName": "Pod Development Phase",
        "das": 75,
        "dasRange": "DAS 70 – 80",
        "waterVolume": "35,000 Liters / Acre",
        "importance": "Critical",
        "guidance": "Essential for pod filling and grain weight plumping."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Pod Borer / Helicoverpa)",
        "das": 50,
        "dasRange": "DAS 45 – 55",
        "targetProblem": "Gram Pod Borer (Helicoverpa armigera)",
        "chemical": "Chlorantraniliprole 18.5% SC or Emamectin Benzoate 5% SG",
        "dosagePer15L": "7.5 ml or 8 g per 15L Knapsack Pump",
        "phi": "15 Days",
        "weatherRule": "Spray at first sign of 1-2 small larvae per meter row length."
      },
      {
        "sprayNumber": "Spray 2 (Wilt & Ascochyta Blight)",
        "das": 70,
        "dasRange": "DAS 65 – 75",
        "targetProblem": "Fusarium Wilt & Ascochyta",
        "chemical": "Carbendazim 12% + Mancozeb 63% WP",
        "dosagePer15L": "30 g per 15L Knapsack Pump",
        "phi": "21 Days",
        "weatherRule": "Spray canopy and drench collar region."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 100 – 115",
      "maturityIndicators": [
        "Leaves turn reddish-brown and shed off completely",
        "Pods turn golden yellowish-brown and become crisp",
        "Seeds rattle inside dried pods"
      ],
      "harvestingMethod": "Uproot or cut plants with sickle early morning to prevent pod breakage.",
      "postHarvestDrying": "Sun dry harvested crop on threshing floor for 4-6 days; thresh with tractor or pulse thresher.",
      "storageWarning": "Sun dry seed to 9% moisture; store with dry neem leaves to repel Bruchus pulse beetle."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹5,440 / Qtl (Government MSP)",
      "currentMandiRate": "₹5,350 – ₹6,100 / Quintal (APMC Pulse Yard)",
      "bestSellingWindow": "February to April (Peak Rabi harvest)",
      "gradingChecklist": [
        "Bold, uniform grain size and natural reddish-brown color",
        "Moisture Content ≤ 9%",
        "Zero pulse beetle (Bruchid) holes or larval droppings",
        "Dirt and cracked grains < 1%"
      ],
      "nearbyMandis": [
        {
          "name": "Bikaner APMC Mandi (Rajasthan)",
          "distance": "Major Chana Terminal Hub",
          "rate": "₹5,850/Qtl"
        },
        {
          "name": "Latur Pulse Market (Maharashtra)",
          "distance": "Maharashtra Pulse Center",
          "rate": "₹5,780/Qtl"
        },
        {
          "name": "Gulbarga (Kalaburagi) APMC",
          "distance": "Karnataka Pulse Bowl",
          "rate": "₹5,720/Qtl"
        },
        {
          "name": "Indore Chana Yard (MP)",
          "distance": "Central India Trading Mandi",
          "rate": "₹5,800/Qtl"
        }
      ],
      "mandiTips": "Clean, machine-graded bold Desi Chana with <8% moisture qualifies for NAFED MSP procurement."
    }
  },
  "barley": {
    "cropKey": "barley",
    "cropName": "Barley",
    "vernacularName": "जौ / जाऊ",
    "season": "Rabi (Winter)",
    "totalDurationDays": 115,
    "optimalSowingWindow": "20 October – 15 November",
    "seedRate": "35 – 40 kg / Acre",
    "seedTreatment": "Carbendazim 50% WP @ 2 g/kg seed + Azotobacter biofertilizer",
    "spacing": "22.5 cm row spacing × 5 cm plant spacing; depth 4-5 cm",
    "soilPrep": "2 ploughings with cultivator followed by planking; apply 3 tonnes FYM + 25 kg N + 15 kg P2O5 / acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Seedbed Preparation & Sowing",
      "description": "Sow certified seeds in moist seedbed with seed drill at 4-5 cm depth.",
      "keyActions": [
        "Ensure good seedbed moisture.",
        "Treat seed with fungicide to prevent Covered Smut.",
        "Maintain uniform 22.5 cm row spacing."
      ],
      "warning": "Avoid sowing in waterlogged soil; barley is drought-hardy but sensitive to standing water."
    },
    "irrigationSchedule": [
      {
        "stageName": "Crown Root Stage",
        "das": 25,
        "dasRange": "DAS 22 – 28",
        "waterVolume": "40,000 L/Acre",
        "importance": "Critical",
        "guidance": "Induces strong crown root anchorage."
      },
      {
        "stageName": "Tillering Stage",
        "das": 45,
        "dasRange": "DAS 42 – 48",
        "waterVolume": "35,000 L/Acre",
        "importance": "High",
        "guidance": "Supports effective tiller development."
      },
      {
        "stageName": "Flowering & Grain Filling",
        "das": 75,
        "dasRange": "DAS 70 – 80",
        "waterVolume": "35,000 L/Acre",
        "importance": "Critical",
        "guidance": "Prevents grain shriveling in early spring heat."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Broadleaf Weeds)",
        "das": 30,
        "dasRange": "DAS 28 – 35",
        "targetProblem": "Chenopodium & Broadleaf Weeds",
        "chemical": "2,4-D Ethyl Ester 38% EC",
        "dosagePer15L": "25 ml / 15L Pump",
        "phi": "60 Days",
        "weatherRule": "Spray on calm sunny days."
      },
      {
        "sprayNumber": "Spray 2 (Rust & Powdery Mildew)",
        "das": 60,
        "dasRange": "DAS 55 – 65",
        "targetProblem": "Stripe Rust & Powdery Mildew",
        "chemical": "Propiconazole 25% EC",
        "dosagePer15L": "15 ml / 15L Pump",
        "phi": "30 Days",
        "weatherRule": "Spray at first sign of yellow rust stripes."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 100 – 115",
      "maturityIndicators": [
        "Spikes turn golden-yellow",
        "Grain is hard and cannot be dented with thumbnail",
        "Moisture reaches below 14%"
      ],
      "harvestingMethod": "Reap with sickle or combine harvester during morning hours to prevent shattering.",
      "postHarvestDrying": "Sun dry grain on clean canvas for 2-3 days to reach 10-12% moisture.",
      "storageWarning": "Store in moisture-proof bins to prevent Khapra beetle infestation."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹1,850 / Qtl",
      "currentMandiRate": "₹1,950 – ₹2,400 / Qtl (Feed & Malt Grade)",
      "bestSellingWindow": "March to May",
      "gradingChecklist": [
        "Plump, uniform bright yellow grains",
        "Moisture ≤ 12%",
        "Germination capacity >95% for malting",
        "Foreign matter < 1%"
      ],
      "nearbyMandis": [
        {
          "name": "Jaipur APMC (Rajasthan)",
          "distance": "Major Barley Hub",
          "rate": "₹2,250/Qtl"
        },
        {
          "name": "Sirsa Grain Market (Haryana)",
          "distance": "Northern Center",
          "rate": "₹2,180/Qtl"
        }
      ],
      "mandiTips": "Two-row malting barley varieties (e.g. DWRB-101) sold to breweries fetch up to ₹300/qtl premium over six-row feed barley."
    }
  },
  "jowar": {
    "cropKey": "jowar",
    "cropName": "Sorghum / Jowar",
    "vernacularName": "ज्वार / ज्वारी",
    "season": "Kharif / Rabi",
    "totalDurationDays": 110,
    "optimalSowingWindow": "Kharif: 15 June – 10 July / Rabi: 15 Sept – 15 Oct",
    "seedRate": "3 – 4 kg / Acre",
    "seedTreatment": "Thiamethoxam 70% WS @ 3g/kg (controls shoot fly) + Azospirillum culture",
    "spacing": "45 cm row spacing × 15 cm plant spacing; depth 3-4 cm",
    "soilPrep": "Deep summer ploughing followed by 2 harrowings; 3 tonnes FYM + 30 kg N + 20 kg P2O5 per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Drilling & Shoot Fly Protection",
      "description": "Drill treated seed in moist soil; early sowing escapes devastating shoot fly attack.",
      "keyActions": [
        "Treat seed with systemic insecticide for shoot fly.",
        "Thin seedlings to single plant per hill at 15 DAS.",
        "Maintain firm seedbed."
      ],
      "warning": "Late sowing after July 10 in Kharif results in severe shoot fly dead-hearts."
    },
    "irrigationSchedule": [
      {
        "stageName": "Knee-High Stage",
        "das": 30,
        "dasRange": "DAS 28 – 35",
        "waterVolume": "40,000 L/Acre",
        "importance": "High",
        "guidance": "Stimulates rapid stem extension."
      },
      {
        "stageName": "Boot & Flowering Stage",
        "das": 55,
        "dasRange": "DAS 50 – 60",
        "waterVolume": "45,000 L/Acre",
        "importance": "Critical",
        "guidance": "Most moisture-critical stage for panicle exertion."
      },
      {
        "stageName": "Grain Milking Stage",
        "das": 75,
        "dasRange": "DAS 70 – 80",
        "waterVolume": "35,000 L/Acre",
        "importance": "High",
        "guidance": "Ensures heavy, well-filled grain heads."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Shoot Fly & Stem Borer)",
        "das": 15,
        "dasRange": "DAS 10 – 18",
        "targetProblem": "Sorghum Shoot Fly (Atherigona soccata)",
        "chemical": "Chlorantraniliprole 18.5% SC",
        "dosagePer15L": "7 ml / 15L Pump",
        "phi": "21 Days",
        "weatherRule": "Spray central whorl of young seedlings."
      },
      {
        "sprayNumber": "Spray 2 (Grain Mold & Anthracnose)",
        "das": 65,
        "dasRange": "DAS 60 – 70",
        "targetProblem": "Grain Mold (Curvularia/Fusarium)",
        "chemical": "Propiconazole 25% EC",
        "dosagePer15L": "15 ml / 15L Pump",
        "phi": "25 Days",
        "weatherRule": "Spray earheads during high morning humidity."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 95 – 110",
      "maturityIndicators": [
        "Black layer (hilum spot) forms at grain base",
        "Grains turn hard and floury",
        "Foliage starts yellowing"
      ],
      "harvestingMethod": "Cut earheads with sickle; harvest stalks separately for nutritious cattle fodder (Kadbi).",
      "postHarvestDrying": "Sun dry earheads on threshing yard for 4-5 days; thresh at 12% moisture.",
      "storageWarning": "Keep grain dry; Kadbi stalks should be stacked in clean conical Ganjis."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹3,180 / Qtl (Maldandi Rabi: ₹3,225)",
      "currentMandiRate": "₹3,200 – ₹4,500 / Qtl (Premium Maldandi fetching ₹5,200)",
      "bestSellingWindow": "November to January (Kharif) / March to May (Rabi)",
      "gradingChecklist": [
        "Bold pearly white grain (Maldandi M-35-1)",
        "Zero grain mold blackening",
        "Moisture ≤ 10%",
        "Clean without husk"
      ],
      "nearbyMandis": [
        {
          "name": "Solapur APMC (Maharashtra)",
          "distance": "Maldandi Jowar Capital",
          "rate": "₹4,600/Qtl"
        },
        {
          "name": "Kalaburagi / Gulbarga APMC",
          "distance": "North Karnataka Hub",
          "rate": "₹3,800/Qtl"
        }
      ],
      "mandiTips": "Winter Rabi Maldandi Jowar commands a 30-50% price premium over Kharif hybrid grain due to superior roti sweetness."
    }
  },
  "bajra": {
    "cropKey": "bajra",
    "cropName": "Pearl Millet / Bajra",
    "vernacularName": "बाजरा / बाजरी",
    "season": "Kharif (Monsoon)",
    "totalDurationDays": 85,
    "optimalSowingWindow": "1 July – 20 July",
    "seedRate": "1.5 – 2.0 kg / Acre",
    "seedTreatment": "Metalaxyl 35% WS @ 3g/kg (controls Downy Mildew / Green Ear) + Azospirillum",
    "spacing": "45 cm row spacing × 12 cm plant spacing; depth 2.5-3 cm",
    "soilPrep": "Light sandy loam or well-drained alluvium; apply 2 tonnes FYM + 25 kg Urea + 40 kg SSP per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Shallow Drilling & Sowing",
      "description": "Sow at shallow depth (2.5 cm) in moist soil; thin seedlings at 15 DAS.",
      "keyActions": [
        "Ensure seeds are treated against downy mildew.",
        "Thin to single plant per 12 cm.",
        "Intercultivate at 20 DAS for weed control."
      ],
      "warning": "Do not sow deeper than 3 cm; tiny pearl millet seeds will fail to break the soil crust."
    },
    "irrigationSchedule": [
      {
        "stageName": "Tillering Phase",
        "das": 25,
        "dasRange": "DAS 20 – 28",
        "waterVolume": "35,000 L/Acre",
        "importance": "High",
        "guidance": "Encourages basal tillers."
      },
      {
        "stageName": "Booting & Flowering",
        "das": 45,
        "dasRange": "DAS 42 – 50",
        "waterVolume": "40,000 L/Acre",
        "importance": "Critical",
        "guidance": "Moisture critical for uniform panicle emergence."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Downy Mildew / Green Ear)",
        "das": 25,
        "dasRange": "DAS 20 – 30",
        "targetProblem": "Downy Mildew (Sclerospora graminicola)",
        "chemical": "Metalaxyl 8% + Mancozeb 64% WP",
        "dosagePer15L": "30 g / 15L Pump",
        "phi": "20 Days",
        "weatherRule": "Rogue out deformed green-ear plants immediately."
      },
      {
        "sprayNumber": "Spray 2 (Ergot & Rust)",
        "das": 50,
        "dasRange": "DAS 45 – 55",
        "targetProblem": "Ergot (Claviceps fusiformis)",
        "chemical": "Carbendazim 50% WP",
        "dosagePer15L": "15 g / 15L Pump",
        "phi": "25 Days",
        "weatherRule": "Spray panicles during early morning flowering."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 70 – 85",
      "maturityIndicators": [
        "Earheads turn brown and dry",
        "Grain becomes firm and produces clear cracking sound",
        "Leaves turn dry straw yellow"
      ],
      "harvestingMethod": "Cut earheads using sickles; dry on clean ground.",
      "postHarvestDrying": "Sun dry earheads for 3-5 days; thresh and clean to 10% moisture.",
      "storageWarning": "High fat content causes rancidity if stored with >11% moisture."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹2,500 / Qtl",
      "currentMandiRate": "₹2,350 – ₹2,750 / Qtl",
      "bestSellingWindow": "October to December",
      "gradingChecklist": [
        "Clean, uniform greyish-green bold grain",
        "Zero ergot sclerotia (toxic)",
        "Moisture ≤ 10%",
        "Fodder quality high"
      ],
      "nearbyMandis": [
        {
          "name": "Jaipur APMC (Rajasthan)",
          "distance": "Major Bajra Terminal",
          "rate": "₹2,550/Qtl"
        },
        {
          "name": "Agra Mandi (Uttar Pradesh)",
          "distance": "Yamuna Belt Hub",
          "rate": "₹2,480/Qtl"
        }
      ],
      "mandiTips": "Ergot-free grain with certificate fetches immediate auction bidding without dockage penalties."
    }
  },
  "ragi": {
    "cropKey": "ragi",
    "cropName": "Finger Millet / Ragi",
    "vernacularName": "रागी / नाचणी",
    "season": "Kharif / Rabi",
    "totalDurationDays": 110,
    "optimalSowingWindow": "July – August (Kharif) / December (Rabi)",
    "seedRate": "2 kg / Acre (Transplanted) or 4 kg / Acre (Direct sown)",
    "seedTreatment": "Pseudomonas fluorescens @ 10g/kg seed + Trichoderma viride @ 5g/kg",
    "spacing": "25 cm row spacing × 10 cm plant spacing",
    "soilPrep": "Fine seedbed; 3 tonnes FYM + 25 kg N + 20 kg P2O5 + 15 kg K2O per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Transplanting or Line Sowing",
      "description": "Transplant 21-day-old nursery seedlings (2 seedlings per hill) in puddled or moist soil.",
      "keyActions": [
        "Transplant seedlings at 2-3 cm depth.",
        "Irrigate immediately after transplanting.",
        "Keep field weed-free for 30 days."
      ],
      "warning": "Avoid delayed transplanting; older seedlings (>25 days) tiller poorly."
    },
    "irrigationSchedule": [
      {
        "stageName": "Tillering Stage",
        "das": 30,
        "dasRange": "DAS 25 – 35",
        "waterVolume": "35,000 L/Acre",
        "importance": "High",
        "guidance": "Encourages vigorous tillers."
      },
      {
        "stageName": "Flowering & Grain Filling",
        "das": 65,
        "dasRange": "DAS 60 – 72",
        "waterVolume": "40,000 L/Acre",
        "importance": "Critical",
        "guidance": "Essential for finger elongation and heavy grain set."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Blast / Pyricularia)",
        "das": 45,
        "dasRange": "DAS 40 – 50",
        "targetProblem": "Finger / Neck Blast",
        "chemical": "Kitazin 48% EC or Tricyclazole 75% WP",
        "dosagePer15L": "15 ml or 10 g / 15L Pump",
        "phi": "21 Days",
        "weatherRule": "Spray foliage before neck infection appears."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 95 – 110",
      "maturityIndicators": [
        "Earheads turn dark brown (characteristic fist shape)",
        "Grains turn reddish-brown and hard",
        "Straw dries up"
      ],
      "harvestingMethod": "Cut mature earheads with sickle in 1-2 pickings as fingers ripen.",
      "postHarvestDrying": "Sun dry earheads for 3-4 days before threshing; store at 10% moisture.",
      "storageWarning": "Ragi has excellent storage life (>2 years) when kept dry in clean bins."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹3,846 / Qtl",
      "currentMandiRate": "₹3,600 – ₹4,200 / Qtl",
      "bestSellingWindow": "November to January",
      "gradingChecklist": [
        "Deep copper-brown uniform grain",
        "Moisture ≤ 10%",
        "Zero sand/grit",
        "High calcium certified"
      ],
      "nearbyMandis": [
        {
          "name": "Bengaluru APMC (Yeshwanthpur)",
          "distance": "Primary Ragi Hub",
          "rate": "₹4,100/Qtl"
        },
        {
          "name": "Mysuru APMC Mandi",
          "distance": "Karnataka Southern Bowl",
          "rate": "₹3,950/Qtl"
        }
      ],
      "mandiTips": "Urban demand for finger millet flour and breakfast cereals offers high direct-to-consumer packaging margins."
    }
  },
  "pigeon-pea": {
    "cropKey": "pigeon-pea",
    "cropName": "Pigeon Pea / Arhar / Tur",
    "vernacularName": "अरहर / तूर",
    "season": "Kharif (Monsoon)",
    "totalDurationDays": 165,
    "optimalSowingWindow": "15 June – 10 July",
    "seedRate": "5 – 6 kg / Acre (Medium duration varieties like BDN-711, Maruti, Asha)",
    "seedTreatment": "Carbendazim + Thiram @ 2g/kg + Rhizobium & PSB culture @ 250g/10kg",
    "spacing": "90 – 120 cm row spacing × 20 cm plant spacing",
    "soilPrep": "Deep well-drained loam or vertisol; apply 2 tonnes FYM + 15 kg N + 40 kg P2O5 + 10 kg Sulphur",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Line Sowing & Intercropping",
      "description": "Sow in ridges or wide furrows at 5 cm depth; excellent intercrop with soybean or cotton.",
      "keyActions": [
        "Treat seeds with bio-inoculant for nitrogen nodulation.",
        "Maintain wide 90-120 cm row spacing.",
        "Nip terminal shoots at 45 DAS to induce bushy branching."
      ],
      "warning": "Avoid planting in waterlogged soils; pigeon pea roots are highly vulnerable to Phytophthora stem blight."
    },
    "irrigationSchedule": [
      {
        "stageName": "Branching Stage",
        "das": 45,
        "dasRange": "DAS 40 – 50",
        "waterVolume": "40,000 L/Acre",
        "importance": "High",
        "guidance": "Supports lateral branch proliferation."
      },
      {
        "stageName": "Flower Bud Initiation",
        "das": 90,
        "dasRange": "DAS 85 – 95",
        "waterVolume": "45,000 L/Acre",
        "importance": "Critical",
        "guidance": "Prevents flower drop during pod initiation."
      },
      {
        "stageName": "Pod Filling Stage",
        "das": 125,
        "dasRange": "DAS 120 – 130",
        "waterVolume": "40,000 L/Acre",
        "importance": "Critical",
        "guidance": "Ensures bold dal grain development."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Pod Borer / Helicoverpa)",
        "das": 85,
        "dasRange": "DAS 80 – 90",
        "targetProblem": "Gram Pod Borer & Plume Moth",
        "chemical": "Chlorantraniliprole 18.5% SC",
        "dosagePer15L": "7.5 ml / 15L Pump",
        "phi": "28 Days",
        "weatherRule": "Spray at 50% flowering before larvae bore into pods."
      },
      {
        "sprayNumber": "Spray 2 (Pod Fly & Blight)",
        "das": 115,
        "dasRange": "DAS 110 – 120",
        "targetProblem": "Pod Fly (Melanagromyza obtusa)",
        "chemical": "Emamectin Benzoate 5% SG + Saaf",
        "dosagePer15L": "8 g + 25 g / 15L Pump",
        "phi": "20 Days",
        "weatherRule": "Thorough spray on pod clusters."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 150 – 165",
      "maturityIndicators": [
        "75-80% pods turn brown and dry",
        "Leaves shed off naturally",
        "Seeds rattle inside pods"
      ],
      "harvestingMethod": "Cut plants with sickle at base; bundle and dry in field.",
      "postHarvestDrying": "Sun dry bundles for 5-7 days; thresh with pulse thresher or beating with flails.",
      "storageWarning": "Dry clean dal seeds to 9% moisture; store with vegetable oil coating (5ml/kg) to deter pulse beetles."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹7,000 / Qtl",
      "currentMandiRate": "₹7,200 – ₹9,800 / Qtl",
      "bestSellingWindow": "December to March",
      "gradingChecklist": [
        "Clean uniform bold grain (White / Red Marathwada quality)",
        "Moisture ≤ 9%",
        "Zero pod borer holes",
        "Split/dal recovery >72%"
      ],
      "nearbyMandis": [
        {
          "name": "Latur Pulse Terminal (Maharashtra)",
          "distance": "National Tur Trading Center",
          "rate": "₹9,200/Qtl"
        },
        {
          "name": "Kalaburagi APMC (Karnataka)",
          "distance": "Tur Bowl of India",
          "rate": "₹8,900/Qtl"
        }
      ],
      "mandiTips": "Unmilled whole grain sells fast; milling into polished or unpolished Desi Dal at local mini dal mills gives 25% added margin."
    }
  },
  "green-gram": {
    "cropKey": "green-gram",
    "cropName": "Green Gram / Mung Bean",
    "vernacularName": "मूंग / मूग",
    "season": "Kharif / Summer / Zaid",
    "totalDurationDays": 65,
    "optimalSowingWindow": "Kharif: 15 June – 5 July / Summer: 1 March – 25 March",
    "seedRate": "6 – 8 kg / Acre",
    "seedTreatment": "Carboxin + Thiram @ 2g/kg + Rhizobium culture + Imidacloprid 600 FS @ 5ml/kg",
    "spacing": "30 cm row spacing × 10 cm plant spacing; depth 3-4 cm",
    "soilPrep": "Well-drained sandy loam or medium black soil; 2 tonnes FYM + 10 kg N + 20 kg P2O5 per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Short-Duration Line Sowing",
      "description": "Sow in moist seedbed; ideal 65-day catch crop between Rabi harvest and Kharif sowing.",
      "keyActions": [
        "Treat seeds to prevent Yellow Mosaic Virus (YMV) whitefly transmission.",
        "Provide first weeding at 15 DAS.",
        "Ensure uniform 30 cm rows."
      ],
      "warning": "Avoid excessive irrigation; standing water causes root rot within 24 hours."
    },
    "irrigationSchedule": [
      {
        "stageName": "Branching Stage",
        "das": 20,
        "dasRange": "DAS 18 – 22",
        "waterVolume": "35,000 L/Acre",
        "importance": "High",
        "guidance": "Stimulates flower bud production."
      },
      {
        "stageName": "Pod Development Stage",
        "das": 40,
        "dasRange": "DAS 38 – 45",
        "waterVolume": "35,000 L/Acre",
        "importance": "Critical",
        "guidance": "Prevents premature pod shedding in summer heat."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Whitefly & Yellow Mosaic)",
        "das": 20,
        "dasRange": "DAS 15 – 25",
        "targetProblem": "Whitefly (Bemisia tabaci) vector of YMV",
        "chemical": "Thiamethoxam 25% WG",
        "dosagePer15L": "5 g / 15L Pump",
        "phi": "15 Days",
        "weatherRule": "Spray at first sign of whitefly nymphs."
      },
      {
        "sprayNumber": "Spray 2 (Pod Borer & Cercospora)",
        "das": 38,
        "dasRange": "DAS 35 – 42",
        "targetProblem": "Spotted Pod Borer & Leaf Spot",
        "chemical": "Novaluron 10% EC + Mancozeb",
        "dosagePer15L": "15 ml + 30 g / 15L Pump",
        "phi": "15 Days",
        "weatherRule": "Spray in evening when pollinators are inactive."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 50 – 65",
      "maturityIndicators": [
        "80% pods turn dark brown or black",
        "Leaves turn yellow and dry"
      ],
      "harvestingMethod": "Pick pods manually in 2 pickings, or harvest whole plant with sickle.",
      "postHarvestDrying": "Sun dry pods for 3-4 days; thresh and clean to 9% moisture.",
      "storageWarning": "Bruchus beetles attack rapidly; store in airtight hermetic bags with dry neem leaves."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹8,558 / Qtl",
      "currentMandiRate": "₹7,800 – ₹8,900 / Qtl",
      "bestSellingWindow": "August – September (Kharif) / May – June (Summer)",
      "gradingChecklist": [
        "Bright lustrous green seed coat (Shining Mung)",
        "Zero weevil punctures",
        "Moisture ≤ 9%",
        "Uniform seed size"
      ],
      "nearbyMandis": [
        {
          "name": "Sumerpur APMC (Rajasthan)",
          "distance": "Mung Trading Hub",
          "rate": "₹8,650/Qtl"
        },
        {
          "name": "Akola Pulse Market (Maharashtra)",
          "distance": "Central Hub",
          "rate": "₹8,400/Qtl"
        }
      ],
      "mandiTips": "Summer mung fetched higher prices than Kharif due to clean grain free from rain stains."
    }
  },
  "black-gram": {
    "cropKey": "black-gram",
    "cropName": "Black Gram / Urad Bean",
    "vernacularName": "उड़द / उडीद",
    "season": "Kharif / Summer",
    "totalDurationDays": 75,
    "optimalSowingWindow": "20 June – 10 July",
    "seedRate": "6 – 8 kg / Acre",
    "seedTreatment": "Trichoderma @ 5g/kg + Imidacloprid @ 4ml/kg + Rhizobium culture",
    "spacing": "30 cm row spacing × 10 cm plant spacing",
    "soilPrep": "Deep loam with good drainage; apply 2 tonnes FYM + 10 kg N + 25 kg P2O5 per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Sowing & Early Weed Management",
      "description": "Drill seeds into moist seedbed; apply Pendimethalin 30% EC pre-emergence within 48h of sowing.",
      "keyActions": [
        "Treat seed to prevent Yellow Mosaic Virus.",
        "Maintain weed-free conditions up to 30 DAS.",
        "Thin at 15 DAS."
      ],
      "warning": "Avoid acidic or saline waterlogged fields."
    },
    "irrigationSchedule": [
      {
        "stageName": "Flowering Stage",
        "das": 30,
        "dasRange": "DAS 28 – 35",
        "waterVolume": "35,000 L/Acre",
        "importance": "Critical",
        "guidance": "Moisture stress causes flower abortion."
      },
      {
        "stageName": "Pod Filling Stage",
        "das": 50,
        "dasRange": "DAS 48 – 55",
        "waterVolume": "35,000 L/Acre",
        "importance": "Critical",
        "guidance": "Increases number of seeds per pod."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Whitefly & Sucking Pests)",
        "das": 22,
        "dasRange": "DAS 18 – 25",
        "targetProblem": "Whitefly & Aphids",
        "chemical": "Acetamiprid 20% SP",
        "dosagePer15L": "5 g / 15L Pump",
        "phi": "15 Days",
        "weatherRule": "Spray under-leaf canopy."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 60 – 75",
      "maturityIndicators": [
        "Pods turn black and brittle",
        "Foliage sheds naturally"
      ],
      "harvestingMethod": "Harvest whole plant with sickle; avoid delayed harvest to prevent pod shattering.",
      "postHarvestDrying": "Sun dry sheaves for 4-5 days; thresh and clean to 9% moisture.",
      "storageWarning": "Keep dry; pulse beetle attacks rapidly if grain is humid."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹6,950 / Qtl",
      "currentMandiRate": "₹7,100 – ₹8,200 / Qtl",
      "bestSellingWindow": "September to November",
      "gradingChecklist": [
        "Bold, jet-black glossy seeds",
        "Moisture ≤ 9%",
        "Zero beetle damage",
        "High dal extraction recovery"
      ],
      "nearbyMandis": [
        {
          "name": "Guntur APMC (Andhra Pradesh)",
          "distance": "Major Urad Terminal",
          "rate": "₹7,950/Qtl"
        },
        {
          "name": "Jabalpur Pulse Yard (MP)",
          "distance": "Central India Center",
          "rate": "₹7,600/Qtl"
        }
      ],
      "mandiTips": "Uniform black shiny seeds command a ₹200-300/qtl premium for South Indian papad and idli processing mills."
    }
  },
  "onion": {
    "cropKey": "onion",
    "cropName": "Onion",
    "vernacularName": "प्याज / कांदा",
    "season": "Kharif / Late Kharif / Rabi",
    "totalDurationDays": 125,
    "optimalSowingWindow": "Nursery: May–June (Kharif) / Oct–Nov (Rabi); Transplant: 45 days after nursery",
    "seedRate": "4 – 5 kg / Acre (Nursery beds)",
    "seedTreatment": "Thiram @ 2g/kg + Azospirillum sett/root dip @ 10g/L water for 20 mins",
    "spacing": "15 cm row spacing × 10 cm plant spacing",
    "soilPrep": "Friable, deep fertile loam rich in organic matter; 10 tonnes FYM + 40 kg N + 25 kg P2O5 + 40 kg K2O + 15 kg Sulphur per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Seedling Nursery & Transplanting",
      "description": "Transplant sturdy 45-day-old pencil-thick seedlings into raised beds or flat beds with irrigation.",
      "keyActions": [
        "Dip seedling roots in Carbendazim + Imidacloprid solution.",
        "Transplant at uniform 2.5-3 cm depth (not too deep).",
        "Irrigate immediately after transplanting."
      ],
      "warning": "Deep planting produces elongated neck bulbs with poor storage life."
    },
    "irrigationSchedule": [
      {
        "stageName": "Transplanting Establishment",
        "das": 5,
        "dasRange": "DAS 3 – 7",
        "waterVolume": "40,000 L/Acre",
        "importance": "Critical",
        "guidance": "Light watering every 4-5 days initially."
      },
      {
        "stageName": "Vegetative Growth Stage",
        "das": 35,
        "dasRange": "DAS 30 – 40",
        "waterVolume": "45,000 L/Acre",
        "importance": "High",
        "guidance": "Maintain steady moisture for leaf canopy."
      },
      {
        "stageName": "Bulb Initiation & Development",
        "das": 70,
        "dasRange": "DAS 65 – 80",
        "waterVolume": "50,000 L/Acre",
        "importance": "Critical",
        "guidance": "Crucial for bulb expansion. Stop 15 days before harvest."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Onion Thrips / Bokadya)",
        "das": 30,
        "dasRange": "DAS 25 – 35",
        "targetProblem": "Thrips (Thrips tabaci)",
        "chemical": "Fipronil 5% SC or Spinetoram 11.7% SC",
        "dosagePer15L": "20 ml or 10 ml / 15L Pump",
        "phi": "15 Days",
        "weatherRule": "Add sticker/spreader (silicone adjuvant) because waxy onion leaves repel spray droplets."
      },
      {
        "sprayNumber": "Spray 2 (Purple Blotch & Stemphylium)",
        "das": 60,
        "dasRange": "DAS 55 – 65",
        "targetProblem": "Purple Blotch (Alternaria porri)",
        "chemical": "Tebuconazole 25.9% EC or Mancozeb",
        "dosagePer15L": "15 ml or 35 g / 15L Pump",
        "phi": "20 Days",
        "weatherRule": "Spray with sticking agent at first appearance of purple-brown lesions."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 110 – 125",
      "maturityIndicators": [
        "50-70% tops fall over naturally (neck fall)",
        "Bulb outer scales turn dry and papery",
        "Leaves dry down"
      ],
      "harvestingMethod": "Uproot bulbs gently by hand or with khurpi during dry sunny weather.",
      "postHarvestDrying": "Field curing for 3-5 days in shade; cut foliage leaving 2.5 cm neck; cure in ventilated shed for 10-15 days.",
      "storageWarning": "Never store onions with moist, thick necks; neck rot destroys entire batches in storage."
    },
    "mandiSellingGuide": {
      "mspGovt": "Market Intervention / NAFED Buffer Procurement: ₹1,500 – ₹2,400 / Qtl",
      "currentMandiRate": "₹1,400 – ₹3,200 / Qtl (Seasonal volatility)",
      "bestSellingWindow": "April to June (Rabi peak) / December to January (Kharif peak)",
      "gradingChecklist": [
        "Medium to large uniform bulbs (45-65mm diameter)",
        "Dry, tight outer red/pink scales",
        "Thin, sealed dry neck",
        "Zero sprouting or doubling"
      ],
      "nearbyMandis": [
        {
          "name": "Lasalgaon APMC (Nashik, Maharashtra)",
          "distance": "Asia's Largest Onion Market",
          "rate": "₹2,250/Qtl"
        },
        {
          "name": "Pimpalgaon Baswant APMC",
          "distance": "Nashik Onion Hub",
          "rate": "₹2,300/Qtl"
        },
        {
          "name": "Mahuva APMC (Gujarat)",
          "distance": "White Onion Hub",
          "rate": "₹1,950/Qtl"
        },
        {
          "name": "Pune APMC Gultekdi",
          "distance": "Regional Terminal",
          "rate": "₹2,400/Qtl"
        }
      ],
      "mandiTips": "Well-cured Rabi onions stored in naturally ventilated Kanda Chawl can be held for 4-6 months to sell during peak festive winter prices (₹3,000+/qtl)."
    }
  },
  "garlic": {
    "cropKey": "garlic",
    "cropName": "Garlic",
    "vernacularName": "लहसुन / लसूण",
    "season": "Rabi (Winter)",
    "totalDurationDays": 135,
    "optimalSowingWindow": "October – November",
    "seedRate": "200 – 250 kg cloves / Acre",
    "seedTreatment": "Carbendazim 50% WP @ 2g/kg cloves + Chlorpyrifos 20% EC dip for 15 mins",
    "spacing": "15 cm row spacing × 8 cm clove spacing; depth 3-4 cm",
    "soilPrep": "Fertile sandy loam rich in humus; 8 tonnes FYM + 35 kg N + 25 kg P2O5 + 35 kg K2O + 20 kg Sulphur per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Clove Separation & Planting",
      "description": "Separate outer bold cloves from healthy bulbs; plant vertically with root end pointing downwards.",
      "keyActions": [
        "Select outer bold cloves (gives 20% higher yield than small central cloves).",
        "Plant with growing tip pointing upwards.",
        "Apply light irrigation immediately."
      ],
      "warning": "Never plant diseased or bruised cloves; rotting spreads in soil."
    },
    "irrigationSchedule": [
      {
        "stageName": "Establishment Stage",
        "das": 8,
        "dasRange": "DAS 5 – 10",
        "waterVolume": "35,000 L/Acre",
        "importance": "Critical",
        "guidance": "Light watering every 6-7 days."
      },
      {
        "stageName": "Bulb Formation Stage",
        "das": 75,
        "dasRange": "DAS 70 – 85",
        "waterVolume": "45,000 L/Acre",
        "importance": "Critical",
        "guidance": "Crucial for clove expansion and pungency."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Thrips & Purple Blotch)",
        "das": 45,
        "dasRange": "DAS 40 – 50",
        "targetProblem": "Thrips & Alternaria",
        "chemical": "Profenofos 50% EC + Mancozeb",
        "dosagePer15L": "25 ml + 35 g / 15L Pump",
        "phi": "20 Days",
        "weatherRule": "Include wetting agent/sticker."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 120 – 135",
      "maturityIndicators": [
        "Leaves turn yellow and dry up from tips",
        "Stems become limp and fall over",
        "Bulbs turn compact with tough white papery skins"
      ],
      "harvestingMethod": "Pull plants by hand when soil is moderately dry; avoid cutting bulbs.",
      "postHarvestDrying": "Tie in bundles and cure under shade for 10-14 days until tops and roots are dry.",
      "storageWarning": "Store in well-ventilated dry rooms; avoid dampness which induces mould and premature sprouting."
    },
    "mandiSellingGuide": {
      "mspGovt": "Market Rate Determined: ₹6,000 – ₹14,000 / Qtl",
      "currentMandiRate": "₹7,500 – ₹13,000 / Qtl (G-2 / Yamuna Safed quality)",
      "bestSellingWindow": "February to April",
      "gradingChecklist": [
        "Large compact bulbs (>40mm)",
        "Pure white papery skins",
        "Zero cloves exposed",
        "Firm texture without hollow cloves"
      ],
      "nearbyMandis": [
        {
          "name": "Mandsaur APMC (Madhya Pradesh)",
          "distance": "Asia's Largest Garlic Market",
          "rate": "₹10,500/Qtl"
        },
        {
          "name": "Neemuch Mandi (MP)",
          "distance": "Major Garlic Trading Yard",
          "rate": "₹10,200/Qtl"
        }
      ],
      "mandiTips": "Grading garlic into Grade-A (Special Bold) and Grade-B increases realization by 35% compared to selling mixed lot."
    }
  },
  "brinjal": {
    "cropKey": "brinjal",
    "cropName": "Brinjal / Eggplant",
    "vernacularName": "बैंगन / वांगे",
    "season": "Year-Round (Kharif / Rabi / Summer)",
    "totalDurationDays": 140,
    "optimalSowingWindow": "Nursery: June–July (Kharif) / Oct–Nov (Rabi) / Feb (Summer)",
    "seedRate": "150 – 200 g / Acre (Hybrid F1)",
    "seedTreatment": "Thiram 75% WP @ 2.5 g/kg seed + Trichoderma viride",
    "spacing": "75 cm row spacing × 60 cm plant spacing",
    "soilPrep": "Rich loamy soil with high drainage; apply 6 tonnes FYM + 40 kg N + 30 kg P2O5 + 30 kg K2O per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Nursery Sowing & Transplanting",
      "description": "Transplant 30-35 day old seedlings at 75x60 cm on ridges or raised beds with drip irrigation.",
      "keyActions": [
        "Treat seedlings with root dip solution.",
        "Transplant during late afternoon.",
        "Stake tall plants."
      ],
      "warning": "Never plant in fields previously infested with Bacterial Wilt."
    },
    "irrigationSchedule": [
      {
        "stageName": "Vegetative Phase",
        "das": 25,
        "dasRange": "DAS 20 – 30",
        "waterVolume": "40,000 L/Acre",
        "importance": "High",
        "guidance": "Regular light watering every 5-6 days."
      },
      {
        "stageName": "Flowering & Fruit Setting",
        "das": 55,
        "dasRange": "DAS 50 – 70",
        "waterVolume": "45,000 L/Acre",
        "importance": "Critical",
        "guidance": "Continuous moisture needed for glossy tender fruits."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Shoot & Fruit Borer)",
        "das": 45,
        "dasRange": "DAS 40 – 50",
        "targetProblem": "Shoot & Fruit Borer (Leucinodes orbonalis)",
        "chemical": "Chlorantraniliprole 18.5% SC or Emamectin Benzoate",
        "dosagePer15L": "7.5 ml or 8 g / 15L Pump",
        "phi": "3 Days",
        "weatherRule": "Rogue out and destroy drooping bored shoot tips before spraying."
      },
      {
        "sprayNumber": "Spray 2 (Little Leaf & Whitefly)",
        "das": 65,
        "dasRange": "DAS 60 – 70",
        "targetProblem": "Little Leaf Phytoplasma / Jassid",
        "chemical": "Thiamethoxam 25% WG",
        "dosagePer15L": "5 g / 15L Pump",
        "phi": "5 Days",
        "weatherRule": "Spray to control leafhopper vectors."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 125 – 140",
      "maturityIndicators": [
        "Fruits reach full size with bright glossy skin",
        "Seeds inside remain tender and white",
        "Calyx is fresh green"
      ],
      "harvestingMethod": "Harvest with sharp shears retaining 2 cm pedicel; pick every 4-5 days.",
      "postHarvestDrying": "Market immediately; brinjal is perishable.",
      "storageWarning": "Keep in cool shaded room; do not store below 10°C (chilling injury)."
    },
    "mandiSellingGuide": {
      "mspGovt": "Perishable Vegetable Spot Rate",
      "currentMandiRate": "₹1,200 – ₹3,500 / Qtl (₹12 – ₹35 / kg)",
      "bestSellingWindow": "Weekly harvests over 60-90 days",
      "gradingChecklist": [
        "Firm, glossy, uniform purple or green color",
        "Zero borer entry holes",
        "Fresh green calyx",
        "Tender non-fibrous pulp"
      ],
      "nearbyMandis": [
        {
          "name": "Vashi APMC Market (Navi Mumbai)",
          "distance": "Metropolitan Terminal",
          "rate": "₹2,600/Qtl"
        },
        {
          "name": "Kolar Vegetable Market (Karnataka)",
          "distance": "South India Hub",
          "rate": "₹2,200/Qtl"
        }
      ],
      "mandiTips": "Early morning harvest with prompt delivery to wholesale mandis prevents loss of glossy shine."
    }
  },
  "okra": {
    "cropKey": "okra",
    "cropName": "Okra / Ladyfinger",
    "vernacularName": "भिंडी / भेंडी",
    "season": "Kharif / Summer",
    "totalDurationDays": 90,
    "optimalSowingWindow": "Summer: Feb – March / Kharif: June – July",
    "seedRate": "4 – 5 kg / Acre (Kharif); 6 – 7 kg / Acre (Summer)",
    "seedTreatment": "Imidacloprid 600 FS @ 5ml/kg (controls YVMV whitefly) + Carbendazim @ 2g/kg",
    "spacing": "45 cm row spacing × 30 cm plant spacing",
    "soilPrep": "Deep sandy loam or clay loam; 5 tonnes FYM + 30 kg N + 25 kg P2O5 + 25 kg K2O per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Direct Line Sowing",
      "description": "Soak seeds in water for 12 hours before sowing to soften hard seed coat; sow 2 cm deep.",
      "keyActions": [
        "Use YVMV-resistant hybrids (Radhika, Singham, Avantika).",
        "Sow on ridges for Kharif drainage.",
        "Thin at 15 DAS."
      ],
      "warning": "Susceptible to Yellow Vein Mosaic Virus; strictly control whitefly vectors."
    },
    "irrigationSchedule": [
      {
        "stageName": "Vegetative Phase",
        "das": 20,
        "dasRange": "DAS 15 – 25",
        "waterVolume": "35,000 L/Acre",
        "importance": "High",
        "guidance": "Light watering every 4-5 days in summer."
      },
      {
        "stageName": "Pod Formation Phase",
        "das": 45,
        "dasRange": "DAS 40 – 60",
        "waterVolume": "40,000 L/Acre",
        "importance": "Critical",
        "guidance": "Ensure soil remains moist for tender pod growth."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Whitefly & Jassids)",
        "das": 25,
        "dasRange": "DAS 20 – 30",
        "targetProblem": "Whitefly & Leafhoppers",
        "chemical": "Diafenthiuron 50% WP (Pegasus)",
        "dosagePer15L": "18 g / 15L Pump",
        "phi": "5 Days",
        "weatherRule": "Spray underleaf surfaces thoroughly."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 75 – 90",
      "maturityIndicators": [
        "Pods are tender, 8-10 cm long",
        "Tip of pod snaps easily when bent with fingers",
        "Color is vibrant deep green"
      ],
      "harvestingMethod": "Pick every alternate day in morning with cotton gloves to prevent skin itching from pod spines.",
      "postHarvestDrying": "Market immediately fresh; perishable.",
      "storageWarning": "Keep pods in ventilated crates; do not pack in polythene without ventilation."
    },
    "mandiSellingGuide": {
      "mspGovt": "Perishable Vegetable Spot Rate",
      "currentMandiRate": "₹1,800 – ₹4,500 / Qtl (Summer fetches up to ₹5,500)",
      "bestSellingWindow": "Frequent pickings from 45 to 85 DAS",
      "gradingChecklist": [
        "Tender, snap-crisp pods (7-10 cm)",
        "Uniform dark green color",
        "Zero fruit borer holes",
        "No fibrous overgrown pods"
      ],
      "nearbyMandis": [
        {
          "name": "Surat APMC Mandi (Gujarat)",
          "distance": "Major Vegetable Market",
          "rate": "₹3,400/Qtl"
        },
        {
          "name": "Pune APMC Gultekdi",
          "distance": "Western Hub",
          "rate": "₹3,100/Qtl"
        }
      ],
      "mandiTips": "Frequent picking every 48 hours keeps plants producing new flower flushes and prevents pods from turning woody."
    }
  },
  "tea": {
    "cropKey": "tea",
    "cropName": "Tea",
    "vernacularName": "चाय",
    "season": "Perennial Plantation",
    "totalDurationDays": 365,
    "optimalSowingWindow": "Nursery vegetative cuttings planted in May–June or Oct–Nov",
    "seedRate": "6,000 – 7,000 clonal bushes / Acre",
    "seedTreatment": "Root dip in IBA (Indole Butyric Acid) + Trichoderma before field planting",
    "spacing": "105 cm row spacing × 60 cm bush spacing",
    "soilPrep": "Deep, well-drained acidic soil (pH 4.5 – 5.5) rich in organic matter; shade tree establishment",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Clonal Bush Planting & Pruning",
      "description": "Plant selected high-yielding clones (TV-1, TV-23) in contoured terraces with shade trees.",
      "keyActions": [
        "Establish green shade cropsList (Albizia).",
        "Ensure mulch on young tea bases.",
        "Maintain plucking table."
      ],
      "warning": "Soil pH above 5.8 causes severe iron chlorosis and bush dieback."
    },
    "irrigationSchedule": [
      {
        "stageName": "Dry Winter / Spring Period",
        "das": 60,
        "dasRange": "Dec – March",
        "waterVolume": "50,000 L/Acre",
        "importance": "Critical",
        "guidance": "Sprinkler irrigation maintains high humidity for first flush shoot emergence."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Tea Mosquito Bug & Thrips)",
        "das": 90,
        "dasRange": "April – June",
        "targetProblem": "Helopeltis theivora (Tea Mosquito Bug)",
        "chemical": "Thiamethoxam 25% WG",
        "dosagePer15L": "5 g / 15L Pump",
        "phi": "7 Days",
        "weatherRule": "Target tender flush shoots."
      },
      {
        "sprayNumber": "Spray 2 (Red Spider Mite)",
        "das": 180,
        "dasRange": "July – Sept",
        "targetProblem": "Oligonychus coffeae (Red Spider Mite)",
        "chemical": "Spiromesifen 22.9% SC",
        "dosagePer15L": "15 ml / 15L Pump",
        "phi": "10 Days",
        "weatherRule": "Spray under-leaf canopy in dry spells."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 350 – 365",
      "maturityIndicators": [
        "Two tender leaves and a bud (Fine Plucking standard)",
        "Shoots reach 3-5 cm above plucking table"
      ],
      "harvestingMethod": "Hand pluck tender two leaves and a bud every 7-10 days throughout flush season.",
      "postHarvestDrying": "Transport immediately in ventilated baskets to tea factory for withering, rolling, fermenting, and drying.",
      "storageWarning": "Keep green leaf cool; compressed leaves in plastic bags undergo sour fermentation."
    },
    "mandiSellingGuide": {
      "mspGovt": "Tea Board Floor Price: ₹22 – ₹35 / kg green leaf",
      "currentMandiRate": "₹180 – ₹420 / kg (Finished Made Tea at Auction)",
      "bestSellingWindow": "March to December (First Flush to Autumnal Flush)",
      "gradingChecklist": [
        "Fine Plucking (>85% two leaves and a bud)",
        "Zero coarse woody stems",
        "Orthodox / CTC grade classification"
      ],
      "nearbyMandis": [
        {
          "name": "Siliguri Tea Auction Center (WB)",
          "distance": "Eastern Auction Hub",
          "rate": "₹240/kg"
        },
        {
          "name": "Guwahati Tea Auction (Assam)",
          "distance": "Assam Tea Capital",
          "rate": "₹260/kg"
        },
        {
          "name": "Kochi Tea Auction (Kerala)",
          "distance": "South India Hub",
          "rate": "₹210/kg"
        }
      ],
      "mandiTips": "First Flush (March-April) and Second Flush (May-June) teas command up to 100% auction premium."
    }
  },
  "coffee": {
    "cropKey": "coffee",
    "cropName": "Coffee",
    "vernacularName": "कॉफी",
    "season": "Perennial Plantation",
    "totalDurationDays": 365,
    "optimalSowingWindow": "June – July (Planting 12-month old nursery seedlings)",
    "seedRate": "800 – 1,000 bushes / Acre (Arabica: 2x2m; Robusta: 3x3m)",
    "seedTreatment": "Seed dip in biofertilizer Azotobacter + PSB",
    "spacing": "2.5 m × 2.5 m (Arabica) or 3.0 m × 3.0 m (Robusta)",
    "soilPrep": "Deep, well-drained fertile volcanic loam rich in organic matter (pH 6.0 – 6.5); dual-tier shade canopy",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Seedling Planting & Shade Management",
      "description": "Plant seedlings in 60x60x60 cm pits filled with topsoil, FYM and bone meal under mixed canopy shade.",
      "keyActions": [
        "Establish permanent shade trees (Silver Oak, Ficus).",
        "Apply leaf mulch around collar.",
        "Provide initial shade basket."
      ],
      "warning": "Exposing young coffee to unshaded direct sun causes leaf scorch and dieback."
    },
    "irrigationSchedule": [
      {
        "stageName": "Blossom Irrigation (Bakki Neeru)",
        "das": 70,
        "dasRange": "Feb – March",
        "waterVolume": "60,000 L/Acre",
        "importance": "Critical",
        "guidance": "Trigger sprinkler irrigation (25-35 mm) to induce uniform synchronous flowering blossom."
      },
      {
        "stageName": "Backing Irrigation",
        "das": 90,
        "dasRange": "2 weeks after blossom",
        "waterVolume": "50,000 L/Acre",
        "importance": "Critical",
        "guidance": "Crucial for fruit set and preventing pinhead berry drop."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Coffee Leaf Rust)",
        "das": 150,
        "dasRange": "May – June (Pre-monsoon)",
        "targetProblem": "Leaf Rust (Hemileia vastatrix)",
        "chemical": "Bordeaux Mixture 0.5% or Epoxiconazole",
        "dosagePer15L": "1% Bordeaux or 15 ml / 15L Pump",
        "phi": "30 Days",
        "weatherRule": "Thoroughly spray lower leaf surfaces."
      },
      {
        "sprayNumber": "Spray 2 (Coffee Berry Borer)",
        "das": 240,
        "dasRange": "Aug – Sept",
        "targetProblem": "Berry Borer (Hypothenemus hampei)",
        "chemical": "Beauveria bassiana or Chlorpyrifos",
        "dosagePer15L": "50 g or 30 ml / 15L Pump",
        "phi": "45 Days",
        "weatherRule": "Target developing berries before borer enters hard bean."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 350 – 365",
      "maturityIndicators": [
        "Berries turn bright crimson red (Cherry stage)",
        "Berry yields to gentle thumb pressure without squashing"
      ],
      "harvestingMethod": "Selective hand picking of ripe red cherries; avoid stripping unripe green berries.",
      "postHarvestDrying": "Sun dry washed parchment or unwashed cherry on clean tiled drying yards until bean moisture is 10.5-11%.",
      "storageWarning": "Keep dry beans away from spices; coffee beans absorb foreign odors rapidly."
    },
    "mandiSellingGuide": {
      "mspGovt": "Coffee Board Indicative Price",
      "currentMandiRate": "Arabica Parchment: ₹16,000 – ₹19,000 / 50kg bag; Robusta Cherry: ₹8,500 – ₹10,500 / 50kg bag",
      "bestSellingWindow": "November to March (Arabica harvested early, Robusta late)",
      "gradingChecklist": [
        "Plantation A / PB (Peaberry) / Cherry AB",
        "Moisture strictly 10.5 – 11.5%",
        "Zero insect-damaged or black beans"
      ],
      "nearbyMandis": [
        {
          "name": "Kushalnagar Coffee Yard (Kodagu, Karnataka)",
          "distance": "Coorg Coffee Capital",
          "rate": "₹18,500/bag"
        },
        {
          "name": "Chikkamagaluru APMC Yard",
          "distance": "Origin Hub",
          "rate": "₹18,200/bag"
        }
      ],
      "mandiTips": "Estate-washed Arabica Plantation-A grade with certified cup score >82 fetches high international specialty coffee export prices."
    }
  },
  "coconut": {
    "cropKey": "coconut",
    "cropName": "Coconut",
    "vernacularName": "नारियल / नारळ",
    "season": "Perennial Palm",
    "totalDurationDays": 365,
    "optimalSowingWindow": "May – June (Onset of monsoon)",
    "seedRate": "60 – 70 palms / Acre",
    "seedTreatment": "Dip seedling roots in Pseudomonas fluorescens @ 10g/L water",
    "spacing": "7.5 m × 7.5 m square planting",
    "soilPrep": "Plant in 1x1x1 m pits filled with topsoil, FYM, coconut husk layer and 1 kg bone meal",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Seedling Planting & Husk Burial",
      "description": "Plant 10-12 month old vigorous seedlings with at least 6-8 leaves; bury coconut husks in layers for water conservation.",
      "keyActions": [
        "Dig deep pits and incorporate 2 layers of coconut husks.",
        "Plant collar level with bottom.",
        "Provide shade and fencing."
      ],
      "warning": "Never plant in waterlogged stagnant clay; drainage is mandatory."
    },
    "irrigationSchedule": [
      {
        "stageName": "Summer Maintenance",
        "das": 90,
        "dasRange": "Regular summer",
        "waterVolume": "50-100 Liters / Palm / Day",
        "importance": "Critical",
        "guidance": "Drip irrigation in palm basin prevents button shedding and nut drop."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Rhinoceros Beetle & Red Palm Weevil)",
        "das": 120,
        "dasRange": "Bi-monthly",
        "targetProblem": "Rhinoceros Beetle / Weevil",
        "chemical": "Neem cake + sand in leaf axils",
        "dosagePer15L": "250g mixture per crown",
        "phi": "0 Days",
        "weatherRule": "Clean crown before placing repellent mixture."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 350 – 365",
      "maturityIndicators": [
        "Nuts reach 11-12 months age",
        "Husk turns brown or dull green",
        "Water swishes loudly when shaken"
      ],
      "harvestingMethod": "Climb palm or use telescopic sickle poles to harvest mature bunches every 30-45 days.",
      "postHarvestDrying": "De-husk nuts; split and sun-dry copra in solar dryers to 6% moisture for oil milling.",
      "storageWarning": "Store whole nuts in dry ventilated sheds; keep copra free from Aspergillus mould."
    },
    "mandiSellingGuide": {
      "mspGovt": "Milling Copra: ₹11,160 / Qtl; Ball Copra: ₹12,000 / Qtl",
      "currentMandiRate": "Tender Coconut: ₹25 – ₹45 / nut; Milling Copra: ₹10,800 – ₹12,200 / Qtl",
      "bestSellingWindow": "Monthly year-round harvests",
      "gradingChecklist": [
        "Ball Copra (Whole dry cup)",
        "Grade A Milling Copra (Moisture <6%, Oil >68%)",
        "Tender water volume >350 ml"
      ],
      "nearbyMandis": [
        {
          "name": "Kochi Coconut Market (Kerala)",
          "distance": "National Coconut Hub",
          "rate": "₹11,800/Qtl (Copra)"
        },
        {
          "name": "Kangayam Coconut Mandi (Tamil Nadu)",
          "distance": "Major Copra Oil Yard",
          "rate": "₹11,500/Qtl"
        }
      ],
      "mandiTips": "Direct farm-gate supply of tender coconuts to urban stalls yields 60% higher net margins than drying for copra."
    }
  },
  "banana": {
    "cropKey": "banana",
    "cropName": "Banana",
    "vernacularName": "केला / केळी",
    "season": "Kharif / Spring (11-12 Months Cycle)",
    "totalDurationDays": 330,
    "optimalSowingWindow": "June – July (Monsoon) or February – March (Spring)",
    "seedRate": "1,200 – 1,450 tissue-culture plantlets / Acre",
    "seedTreatment": "Root dip in Trichoderma viride (10g/L) + Carbendazim (1g/L) for 20 mins",
    "spacing": "1.8 m × 1.8 m (Grand Naine Cavendish)",
    "soilPrep": "Deep, rich, well-drained loamy soil (pH 6.5-7.5); apply 10 tonnes FYM + 200g Urea + 300g SSP + 300g MOP per plant in split doses",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Tissue Culture Planting & Basal Care",
      "description": "Plant hardened secondary tissue-culture plants (Grand Naine / Robusta) in 45x45 cm pits with drip fertigation.",
      "keyActions": [
        "Plant in evening hours; press soil firmly around plantlet.",
        "Provide immediate drip irrigation.",
        "De-sucker extra side shoots regularly to maintain single main pseudo-stem."
      ],
      "warning": "Avoid planting infected field suckers; tissue culture guarantees freedom from Panama Wilt."
    },
    "irrigationSchedule": [
      {
        "stageName": "Vegetative Canopy Phase",
        "das": 90,
        "dasRange": "DAS 60 – 120",
        "waterVolume": "20-25 Liters / Plant / Day",
        "importance": "High",
        "guidance": "High water requirement; drip irrigation every day."
      },
      {
        "stageName": "Shooting & Bunch Emergence",
        "das": 220,
        "dasRange": "DAS 200 – 240",
        "waterVolume": "30-35 Liters / Plant / Day",
        "importance": "Critical",
        "guidance": "Peak water consumption; deficit causes choked throat and small hands."
      },
      {
        "stageName": "Bunch Filling & Maturity",
        "das": 300,
        "dasRange": "DAS 280 – 320",
        "waterVolume": "25 Liters / Plant / Day",
        "importance": "Critical",
        "guidance": "Maintain steady moisture for plump fruit fingers."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Sigatoka Leaf Spot)",
        "das": 120,
        "dasRange": "Monsoon period",
        "targetProblem": "Sigatoka Leaf Spot (Mycosphaerella)",
        "chemical": "Propiconazole 25% EC (Tilt) + Mineral Oil",
        "dosagePer15L": "15 ml + 15 ml oil / 15L Pump",
        "phi": "21 Days",
        "weatherRule": "Spray under-leaf canopy at onset of monsoon rains."
      },
      {
        "sprayNumber": "Spray 2 (Bunch Cover & Thrips)",
        "das": 240,
        "dasRange": "At flower drop",
        "targetProblem": "Flower Thrips & Fruit Blemishes",
        "chemical": "Bagging bunch with blue polypropylene sleeves",
        "dosagePer15L": "Physical cover sleeve",
        "phi": "0 Days",
        "weatherRule": "Place sleeve after removal of male flower bud (denavelling)."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 315 – 330",
      "maturityIndicators": [
        "Fruit fingers turn light green and ribs become rounded",
        "Floral remnants at finger tips drop easily",
        "Top leaf dries naturally"
      ],
      "harvestingMethod": "Harvest bunch with sharp sickle leaving 30 cm peduncle handle; carry in foam-padded slings.",
      "postHarvestDrying": "De-hand in packing shed; wash in alum water tank to remove latex stains; pack in 13kg corrugated export cartons.",
      "storageWarning": "Never store green bananas with ripe fruit; ethylene triggers premature ripening."
    },
    "mandiSellingGuide": {
      "mspGovt": "Spot Market Determined: ₹1,200 – ₹2,400 / Qtl",
      "currentMandiRate": "₹1,400 – ₹2,600 / Qtl (₹14 – ₹26 / kg)",
      "bestSellingWindow": "Year-round peak bunches (9 to 12 months after planting)",
      "gradingChecklist": [
        "Export Grade: 8-inch+ finger length, 38-42mm caliber, spotless skin",
        "Domestic Table: Clean 6-7 inch fingers, zero mechanical bruises"
      ],
      "nearbyMandis": [
        {
          "name": "Jalgaon APMC (Maharashtra)",
          "distance": "Banana City of India",
          "rate": "₹2,150/Qtl"
        },
        {
          "name": "Theni Banana Market (Tamil Nadu)",
          "distance": "South India Center",
          "rate": "₹1,950/Qtl"
        }
      ],
      "mandiTips": "Bunched sleeve covering and clean packing in foam-lined boxes fetches 30% export premium at Gulf export terminals."
    }
  },
  "mango": {
    "cropKey": "mango",
    "cropName": "Mango",
    "vernacularName": "आम / आंबा",
    "season": "Perennial Orchard",
    "totalDurationDays": 365,
    "optimalSowingWindow": "July – August (Monsoon planting of grafted saplings)",
    "seedRate": "40 – 70 trees / Acre (Traditional: 10x10m; High Density: 5x5m)",
    "seedTreatment": "Root dip in Trichoderma + Carbendazim before pit planting",
    "spacing": "5 m × 5 m (Ultra High Density: Totapuri / Kesar / Alphonso)",
    "soilPrep": "Deep, well-drained alluvial or red loamy soil (pH 6.0 – 7.5); 1x1x1 m pits with 25 kg FYM, 1 kg SSP, and neem cake",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Grafted Sapling Planting",
      "description": "Plant genuine certified stone-grafted or epicotyl-grafted saplings; keep graft union 15 cm above ground.",
      "keyActions": [
        "Keep graft union above soil line.",
        "Stake sapling with bamboo stick.",
        "Remove rootstock sprouts promptly."
      ],
      "warning": "Never allow standing water around tree trunk; Phytophthora root rot can kill trees."
    },
    "irrigationSchedule": [
      {
        "stageName": "Flowering & Fruit Set",
        "das": 60,
        "dasRange": "Jan – Feb",
        "waterVolume": "50-80 Liters / Tree / Week",
        "importance": "Critical",
        "guidance": "Start irrigation only after fruit set (pea size); irrigating during flower emergence causes vegetative flush."
      },
      {
        "stageName": "Fruit Development Stage",
        "das": 110,
        "dasRange": "March – April",
        "waterVolume": "100 Liters / Tree / Week",
        "importance": "Critical",
        "guidance": "Prevents fruit drop and maximizes fruit size. Stop 15 days before harvest."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Mango Hopper & Powdery Mildew)",
        "das": 45,
        "dasRange": "Panicle emergence (Dec-Jan)",
        "targetProblem": "Mango Hopper (Idioscopus) & Powdery Mildew",
        "chemical": "Imidacloprid 17.8% SL + Hexaconazole 5% SC",
        "dosagePer15L": "5 ml + 20 ml / 15L Pump",
        "phi": "21 Days",
        "weatherRule": "Spray entire canopy before blossoms open."
      },
      {
        "sprayNumber": "Spray 2 (Anthracnose & Fruit Fly)",
        "das": 120,
        "dasRange": "Pre-harvest (April)",
        "targetProblem": "Fruit Fly & Anthracnose",
        "chemical": "Install methyl eugenol pheromone traps + Azoxystrobin",
        "dosagePer15L": "6 traps/acre + 15 ml / 15L Pump",
        "phi": "15 Days",
        "weatherRule": "Pheromone traps monitor fruit fly emergence."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 350 – 365",
      "maturityIndicators": [
        "Fruit shoulders rise above pedicel stalk attachment",
        "Skin color changes from dark olive green to light green with yellow/red blush",
        "Specific gravity reaches 1.01 – 1.02 (mature fruit sinks in water)"
      ],
      "harvestingMethod": "Harvest with pole harvesters with net bag attached; retain 1 cm stalk to prevent sap burning (latex burn) on skin.",
      "postHarvestDrying": "De-sap upside down on corrugated racks; hot water treatment at 48°C for 5 mins controls anthracnose and fruit fly.",
      "storageWarning": "Ripen in ethylene ripening chambers at 20-22°C; never use hazardous calcium carbide."
    },
    "mandiSellingGuide": {
      "mspGovt": "Auction Market Determined",
      "currentMandiRate": "₹3,500 – ₹12,000 / Qtl (Alphonso / Kesar / Dasheri / Banganapalle)",
      "bestSellingWindow": "April to July",
      "gradingChecklist": [
        "Export Grade: 250-350g, blemish-free, hot water treated",
        "Grade 1 Table: 200-250g, uniform shape"
      ],
      "nearbyMandis": [
        {
          "name": "Vashi APMC Fruit Market (Navi Mumbai)",
          "distance": "Alphonso Terminal",
          "rate": "₹9,500/Qtl"
        },
        {
          "name": "Malihabad Mango Mandi (Lucknow, UP)",
          "distance": "Dasheri Capital",
          "rate": "₹4,200/Qtl"
        }
      ],
      "mandiTips": "De-sapped, size-graded mangoes packed in 4kg 12-fruit partitions fetch 40% premium over bulk crates."
    }
  },
  "turmeric": {
    "cropKey": "turmeric",
    "cropName": "Turmeric",
    "vernacularName": "हल्दी / हळद",
    "season": "Kharif (9 Months Cycle)",
    "totalDurationDays": 260,
    "optimalSowingWindow": "15 May – 25 June (Pre-monsoon sowing on raised beds)",
    "seedRate": "800 – 1,000 kg mother / finger rhizomes / Acre",
    "seedTreatment": "Mancozeb 75% WP @ 3g/L + Chlorpyrifos 20% EC @ 2ml/L water rhizome dip for 30 mins",
    "spacing": "Broad Bed Furrows (BBF): 30 cm × 20 cm on 120 cm wide raised beds",
    "soilPrep": "Deep, fertile friable loam rich in organic matter; apply 10 tonnes FYM + 25 kg N + 25 kg P2O5 + 40 kg K2O + 15 kg Zinc Sulphate",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Rhizome Bed Planting & Mulching",
      "description": "Plant treated mother or bold finger rhizomes at 4 cm depth; apply heavy green leaf mulch immediately.",
      "keyActions": [
        "Apply 5 tonnes/acre green tree leaf mulch (Glyricidia / Subabul) immediately after planting.",
        "Repeat mulching at 45 and 90 DAS.",
        "Ensure excellent soil drainage."
      ],
      "warning": "Waterlogging triggers severe Rhizome Rot (Pythium / Ralstonia) that can wipe out entire plots."
    },
    "irrigationSchedule": [
      {
        "stageName": "Rhizome Sprouting Phase",
        "das": 30,
        "dasRange": "DAS 20 – 40",
        "waterVolume": "40,000 L/Acre",
        "importance": "High",
        "guidance": "Maintain moist soil under mulch cover."
      },
      {
        "stageName": "Tillering & Rhizome Initiation",
        "das": 90,
        "dasRange": "DAS 80 – 110",
        "waterVolume": "45,000 L/Acre",
        "importance": "Critical",
        "guidance": "Active underground finger branching phase."
      },
      {
        "stageName": "Rhizome Bulking Stage",
        "das": 170,
        "dasRange": "DAS 150 – 190",
        "waterVolume": "45,000 L/Acre",
        "importance": "Critical",
        "guidance": "Peak curcumin and dry matter synthesis."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Rhizome Rot / Pythium Drench)",
        "das": 60,
        "dasRange": "Monsoon onset",
        "targetProblem": "Rhizome Rot & Leaf Blotch",
        "chemical": "Metalaxyl 8% + Mancozeb 64% WP",
        "dosagePer15L": "35 g / 15L Pump (soil drench at root zone)",
        "phi": "30 Days",
        "weatherRule": "Drench infected patches and surrounding 2 meters."
      },
      {
        "sprayNumber": "Spray 2 (Leaf Spot / Taphrina)",
        "das": 120,
        "dasRange": "Post-monsoon",
        "targetProblem": "Leaf Spot (Colletotrichum / Taphrina)",
        "chemical": "Propiconazole 25% EC",
        "dosagePer15L": "15 ml / 15L Pump",
        "phi": "30 Days",
        "weatherRule": "Spray upper and lower leaf surface."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 245 – 260",
      "maturityIndicators": [
        "Leaves turn yellow and dry up completely from base to tip",
        "Stems collapse naturally"
      ],
      "harvestingMethod": "Uproot rhizome clumps carefully with spade or tractor digger; shake off adhering soil.",
      "postHarvestDrying": "Boil rhizomes in boiling water for 45-60 mins until soft; sun-dry on clean canvas for 10-15 days until crisp (10% moisture).",
      "storageWarning": "Polish dry rhizomes in mechanical polishing drum; store in dry, insect-proof gunny bags."
    },
    "mandiSellingGuide": {
      "mspGovt": "NCDEX Commodity Exchange Rate",
      "currentMandiRate": "₹11,500 – ₹16,800 / Qtl (Salem / Nizamabad / Waigaon / Rajapore quality)",
      "bestSellingWindow": "February to May",
      "gradingChecklist": [
        "Finger / Mother Rhizome separation",
        "High Curcumin Content (>4.5 - 5.5%)",
        "Deep golden-yellow core color",
        "Moisture ≤ 10%"
      ],
      "nearbyMandis": [
        {
          "name": "Nizamabad APMC (Telangana)",
          "distance": "Major Turmeric Terminal Hub",
          "rate": "₹14,200/Qtl"
        },
        {
          "name": "Erode Turmeric Market (Tamil Nadu)",
          "distance": "Erode Yellow City",
          "rate": "₹14,800/Qtl"
        },
        {
          "name": "Sangli Turmeric Yard (Maharashtra)",
          "distance": "Western India Center",
          "rate": "₹15,200/Qtl"
        }
      ],
      "mandiTips": "Testing and certifying high curcumin content (>5%) through local Spices Board laboratories fetches up to ₹1,500/qtl export bonus."
    }
  },
  "ginger": {
    "cropKey": "ginger",
    "cropName": "Ginger",
    "vernacularName": "अदरक / आले",
    "season": "Kharif (8-9 Months)",
    "totalDurationDays": 245,
    "optimalSowingWindow": "15 April – 31 May",
    "seedRate": "600 – 800 kg seed rhizomes / Acre",
    "seedTreatment": "Mancozeb 75% WP @ 3g/L + Streptocycline @ 0.5g/L water dip for 30 mins",
    "spacing": "30 cm row spacing × 20 cm plant spacing on raised beds",
    "soilPrep": "Rich friable loam with high humus content; apply 12 tonnes FYM + 30 kg N + 25 kg P2O5 + 35 kg K2O",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Raised Bed Planting & Heavy Mulching",
      "description": "Plant 25-30g healthy seed pieces on raised beds; cover with thick green leaf mulch.",
      "keyActions": [
        "Mulch with 4 tonnes green leaves immediately.",
        "Ensure slope drainage.",
        "Apply Trichoderma drenching at 30 DAS."
      ],
      "warning": "Bacterial wilt (Ralstonia) is seed-borne; never plant seed from wilted fields."
    },
    "irrigationSchedule": [
      {
        "stageName": "Tillering Phase",
        "das": 60,
        "dasRange": "DAS 50 – 75",
        "waterVolume": "40,000 L/Acre",
        "importance": "Critical",
        "guidance": "Maintain cool moist root zone."
      },
      {
        "stageName": "Rhizome Bulking Phase",
        "das": 140,
        "dasRange": "DAS 130 – 160",
        "waterVolume": "45,000 L/Acre",
        "importance": "Critical",
        "guidance": "Active hand rhizome expansion."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Soft Rot / Pythium Drench)",
        "das": 75,
        "dasRange": "Heavy rains",
        "targetProblem": "Soft Rot / Pythium Rhizome Rot",
        "chemical": "Metalaxyl-Mancozeb (Ridomil Gold)",
        "dosagePer15L": "35 g / 15L Pump (drench)",
        "phi": "30 Days",
        "weatherRule": "Drench beds at first symptom of leaf yellowing."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 230 – 245",
      "maturityIndicators": [
        "Foliage turns completely yellow and withers away",
        "Rhizomes turn firm with tough skin"
      ],
      "harvestingMethod": "Dig with fork; wash in clean water; sun-dry green ginger or peel and dry for Sonth.",
      "postHarvestDrying": "Dry peeled ginger for 7-10 days to make dry ginger (Sonth) with 10% moisture.",
      "storageWarning": "Keep dry ginger away from humidity to prevent mould."
    },
    "mandiSellingGuide": {
      "mspGovt": "Spot Market Determined",
      "currentMandiRate": "Fresh Green Ginger: ₹3,500 – ₹7,500 / Qtl; Dry Ginger (Sonth): ₹22,000 – ₹32,000 / Qtl",
      "bestSellingWindow": "December to March",
      "gradingChecklist": [
        "Bold plump fingers",
        "Clean without fibrous shrinkage",
        "Zero soft rot lesions"
      ],
      "nearbyMandis": [
        {
          "name": "Kochi Spice Market (Kerala)",
          "distance": "Spices Board Terminal",
          "rate": "₹26,000/Qtl (Dry)"
        },
        {
          "name": "Shimoga APMC (Karnataka)",
          "distance": "Green Ginger Hub",
          "rate": "₹5,200/Qtl (Fresh)"
        }
      ],
      "mandiTips": "Drying and curing into dry ginger (Sonth) allows holding for off-season sales when prices peak in monsoon."
    }
  },
  "coriander": {
    "cropKey": "coriander",
    "cropName": "Coriander / Dhaniya",
    "vernacularName": "धनिया / धणे",
    "season": "Rabi / Late Kharif",
    "totalDurationDays": 100,
    "optimalSowingWindow": "15 October – 15 November",
    "seedRate": "8 – 10 kg split seeds / Acre",
    "seedTreatment": "Trichoderma @ 5g/kg + split seeds by rubbing into halves before sowing",
    "spacing": "30 cm row spacing × 10 cm plant spacing; depth 2-3 cm",
    "soilPrep": "Fine seedbed; 3 tonnes FYM + 25 kg N + 20 kg P2O5 per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Seed Splitting & Drilling",
      "description": "Rub round seeds gently to split into two mericarps; drill into moist soil.",
      "keyActions": [
        "Split seeds into halves for double germination count.",
        "Soak in water for 12 hours before sowing.",
        "Keep soil moist for 10 days."
      ],
      "warning": "Avoid sowing whole unsplit seeds; germination takes 15-20 days otherwise."
    },
    "irrigationSchedule": [
      {
        "stageName": "Flowering Phase",
        "das": 50,
        "dasRange": "DAS 45 – 55",
        "waterVolume": "35,000 L/Acre",
        "importance": "Critical",
        "guidance": "Light watering for uniform umbel bloom."
      },
      {
        "stageName": "Seed Formation Stage",
        "das": 75,
        "dasRange": "DAS 70 – 80",
        "waterVolume": "35,000 L/Acre",
        "importance": "Critical",
        "guidance": "Ensures green round aromatic seed filling."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Powdery Mildew)",
        "das": 60,
        "dasRange": "DAS 55 – 65",
        "targetProblem": "Powdery Mildew (Erysiphe polygoni)",
        "chemical": "Wettable Sulphur 80% WP or Hexaconazole",
        "dosagePer15L": "30 g or 15 ml / 15L Pump",
        "phi": "20 Days",
        "weatherRule": "Spray at first sign of white dusting on umbels."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 85 – 100",
      "maturityIndicators": [
        "Umbels turn brownish-yellow",
        "Seeds become firm and fragrant",
        "Foliage dries"
      ],
      "harvestingMethod": "Harvest early morning with sickle; bundle and dry in shade to preserve parrot-green color.",
      "postHarvestDrying": "Shade dry on canvas for 4-5 days; green colored coriander fetches 30% price premium.",
      "storageWarning": "Keep in clean bags; direct sun bleaches green color to dull brown."
    },
    "mandiSellingGuide": {
      "mspGovt": "Commercial Spice Rate",
      "currentMandiRate": "₹6,800 – ₹9,500 / Qtl (Eagle / Scooter / Green Badami quality)",
      "bestSellingWindow": "February to April",
      "gradingChecklist": [
        "Parrot-green color (Green Gold)",
        "Uniform round split-free seeds",
        "High volatile oil aroma",
        "Zero powdery mildew residue"
      ],
      "nearbyMandis": [
        {
          "name": "Ramganj Mandi (Kota, Rajasthan)",
          "distance": "Asia's Largest Coriander Mandi",
          "rate": "₹8,400/Qtl"
        },
        {
          "name": "Guna APMC Mandi (Madhya Pradesh)",
          "distance": "Central Spice Hub",
          "rate": "₹7,900/Qtl"
        }
      ],
      "mandiTips": "Drying under shade nets preserves the prized parrot-green color that fetches ₹1,500/qtl premium at Ramganj Mandi."
    }
  },
  "cumin": {
    "cropKey": "cumin",
    "cropName": "Cumin / Jeera",
    "vernacularName": "जीरा / जिरे",
    "season": "Rabi (Winter)",
    "totalDurationDays": 105,
    "optimalSowingWindow": "1 November – 25 November (Temp 20-25°C)",
    "seedRate": "5 – 6 kg / Acre",
    "seedTreatment": "Carbendazim 50% WP @ 2.5 g/kg seed + Trichoderma viride @ 5g/kg",
    "spacing": "25 cm row spacing × 10 cm plant spacing; shallow depth 1-1.5 cm",
    "soilPrep": "Fine, friable, weed-free seedbed; 3 tonnes FYM + 15 kg N + 20 kg P2O5 per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 10",
      "title": "Shallow Drilling & Sowing",
      "description": "Drill seeds very shallowly (1 cm) in moist soil; light watering immediately after sowing.",
      "keyActions": [
        "Treat seed to prevent devastating Cumin Wilt.",
        "Sow at shallow depth.",
        "Keep soil crusted moist for 8 days."
      ],
      "warning": "Cloudy humid weather triggers Blight (Alternaria burns) that can destroy 80% crop in 3 days."
    },
    "irrigationSchedule": [
      {
        "stageName": "Germination Light Irrigation",
        "das": 8,
        "dasRange": "DAS 6 – 10",
        "waterVolume": "25,000 L/Acre",
        "importance": "Critical",
        "guidance": "Light sprinkle to prevent soil crusting."
      },
      {
        "stageName": "Vegetative Branching",
        "das": 35,
        "dasRange": "DAS 30 – 40",
        "waterVolume": "35,000 L/Acre",
        "importance": "High",
        "guidance": "Supports umbrella branching."
      },
      {
        "stageName": "Flowering & Seed Set",
        "das": 65,
        "dasRange": "DAS 60 – 70",
        "waterVolume": "35,000 L/Acre",
        "importance": "Critical",
        "guidance": "Stop irrigation during seed maturation."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Cumin Blight / Alternaria)",
        "das": 50,
        "dasRange": "DAS 45 – 55",
        "targetProblem": "Blight (Alternaria burns)",
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC",
        "dosagePer15L": "15 ml / 15L Pump",
        "phi": "25 Days",
        "weatherRule": "Prophylactic spray before morning fog occurs."
      },
      {
        "sprayNumber": "Spray 2 (Powdery Mildew)",
        "das": 70,
        "dasRange": "DAS 65 – 75",
        "targetProblem": "Powdery Mildew",
        "chemical": "Dinocap 48% EC or Wettable Sulphur",
        "dosagePer15L": "15 ml or 30 g / 15L Pump",
        "phi": "20 Days",
        "weatherRule": "Spray umbels at first white mycelium."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 90 – 105",
      "maturityIndicators": [
        "Plants and umbels turn greyish-brown",
        "Seeds are firm and highly fragrant"
      ],
      "harvestingMethod": "Uproot early morning to prevent shattering; bundle and transport on sheets.",
      "postHarvestDrying": "Sun dry for 3-4 days on clean tarpaulins; thresh with gentle beating; winnow clean to 8% moisture.",
      "storageWarning": "Store in moisture-proof gunny bags lined with polythene in dry warehouses."
    },
    "mandiSellingGuide": {
      "mspGovt": "NCDEX Commodity Exchange Listed",
      "currentMandiRate": "₹24,000 – ₹38,000 / Qtl (High value cash spice)",
      "bestSellingWindow": "February to April",
      "gradingChecklist": [
        "Clean uniform bold seeds without stalks",
        "Zero blight blackening",
        "Moisture ≤ 8%",
        "Volatile oil > 2.5%"
      ],
      "nearbyMandis": [
        {
          "name": "Unjha APMC Mandi (Patan, Gujarat)",
          "distance": "World's Largest Cumin Trading Capital",
          "rate": "₹31,500/Qtl"
        },
        {
          "name": "Merta City APMC (Nagaur, Rajasthan)",
          "distance": "Rajasthan Jeera Hub",
          "rate": "₹29,800/Qtl"
        }
      ],
      "mandiTips": "Machine-cleaned (Sortex quality) cumin with <0.5% dust commands top dollar bids in Unjha e-auctions."
    }
  },
  "sunflower": {
    "cropKey": "sunflower",
    "cropName": "Sunflower",
    "vernacularName": "सूरजमुखी / सूर्यफूल",
    "season": "Kharif / Rabi / Spring",
    "totalDurationDays": 95,
    "optimalSowingWindow": "Kharif: July / Rabi: October / Spring: February",
    "seedRate": "2 – 2.5 kg hybrid seed / Acre",
    "seedTreatment": "Trichoderma @ 5g/kg + Imidacloprid @ 5ml/kg",
    "spacing": "60 cm row-to-row × 30 cm plant-to-plant; depth 3-4 cm",
    "soilPrep": "Medium black or fertile alluvial loam; 3 tonnes FYM + 30 kg N + 35 kg P2O5 + 20 kg K2O + 10 kg Sulphur",
    "sowingDetails": {
      "dasRange": "DAS 0 – 7",
      "title": "Precision Sowing & Bee Pollination Preparation",
      "description": "Drill seeds into moist seedbed; maintain honeybee hives (2-3 hives/acre) for high seed set.",
      "keyActions": [
        "Apply Sulphur for oil synthesis.",
        "Thin out seedlings at 15 DAS.",
        "Avoid moisture stress during head emergence."
      ],
      "warning": "Poor insect pollination causes hollow chaffy seeds in the center of the disc head."
    },
    "irrigationSchedule": [
      {
        "stageName": "Bud Initiation (Star Stage)",
        "das": 35,
        "dasRange": "DAS 30 – 40",
        "waterVolume": "40,000 L/Acre",
        "importance": "Critical",
        "guidance": "Crucial for head disc size enlargement."
      },
      {
        "stageName": "Flowering Stage",
        "das": 55,
        "dasRange": "DAS 50 – 60",
        "waterVolume": "45,000 L/Acre",
        "importance": "Critical",
        "guidance": "Most moisture-sensitive stage; moisture deficit causes floret abortion."
      },
      {
        "stageName": "Seed Filling Stage",
        "das": 75,
        "dasRange": "DAS 70 – 80",
        "waterVolume": "35,000 L/Acre",
        "importance": "High",
        "guidance": "Ensures plump heavy achenes and high oil content."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Head Borer / Helicoverpa)",
        "das": 50,
        "dasRange": "DAS 45 – 55",
        "targetProblem": "Sunflower Head Borer",
        "chemical": "Spinosad 45% SC or Chlorantraniliprole",
        "dosagePer15L": "4 ml or 7.5 ml / 15L Pump",
        "phi": "15 Days",
        "weatherRule": "Spray in evening when honeybees have returned to hives."
      },
      {
        "sprayNumber": "Spray 2 (Alternaria Leaf & Head Blight)",
        "das": 65,
        "dasRange": "DAS 60 – 70",
        "targetProblem": "Alternaria Blight",
        "chemical": "Mancozeb 75% WP or Propiconazole",
        "dosagePer15L": "35 g or 15 ml / 15L Pump",
        "phi": "20 Days",
        "weatherRule": "Spray back of capitulum head and foliage."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 90 – 100",
      "maturityIndicators": [
        "Back of the sunflower head turns lemony-yellow and bracts turn brown",
        "Seeds turn hard, black and glossy",
        "Ray florets wither and drop"
      ],
      "harvestingMethod": "Cut mature heads with sickle; dry heads on clean threshing floor.",
      "postHarvestDrying": "Sun dry heads for 3-4 days before mechanical threshing; clean seeds to 8-9% moisture.",
      "storageWarning": "Store in well-ventilated dry gunny bags; dampness leads to rapid oil rancidity."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹6,760 / Qtl (Government MSP)",
      "currentMandiRate": "₹6,200 – ₹7,100 / Qtl",
      "bestSellingWindow": "May to July (Spring crop) / November to January (Kharif crop)",
      "gradingChecklist": [
        "Oil Content > 40%",
        "Moisture Content ≤ 9%",
        "Zero hollow or insect-eaten chaff",
        "Clean black achenes"
      ],
      "nearbyMandis": [
        {
          "name": "Latur APMC Oilseed Yard (Maharashtra)",
          "distance": "Sunflower Hub",
          "rate": "₹6,850/Qtl"
        },
        {
          "name": "Bagalkot APMC (Karnataka)",
          "distance": "North Karnataka Center",
          "rate": "₹6,700/Qtl"
        }
      ],
      "mandiTips": "Test oil recovery in mandi lab before auction; lots with >42% oil command instant premium bidding from solvent extraction units."
    }
  },
  "sesame": {
    "cropKey": "sesame",
    "cropName": "Sesame / Til",
    "vernacularName": "तिल / तीळ",
    "season": "Kharif / Summer",
    "totalDurationDays": 85,
    "optimalSowingWindow": "Kharif: June – July / Summer: February – March",
    "seedRate": "1.5 – 2 kg / Acre",
    "seedTreatment": "Trichoderma @ 5g/kg + Carbendazim @ 2g/kg",
    "spacing": "30 cm row-to-row × 10 cm plant-to-plant; shallow 1.5-2 cm depth",
    "soilPrep": "Fine firm seedbed; 2 tonnes FYM + 15 kg N + 20 kg P2O5 + 10 kg Sulphur per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 5",
      "title": "Fine Seedbed Sowing & Thinning",
      "description": "Mix seed with 4 parts fine sand or sieved FYM for uniform broadcasting or drilling.",
      "keyActions": [
        "Mix seeds with dry sand for uniform distribution.",
        "Thin out excess seedlings at 15 DAS.",
        "Avoid crust formation."
      ],
      "warning": "Excessive depth (>2 cm) prevents tiny sesame seeds from emerging."
    },
    "irrigationSchedule": [
      {
        "stageName": "Branching Phase",
        "das": 25,
        "dasRange": "DAS 20 – 30",
        "waterVolume": "30,000 L/Acre",
        "importance": "High",
        "guide": "Induces lateral capsule-bearing branches."
      },
      {
        "stageName": "Flowering & Capsule Filling",
        "das": 50,
        "dasRange": "DAS 45 – 55",
        "waterVolume": "35,000 L/Acre",
        "importance": "Critical",
        "guide": "Crucial for high oil content and seed weight."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Phyllody / Leafhopper Vector)",
        "das": 30,
        "dasRange": "DAS 25 – 35",
        "targetProblem": "Sesame Phyllody (Phytoplasma)",
        "chem": "Dimethoate 30% EC or Thiamethoxam",
        "dosagePer15L": "20 ml or 5 g / 15L Pump",
        "phi": "20 Days",
        "rule": "Rogue out bushy green floral phyllody plants."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 80 – 90",
      "maturityIndicators": [
        "Leaves turn yellow and drop",
        "Bottom capsules turn yellowish-brown and just begin to split at tip",
        "Seeds inside capsules turn white/black and firm"
      ],
      "harvestMethod": "Cut plants before top capsules split to avoid shattering loss; tie in small upright bundles.",
      "postHarvestDrying": "Stand bundles upright in conical shocks for 5-7 days; invert bundles over clean plastic sheet and shake seeds out.",
      "storageWarning": "Clean and sun dry seeds to 7% moisture; store in moisture-proof drums."
    },
    "mandiSellingGuide": {
      "mspGovt": "₹8,635 / Qtl (Government MSP)",
      "currentMandiRate": "₹11,000 – ₹15,500 / Qtl (Export White Til / Natural Black)",
      "bestSellingWindow": "October to December",
      "gradingChecklist": [
        "Pure white or jet black color",
        "Moisture ≤ 7%",
        "Purity > 99.5% (Sortex cleaned)",
        "Zero dirt or sand"
      ],
      "nearbyMandis": [
        {
          "name": "Rajkot APMC (Gujarat)",
          "distance": "Major Sesame Export Hub",
          "rate": "₹14,500/Qtl"
        },
        {
          "name": "Patan APMC Mandi (Gujarat)",
          "distance": "North Gujarat Terminal",
          "rate": "₹13,800/Qtl"
        }
      ],
      "mandiTips": "Sortex-cleaned bold White Sesame (Export 99.9% purity) commands up to ₹16,000/qtl in Gujarat port terminals."
    }
  },
  "cauliflower": {
    "cropKey": "cauliflower",
    "cropName": "Cauliflower",
    "vernacularName": "फूलगोभी / फ्लॉवर",
    "season": "Rabi / Early Kharif",
    "totalDurationDays": 90,
    "optimalSowingWindow": "Nursery: July–August (Early) / September–October (Main Rabi)",
    "seedRate": "150 – 200 g hybrid seed / Acre",
    "seedTreatment": "Captan or Thiram @ 2.5 g/kg seed + hot water treatment at 50°C for 30 mins",
    "spacing": "45 cm row-to-row × 45 cm plant-to-plant",
    "soilPrep": "Rich fertile loam; 8 tonnes FYM + 40 kg N + 30 kg P2O5 + 30 kg K2O + 1 kg Boron (Borax) per acre",
    "sowingDetails": {
      "dasRange": "DAS 0 – 25",
      "title": "Nursery Raising & Transplanting",
      "description": "Transplant 25-day-old sturdy seedlings on ridges; apply Boron to prevent curd browning.",
      "keyActions": [
        "Incorporate Boron in basal fertilizer.",
        "Transplant in cool evening hours.",
        "Blanch curds by folding outer leaves over curd."
      ],
      "warning": "Boron deficiency causes hollow stem and brown rotting of curds (Browning)."
    },
    "irrigationSchedule": [
      {
        "stageName": "Establishment Phase",
        "das": 5,
        "dasRange": "DAS 3 – 8",
        "vol": "35,000 L/Acre",
        "importance": "Critical",
        "guide": "Frequent light watering every 4-5 days."
      },
      {
        "stageName": "Curd Initiation & Sizing",
        "das": 50,
        "dasRange": "DAS 45 – 65",
        "vol": "45,000 L/Acre",
        "importance": "Critical",
        "guide": "Constant moisture needed for compact snow-white curds."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Diamondback Moth DBM)",
        "das": 35,
        "dasRange": "DAS 30 – 40",
        "targetProblem": "Diamondback Moth (Plutella xylostella)",
        "chem": "Chlorantraniliprole 18.5% SC or Spinosad",
        "dosagePer15L": "7.5 ml or 5 ml / 15L Pump",
        "phi": "3 Days",
        "rule": "Spray with wetting agent on underside of leaves."
      },
      {
        "sprayNumber": "Spray 2 (Downy Mildew & Black Rot)",
        "das": 55,
        "dasRange": "DAS 50 – 60",
        "targetProblem": "Downy Mildew & Bacterial Black Rot",
        "chem": "Copper Oxychloride 50% WP + Streptocycline",
        "dosagePer15L": "35 g + 1.5 g / 15L Pump",
        "phi": "7 Days",
        "rule": "Prophylactic spray during morning mist."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 75 – 90",
      "maturityIndicators": [
        "Curds reach full size, firm and compact",
        "Color is crisp snow-white without riceyness or yellowing",
        "Curd bracts remain tight"
      ],
      "harvestMethod": "Cut curds with sharp knife leaving 2-3 outer protective jacket leaves to shield the curd during transport.",
      "postHarvestDrying": "Pack in ventilated wooden or plastic crates; transport immediately to wholesale terminal.",
      "storageWarning": "Do not expose curds to direct sun after cutting; curds turn yellow within 2 hours."
    },
    "mandiSellingGuide": {
      "mspGovt": "Perishable Daily Auction Rate",
      "currentMandiRate": "₹1,200 – ₹3,500 / Qtl (₹12 – ₹35 / kg)",
      "bestSellingWindow": "November to February (Main Rabi season)",
      "gradingChecklist": [
        "Snow-white compact curds (700g – 1.2kg)",
        "Zero riceyness or loose florets",
        "Clean protective jacket leaves",
        "Zero insect caterpillar droppings"
      ],
      "nearbyMandis": [
        {
          "name": "Azadpur Mandi (Delhi)",
          "distance": "Northern Mega Terminal",
          "rate": "₹2,600/Qtl"
        },
        {
          "name": "Pune APMC Gultekdi",
          "distance": "Western Terminal",
          "rate": "₹2,400/Qtl"
        }
      ],
      "mandiTips": "Blanching outer leaves over curds 5 days before harvest maintains pure snow-white color that earns ₹5/kg higher price."
    }
  },
  "watermelon": {
    "cropKey": "watermelon",
    "cropName": "Watermelon",
    "vernacularName": "तरबूज / टरबूज",
    "season": "Summer / Zaid (Spring)",
    "totalDurationDays": 85,
    "optimalSowingWindow": "15 January – 28 February (Spring / Summer sowing)",
    "seedRate": "350 – 450 g hybrid seed / Acre",
    "seedTreatment": "Trichoderma @ 5g/kg + Imidacloprid @ 3ml/kg seed",
    "spacing": "2.5 m channel/bed spacing × 0.6 m plant spacing on silver-black mulch beds",
    "soilPrep": "Warm, well-drained sandy loam rich in organic matter; 8 tonnes FYM + 40 kg N + 30 kg P2O5 + 40 kg K2O per acre with drip fertigation",
    "sowingDetails": {
      "dasRange": "DAS 0 – 6",
      "title": "Mulch Bed Sowing & Drip Installation",
      "description": "Sow 1-2 seeds per hole in silver-black plastic mulch on raised beds with inline drip tubing.",
      "keyActions": [
        "Punch holes in 25-micron reflective mulch film.",
        "Maintain honeybee activity for fruit set.",
        "Provide water soluble 19:19:19 via fertigation."
      ],
      "warning": "Cold soil below 18°C causes seed rot; sow when daytime temperatures reach 26°C+."
    },
    "irrigationSchedule": [
      {
        "stageName": "Vegetative Vine Run",
        "das": 20,
        "dasRange": "DAS 15 – 25",
        "vol": "35,000 L/Acre",
        "importance": "High",
        "guide": "Encourages rapid vine branching."
      },
      {
        "stageName": "Fruit Set & Expansion",
        "das": 50,
        "dasRange": "DAS 45 – 65",
        "vol": "50,000 L/Acre",
        "importance": "Critical",
        "guide": "Peak water requirement for fruit sizing."
      },
      {
        "stageName": "Sugar Ripening Phase",
        "das": 75,
        "dasRange": "DAS 70 – 80",
        "vol": "25,000 L/Acre",
        "importance": "Moderate",
        "guide": "Reduce irrigation drastically 10 days before harvest to concentrate natural Brix sugars."
      }
    ],
    "spraySchedule": [
      {
        "sprayNumber": "Spray 1 (Red Pumpkin Beetle & Thrips)",
        "das": 20,
        "dasRange": "DAS 15 – 25",
        "targetProblem": "Red Pumpkin Beetle & Leaf Thrips",
        "chem": "Thiamethoxam 25% WG or Spinetoram",
        "dosagePer15L": "5 g or 8 ml / 15L Pump",
        "phi": "5 Days",
        "rule": "Spray early morning before beetles become active."
      },
      {
        "sprayNumber": "Spray 2 (Downy Mildew & Anthracnose)",
        "das": 50,
        "dasRange": "DAS 45 – 55",
        "targetProblem": "Downy Mildew (Pseudoperonospora)",
        "chem": "Cymoxanil + Mancozeb (Curzate)",
        "dosagePer15L": "30 g / 15L Pump",
        "phi": "7 Days",
        "rule": "Spray canopy before humid cloudy spells."
      }
    ],
    "harvestingSchedule": {
      "dasRange": "DAS 75 – 85",
      "maturityIndicators": [
        "Tendril at fruit attachment turns completely brown and dries up",
        "Ground spot turns from white to creamy butter-yellow",
        "Fruit gives dull hollow thud sound when tapped with knuckles"
      ],
      "harvestMethod": "Cut fruit stem with sharp knife leaving 3 cm stalk attached; harvest early morning before sun heats melons.",
      "postHarvestDrying": "Stack in single layer in shaded sheds; transport in straw-cushioned trucks.",
      "storageWarning": "Do not drop or rough handle; internal rind cracking ruins flesh sweetness."
    },
    "mandiSellingGuide": {
      "mspGovt": "Commercial Summer Fruit Rate",
      "currentMandiRate": "₹900 – ₹1,800 / Qtl (₹9 – ₹18 / kg in peak summer)",
      "bestSellingWindow": "March to June (Summer heat drives peak consumption)",
      "gradingChecklist": [
        "Uniform oblong or round shape (3.5 – 6.0 kg icebox size)",
        "High Sugar Brix > 11.5%",
        "Deep crimson-red crispy flesh with small seeds",
        "Zero sun-scald patches"
      ],
      "nearbyMandis": [
        {
          "name": "Kolar Watermelon Yard (Karnataka)",
          "distance": "South India Hub",
          "rate": "₹1,450/Qtl"
        },
        {
          "name": "Pune APMC Gultekdi",
          "distance": "Maharashtra Center",
          "rate": "₹1,350/Qtl"
        },
        {
          "name": "Azadpur Fruit Mandi (Delhi)",
          "distance": "Northern Terminal",
          "rate": "₹1,600/Qtl"
        }
      ],
      "mandiTips": "Tapering off irrigation 8-10 days before harvest raises sugar Brix to 12.5%, fetching top tier bids from metropolitan fruit buyers."
    }
  }
};
