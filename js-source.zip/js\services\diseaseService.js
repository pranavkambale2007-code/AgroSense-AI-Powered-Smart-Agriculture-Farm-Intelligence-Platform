// AgroSense Computer Vision Plant Disease Classifier Service
// Real-time leaf pathology screening, biomarker extraction, dynamic lesion localization & multi-tiered farmer solutions

import {
  plantDiseaseDatabase,
  demoLeafSamples,
  getSampleDataUrl,
  analyzeLeafImage,
  parseFilenameHints,
  getWhyThisHappens,
  healthyCropReferenceModels,
  recognizeCropSpecies,
  diseaseVernacularDictionary
} from '../ml/plantDiseaseModel.js';

export function getPlantDiseaseById(id) {
  return plantDiseaseDatabase.find(d => d.id === id) || plantDiseaseDatabase[0];
}

/**
 * Classify a leaf image synchronously (for preset samples or initial load)
 */
export function classifyLeafImage(imageSource = null, selectedSampleId = null, cropHint = 'all') {
  let matchedDisease = null;
  let dataUrl = null;

  if (selectedSampleId) {
    let diseaseId = selectedSampleId;
    if (selectedSampleId === 'disease-01') diseaseId = 'wheat-leaf-rust';
    if (selectedSampleId === 'disease-02') diseaseId = 'cotton-bacterial-blight';
    if (selectedSampleId === 'disease-03') diseaseId = 'tomato-healthy';

    const sample = demoLeafSamples.find(s => s.id === selectedSampleId || s.diseaseId === selectedSampleId || s.diseaseId === diseaseId);
    matchedDisease = plantDiseaseDatabase.find(d => d.id === (sample?.diseaseId || diseaseId)) || plantDiseaseDatabase[0];
    dataUrl = sample ? getSampleDataUrl(sample.svg) : null;
  } else if (cropHint && cropHint !== 'all') {
    const rec = recognizeCropSpecies({ userHint: cropHint });
    const canonicalKey = rec?.cropKey || cropHint;
    matchedDisease = plantDiseaseDatabase.find(d => d.cropKey === canonicalKey || d.cropKey === cropHint) || plantDiseaseDatabase[0];
    const matchingSample = demoLeafSamples.find(s => s.cropKey === canonicalKey || s.cropKey === cropHint);
    dataUrl = matchingSample ? getSampleDataUrl(matchingSample.svg) : getSampleDataUrl(demoLeafSamples[0].svg);
  } else {
    matchedDisease = plantDiseaseDatabase[0];
    dataUrl = getSampleDataUrl(demoLeafSamples[0].svg);
  }

  const isHealthy = matchedDisease.pathogenType.toLowerCase().includes('healthy');
  const confidence = isHealthy ? 98.5 : 94.2;
  const targetCropKey = matchedDisease.cropKey;
  const healthyRef = healthyCropReferenceModels[targetCropKey] || healthyCropReferenceModels.tomato;

  const observedBiomarkers = {
    greenPercentage: Math.round(matchedDisease.targetBiomarkers.green * 100),
    necroticPercentage: Math.round(matchedDisease.targetBiomarkers.necrotic * 100),
    chlorosisPercentage: Math.round(matchedDisease.targetBiomarkers.chlorosis * 100),
    powderyPercentage: Math.round(matchedDisease.targetBiomarkers.powdery * 100),
    rustPercentage: Math.round(matchedDisease.targetBiomarkers.rust * 100)
  };

  const greenDeficit = Math.max(0, healthyRef.healthyBiomarkers.green - observedBiomarkers.greenPercentage);
  const pathogenSpread = Math.round((matchedDisease.targetBiomarkers.necrotic + matchedDisease.targetBiomarkers.chlorosis + matchedDisease.targetBiomarkers.powdery + matchedDisease.targetBiomarkers.rust) * 100);

  const cropRecognition = {
    cropKey: targetCropKey,
    cropName: matchedDisease.crop,
    confidence: isHealthy ? 98.8 : 96.5,
    botanicalClass: healthyRef.botanicalClass,
    leafMorphology: healthyRef.leafMorphology,
    marginType: healthyRef.marginType,
    aspectRatioDescriptor: healthyRef.aspectRatioDescriptor,
    runnerUp: null
  };

  const healthyBaseline = {
    cropKey: targetCropKey,
    cropName: matchedDisease.crop,
    botanicalClass: healthyRef.botanicalClass,
    leafMorphology: healthyRef.leafMorphology,
    marginType: healthyRef.marginType,
    aspectRatioDescriptor: healthyRef.aspectRatioDescriptor,
    svg: healthyRef.svg,
    realPhotoUrl: healthyRef.realPhotoUrl,
    realPhotoDescription: healthyRef.realPhotoDescription,
    healthyBiomarkers: healthyRef.healthyBiomarkers,
    healthyTraits: healthyRef.healthyTraits,
    observedBiomarkers,
    deviationAnalysis: {
      greenDeficit,
      necroticSpread: observedBiomarkers.necroticPercentage,
      chlorosisSpread: observedBiomarkers.chlorosisPercentage,
      powderySpread: observedBiomarkers.powderyPercentage,
      rustSpread: observedBiomarkers.rustPercentage,
      pathogenSpread,
      healthStatus: (isHealthy || pathogenSpread < 6) ? 'Nominal (Healthy Baseline Foliage)' : 'Pathological Tissue Loss'
    }
  };

  const vernacularInfo = diseaseVernacularDictionary[matchedDisease.id] || {
    commonName: matchedDisease.diseaseName.split('(')[0].trim(),
    scientificName: matchedDisease.diseaseName.includes('(') ? matchedDisease.diseaseName.match(/\((.*?)\)/)?.[1] || '' : '',
    vernacularName: matchedDisease.diseaseName,
    vernacularHindi: '',
    vernacularMarathi: ''
  };

  const getCandidateMeta = (cand) => {
    return diseaseVernacularDictionary[cand.id] || {
      commonName: cand.diseaseName.split('(')[0].trim(),
      scientificName: cand.diseaseName.includes('(') ? cand.diseaseName.match(/\((.*?)\)/)?.[1] || '' : '',
      vernacularName: cand.diseaseName
    };
  };

  // Same-crop alternative candidates
  const altSameCrop = plantDiseaseDatabase.filter(d => d.cropKey === targetCropKey && d.id !== matchedDisease.id);
  const topCandidates = [
    {
      id: matchedDisease.id,
      name: matchedDisease.diseaseName,
      commonName: vernacularInfo.commonName,
      scientificName: vernacularInfo.scientificName,
      vernacularName: vernacularInfo.vernacularName,
      crop: matchedDisease.crop,
      prob: confidence,
      category: matchedDisease.pathogenType,
      status: "Primary Candidate"
    }
  ];
  if (altSameCrop[0]) {
    const meta0 = getCandidateMeta(altSameCrop[0]);
    topCandidates.push({
      id: altSameCrop[0].id,
      name: altSameCrop[0].diseaseName,
      commonName: meta0.commonName,
      scientificName: meta0.scientificName,
      vernacularName: meta0.vernacularName,
      crop: altSameCrop[0].crop,
      prob: Math.max(1.0, Number(((100 - confidence) * 0.72).toFixed(1))),
      category: altSameCrop[0].pathogenType,
      status: "Secondary Candidate"
    });
  }
  if (altSameCrop[1]) {
    const meta1 = getCandidateMeta(altSameCrop[1]);
    topCandidates.push({
      id: altSameCrop[1].id,
      name: altSameCrop[1].diseaseName,
      commonName: meta1.commonName,
      scientificName: meta1.scientificName,
      vernacularName: meta1.vernacularName,
      crop: altSameCrop[1].crop,
      prob: Math.max(0.5, Number(((100 - confidence) * 0.28).toFixed(1))),
      category: altSameCrop[1].pathogenType,
      status: "Low Likelihood"
    });
  }

  let sampleBbox = { x: 25, y: 32, w: 50, h: 42 };
  if (matchedDisease.id.includes('wheat')) sampleBbox = { x: 42, y: 15, w: 16, h: 70 };
  else if (matchedDisease.id.includes('rice')) sampleBbox = { x: 44, y: 22, w: 16, h: 62 };
  else if (matchedDisease.id.includes('cotton')) sampleBbox = { x: 28, y: 26, w: 48, h: 48 };
  else if (matchedDisease.id.includes('chilli-leaf-curl')) sampleBbox = { x: 28, y: 20, w: 44, h: 60 };
  else if (matchedDisease.id.includes('chilli-bacterial-spot')) sampleBbox = { x: 32, y: 25, w: 36, h: 50 };
  else if (matchedDisease.id.includes('maize-leaf-blight')) sampleBbox = { x: 34, y: 20, w: 32, h: 65 };
  else if (matchedDisease.id.includes('maize-common-rust')) sampleBbox = { x: 30, y: 18, w: 38, h: 68 };

  return {
    ...matchedDisease,
    commonName: vernacularInfo.commonName,
    scientificName: vernacularInfo.scientificName,
    vernacularName: vernacularInfo.vernacularName,
    vernacularHindi: vernacularInfo.vernacularHindi || '',
    vernacularMarathi: vernacularInfo.vernacularMarathi || '',
    primarySymptom: vernacularInfo.primarySymptom || '',
    confidence: confidence,
    severity: isHealthy ? "None (Healthy)" : (matchedDisease.id.includes('late') ? "High" : "Moderate"),
    imageSrc: dataUrl,
    cropRecognition,
    healthyBaseline,
    whyThisHappens: matchedDisease.whyThisHappens || getWhyThisHappens(matchedDisease.id, matchedDisease),
    recommendedActions: [
      ...matchedDisease.culturalMeasures.slice(0, 1),
      ...(matchedDisease.chemicalControl && matchedDisease.chemicalControl[0] ? [`Chemical: ${matchedDisease.chemicalControl[0].chemical} @ ${matchedDisease.chemicalControl[0].dosage}`] : []),
      ...matchedDisease.biologicalControl.slice(0, 1)
    ],
    biomarkers: observedBiomarkers,
    boundingBox: sampleBbox,
    topCandidates,
    screeningMode: "AgroSense Computer Vision V2.5 Model",
    disclaimer: "AI computer vision screening advisory — confirm with your local Krishi Vigyan Kendra (KVK) agronomist before chemical treatment."
  };
}

export {
  analyzeLeafImage,
  plantDiseaseDatabase,
  demoLeafSamples,
  getSampleDataUrl,
  parseFilenameHints,
  getWhyThisHappens,
  healthyCropReferenceModels,
  recognizeCropSpecies,
  diseaseVernacularDictionary
};
