// AgroSense Product Landing Page Component (SPA View)
// Credible, professional agricultural intelligence product presentation

const { translations } = require('js/data/translations.js');

function renderLandingPage(state) {
  const t = translations[state.lang] || translations.en;

  return `
    <div class="space-y-12 py-6 px-4 lg:px-8 max-w-7xl mx-auto">
      <!-- 1. HERO SECTION -->
      <section class="p-8 sm:p-12 rounded-3xl bg-[#091a13] border border-emerald-900/60 relative overflow-hidden space-y-6">
        <div class="max-w-3xl space-y-4">
          <div class="inline-flex items-center gap-2 px-3 py-1 rounded-md bg-emerald-950 border border-emerald-700/60 text-emerald-300 text-xs font-mono font-semibold">
            <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>AGRICULTURAL INTELLIGENCE PLATFORM</span>
          </div>

          <h1 class="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight font-heading">
            Better Farming Starts With Better Decisions.
          </h1>

          <p class="text-sm sm:text-base text-slate-300 leading-relaxed font-normal">
            AgroSense brings crop recommendations, plant disease analysis, and farm intelligence into one platform to help users make more informed agricultural decisions.
          </p>

          <div class="flex flex-wrap items-center gap-3 pt-2">
            <a href="#/onboarding" class="inline-flex items-center gap-2 px-5 py-3 rounded-xl text-xs sm:text-sm font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 transition shadow-md text-decoration-none">
              <i data-lucide="play" class="w-4 h-4 fill-slate-950"></i>
              <span>Explore AgroSense</span>
            </a>
            <a href="#/crop-recommendation" class="inline-flex items-center gap-2 px-5 py-3 rounded-xl text-xs sm:text-sm font-semibold text-slate-200 bg-[#0d261c] hover:bg-[#123326] border border-emerald-800/80 hover:border-emerald-600 transition text-decoration-none">
              <i data-lucide="sparkles" class="w-4 h-4 text-emerald-400"></i>
              <span>Explore Crop Intelligence</span>
            </a>
          </div>

          <!-- Credibility Metrics -->
          <div class="pt-4 border-t border-emerald-950 grid grid-cols-3 gap-4 max-w-md text-xs font-mono">
            <div>
              <span class="text-emerald-400 font-bold block text-sm sm:text-base">69 Crops</span>
              <span class="text-slate-400 text-[11px]">Agronomic Profiles</span>
            </div>
            <div>
              <span class="text-emerald-400 font-bold block text-sm sm:text-base">271 Pathologies</span>
              <span class="text-slate-400 text-[11px]">Foliar Screening</span>
            </div>
            <div>
              <span class="text-emerald-400 font-bold block text-sm sm:text-base">5 Stages</span>
              <span class="text-slate-400 text-[11px]">Biological Lifecycle</span>
            </div>
          </div>
        </div>
      </section>

      <!-- 2. FOUR PRODUCT PILLARS -->
      <section class="space-y-6">
        <div class="max-w-3xl space-y-1">
          <span class="text-xs font-bold uppercase tracking-wider text-emerald-400 font-mono">CORE CAPABILITIES</span>
          <h2 class="text-2xl sm:text-3xl font-black text-white font-heading">
            Engineered for Precision Farm Management
          </h2>
          <p class="text-xs text-slate-300">
            Transparent, empirical tools designed to solve operational problems from pre-sowing soil chemistry to post-harvest Mandi sales.
          </p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
          <!-- Card 1 -->
          <div class="p-6 rounded-2xl bg-[#0d2019] border border-emerald-900/60 space-y-3">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <i data-lucide="sparkles" class="w-5 h-5 text-emerald-400"></i>
                <h3 class="text-sm font-bold text-white font-heading">1. AI Crop Selection Model</h3>
              </div>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                Random Forest & Agronomy
              </span>
            </div>
            <p class="text-xs text-slate-300 leading-relaxed">
              Analyzes soil N, P, K, pH, rainfall, and temperature to calculate crop suitability scores, expected yield (Qtl/Acre), and projected farm net margin across registered acreage.
            </p>
            <div class="pt-2">
              <a href="#/crop-recommendation" class="text-xs font-bold text-emerald-400 hover:text-emerald-300 inline-flex items-center gap-1">
                <span>Open Crop Selection</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
              </a>
            </div>
          </div>

          <!-- Card 2 -->
          <div class="p-6 rounded-2xl bg-[#0d2019] border border-emerald-900/60 space-y-3">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <i data-lucide="scan-line" class="w-5 h-5 text-teal-400"></i>
                <h3 class="text-sm font-bold text-white font-heading">2. Plant Disease Screening</h3>
              </div>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-teal-950 text-teal-300 border border-teal-800">
                89 Crops • 271 Pathologies
              </span>
            </div>
            <p class="text-xs text-slate-300 leading-relaxed">
              Computer vision foliar biomarker analysis identifying bacterial, fungal, and viral lesions with multi-tiered remedies: certified organic, chemical tank dosages, and cultural controls.
            </p>
            <div class="pt-2">
              <a href="#/disease" class="text-xs font-bold text-teal-400 hover:text-teal-300 inline-flex items-center gap-1">
                <span>Open Disease Screening</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
              </a>
            </div>
          </div>

          <!-- Card 3 -->
          <div class="p-6 rounded-2xl bg-[#0d2019] border border-emerald-900/60 space-y-3">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <i data-lucide="box" class="w-5 h-5 text-blue-400"></i>
                <h3 class="text-sm font-bold text-white font-heading">3. 3D Farm Simulator</h3>
              </div>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                HTML5 Canvas PBR Twin
              </span>
            </div>
            <p class="text-xs text-slate-300 leading-relaxed">
              Interactive 3D digital twin of agricultural plots with procedural plant morphology, diurnal solar irradiance angles, irrigation zones, and root-zone soil layer cross-sections.
            </p>
            <div class="pt-2">
              <a href="#/3d-farm" class="text-xs font-bold text-blue-400 hover:text-blue-300 inline-flex items-center gap-1">
                <span>Launch 3D Simulator</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
              </a>
            </div>
          </div>

          <!-- Card 4 -->
          <div class="p-6 rounded-2xl bg-[#0d2019] border border-emerald-900/60 space-y-3">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <i data-lucide="calendar-clock" class="w-5 h-5 text-amber-400"></i>
                <h3 class="text-sm font-bold text-white font-heading">4. Crop Lifecycle & Mandi Monitor</h3>
              </div>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                5 Biological Stages
              </span>
            </div>
            <p class="text-xs text-slate-300 leading-relaxed">
              Actionable phenological calendar covering Sowing, Critical Irrigation (volumes/acre), Scheduled Sprays (tank dosages), Harvest Maturity Signs, and APMC Mandi price discovery.
            </p>
            <div class="pt-2">
              <a href="#/crop-monitor" class="text-xs font-bold text-amber-400 hover:text-amber-300 inline-flex items-center gap-1">
                <span>View Lifecycle Monitor</span>
                <i data-lucide="arrow-right" class="w-3.5 h-3.5"></i>
              </a>
            </div>
          </div>
        </div>
      </section>

      <!-- 3. WORKFLOW STEPS -->
      <section class="space-y-6 pt-4 border-t border-emerald-950/80">
        <div class="space-y-1">
          <span class="text-xs font-bold uppercase tracking-wider text-emerald-400 font-mono">OPERATIONAL WORKFLOW</span>
          <h2 class="text-xl sm:text-2xl font-bold text-white font-heading">
            From Field Data to Actionable Farm Decisions
          </h2>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5 text-xs">
          <div class="p-4 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
            <span class="w-6 h-6 rounded-full bg-emerald-950 border border-emerald-700 flex items-center justify-center font-mono font-bold text-xs text-emerald-400">1</span>
            <div class="font-bold text-white">Enter Soil Telemetry</div>
            <p class="text-[11px] text-slate-400 leading-relaxed">Provide soil test NPK, pH, or map farm boundaries via GPS.</p>
          </div>
          <div class="p-4 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
            <span class="w-6 h-6 rounded-full bg-emerald-950 border border-emerald-700 flex items-center justify-center font-mono font-bold text-xs text-emerald-400">2</span>
            <div class="font-bold text-white">Assess Weather Risk</div>
            <p class="text-[11px] text-slate-400 leading-relaxed">Evaluate 6 hazards: rain, heat, drought, frost, wind, humidity.</p>
          </div>
          <div class="p-4 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
            <span class="w-6 h-6 rounded-full bg-emerald-950 border border-emerald-700 flex items-center justify-center font-mono font-bold text-xs text-emerald-400">3</span>
            <div class="font-bold text-white">Run ML Inference</div>
            <p class="text-[11px] text-slate-400 leading-relaxed">Compute calibrated crop suitability and foliar lesion diagnostics.</p>
          </div>
          <div class="p-4 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
            <span class="w-6 h-6 rounded-full bg-emerald-950 border border-emerald-700 flex items-center justify-center font-mono font-bold text-xs text-emerald-400">4</span>
            <div class="font-bold text-white">Review Margins</div>
            <p class="text-[11px] text-slate-400 leading-relaxed">Examine projected yields, production costs, and net farm profits.</p>
          </div>
          <div class="p-4 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
            <span class="w-6 h-6 rounded-full bg-emerald-950 border border-emerald-700 flex items-center justify-center font-mono font-bold text-xs text-emerald-400">5</span>
            <div class="font-bold text-white">Execute Schedule</div>
            <p class="text-[11px] text-slate-400 leading-relaxed">Follow 5 biological stages: sowing, watering, spray, and Mandi selling.</p>
          </div>
        </div>
      </section>

      <!-- 4. DISCLAIMER & ACADEMIC FOOTER -->
      <section class="pt-6 border-t border-emerald-950/80 text-[11px] text-slate-500 space-y-2">
        <p class="leading-relaxed">
          <strong class="text-slate-400">Academic & Agronomic Disclaimer:</strong> AgroSense is an academic and research agricultural decision intelligence platform designed for national competition demonstration. Agricultural recommendations are based on ICAR and empirical agronomic trial datasets and should be validated with local certified agricultural extension officers (Krishi Vigyan Kendra).
        </p>
        <div class="flex flex-col sm:flex-row items-center justify-between gap-2 pt-2 text-slate-500 font-mono text-[10px]">
          <div>&copy; 2026 AgroSense Platform. Open-source agricultural decision intelligence.</div>
          <div>Calibrated with ICAR, AgMIP, and e-NAM APMC Price Discovery Tables.</div>
        </div>
      </section>
    </div>
  `;
}

/* Module Exports */
exports.renderLandingPage = renderLandingPage;
