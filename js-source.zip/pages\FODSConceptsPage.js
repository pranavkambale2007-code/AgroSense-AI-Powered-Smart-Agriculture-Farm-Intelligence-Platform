// AGROSENSE FODS CONCEPTS & ACADEMIC MAPPING PAGE (/#/fods-concepts)

function renderFODSConceptsPage(state) {
  const concepts = [
    { title: '1. Data Collection & Schema', icon: 'database', desc: 'Structuring multi-variable agricultural datasets containing 2,200 samples across NPK, weather, and crop targets.' },
    { title: '2. Data Cleaning & Preprocessing', icon: 'sparkles', desc: 'Missing value median imputation, duplicate row purging, and 1.5x IQR outlier winsorization.' },
    { title: '3. Summary Statistics', icon: 'calculator', desc: 'Calculating Mean (μ), Standard Deviation (σ), Median, Quartiles (Q1, Q3), and Skewness across continuous variables.' },
    { title: '4. Exploratory Data Analysis (EDA)', icon: 'bar-chart-2', desc: 'Univariate distribution plotting, bivariate scatter relationships, and 8x8 Pearson correlation heatmap matrix ($r_{xy}$).' },
    { title: '5. Data Visualization', icon: 'pie-chart', desc: 'Interactive HTML5 Canvas charts (Radar, Scatter with $R^2=0.88$ trendline, Area price trends, Donut cost distribution).' },
    { title: '6. Feature Engineering & Scaling', icon: 'sliders', desc: 'StandardScaler Z-score transformation ($z = \\frac{x-\\mu}{\\sigma}$) to prevent magnitude dominance.' },
    { title: '7. Machine Learning Classification', icon: 'cpu', desc: 'Training 5 classifiers (Random Forest, SVM RBF, KNN k=5, Decision Tree, Logistic Regression).' },
    { title: '8. Model Evaluation & Benchmarking', icon: 'award', desc: 'Evaluating models using Accuracy, Precision, Recall, F1 Score ($F1 = 2 \\cdot \\frac{P \\cdot R}{P + R}$), and Confusion Matrix.' },
    { title: '9. Explainable AI (XAI)', icon: 'eye', desc: 'Gini Impurity feature importance ranking ($I_G = 1 - \\sum p_i^2$) and decision attribution cards.' },
    { title: '10. Decision Support Systems', icon: 'compass', desc: 'Translating statistical insights into real-world farm decision support for irrigation, fertilizers, and crop rotation.' }
  ];

  return `
    <div class="space-y-8 max-w-7xl mx-auto py-2">
      <!-- Page Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-extrabold text-white tracking-tight">Data Science & Agronomic Algorithmic Architecture</h1>
            <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">MATHEMATICAL ARCHITECTURE</span>
          </div>
          <p class="text-xs text-gray-400 mt-1">Mathematical formulations, statistical preprocessing pipelines, and ensemble machine learning architectures powering the AgroSense engine</p>
        </div>
      </div>

      <!-- Concepts Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        ${concepts.map(c => `
          <div class="glass-card p-6 space-y-3 border-t-4 border-t-emerald-500 hover:border-emerald-400 transition">
            <div class="flex items-center gap-3">
              <div class="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <i data-lucide="${c.icon}" class="w-5 h-5"></i>
              </div>
              <h3 class="text-sm font-bold text-white">${c.title}</h3>
            </div>
            <p class="text-xs text-gray-300">${c.desc}</p>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

/* Module Exports */
exports.renderFODSConceptsPage = renderFODSConceptsPage;
