// AgroSense RAG Knowledge Base Page Component

import { knowledgeDocuments } from '../data/knowledgeBase.js';
import { searchKnowledgeBase } from '../services/ragService.js';

export function renderKnowledgeBasePage(state) {
  const query = state.knowledgeSearchQuery || "";
  const docs = searchKnowledgeBase(query);

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="book-open" class="w-6 h-6 text-emerald-400"></i>
            Verified Agricultural Knowledge Base (RAG Ready)
          </h1>
          <p class="text-xs text-gray-400">Curated research publications from ICAR, State Extension Services & Krishi Vigyan Kendra (KVK)</p>
        </div>
        <span class="prototype-badge">VERIFIED RAG REPOSITORY</span>
      </div>

      <!-- Search Input Bar -->
      <div class="glass-card p-4 flex gap-3">
        <div class="relative flex-1">
          <input id="knowledge-search-input" type="text" value="${query}" placeholder="Search nitrogen management, leaf rust, drip irrigation..." class="w-full bg-gray-900 border border-emerald-700/50 rounded-xl px-4 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400" />
        </div>
        <button id="trigger-knowledge-search-btn" class="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs">
          Search Repository
        </button>
      </div>

      <!-- Document Cards Grid -->
      <div class="space-y-4">
        ${docs.map(doc => `
          <div class="glass-card p-6 space-y-3">
            <div class="flex flex-wrap items-center justify-between gap-2">
              <span class="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                ${doc.category}
              </span>
              <span class="text-[11px] font-mono text-emerald-400 font-bold flex items-center gap-1">
                <i data-lucide="check-circle-2" class="w-3.5 h-3.5"></i> ${doc.status} Source
              </span>
            </div>

            <h3 class="text-base font-bold text-white">${doc.title}</h3>
            <p class="text-xs font-semibold text-amber-300">Published by: ${doc.organization}</p>
            <p class="text-xs text-gray-300 leading-relaxed bg-emerald-950/40 p-3 rounded-xl border border-emerald-950">${doc.content}</p>

            <div class="flex items-center justify-between pt-2 text-xs border-t border-emerald-950/60">
              <div class="flex flex-wrap gap-1">
                ${doc.keywords.map(kw => `
                  <span class="px-2 py-0.5 rounded text-[10px] bg-gray-900 text-gray-400 border border-emerald-950">#${kw}</span>
                `).join('')}
              </div>
              <a href="${doc.url}" target="_blank" class="text-emerald-400 font-semibold hover:underline flex items-center gap-1 text-decoration-none">
                Source Document <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
              </a>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}
