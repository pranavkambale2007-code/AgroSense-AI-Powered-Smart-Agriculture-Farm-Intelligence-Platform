// AgroSense Advanced Farmer Crop Selection Prediction Model
// Integrates multi-variable agronomic machine learning inference based on:
// 1. Farm parameters (size, season, irrigation method, previous crop)
// 2. Soil fertility & contains (NPK, pH, Organic Carbon, Soil Type, Moisture, Fertility Index)
// 3. Rainfall & climate (Rainfall mm, Temperature, Humidity)

import { expanded100Crops } from '../data/expandedCropDatabase.js';

/**
 * Helper to parse numeric range strings like "450 - 650 mm", "6.0 - 7.5", "15°C - 25°C"
 */
function parseRange(str, defaultMin = 0, defaultMax = 100) {
  if (!str) return { min: defaultMin, max: defaultMax, avg: (defaultMin + defaultMax) / 2 };
  const matches = str.match(/(\d+(\.\d+)?)/g);
  if (!matches || matches.length === 0) return { min: defaultMin, max: defaultMax, avg: (defaultMin + defaultMax) / 2 };
  if (matches.length === 1) {
    const val = parseFloat(matches[0]);
    return { min: val * 0.9, max: val * 1.1, avg: val };
  }
  const min = parseFloat(matches[0]);
  const max = parseFloat(matches[1]);
  return { min, max, avg: (min + max) / 2 };
}

/**
 * Helper to parse NPK demand like "120:60:40 kg/ha"
 */
function parseNPK(str) {
  if (!str) return { n: 100, p: 50, k: 40 };
  const parts = str.replace(/[^\d:]/g, '').split(':');
  return {
    n: parseFloat(parts[0]) || 100,
    p: parseFloat(parts[1]) || 50,
    k: parseFloat(parts[2]) || 40
  };
}

/**
 * Predicts the most appropriate crops for a farmer's specific farm profile
 * @param {Object} input
 * @param {Object} input.farm - { acres: 5, state: 'Maharashtra', season: 'Kharif', irrigation: 'Drip', previousCrop: 'Soybean' }
 * @param {Object} input.soil - { type: 'Black Vertisol', fertilityIndex: 75, n: 240, p: 45, k: 180, ph: 7.2, oc: 0.65, moisture: 38 }
 * @param {Object} input.climate - { rainfall: 650, temp: 28, humidity: 65 }
 */
export function predictFarmerCropSelection(input) {
  const farm = input.farm || {};
  const soil = input.soil || {};
  const climate = input.climate || {};

  const acres = Number(farm.acres) || 5;
  const hectares = Number((acres * 0.404686).toFixed(2));
  const season = farm.season || 'Kharif';
  const irrigation = farm.irrigation || 'Rainfed';
  const previousCrop = (farm.previousCrop || '').toLowerCase();

  const soilType = soil.type || 'Black Vertisol';
  const fertilityIndex = Number(soil.fertilityIndex) || 70;
  const soilN = Number(soil.n) || 220; // kg/ha
  const soilP = Number(soil.p) || 40;  // kg/ha
  const soilK = Number(soil.k) || 160; // kg/ha
  const soilPh = Number(soil.ph) || 6.8;
  const soilOC = Number(soil.oc) || 0.6; // Organic Carbon %
  const soilMoisture = Number(soil.moisture) || 35; // %

  const rainfall = Number(climate.rainfall) || 600; // mm
  const temp = Number(climate.temp) || 26; // °C
  const humidity = Number(climate.humidity) || 65; // %

  // Calculate effective water availability based on rainfall + irrigation technology
  let irrigationWaterBonus = 0;
  if (irrigation === 'Drip') irrigationWaterBonus = 350; // equivalent effective water due to high water-use efficiency
  else if (irrigation === 'Sprinkler') irrigationWaterBonus = 250;
  else if (irrigation === 'Canal' || irrigation === 'Well/Flood') irrigationWaterBonus = 500;
  else irrigationWaterBonus = 0; // Rainfed

  const totalEffectiveWater = rainfall + (irrigation === 'Drip' ? 350 : (irrigation === 'Sprinkler' ? 250 : (irrigation === 'Canal' || irrigation === 'Well/Flood' ? 600 : 0)));

  // Evaluate every crop in the database
  const scoredCrops = expanded100Crops.map(crop => {
    const waterRange = parseRange(crop.waterRequirement, 400, 800);
    const phRange = parseRange(crop.idealSoilPh, 6.0, 7.5);
    const tempRange = parseRange(crop.idealTemp, 18, 30);
    const npkDemand = parseNPK(crop.npkDemand);

    // 1. WATER & RAINFALL FIT (Max 30 pts)
    // Precision irrigation deficit-bridging: Drip/Sprinkler bridges deficit without artificially flooding drought-tolerant crops
    let cropEffectiveWater = rainfall;
    if (irrigation === 'Drip') {
      const deficit = Math.max(0, waterRange.min - rainfall);
      cropEffectiveWater = rainfall + Math.min(deficit, 400);
    } else if (irrigation === 'Sprinkler') {
      const deficit = Math.max(0, waterRange.min - rainfall);
      cropEffectiveWater = rainfall + Math.min(deficit, 300);
    } else if (irrigation === 'Canal' || irrigation === 'Well/Flood') {
      cropEffectiveWater = rainfall + 600;
    }

    let waterScore = 0;
    let waterStatus = "Optimal";
    const waterMid = (waterRange.min + waterRange.max) / 2;
    const isRice = crop.name.includes('Rice') || crop.name.includes('Paddy');
    const isCane = crop.name.includes('Sugarcane');
    const isDryland = crop.category.includes('Pulses') || crop.name.includes('Millet') || crop.name.includes('Bajra') || crop.name.includes('Moth') || crop.name.includes('Chickpea');

    if (cropEffectiveWater >= waterRange.min && cropEffectiveWater <= waterRange.max) {
      // Centered peak within optimal range
      const proximity = 1 - Math.abs(cropEffectiveWater - waterMid) / (waterRange.max - waterRange.min || 1);
      waterScore = 26 + Math.max(0, proximity * 4);
      waterStatus = "Ideal water duty match";
    } else if (cropEffectiveWater < waterRange.min) {
      const deficit = waterRange.min - cropEffectiveWater;
      const penalty = (deficit / (waterRange.min || 1)) * 30;
      waterScore = Math.max(2, 26 - penalty);
      waterStatus = deficit > 350 ? "Severe drought / moisture stress risk" : "Moderate moisture deficit";
    } else {
      // Excess water
      if (isRice || isCane) {
        waterScore = 29.5; // Thrives in abundant/standing water
        waterStatus = "Abundant standing water (thrives in flooded/submerged soil)";
      } else {
        const excess = cropEffectiveWater - waterRange.max;
        const penalty = isDryland ? (excess / 200) * 26 : (excess / 550) * 16;
        waterScore = Math.max(2, 26 - penalty);
        waterStatus = isDryland && excess > 120 ? "High waterlogging / root-rot vulnerability" : "Surplus moisture available";
      }
    }

    // 2. SOIL FERTILITY & NUTRIENTS FIT (Max 25 pts)
    const isLegume = crop.category.includes('Pulses') || crop.name.includes('Gram') || crop.name.includes('Soybean') || crop.name.includes('Pea');
    let nScore = 0;
    if (isLegume) {
      // Legumes fix their own nitrogen; they thrive in low to medium N and dislike excessive N
      nScore = soilN <= 250 ? 9.5 : Math.max(5, 9.5 - ((soilN - 250) / 100) * 3);
    } else {
      const nRatio = soilN / (npkDemand.n || 100);
      nScore = Math.min(9.5, Math.max(2.5, nRatio >= 1 ? 9.5 - (nRatio - 1) * 1.5 : nRatio * 9.5));
    }

    const pRatio = soilP / (npkDemand.p || 50);
    const pScore = Math.min(8, Math.max(2, pRatio >= 1 ? 8 : pRatio * 8));

    const kRatio = soilK / (npkDemand.k || 40);
    const kScore = Math.min(7.5, Math.max(2, kRatio >= 1 ? 7.5 : kRatio * 7.5));

    let nutrientScore = nScore + pScore + kScore;
    const fertilityBonus = ((fertilityIndex - 50) / 50) * 3;
    const ocBonus = (soilOC - 0.5) * 2;
    nutrientScore = Math.min(25, Math.max(5, nutrientScore + fertilityBonus + ocBonus));

    // 3. SOIL pH BIOAVAILABILITY FIT (Max 15 pts) - Gaussian curve
    const phDist = Math.abs(soilPh - phRange.avg);
    const phScore = Number((15 * Math.exp(-Math.pow(phDist / 1.1, 2))).toFixed(1));

    // 4. SOIL TYPE & TEXTURE FIT (Max 15 pts)
    let soilTypeScore = 7;
    const cropSoilPref = (crop.soilPreference || '').toLowerCase();
    const currentSoilLower = soilType.toLowerCase();

    if (currentSoilLower.includes('black') && (cropSoilPref.includes('black') || cropSoilPref.includes('vertisol') || cropSoilPref.includes('clay loam'))) {
      soilTypeScore = 15;
    } else if (currentSoilLower.includes('alluvial') && (cropSoilPref.includes('alluvial') || cropSoilPref.includes('loam') || cropSoilPref.includes('silt'))) {
      soilTypeScore = 15;
    } else if (currentSoilLower.includes('red') && (cropSoilPref.includes('red') || cropSoilPref.includes('sandy loam') || cropSoilPref.includes('well-drained'))) {
      soilTypeScore = 15;
    } else if (currentSoilLower.includes('sandy') && (cropSoilPref.includes('sandy') || cropSoilPref.includes('light') || cropSoilPref.includes('well-drained'))) {
      soilTypeScore = 15;
    } else if (currentSoilLower.includes('clay') && cropSoilPref.includes('clay')) {
      soilTypeScore = 15;
    } else if (cropSoilPref.includes(currentSoilLower.split(' ')[0])) {
      soilTypeScore = 13;
    } else {
      soilTypeScore = 6;
    }

    // 5. STRICT SEASON & TEMPERATURE GATING (Max 20 pts)
    let seasonScore = 15;
    const cropSeason = (crop.season || '').toLowerCase();
    const selectedSeasonLower = season.toLowerCase();

    if (cropSeason.includes(selectedSeasonLower)) {
      seasonScore = 20;
    } else if (cropSeason.includes('annual') || cropSeason.includes('perennial')) {
      seasonScore = 16;
    } else if (selectedSeasonLower === 'kharif' && (cropSeason.includes('monsoon') || cropSeason.includes('summer'))) {
      seasonScore = 15;
    } else if (selectedSeasonLower === 'rabi' && cropSeason.includes('winter')) {
      seasonScore = 15;
    } else if (selectedSeasonLower === 'zaid' && (cropSeason.includes('summer') || cropSeason.includes('spring'))) {
      seasonScore = 15;
    } else {
      seasonScore = -40; // STRICT OFF-SEASON PENALTY: Prevents off-season crops from ranking
    }

    // Temperature window alignment
    if (temp >= tempRange.min && temp <= tempRange.max) {
      seasonScore += 2;
    } else {
      const tempDiff = temp < tempRange.min ? tempRange.min - temp : temp - tempRange.max;
      seasonScore = seasonScore - tempDiff * 1.2;
    }

    // Specialty Polyhouse / Protected cultivation check for open-field farming
    let openFieldBonus = 0;
    if (crop.name.toLowerCase().includes('polyhouse')) {
      openFieldBonus = -12; // De-prioritize greenhouse items for standard open-field agriculture
    }

    // 6. CROP ROTATION BENEFIT
    let rotationBonus = 0;
    if (previousCrop && previousCrop !== 'fallow / none') {
      if ((previousCrop.includes('cotton') || previousCrop.includes('sugarcane') || previousCrop.includes('maize') || previousCrop.includes('rice')) && isLegume) {
        rotationBonus = 5; // Restorative legume bonus after exhaustive crop
      } else if (previousCrop.includes(crop.id) || previousCrop.includes(crop.name.toLowerCase().split(' ')[0])) {
        rotationBonus = -8; // Monoculture pest buildup penalty
      }
    }

    // Continuous Raw Score for exact differentiation
    const rawScore = Number((waterScore + nutrientScore + phScore + soilTypeScore + seasonScore + openFieldBonus + rotationBonus).toFixed(2));
    const totalScore = Math.max(15, Math.min(99, Math.round(rawScore)));

    // Calculate Yield Estimation based on fertility & water match
    const yieldRange = parseRange(crop.expectedYield, 25, 45);
    const yieldMultiplier = (totalScore / 100) * (0.82 + (fertilityIndex / 100) * 0.28);
    const estimatedYieldPerHa = Number((yieldRange.avg * yieldMultiplier).toFixed(1));
    const estimatedYieldPerAcre = Number((estimatedYieldPerHa * 0.404686).toFixed(1));
    const totalFarmProductionQtl = Number((estimatedYieldPerAcre * acres).toFixed(1));

    // Financial Projections
    const priceNum = parseFloat((crop.marketPriceAvg || '2200').replace(/[^\d.]/g, '')) || 2200;
    const grossIncomePerAcre = Math.round(estimatedYieldPerAcre * priceNum);
    const estimatedCostPerAcre = Math.round(grossIncomePerAcre * 0.42); // avg cost ratio
    const netProfitPerAcre = grossIncomePerAcre - estimatedCostPerAcre;
    const totalFarmNetProfit = netProfitPerAcre * acres;

    return {
      ...crop,
      rawScore,
      suitabilityScore: totalScore,
      waterScore: Number(waterScore.toFixed(1)),
      nutrientScore: Number(nutrientScore.toFixed(1)),
      phScore: Number(phScore.toFixed(1)),
      soilTypeScore: Number(soilTypeScore.toFixed(1)),
      seasonScore: Number(seasonScore.toFixed(1)),
      waterStatus,
      cropEffectiveWater: Math.round(cropEffectiveWater),
      estimatedYieldPerHa,
      estimatedYieldPerAcre,
      totalFarmProductionQtl,
      grossIncomePerAcre,
      netProfitPerAcre,
      totalFarmNetProfit,
      priceNum,
      npkDemand,
      waterRange,
      phRange,
      tempRange,
      isLegume
    };
  });

  // Sort descending by exact raw floating-point score for crisp differentiation
  scoredCrops.sort((a, b) => b.rawScore - a.rawScore);

  const primaryCrop = scoredCrops[0];
  const alternatives = scoredCrops.slice(1, 4);

  // Identify high-risk / incompatible crops to avoid
  const avoidCrops = scoredCrops
    .filter(c => c.suitabilityScore < 60 || c.waterScore <= 12 || c.seasonScore <= 4)
    .slice(-3)
    .map(c => {
      let reason = "Mismatched agronomic conditions.";
      if (c.waterScore <= 12) {
        reason = totalEffectiveWater < c.waterRange.min 
          ? `High drought risk: requires ${c.waterRequirement} but available water is only ${Math.round(totalEffectiveWater)}mm.`
          : `Excess water vulnerability: crop sensitive to waterlogging under ${Math.round(totalEffectiveWater)}mm water.`;
      } else if (c.seasonScore <= 4) {
        reason = `Season mismatch: ${c.name} is a ${c.season} crop and cannot thrive in ${season}.`;
      } else if (c.phScore <= 6) {
        reason = `Soil pH mismatch: your pH (${soilPh}) falls outside ideal (${c.idealSoilPh}), causing nutrient lockup.`;
      }
      return {
        id: c.id,
        name: c.name,
        category: c.category,
        suitabilityScore: c.suitabilityScore,
        reason
      };
    });

  // Generate Fertilizer & Soil Fertility Prescription based on soil deficits
  const fertilizerPlan = [];
  const nDeficit = primaryCrop.npkDemand.n - soilN;
  const pDeficit = primaryCrop.npkDemand.p - soilP;
  const kDeficit = primaryCrop.npkDemand.k - soilK;

  if (primaryCrop.isLegume) {
    fertilizerPlan.push({
      nutrient: "Nitrogen (N) & Bio-Inoculant",
      action: "Rhizobium Seed Treatment + Starter Dose",
      dosage: "Treat seeds with Rhizobium culture (250g/10kg seed) + 20 kg/ha starter DAP. Crop will biologically fix atmospheric nitrogen.",
      urgency: "Optimal"
    });
  } else if (nDeficit > 20) {
    const ureaDoseKg = Math.round((nDeficit / 0.46) * 0.404686); // converted to kg/acre
    fertilizerPlan.push({
      nutrient: "Nitrogen (N) Deficit",
      action: "Urea Top-Dressing (Split Application)",
      dosage: `Apply ${ureaDoseKg} kg/acre Urea in 2 equal splits: 50% at basal sowing and 50% at vegetative crown root initiation.`,
      urgency: "Critical"
    });
  }

  if (pDeficit > 10) {
    const dapDoseKg = Math.round((pDeficit / 0.46) * 0.404686);
    fertilizerPlan.push({
      nutrient: "Phosphorus (P) Support",
      action: "DAP / Single Super Phosphate (SSP)",
      dosage: `Apply ${dapDoseKg} kg/acre DAP as basal dose in the furrow at 5cm below seed depth for robust root development.`,
      urgency: "Recommended"
    });
  }

  if (kDeficit > 20) {
    const mopDoseKg = Math.round((kDeficit / 0.60) * 0.404686);
    fertilizerPlan.push({
      nutrient: "Potassium (K) Reserve",
      action: "Muriate of Potash (MOP)",
      dosage: `Apply ${mopDoseKg} kg/acre MOP to enhance drought tolerance and cellular disease resistance.`,
      urgency: "Recommended"
    });
  }

  // Organic matter / carbon improvement
  if (soilOC < 0.6) {
    fertilizerPlan.push({
      nutrient: "Soil Organic Carbon (Low: " + soilOC + "%)",
      action: "Farm Yard Manure (FYM) or Vermicompost",
      dosage: "Incorporate 3 - 4 tonnes/acre well-decomposed FYM or 1.5 tonnes vermicompost during land preparation to elevate microbial activity and moisture retention.",
      urgency: "High Priority"
    });
  }

  // pH Soil Amendment
  if (soilPh < 6.0) {
    fertilizerPlan.push({
      nutrient: "Soil Acidity (pH " + soilPh + ")",
      action: "Agricultural Dolomite / Lime",
      dosage: "Broadcast 300 - 400 kg/acre Agricultural Lime 3 weeks before sowing to neutralize acidity and unlock bound phosphorus.",
      urgency: "Corrective"
    });
  } else if (soilPh > 8.0) {
    fertilizerPlan.push({
      nutrient: "Soil Alkalinity / Salinity (pH " + soilPh + ")",
      action: "Agricultural Gypsum & Zinc Sulfate",
      dosage: "Apply 250 kg/acre Gypsum with irrigation water + 10 kg/acre Zinc Sulfate (ZnSO4) to alleviate micronutrient deficiencies.",
      urgency: "Corrective"
    });
  }

  // Explainable AI (XAI) Attribution Breakdown
  const xaiAttribution = [
    {
      factor: "Water & Rainfall Match",
      score: primaryCrop.waterScore,
      max: 30,
      percentage: Math.round((primaryCrop.waterScore / 30) * 100),
      detail: `${rainfall}mm rainfall + ${irrigation} irrigation (${Math.round(totalEffectiveWater)}mm effective water vs ${primaryCrop.waterRequirement} required)`
    },
    {
      factor: "Soil NPK & Fertility Index",
      score: primaryCrop.nutrientScore,
      max: 30,
      percentage: Math.round((primaryCrop.nutrientScore / 30) * 100),
      detail: `Soil Fertility Index: ${fertilityIndex}/100. N:${soilN}, P:${soilP}, K:${soilK} kg/ha (Crop requires ${primaryCrop.npkDemand.n}:${primaryCrop.npkDemand.p}:${primaryCrop.npkDemand.k})`
    },
    {
      factor: "Soil pH Bioavailability",
      score: primaryCrop.phScore,
      max: 15,
      percentage: Math.round((primaryCrop.phScore / 15) * 100),
      detail: `Soil pH ${soilPh} provides optimal bioavailability for ${primaryCrop.idealSoilPh} target window`
    },
    {
      factor: "Soil Texture & Structure",
      score: primaryCrop.soilTypeScore,
      max: 15,
      percentage: Math.round((primaryCrop.soilTypeScore / 15) * 100),
      detail: `${soilType} matches crop preference: "${primaryCrop.soilPreference}"`
    },
    {
      factor: "Season & Thermal Window",
      score: primaryCrop.seasonScore,
      max: 10,
      percentage: Math.round((primaryCrop.seasonScore / 10) * 100),
      detail: `${season} season at ${temp}°C fits crop thermal window (${primaryCrop.idealTemp})`
    }
  ];

  // Reasons Why
  const whyReasons = [
    `High biological compatibility (${primaryCrop.suitabilityScore}%) between your ${soilType} and ${primaryCrop.name}.`,
    `Effective water availability (${Math.round(totalEffectiveWater)}mm) via ${irrigation} aligns with required water duty (${primaryCrop.waterRequirement}).`,
    `Nutrient demand (${primaryCrop.npkDemand.n}:${primaryCrop.npkDemand.p}:${primaryCrop.npkDemand.k}) can be fully met with current soil reserves and targeted top-dressing.`,
    `Projected net profit of ₹${primaryCrop.netProfitPerAcre.toLocaleString('en-IN')}/acre with ₹${primaryCrop.totalFarmNetProfit.toLocaleString('en-IN')} total farm return across ${acres} acres.`
  ];

  if (previousCrop) {
    if (primaryCrop.isLegume && (previousCrop.includes('cotton') || previousCrop.includes('sugarcane'))) {
      whyReasons.push(`Excellent crop rotation choice: fixes nitrogen after exhaustive ${farm.previousCrop} cultivation.`);
    }
  }

  return {
    primaryCrop,
    alternatives,
    rankedCrops: scoredCrops,
    avoidCrops,
    fertilizerPlan,
    xaiAttribution,
    whyReasons,
    inputs: {
      farm: { acres, hectares, season, irrigation, previousCrop: farm.previousCrop || 'None' },
      soil: { soilType, fertilityIndex, soilN, soilP, soilK, soilPh, soilOC, soilMoisture },
      climate: { rainfall, temp, humidity, totalEffectiveWater: Math.round(totalEffectiveWater) }
    }
  };
}

/**
 * Quick 1-click realistic agricultural scenario presets for farmers
 */
export const farmerPresets = {
  activeFarm: {
    label: "🌿 Load My Current Active Farm Profile",
    desc: "Autofill from active farm sensors and telemetry",
    farm: { acres: 5, season: 'Kharif', irrigation: 'Drip', previousCrop: 'Fallow' },
    soil: { type: 'Medium Black Vertisol', fertilityIndex: 78, n: 240, p: 48, k: 190, ph: 7.2, oc: 0.68, moisture: 42 },
    climate: { rainfall: 650, temp: 26, humidity: 68 }
  },
  blackSoilCottonSoybean: {
    label: "🌾 Black Vertisol + Moderate Rainfall (Cotton / Soybean / Wheat)",
    desc: "Deccan / Vidarbha / Malwa region deep clay soil with moderate monsoon",
    farm: { acres: 8, season: 'Kharif', irrigation: 'Rainfed', previousCrop: 'Wheat' },
    soil: { type: 'Deep Black Vertisol', fertilityIndex: 72, n: 210, p: 38, k: 220, ph: 7.6, oc: 0.55, moisture: 36 },
    climate: { rainfall: 750, temp: 29, humidity: 62 }
  },
  alluvialPaddyBasin: {
    label: "🌱 Alluvial Basin + High Rainfall (Paddy / Sugarcane / Jute)",
    desc: "Indo-Gangetic / Delta plains with abundant water availability",
    farm: { acres: 6, season: 'Kharif', irrigation: 'Canal', previousCrop: 'Mustard' },
    soil: { type: 'Fertile Alluvial Loam', fertilityIndex: 84, n: 280, p: 56, k: 180, ph: 6.8, oc: 0.82, moisture: 58 },
    climate: { rainfall: 1350, temp: 31, humidity: 82 }
  },
  drylandRedSoilPulses: {
    label: "🌾 Red Loamy Soil + Low Rainfall / Dryland (Millets / Groundnut / Pulses)",
    desc: "Semi-arid Southern / Western rainfed zones with low water retention",
    farm: { acres: 10, season: 'Kharif', irrigation: 'Rainfed', previousCrop: 'Millets' },
    soil: { type: 'Red Sandy Loam', fertilityIndex: 58, n: 160, p: 28, k: 140, ph: 6.2, oc: 0.42, moisture: 22 },
    climate: { rainfall: 420, temp: 32, humidity: 45 }
  },
  sandyLoamDripVeg: {
    label: "🧪 Sandy Loam + Drip Precision (Vegetables / Spices / Maize)",
    desc: "Intensive commercial horticulture farm with precision fertigation",
    farm: { acres: 3, season: 'Rabi', irrigation: 'Drip', previousCrop: 'Onion' },
    soil: { type: 'Well-Drained Sandy Loam', fertilityIndex: 88, n: 310, p: 65, k: 240, ph: 6.6, oc: 0.95, moisture: 48 },
    climate: { rainfall: 350, temp: 22, humidity: 55 }
  }
};
