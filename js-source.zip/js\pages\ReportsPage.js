// AgroSense Report Generation Page Component

export function renderReportsPage(state) {
  const farm = state.activeFarm;

  const reports = [
    { title: "Comprehensive Farm Health Report", category: "Full Summary", format: "PDF & CSV", date: "2026-09-05", desc: "Includes Soil NPK, Crop Phenology, Weather Risk & Water Status." },
    { title: "Soil Intelligence & NPK Analysis Report", category: "Soil Science", format: "PDF", date: "2026-09-05", desc: "Detailed breakdown of Nitrogen, Phosphorus, Potassium, pH & Organic Carbon." },
    { title: "Explainable Crop Recommendation Report", category: "AI Crop Model", format: "PDF & CSV", date: "2026-09-05", desc: "Top 4 suitability scores with Explainable AI attribution factors." },
    { title: "Plant Disease AI Screening Certificate", category: "Vision Screening", format: "PDF", date: "2026-09-05", desc: "Pathogen identification report with expert agronomist disclaimer." }
  ];

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="file-text" class="w-6 h-6 text-emerald-400"></i>
            Farm Intelligence PDF & CSV Report Generator
          </h1>
          <p class="text-xs text-gray-400">Generate official agricultural reports for ${farm.name} suitable for bank loans, crop insurance & extension officers</p>
        </div>
        <span class="prototype-badge">EXPORT ENGINE</span>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        ${reports.map(r => `
          <div class="glass-card p-6 space-y-4">
            <div class="flex items-center justify-between">
              <span class="px-2.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                ${r.category}
              </span>
              <span class="text-xs font-mono font-bold text-gray-400">${r.format}</span>
            </div>

            <h3 class="text-base font-bold text-white">${r.title}</h3>
            <p class="text-xs text-gray-300">${r.desc}</p>

            <div class="flex items-center justify-between pt-3 border-t border-emerald-950/60">
              <span class="text-[10px] text-gray-500 font-mono">Generated: ${r.date}</span>
              <button class="download-report-btn px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1.5">
                <i data-lucide="download" class="w-3.5 h-3.5"></i> Download PDF
              </button>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}
