// AgroSense 3D Farm Botanical Profiles for all 100+ Crops
// Provides tailored 3D botanical archetype, realistic proportional heightScale, fruit/grain colors and scale

const crop3DProfiles = exports.crop3DProfiles = {
  "c-01": {
    "id": "c-01",
    "name": "Wheat",
    "category": "Cereals & Grains",
    "archetype": "grain_wheat",
    "heightScale": 1,
    "fruitColor": "#f59e0b",
    "hasWaterLayer": false
  },
  "c-02": {
    "id": "c-02",
    "name": "Paddy / Rice",
    "category": "Cereals & Grains",
    "archetype": "paddy",
    "heightScale": 1,
    "fruitColor": "#fde047",
    "hasWaterLayer": true
  },
  "c-03": {
    "id": "c-03",
    "name": "Basmati Rice",
    "category": "Cereals & Grains",
    "archetype": "paddy",
    "heightScale": 1.1,
    "fruitColor": "#86efac",
    "hasWaterLayer": true
  },
  "c-04": {
    "id": "c-04",
    "name": "Maize / Corn",
    "category": "Cereals & Grains",
    "archetype": "tall_stalk",
    "heightScale": 1.5,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "c-05": {
    "id": "c-05",
    "name": "Barley",
    "category": "Cereals & Grains",
    "archetype": "grain_barley",
    "heightScale": 0.95,
    "fruitColor": "#fde047",
    "hasWaterLayer": false
  },
  "c-06": {
    "id": "c-06",
    "name": "Sorghum / Jowar",
    "category": "Cereals & Grains",
    "archetype": "sorghum_jowar",
    "heightScale": 1.65,
    "fruitColor": "#b45309",
    "hasWaterLayer": false
  },
  "c-07": {
    "id": "c-07",
    "name": "Pearl Millet / Bajra",
    "category": "Cereals & Grains",
    "archetype": "millet_spike",
    "heightScale": 1.45,
    "fruitColor": "#cbd5e1",
    "hasWaterLayer": false
  },
  "c-08": {
    "id": "c-08",
    "name": "Finger Millet / Ragi",
    "category": "Cereals & Grains",
    "archetype": "millet_ragi",
    "heightScale": 0.95,
    "fruitColor": "#78350f",
    "hasWaterLayer": false
  },
  "c-09": {
    "id": "c-09",
    "name": "Foxtail Millet",
    "category": "Cereals & Grains",
    "archetype": "millet_spike",
    "heightScale": 1.45,
    "fruitColor": "#cbd5e1",
    "hasWaterLayer": false
  },
  "c-10": {
    "id": "c-10",
    "name": "Kodo Millet",
    "category": "Cereals & Grains",
    "archetype": "millet_spike",
    "heightScale": 1.45,
    "fruitColor": "#cbd5e1",
    "hasWaterLayer": false
  },
  "c-11": {
    "id": "c-11",
    "name": "Little Millet",
    "category": "Cereals & Grains",
    "archetype": "millet_spike",
    "heightScale": 1.45,
    "fruitColor": "#cbd5e1",
    "hasWaterLayer": false
  },
  "c-12": {
    "id": "c-12",
    "name": "Barnyard Millet",
    "category": "Cereals & Grains",
    "archetype": "millet_spike",
    "heightScale": 1.45,
    "fruitColor": "#cbd5e1",
    "hasWaterLayer": false
  },
  "c-13": {
    "id": "c-13",
    "name": "Proso Millet",
    "category": "Cereals & Grains",
    "archetype": "millet_spike",
    "heightScale": 1.45,
    "fruitColor": "#cbd5e1",
    "hasWaterLayer": false
  },
  "c-14": {
    "id": "c-14",
    "name": "Oats",
    "category": "Cereals & Grains",
    "archetype": "oats_panicle",
    "heightScale": 1.05,
    "fruitColor": "#a3e635",
    "hasWaterLayer": false
  },
  "c-15": {
    "id": "c-15",
    "name": "Quinoa",
    "category": "Cereals & Grains",
    "archetype": "millet_spike",
    "heightScale": 1.25,
    "fruitColor": "#be123c",
    "hasWaterLayer": false
  },
  "c-16": {
    "id": "c-16",
    "name": "Amaranth Grain / Rajgira",
    "category": "Cereals & Grains",
    "archetype": "millet_spike",
    "heightScale": 1.25,
    "fruitColor": "#be123c",
    "hasWaterLayer": false
  },
  "c-17": {
    "id": "c-17",
    "name": "Sweet Corn",
    "category": "Cereals & Grains",
    "archetype": "tall_stalk",
    "heightScale": 1.5,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "c-18": {
    "id": "c-18",
    "name": "Baby Corn",
    "category": "Cereals & Grains",
    "archetype": "tall_stalk",
    "heightScale": 1.5,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "p-01": {
    "id": "p-01",
    "name": "Chickpea / Desi Chana",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.72,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "p-02": {
    "id": "p-02",
    "name": "Kabuli Chana / Dollar Gram",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.72,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "p-03": {
    "id": "p-03",
    "name": "Pigeon Pea / Arhar / Tur",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 1.35,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "p-04": {
    "id": "p-04",
    "name": "Green Gram / Mung Bean",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.85,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "p-05": {
    "id": "p-05",
    "name": "Black Gram / Urad Bean",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.85,
    "fruitColor": "#1e293b",
    "hasWaterLayer": false
  },
  "p-06": {
    "id": "p-06",
    "name": "Red Lentil / Masoor",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.85,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "p-07": {
    "id": "p-07",
    "name": "Soybean",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.85,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "p-08": {
    "id": "p-08",
    "name": "Cowpea / Lobia",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.85,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "p-09": {
    "id": "p-09",
    "name": "Field Pea / Matar",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.85,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "p-10": {
    "id": "p-10",
    "name": "Horse Gram",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.85,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "p-11": {
    "id": "p-11",
    "name": "Kidney Bean / Rajma",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.85,
    "fruitColor": "#b91c1c",
    "hasWaterLayer": false
  },
  "p-12": {
    "id": "p-12",
    "name": "Moth Bean",
    "category": "Pulses & Legumes",
    "archetype": "legume_pod",
    "heightScale": 0.85,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "o-01": {
    "id": "o-01",
    "name": "Mustard / Rapeseed",
    "category": "Oilseeds",
    "archetype": "mustard_bloom",
    "heightScale": 1.05,
    "fruitColor": "#fde047",
    "hasWaterLayer": false
  },
  "o-02": {
    "id": "o-02",
    "name": "Groundnut / Peanut",
    "category": "Oilseeds",
    "archetype": "groundnut_runner",
    "heightScale": 0.42,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "o-03": {
    "id": "o-03",
    "name": "Sunflower",
    "category": "Oilseeds",
    "archetype": "sunflower",
    "heightScale": 1.75,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "o-04": {
    "id": "o-04",
    "name": "Sesame / Til",
    "category": "Oilseeds",
    "archetype": "mustard_bloom",
    "heightScale": 1.05,
    "fruitColor": "#ffffff",
    "hasWaterLayer": false
  },
  "o-05": {
    "id": "o-05",
    "name": "Safflower / Kardi",
    "category": "Oilseeds",
    "archetype": "sunflower",
    "heightScale": 1.1,
    "fruitColor": "#ea580c",
    "hasWaterLayer": false
  },
  "o-06": {
    "id": "o-06",
    "name": "Castor Seed",
    "category": "Oilseeds",
    "archetype": "mustard_bloom",
    "heightScale": 1.05,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "o-07": {
    "id": "o-07",
    "name": "Linseed / Flaxseed",
    "category": "Oilseeds",
    "archetype": "mustard_bloom",
    "heightScale": 1.05,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "o-08": {
    "id": "o-08",
    "name": "Niger Seed",
    "category": "Oilseeds",
    "archetype": "mustard_bloom",
    "heightScale": 1.05,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "cash-01": {
    "id": "cash-01",
    "name": "Sugarcane",
    "category": "Commercial & Cash Crops",
    "archetype": "sugarcane",
    "heightScale": 2.05,
    "fruitColor": "#16a34a",
    "hasWaterLayer": false
  },
  "cash-02": {
    "id": "cash-02",
    "name": "Cotton",
    "category": "Commercial & Cash Crops",
    "archetype": "cotton_boll",
    "heightScale": 1.25,
    "fruitColor": "#ffffff",
    "hasWaterLayer": false
  },
  "cash-03": {
    "id": "cash-03",
    "name": "Tea",
    "category": "Commercial & Cash Crops",
    "archetype": "tea_bush",
    "heightScale": 0.85,
    "fruitColor": "#4ade80",
    "hasWaterLayer": false
  },
  "cash-04": {
    "id": "cash-04",
    "name": "Coffee",
    "category": "Commercial & Cash Crops",
    "archetype": "coffee_shrub",
    "heightScale": 1.45,
    "fruitColor": "#dc2626",
    "hasWaterLayer": false
  },
  "cash-05": {
    "id": "cash-05",
    "name": "Coconut",
    "category": "Commercial & Cash Crops",
    "archetype": "palm_coconut",
    "heightScale": 2.65,
    "fruitColor": "#65a30d",
    "hasWaterLayer": false
  },
  "v-01": {
    "id": "v-01",
    "name": "Tomato",
    "category": "Vegetables",
    "archetype": "fruiting_bush",
    "heightScale": 0.95,
    "fruitColor": "#ef4444",
    "hasWaterLayer": false
  },
  "v-02": {
    "id": "v-02",
    "name": "Potato",
    "category": "Vegetables",
    "archetype": "potato_crop",
    "heightScale": 0.65,
    "fruitColor": "#a16207",
    "hasWaterLayer": false
  },
  "v-03": {
    "id": "v-03",
    "name": "Onion",
    "category": "Vegetables",
    "archetype": "onion_garlic",
    "heightScale": 0.52,
    "fruitColor": "#f8fafc",
    "hasWaterLayer": false
  },
  "v-04": {
    "id": "v-04",
    "name": "Garlic",
    "category": "Vegetables",
    "archetype": "garlic_crop",
    "heightScale": 0.52,
    "fruitColor": "#f8fafc",
    "hasWaterLayer": false
  },
  "v-05": {
    "id": "v-05",
    "name": "Brinjal / Eggplant",
    "category": "Vegetables",
    "archetype": "brinjal_eggplant",
    "heightScale": 1.05,
    "fruitColor": "#581c87",
    "hasWaterLayer": false
  },
  "v-06": {
    "id": "v-06",
    "name": "Okra / Ladyfinger",
    "category": "Vegetables",
    "archetype": "okra_stalk",
    "heightScale": 1.4,
    "fruitColor": "#16a34a",
    "hasWaterLayer": false
  },
  "v-07": {
    "id": "v-07",
    "name": "Green Chilli",
    "category": "Vegetables",
    "archetype": "chilli_pepper",
    "heightScale": 0.88,
    "fruitColor": "#dc2626",
    "hasWaterLayer": false
  },
  "s-01": {
    "id": "s-01",
    "name": "Turmeric",
    "category": "Spices & Condiments",
    "archetype": "ginger_turmeric",
    "heightScale": 0.9,
    "fruitColor": "#eab308",
    "hasWaterLayer": false
  },
  "s-02": {
    "id": "s-02",
    "name": "Ginger",
    "category": "Spices & Condiments",
    "archetype": "ginger_rhizome",
    "heightScale": 0.85,
    "fruitColor": "#ca8a04",
    "hasWaterLayer": false
  },
  "s-03": {
    "id": "s-03",
    "name": "Cumin / Jeera",
    "category": "Spices & Condiments",
    "archetype": "mustard_bloom",
    "heightScale": 1.05,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "s-04": {
    "id": "s-04",
    "name": "Coriander / Dhaniya",
    "category": "Spices & Condiments",
    "archetype": "coriander_herb",
    "heightScale": 0.42,
    "fruitColor": "#22c55e",
    "hasWaterLayer": false
  },
  "s-05": {
    "id": "s-05",
    "name": "Black Pepper",
    "category": "Spices & Condiments",
    "archetype": "black_pepper",
    "heightScale": 1.45,
    "fruitColor": "#15803d",
    "hasWaterLayer": false
  },
  "s-06": {
    "id": "s-06",
    "name": "Small Cardamom",
    "category": "Spices & Condiments",
    "archetype": "cardamom_clump",
    "heightScale": 1.35,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "m-01": {
    "id": "m-01",
    "name": "Ashwagandha",
    "category": "Medicinal & Aromatic",
    "archetype": "ashwagandha_shrub",
    "heightScale": 0.90,
    "fruitColor": "#ea580c",
    "hasWaterLayer": false
  },
  "m-02": {
    "id": "m-02",
    "name": "Tulsi / Holy Basil",
    "category": "Medicinal & Aromatic",
    "archetype": "tulsi_plant",
    "heightScale": 0.80,
    "fruitColor": "#a855f7",
    "hasWaterLayer": false
  },
  "m-03": {
    "id": "m-03",
    "name": "Lemongrass",
    "category": "Medicinal & Aromatic",
    "archetype": "lemongrass_tuft",
    "heightScale": 1.15,
    "fruitColor": "#22c55e",
    "hasWaterLayer": false
  },
  "c-spec-77": {
    "id": "c-spec-77",
    "name": "Watermelon",
    "category": "Vegetables",
    "archetype": "curcurbit_vine",
    "heightScale": 0.38,
    "fruitColor": "#15803d",
    "hasWaterLayer": false
  },
  "c-spec-78": {
    "id": "c-spec-78",
    "name": "Muskmelon",
    "category": "Vegetables",
    "archetype": "curcurbit_vine",
    "heightScale": 0.38,
    "fruitColor": "#f59e0b",
    "hasWaterLayer": false
  },
  "c-spec-79": {
    "id": "c-spec-79",
    "name": "Bottle Gourd / Lauki",
    "category": "Vegetables",
    "archetype": "curcurbit_vine",
    "heightScale": 0.42,
    "fruitColor": "#86efac",
    "hasWaterLayer": false
  },
  "c-spec-80": {
    "id": "c-spec-80",
    "name": "Bitter Gourd / Karela",
    "category": "Vegetables",
    "archetype": "curcurbit_vine",
    "heightScale": 0.42,
    "fruitColor": "#16a34a",
    "hasWaterLayer": false
  },
  "c-spec-81": {
    "id": "c-spec-81",
    "name": "Ridge Gourd / Turai",
    "category": "Vegetables",
    "archetype": "curcurbit_vine",
    "heightScale": 0.42,
    "fruitColor": "#16a34a",
    "hasWaterLayer": false
  },
  "c-spec-82": {
    "id": "c-spec-82",
    "name": "Cucumber",
    "category": "Vegetables",
    "archetype": "curcurbit_vine",
    "heightScale": 0.42,
    "fruitColor": "#16a34a",
    "hasWaterLayer": false
  },
  "c-spec-83": {
    "id": "c-spec-83",
    "name": "Spinach / Palak",
    "category": "Vegetables",
    "archetype": "leafy_greens",
    "heightScale": 0.38,
    "fruitColor": "#16a34a",
    "hasWaterLayer": false
  },
  "c-spec-84": {
    "id": "c-spec-84",
    "name": "Fenugreek Leaves / Methi",
    "category": "Vegetables",
    "archetype": "fenugreek_herb",
    "heightScale": 0.36,
    "fruitColor": "#15803d",
    "hasWaterLayer": false
  },
  "c-spec-85": {
    "id": "c-spec-85",
    "name": "Carrot",
    "category": "Vegetables",
    "archetype": "carrot_radish",
    "heightScale": 0.55,
    "fruitColor": "#ea580c",
    "hasWaterLayer": false
  },
  "c-spec-86": {
    "id": "c-spec-86",
    "name": "Radish / Mooli",
    "category": "Vegetables",
    "archetype": "radish_crop",
    "heightScale": 0.55,
    "fruitColor": "#f8fafc",
    "hasWaterLayer": false
  },
  "c-spec-87": {
    "id": "c-spec-87",
    "name": "Beetroot",
    "category": "Vegetables",
    "archetype": "carrot_radish",
    "heightScale": 0.52,
    "fruitColor": "#881337",
    "hasWaterLayer": false
  },
  "c-spec-88": {
    "id": "c-spec-88",
    "name": "Sweet Potato",
    "category": "Vegetables",
    "archetype": "curcurbit_vine",
    "heightScale": 0.45,
    "fruitColor": "#ea580c",
    "hasWaterLayer": false
  },
  "c-spec-89": {
    "id": "c-spec-89",
    "name": "Cassava / Tapioca",
    "category": "Vegetables",
    "archetype": "fruiting_bush",
    "heightScale": 0.95,
    "fruitColor": "#22c55e",
    "hasWaterLayer": false
  },
  "c-spec-90": {
    "id": "c-spec-90",
    "name": "Elephant Foot Yam",
    "category": "Vegetables",
    "archetype": "fruiting_bush",
    "heightScale": 0.95,
    "fruitColor": "#22c55e",
    "hasWaterLayer": false
  },
  "c-spec-91": {
    "id": "c-spec-91",
    "name": "Drumstick / Moringa",
    "category": "Vegetables",
    "archetype": "moringa_drumstick",
    "heightScale": 1.65,
    "fruitColor": "#65a30d",
    "hasWaterLayer": false
  },
  "c-spec-92": {
    "id": "c-spec-92",
    "name": "Nutmeg & Mace",
    "category": "Spices & Condiments",
    "archetype": "orchard_tree",
    "heightScale": 1.7,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "c-spec-93": {
    "id": "c-spec-93",
    "name": "Clove",
    "category": "Spices & Condiments",
    "archetype": "orchard_tree",
    "heightScale": 1.7,
    "fruitColor": "#84cc16",
    "hasWaterLayer": false
  },
  "c-spec-94": {
    "id": "c-spec-94",
    "name": "Cinnamon",
    "category": "Spices & Condiments",
    "archetype": "orchard_tree",
    "heightScale": 1.7,
    "fruitColor": "#92400e",
    "hasWaterLayer": false
  },
  "c-spec-95": {
    "id": "c-spec-95",
    "name": "Fenugreek Seeds / Methi",
    "category": "Spices & Condiments",
    "archetype": "leafy_greens",
    "heightScale": 0.38,
    "fruitColor": "#ca8a04",
    "hasWaterLayer": false
  },
  "c-spec-96": {
    "id": "c-spec-96",
    "name": "Ajwain / Carom Seeds",
    "category": "Spices & Condiments",
    "archetype": "mustard_bloom",
    "heightScale": 1.05,
    "fruitColor": "#ffffff",
    "hasWaterLayer": false
  },
  "c-spec-97": {
    "id": "c-spec-97",
    "name": "Kalonji / Black Cumin",
    "category": "Spices & Condiments",
    "archetype": "mustard_bloom",
    "heightScale": 1.05,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "c-spec-98": {
    "id": "c-spec-98",
    "name": "Aloe Vera",
    "category": "Medicinal & Aromatic",
    "archetype": "succulent_aloe",
    "heightScale": 0.46,
    "fruitColor": "#10b981",
    "hasWaterLayer": false
  },
  "c-spec-99": {
    "id": "c-spec-99",
    "name": "Stevia Sweet Herb",
    "category": "Medicinal & Aromatic",
    "archetype": "leafy_greens",
    "heightScale": 0.52,
    "fruitColor": "#22c55e",
    "hasWaterLayer": false
  },
  "c-spec-100": {
    "id": "c-spec-100",
    "name": "Isabgol / Psyllium Husk",
    "category": "Medicinal & Aromatic",
    "archetype": "millet_spike",
    "heightScale": 0.65,
    "fruitColor": "#fde047",
    "hasWaterLayer": false
  },
  "c-spec-101": {
    "id": "c-spec-101",
    "name": "Senna / Sonamukhi",
    "category": "Medicinal & Aromatic",
    "archetype": "ashwagandha_shrub",
    "heightScale": 0.95,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "c-spec-108": {
    "id": "c-spec-108",
    "name": "Areca Palm",
    "category": "Commercial & Cash Crops",
    "archetype": "palm_areca",
    "heightScale": 2.35,
    "fruitColor": "#ea580c",
    "hasWaterLayer": false
  },
  "c-spec-119": {
    "id": "c-spec-119",
    "name": "Marigold",
    "category": "Floriculture",
    "archetype": "marigold_flower",
    "heightScale": 0.95,
    "fruitColor": "#f97316",
    "hasWaterLayer": false
  },
  "c-spec-120": {
    "id": "c-spec-120",
    "name": "Cauliflower",
    "category": "Vegetables",
    "archetype": "cauliflower_crop",
    "heightScale": 0.55,
    "fruitColor": "#f8fafc",
    "hasWaterLayer": false
  },
  "banana": {
    "id": "banana",
    "name": "Banana",
    "category": "Plantation & Commercial Crops",
    "archetype": "banana_plant",
    "heightScale": 1.75,
    "fruitColor": "#fde047",
    "hasWaterLayer": false
  },
  "c-banana": {
    "id": "c-banana",
    "name": "Banana",
    "category": "Plantation & Commercial Crops",
    "archetype": "banana_plant",
    "heightScale": 1.75,
    "fruitColor": "#fde047",
    "hasWaterLayer": false
  },
  "rose": {
    "id": "rose",
    "name": "Rose",
    "category": "Floriculture & Commercial Flowers",
    "archetype": "flower_ornamental",
    "heightScale": 0.85,
    "fruitColor": "#f43f5e",
    "hasWaterLayer": false
  },
  "c-rose": {
    "id": "c-rose",
    "name": "Rose",
    "category": "Floriculture & Commercial Flowers",
    "archetype": "flower_ornamental",
    "heightScale": 0.85,
    "fruitColor": "#f43f5e",
    "hasWaterLayer": false
  },
  "wheat": {
    "id": "wheat",
    "name": "Wheat",
    "category": "Cereals & Grains",
    "archetype": "grain_wheat",
    "heightScale": 1.0,
    "fruitColor": "#f59e0b",
    "hasWaterLayer": false
  },
  "rice": {
    "id": "rice",
    "name": "Paddy / Rice",
    "category": "Cereals & Grains",
    "archetype": "paddy",
    "heightScale": 1.0,
    "fruitColor": "#84cc16",
    "hasWaterLayer": true
  },
  "maize": {
    "id": "maize",
    "name": "Maize / Corn",
    "category": "Cereals & Grains",
    "archetype": "tall_stalk",
    "heightScale": 1.5,
    "fruitColor": "#facc15",
    "hasWaterLayer": false
  },
  "cotton": {
    "id": "cotton",
    "name": "Cotton",
    "category": "Commercial & Cash Crops",
    "archetype": "cotton_boll",
    "heightScale": 1.15,
    "fruitColor": "#ffffff",
    "hasWaterLayer": false
  },
  "tomato": {
    "id": "tomato",
    "name": "Tomato",
    "category": "Vegetables",
    "archetype": "fruiting_bush",
    "heightScale": 0.95,
    "fruitColor": "#ef4444",
    "hasWaterLayer": false
  },
  "potato": {
    "id": "potato",
    "name": "Potato",
    "category": "Vegetables",
    "archetype": "potato_crop",
    "heightScale": 0.75,
    "fruitColor": "#eab308",
    "hasWaterLayer": false
  },
  "chilli": {
    "id": "chilli",
    "name": "Green Chilli",
    "category": "Vegetables",
    "archetype": "chilli_pepper",
    "heightScale": 0.85,
    "fruitColor": "#dc2626",
    "hasWaterLayer": false
  }
};

function getCrop3DProfile(cropIdOrName = '') {
  if (!cropIdOrName) return crop3DProfiles['c-04'] || crop3DProfiles['c-01'];
  if (crop3DProfiles[cropIdOrName]) return crop3DProfiles[cropIdOrName];
  const q = String(cropIdOrName).toLowerCase().trim();
  if (crop3DProfiles[q]) return crop3DProfiles[q];

  // Explicit botanical keyword mappings (eliminates silent wheat fallthrough!)
  if (q.includes('banana') || q.includes('केला')) return crop3DProfiles['banana'];
  if (q.includes('rose') || q.includes('गुलाब')) return crop3DProfiles['rose'];
  if (q.includes('wheat') || q.includes('गेहूं') || q.includes('गहू')) return crop3DProfiles['wheat'];
  if (q.includes('rice') || q.includes('paddy') || q.includes('धान') || q.includes('भात')) return crop3DProfiles['rice'];
  if (q.includes('maize') || q.includes('corn') || q.includes('मक्का') || q.includes('मका')) return crop3DProfiles['maize'];
  if (q.includes('cotton') || q.includes('कपास')) return crop3DProfiles['cotton'];
  if (q.includes('tomato') || q.includes('टमाटर')) return crop3DProfiles['tomato'];
  if (q.includes('potato') || q.includes('आलू') || q.includes('बटाटा')) return crop3DProfiles['potato'];
  if (q.includes('chilli') || q.includes('pepper') || q.includes('मिर्च')) return crop3DProfiles['chilli'];

  for (const id in crop3DProfiles) {
    const p = crop3DProfiles[id];
    if (p.archetype === q) return p;
    if (p.name.toLowerCase() === q || p.name.toLowerCase().includes(q) || q.includes(p.name.toLowerCase().split(' ')[0])) {
      return p;
    }
  }

  // Fallback: Return explicit unsupported profile, NEVER silently substitute wheat!
  return {
    id: q,
    name: cropIdOrName,
    isUnsupported: true,
    category: "Unsupported Species",
    archetype: "unsupported_crop",
    heightScale: 1.0,
    fruitColor: "#f59e0b",
    hasWaterLayer: false
  };
}

const archetypeConfigs = exports.archetypeConfigs = {
  sugarcane: {
    numRows: 5, plantsPerRow: 16, rowStartY: 0.50, rowSpacing: 22,
    baseHeight: 92, fruitScale: 1.0, foliageScale: 1.6, stagger: false,
    realWorldHeight: "3.0 – 4.5 m (Towering Jointed Culm)",
    botanicalName: "Saccharum officinarum",
    botanicalFamily: "Poaceae (Gramineae)",
    stemTexture: "Solid jointed purple-golden culms, swollen node rings with root primordia, powdery white waxy bloom band, stilt brace roots",
    foliageTexture: "Linear-lanceolate arching ribbon blades, sharp serrated margins, ivory-white central midrib",
    reproductiveStructure: "Silvery-white silky plumose arrow inflorescence (panicle)",
    realPhotoUrl: "images/healthy_crops/sugarcane_healthy.jpg"
  },
  banana_plant: {
    numRows: 4, plantsPerRow: 8, rowStartY: 0.50, rowSpacing: 30,
    baseHeight: 88, fruitScale: 2.2, foliageScale: 2.4, stagger: true,
    realWorldHeight: "2.8 – 4.5 m (Giant Herb Pseudostem)",
    botanicalName: "Musa acuminata",
    botanicalFamily: "Musaceae",
    stemTexture: "Overlapping concentric fibrous leaf sheaths, dried papery brown basal scales, rhizome suckers",
    foliageTexture: "Massive paddle-shaped oblong blades up to 3m long, pinnate-parallel venation with natural wind tears/slits",
    reproductiveStructure: "Pendulous hanging bunch of curved bananas with dark perianth tips and deep royal-purple terminal flower heart",
    realPhotoUrl: "images/healthy_crops/banana_healthy.jpg"
  },
  tall_stalk: {
    numRows: 5, plantsPerRow: 16, rowStartY: 0.51, rowSpacing: 22,
    baseHeight: 78, fruitScale: 1.8, foliageScale: 1.6, stagger: true,
    realWorldHeight: "2.0 – 3.2 m (Sturdy Single Culm)",
    botanicalName: "Zea mays",
    botanicalFamily: "Poaceae",
    stemTexture: "Cylindrical segmented culm with swollen node rings, fibrous adventitious prop/brace roots anchoring into furrow",
    foliageTexture: "Broad distichous strap leaves with undulating wavy margins and pale ivory central midrib",
    reproductiveStructure: "Axillary husked ear with streaming red-brown silks; apical branched staminate tassel shedding golden pollen",
    realPhotoUrl: "images/healthy_crops/maize_healthy.jpg"
  },
  sorghum_jowar: {
    numRows: 5, plantsPerRow: 16, rowStartY: 0.51, rowSpacing: 22,
    baseHeight: 82, fruitScale: 1.6, foliageScale: 1.5, stagger: true,
    realWorldHeight: "2.4 – 3.8 m (Erect Robust Culm)",
    botanicalName: "Sorghum bicolor",
    botanicalFamily: "Poaceae",
    stemTexture: "Solid pithy culm with waxy bloom coating, nodal rings, lower brace roots",
    foliageTexture: "Long alternate waxy leaves with white midrib and rolled margins",
    reproductiveStructure: "Dense terminal compact panicle packed with reddish-brown to creamy-white grain spikelets",
    realPhotoUrl: "images/healthy_crops/jowar_healthy.jpg"
  },
  sunflower: {
    numRows: 5, plantsPerRow: 12, rowStartY: 0.51, rowSpacing: 24,
    baseHeight: 78, fruitScale: 2.5, foliageScale: 1.7, stagger: true,
    realWorldHeight: "2.0 – 3.2 m (Rough Bristly Stalk)",
    botanicalName: "Helianthus annuus",
    botanicalFamily: "Asteraceae (Compositae)",
    stemTexture: "Thick erect hispid stalk covered with stiff coarse white trichome bristles",
    foliageTexture: "Large alternate cordate (heart-shaped) leaves with coarsely serrated margins and reticulate venation",
    reproductiveStructure: "Large saucer-shaped capitulum with bright golden ray florets and spiral Fibonacci disc florets facing the sun",
    realPhotoUrl: "images/healthy_crops/sunflower_healthy.jpg"
  },
  cotton_boll: {
    numRows: 5, plantsPerRow: 12, rowStartY: 0.52, rowSpacing: 24,
    baseHeight: 60, fruitScale: 2.6, foliageScale: 1.8, stagger: true,
    realWorldHeight: "1.2 – 1.8 m (Woody Shrub with Sympodial Branches)",
    botanicalName: "Gossypium hirsutum",
    botanicalFamily: "Malvaceae",
    stemTexture: "Monopodial main woody stem with zig-zag sympodial lateral fruiting branches and red petiole pigmentation",
    foliageTexture: "3-5 lobed palmate leaves with radiating veins, heliotropic tracking",
    reproductiveStructure: "Creamy-yellow cup blossoms; 4-5 locular fluffy white cotton bolls popping from dried reflexed brown burrs (calyx)",
    realPhotoUrl: "images/healthy_crops/cotton_healthy.jpg"
  },
  okra_stalk: {
    numRows: 5, plantsPerRow: 14, rowStartY: 0.52, rowSpacing: 24,
    baseHeight: 62, fruitScale: 2.2, foliageScale: 1.5, stagger: true,
    realWorldHeight: "1.2 – 1.8 m (Semi-Woody Hispid Stalk)",
    botanicalName: "Abelmoschus esculentus",
    botanicalFamily: "Malvaceae",
    stemTexture: "Sturdy hispid green stalk with fine bristles, reddish-purple node rings and petiole joints",
    foliageTexture: "Deeply cleft 3-5 palmate lobed leaves with coarse serrated borders and palmate primary veins",
    reproductiveStructure: "Creamy-yellow hibiscus flowers with deep maroon center throat; upward-pointing 5-ribbed beaked pods with velvety hairs",
    realPhotoUrl: "images/healthy_crops/okra_healthy.jpg"
  },
  mustard_bloom: {
    numRows: 6, plantsPerRow: 16, rowStartY: 0.51, rowSpacing: 20,
    baseHeight: 56, fruitScale: 1.8, foliageScale: 1.4, stagger: true,
    realWorldHeight: "1.1 – 1.8 m (Branched Slender Stems)",
    botanicalName: "Brassica juncea",
    botanicalFamily: "Brassicaceae",
    stemTexture: "Slender glaucous branched green stems with thin epidermis",
    foliageTexture: "Lower lyrate-pinnatifid leaves, upper lanceolate sessile leaves with waxy bloom",
    reproductiveStructure: "Vibrant bright golden-yellow 4-petaled cruciform flowers, upright slender cylindrical silique seed pods",
    realPhotoUrl: "images/healthy_crops/mustard_healthy.jpg"
  },
  grain_wheat: {
    numRows: 7, plantsPerRow: 24, rowStartY: 0.51, rowSpacing: 18,
    baseHeight: 46, fruitScale: 1.5, foliageScale: 1.2, stagger: false,
    realWorldHeight: "0.8 – 1.1 m (Tiller Clump & Flag Leaves)",
    botanicalName: "Triticum aestivum",
    botanicalFamily: "Poaceae",
    stemTexture: "Hollow culm tillers with solid swollen node rings",
    foliageTexture: "Linear flag leaves with parallel venation, auricles and ligules",
    reproductiveStructure: "Erect golden-amber spikes with 2-ranked overlapping spikelets, glumes, and long bristly awns (beards)",
    realPhotoUrl: "images/healthy_crops/wheat_healthy.jpg"
  },
  paddy: {
    numRows: 7, plantsPerRow: 24, rowStartY: 0.51, rowSpacing: 18,
    baseHeight: 45, fruitScale: 1.5, foliageScale: 1.2, stagger: false,
    realWorldHeight: "0.8 – 1.2 m (Submerged Crown in Water)",
    botanicalName: "Oryza sativa",
    botanicalFamily: "Poaceae",
    stemTexture: "Semi-aquatic culm with spongy aerenchyma tissue, tillers emerging from submerged basal nodes",
    foliageTexture: "Slender flat blades with parallel venation, prominent ligules and auricles",
    reproductiveStructure: "Terminal gracefully nodding arched panicles bearing golden-yellow spikelets with fine awns",
    realPhotoUrl: "images/healthy_crops/rice_healthy.jpg"
  },
  chilli_pepper: {
    numRows: 5, plantsPerRow: 13, rowStartY: 0.52, rowSpacing: 22,
    baseHeight: 44, fruitScale: 2.2, foliageScale: 1.5, stagger: true,
    realWorldHeight: "0.6 – 1.0 m (Dichotomous Bush)",
    botanicalName: "Capsicum annuum",
    botanicalFamily: "Solanaceae",
    stemTexture: "Green-purple dichotomously Y-forked branching stems with angular ribs and swollen nodes",
    foliageTexture: "Alternate glossy dark green lanceolate to ovate leaves with herringbone venation",
    reproductiveStructure: "Solitary white 5-star flowers with purple anthers; drooping glossy tapered green and crimson-red berries with 5-toothed calyx caps",
    realPhotoUrl: "images/healthy_crops/chilli_healthy.jpg"
  },
  potato_crop: {
    numRows: 5, plantsPerRow: 14, rowStartY: 0.52, rowSpacing: 22,
    baseHeight: 36, fruitScale: 2.0, foliageScale: 1.5, stagger: true,
    realWorldHeight: "0.45 – 0.7 m (Winged Stems & Subterranean Tubers)",
    botanicalName: "Solanum tuberosum",
    botanicalFamily: "Solanaceae",
    stemTexture: "Herbaceous angular winged green-purple stems, subterranean hooked stolons bearing tubers",
    foliageTexture: "Imparipinnate compound leaves (paired ovate lateral leaflets + large apical leaflet + tiny intercalary micro-leaflets)",
    reproductiveStructure: "Delicate apical star-shaped white/violet flowers with bright yellow cone anthers; subterranean russet tubers with eye buds",
    realPhotoUrl: "images/healthy_crops/potato_healthy.jpg"
  },
  groundnut_runner: {
    numRows: 5, plantsPerRow: 14, rowStartY: 0.53, rowSpacing: 22,
    baseHeight: 24, fruitScale: 2.0, foliageScale: 1.5, stagger: true,
    realWorldHeight: "0.25 – 0.45 m (Prostrate Runner Stems)",
    botanicalName: "Arachis hypogaea",
    botanicalFamily: "Fabaceae",
    stemTexture: "Prostrate trailing green runner stems hugging the soil furrow, hairy nodes",
    foliageTexture: "Pinnately compound tetrafoliate leaves with 4 rounded obovate leaflets in opposite pairs (no terminal leaflet)",
    reproductiveStructure: "Yellow papilionaceous pea flowers; geotropic pegs elongating downwards into soil to form reticulated peanut pods underground",
    realPhotoUrl: "images/healthy_crops/groundnut_healthy.jpg"
  },
  onion_garlic: {
    numRows: 6, plantsPerRow: 18, rowStartY: 0.52, rowSpacing: 18,
    baseHeight: 32, fruitScale: 2.0, foliageScale: 1.3, stagger: false,
    realWorldHeight: "0.35 – 0.55 m (Papery Tunic Bulb & Scapes)",
    botanicalName: "Allium cepa",
    botanicalFamily: "Amaryllidaceae",
    stemTexture: "Compressed basal stem disc with dense fibrous white roots; erect hollow cylindrical floral scape",
    foliageTexture: "Erect tubular fistulose blue-green leaves with glaucous waxy bloom",
    reproductiveStructure: "Half-exposed swollen golden-brown tunic bulb with striations; spherical globose flowering umbel with white star florets",
    realPhotoUrl: "images/healthy_crops/onion_healthy.jpg"
  },
  legume_pod: {
    numRows: 6, plantsPerRow: 16, rowStartY: 0.52, rowSpacing: 20,
    baseHeight: 42, fruitScale: 1.8, foliageScale: 1.4, stagger: true,
    realWorldHeight: "0.5 – 0.9 m (Bushy Pubescent Legume)",
    botanicalName: "Glycine max / Cajanus cajan",
    botanicalFamily: "Fabaceae",
    stemTexture: "Tawny-pubescent erect branching stems covered in fine golden hairs",
    foliageTexture: "Trifoliate compound leaves with 3 ovate leaflets and distinct petiolules, velvet texture",
    reproductiveStructure: "Small axillary papilionaceous pea flowers; dense clusters of fuzzy hairy green and golden 2-3 seeded legume pods",
    realPhotoUrl: "images/healthy_crops/soybean_healthy.jpg"
  },
  cabbage_brassica: {
    numRows: 5, plantsPerRow: 12, rowStartY: 0.53, rowSpacing: 24,
    baseHeight: 28, fruitScale: 2.5, foliageScale: 2.2, stagger: true,
    realWorldHeight: "0.25 – 0.4 m (Dense Savoyed Head)",
    botanicalName: "Brassica oleracea",
    botanicalFamily: "Brassicaceae",
    stemTexture: "Short thick central stem core resting close to the ground",
    foliageTexture: "Spreading outer wavy wrapper leaves with radiating white venation and waxy bloom",
    reproductiveStructure: "Tightly cupped spherical head of crisp layered leaves with savoyed folds",
    realPhotoUrl: "images/healthy_crops/cabbage_healthy.jpg"
  },
  curcurbit_vine: {
    numRows: 4, plantsPerRow: 7, rowStartY: 0.53, rowSpacing: 32,
    baseHeight: 22, fruitScale: 3.6, foliageScale: 2.0, stagger: true,
    realWorldHeight: "0.2 – 0.35 m (Ground Creeping Runner)",
    botanicalName: "Citrullus lanatus / Cucurbita",
    botanicalFamily: "Cucurbitaceae",
    stemTexture: "Long sprawling furrow runner stems with bifurcated climbing tendrils and hairy ribs",
    foliageTexture: "Deeply pinnatifid 3-5 lobed scabrous leaves with rough surfaces",
    reproductiveStructure: "Yellow 5-petaled campanulate flowers; massive oval green-and-white striped melons resting on furrow soil",
    realPhotoUrl: "images/healthy_crops/watermelon_healthy.jpg"
  },
  brinjal_eggplant: {
    numRows: 5, plantsPerRow: 11, rowStartY: 0.52, rowSpacing: 24,
    baseHeight: 52, fruitScale: 2.6, foliageScale: 1.7, stagger: true,
    realWorldHeight: "0.7 – 1.2 m (Subshrub with Purple Cast)",
    botanicalName: "Solanum melongena",
    botanicalFamily: "Solanaceae",
    stemTexture: "Semi-woody purple-tinged branching stem with fine stellate hairs",
    foliageTexture: "Large velvety ovate-oblong leaves with sinuate margins and purple primary veins",
    reproductiveStructure: "Violet 5-star blossoms with yellow staminal cone; glossy deep royal-purple pear-shaped fruit with spiny green calyx cap",
    realPhotoUrl: "images/healthy_crops/brinjal_healthy.jpg"
  },
  fruiting_bush: {
    numRows: 5, plantsPerRow: 11, rowStartY: 0.52, rowSpacing: 24,
    baseHeight: 52, fruitScale: 2.5, foliageScale: 1.7, stagger: true,
    realWorldHeight: "1.2 – 1.8 m (Staked Trellised Bush)",
    botanicalName: "Solanum lycopersicum",
    botanicalFamily: "Solanaceae",
    stemTexture: "Indeterminate zig-zag stems supported by sturdy bamboo stakes and jute twine",
    foliageTexture: "Glandular-pubescent pinnately divided leaves with dentate leaflets and pungent herbal scent",
    reproductiveStructure: "Trusses of bright yellow star blossoms; hanging clusters of green, orange breaker, and scarlet ripe beefsteak tomatoes",
    realPhotoUrl: "images/healthy_crops/tomato_healthy.jpg"
  },
  carrot_radish: {
    numRows: 6, plantsPerRow: 18, rowStartY: 0.52, rowSpacing: 18,
    baseHeight: 32, fruitScale: 2.2, foliageScale: 1.4, stagger: false,
    realWorldHeight: "0.3 – 0.5 m (Lace Frills & Conical Taproot)",
    botanicalName: "Daucus carota / Raphanus sativus",
    botanicalFamily: "Apiaceae / Brassicaceae",
    stemTexture: "Short subterranean crown collar resting on the soil surface",
    foliageTexture: "Dense basal rosette of feathery tripinnate lace frills with delicate ribbed petioles",
    reproductiveStructure: "Protruding conical taproot with horizontal lenticel rings and fine feeder roots",
    realPhotoUrl: "images/healthy_crops/carrot_healthy.jpg"
  },
  millet_spike: {
    numRows: 6, plantsPerRow: 18, rowStartY: 0.51, rowSpacing: 20,
    baseHeight: 72, fruitScale: 1.8, foliageScale: 1.4, stagger: true,
    realWorldHeight: "1.8 – 2.8 m (Slender Tall Culm)",
    botanicalName: "Pennisetum glaucum",
    botanicalFamily: "Poaceae",
    stemTexture: "Solid slender green culm with hairy nodes and tillers",
    foliageTexture: "Long linear leaves with serrulate margins and prominent midrib",
    reproductiveStructure: "Dense erect cylindrical cattail-like spike packed with grey-amber grain involucres and stiff bristles",
    realPhotoUrl: "images/healthy_crops/bajra_healthy.jpg"
  },
  grain_barley: {
    numRows: 7, plantsPerRow: 22, rowStartY: 0.51, rowSpacing: 18,
    baseHeight: 46, fruitScale: 1.6, foliageScale: 1.2, stagger: false,
    realWorldHeight: "0.8 – 1.1 m (Golden Head with Silky Awns)",
    botanicalName: "Hordeum vulgare",
    botanicalFamily: "Poaceae",
    stemTexture: "Erect hollow culm with smooth nodes",
    foliageTexture: "Alternate flat linear leaves with clasping auricles",
    reproductiveStructure: "Compact 2-ranked or 6-ranked golden head with extremely long, fine, silky awns extending skyward",
    realPhotoUrl: "images/healthy_crops/barley_healthy.jpg"
  },
  oats_panicle: {
    numRows: 7, plantsPerRow: 22, rowStartY: 0.51, rowSpacing: 18,
    baseHeight: 48, fruitScale: 1.5, foliageScale: 1.2, stagger: false,
    realWorldHeight: "0.9 – 1.2 m (Open Spreading Panicle)",
    botanicalName: "Avena sativa",
    botanicalFamily: "Poaceae",
    stemTexture: "Smooth culm with distinct nodes",
    foliageTexture: "Rough linear-lanceolate leaves with blue-green bloom and prominent ligules",
    reproductiveStructure: "Loose, open, pyramidal panicle with gracefully drooping pendulous spikelets",
    realPhotoUrl: "images/healthy_crops/oats_healthy.jpg"
  },
  millet_ragi: {
    numRows: 6, plantsPerRow: 18, rowStartY: 0.52, rowSpacing: 18,
    baseHeight: 42, fruitScale: 1.6, foliageScale: 1.3, stagger: true,
    realWorldHeight: "0.7 – 1.0 m (Digitate Bird-Foot Spikes)",
    botanicalName: "Eleusine coracana",
    botanicalFamily: "Poaceae",
    stemTexture: "Tillered culm with compressed leaf sheaths",
    foliageTexture: "Linear leaves with folded v-shaped cross-section",
    reproductiveStructure: "Terminal cluster of 4-6 finger-like curved spikes arranged like a bird's foot packed with red-brown grains",
    realPhotoUrl: "images/healthy_crops/ragi_healthy.jpg"
  },
  ginger_turmeric: {
    numRows: 5, plantsPerRow: 13, rowStartY: 0.52, rowSpacing: 22,
    baseHeight: 40, fruitScale: 1.6, foliageScale: 1.6, stagger: true,
    realWorldHeight: "0.6 – 1.0 m (Distichous Pseudostem & Rhizome)",
    botanicalName: "Zingiber officinale / Curcuma longa",
    botanicalFamily: "Zingiberaceae",
    stemTexture: "Erect annual pseudostem formed by rolled leaf sheaths; subterranean knobby rhizome knuckles with annuli rings",
    foliageTexture: "Alternating distichous glossy lanceolate leaves with parallel-pinnate venation",
    reproductiveStructure: "Cone-like terminal flower spike with layered green and pastel-pink bracts",
    realPhotoUrl: "images/healthy_crops/turmeric_healthy.jpg"
  },
  palm_coconut: {
    numRows: 4, plantsPerRow: 7, rowStartY: 0.49, rowSpacing: 34,
    baseHeight: 120, fruitScale: 2.4, foliageScale: 2.6, stagger: true,
    realWorldHeight: "15.0 – 25.0 m (Tall Columnar Palm)",
    botanicalName: "Cocos nucifera",
    botanicalFamily: "Arecaceae",
    stemTexture: "Single grey ring-scarred columnar trunk with swollen flared base and fibrous root mass",
    foliageTexture: "Graceful crown of 25-30 pinnate feather fronds 4-6m long with stiff leaflets",
    reproductiveStructure: "Axillary spadix inflorescence with dense clusters of large green and brown coconuts",
    realPhotoUrl: "images/healthy_crops/coconut_healthy.jpg"
  },
  palm_areca: {
    numRows: 4, plantsPerRow: 8, rowStartY: 0.50, rowSpacing: 32,
    baseHeight: 105, fruitScale: 1.8, foliageScale: 2.2, stagger: true,
    realWorldHeight: "12.0 – 20.0 m (Slender Ringed Palm)",
    botanicalName: "Areca catechu",
    botanicalFamily: "Arecaceae",
    stemTexture: "Slender erect green-grey trunk with prominent circular white ring scars",
    foliageTexture: "Compact crown of arching pinnate fronds with crowded linear leaflets",
    reproductiveStructure: "Branched inflorescence hanging below crown shaft bearing dense clusters of orange-red ovoid betel nuts",
    realPhotoUrl: "images/healthy_crops/arecanut_healthy.jpg"
  },
  coffee_shrub: {
    numRows: 5, plantsPerRow: 9, rowStartY: 0.51, rowSpacing: 26,
    baseHeight: 65, fruitScale: 1.8, foliageScale: 2.0, stagger: true,
    realWorldHeight: "1.5 – 2.5 m (Glossy Evergreen Shrub)",
    botanicalName: "Coffea arabica",
    botanicalFamily: "Rubiaceae",
    stemTexture: "Woody main trunk with horizontal opposite lateral branches",
    foliageTexture: "Opposite dark glossy emerald-green elliptic leaves with undulate margins and sunken veins",
    reproductiveStructure: "Fragrant white star flowers; axillary clusters of crimson-red coffee cherries",
    realPhotoUrl: "images/healthy_crops/coffee_healthy.jpg"
  },
  tea_bush: {
    numRows: 5, plantsPerRow: 11, rowStartY: 0.52, rowSpacing: 22,
    baseHeight: 38, fruitScale: 1.0, foliageScale: 2.4, stagger: true,
    realWorldHeight: "0.6 – 1.0 m (Pruned Plucking Table)",
    botanicalName: "Camellia sinensis",
    botanicalFamily: "Theaceae",
    stemTexture: "Dense woody branched bush pruned to a continuous horizontal plucking table",
    foliageTexture: "Alternate glossy dark green elliptic leaves with serrated margins; tender light-green two-leaves-and-a-bud apical shoots",
    reproductiveStructure: "Small white nodding flowers with prominent yellow stamens",
    realPhotoUrl: "images/healthy_crops/tea_healthy.jpg"
  },
  moringa_drumstick: {
    numRows: 4, plantsPerRow: 7, rowStartY: 0.49, rowSpacing: 34,
    baseHeight: 88, fruitScale: 2.4, foliageScale: 2.4, stagger: true,
    realWorldHeight: "4.0 – 8.0 m (Slender Tree with Hanging Pods)",
    botanicalName: "Moringa oleifera",
    botanicalFamily: "Moringaceae",
    stemTexture: "Soft corky whitish-grey bark with drooping branches",
    foliageTexture: "Tripinnate feathery compound leaves with tiny elliptic leaflets",
    reproductiveStructure: "Fragrant yellowish-white flowers; long pendulous 30-50cm triangular grooved green drumstick pods",
    realPhotoUrl: "images/healthy_crops/drumstick_healthy.jpg"
  },
  succulent_aloe: {
    numRows: 5, plantsPerRow: 12, rowStartY: 0.53, rowSpacing: 24,
    baseHeight: 30, fruitScale: 1.5, foliageScale: 2.0, stagger: true,
    realWorldHeight: "0.4 – 0.7 m (Spiky Rosette)",
    botanicalName: "Aloe vera",
    botanicalFamily: "Asphodelaceae",
    stemTexture: "Acaulescent or short-stemmed succulent",
    foliageTexture: "Dense rosette of thick fleshy lanceolate green leaves with white spots and spiny marginal teeth",
    reproductiveStructure: "Tall central flower spike bearing tubular yellow-orange blossoms",
    realPhotoUrl: "images/healthy_crops/aloe_healthy.jpg"
  },
  lemongrass_tuft: {
    numRows: 5, plantsPerRow: 14, rowStartY: 0.52, rowSpacing: 22,
    baseHeight: 50, fruitScale: 1.2, foliageScale: 2.0, stagger: true,
    realWorldHeight: "1.0 – 1.5 m (Dense Aromatic Tussock)",
    botanicalName: "Cymbopogon citratus",
    botanicalFamily: "Poaceae",
    stemTexture: "Dense clump of swollen pseudostems at soil level with fibrous roots",
    foliageTexture: "Dense fountain of long arching aromatic ribbon leaves with rough edges and citrus fragrance",
    reproductiveStructure: "Terminal open panicle (rarely flowering in cultivation)",
    realPhotoUrl: "images/healthy_crops/lemongrass_healthy.jpg"
  },
  leafy_greens: {
    numRows: 6, plantsPerRow: 18, rowStartY: 0.52, rowSpacing: 18,
    baseHeight: 26, fruitScale: 1.4, foliageScale: 1.8, stagger: false,
    realWorldHeight: "0.2 – 0.35 m (Crisp Succulent Greens)",
    botanicalName: "Spinacia oleracea / Trigonella",
    botanicalFamily: "Amaranthaceae / Fabaceae",
    stemTexture: "Tender succulent annual stems branching near ground level",
    foliageTexture: "Crisp emerald-green tender leaves with delicate venation and high chlorophyll saturation",
    reproductiveStructure: "Small axillary florets",
    realPhotoUrl: "images/healthy_crops/spinach_healthy.jpg"
  },
  orchard_tree: {
    numRows: 4, plantsPerRow: 6, rowStartY: 0.49, rowSpacing: 35,
    baseHeight: 90, fruitScale: 2.0, foliageScale: 2.5, stagger: true,
    realWorldHeight: "3.5 – 6.0 m (Commercial Plantation Canopy)",
    botanicalName: "Commercial Plantation Tree (Nutmeg, Clove, Cinnamon)",
    botanicalFamily: "Plantae",
    stemTexture: "Rough fissured dark brown woody bark trunk with scaffold branches",
    foliageTexture: "Dense dome-shaped canopy of glossy dark green leaves with aromatic oils",
    reproductiveStructure: "Aromatic floral buds and spice capsules",
    realPhotoUrl: "images/healthy_crops/tea_healthy.jpg"
  },
  flower_ornamental: {
    numRows: 5, plantsPerRow: 13, rowStartY: 0.52, rowSpacing: 22,
    baseHeight: 46, fruitScale: 2.2, foliageScale: 1.6, stagger: true,
    realWorldHeight: "0.6 – 1.0 m (Flowering Open Field)",
    botanicalName: "Tagetes erecta / Flora",
    botanicalFamily: "Asteraceae",
    stemTexture: "Erect herbaceous branching floral stems",
    foliageTexture: "Pinnate deep green foliage supporting prominent blossoms",
    reproductiveStructure: "Radiant multi-petaled blossoms with vibrant floral pigmentation",
    realPhotoUrl: "images/healthy_crops/marigold_healthy.jpg"
  },
  black_pepper: {
    numRows: 4, plantsPerRow: 8, rowStartY: 0.50, rowSpacing: 30,
    baseHeight: 70, fruitScale: 2.0, foliageScale: 2.2, stagger: true,
    realWorldHeight: "2.5 – 4.0 m (Climbing Vine on Living Support)",
    botanicalName: "Piper nigrum",
    botanicalFamily: "Piperaceae",
    stemTexture: "Woody perennial climber clinging to living shade tree trunk standards with aerial adventitious rootlets",
    foliageTexture: "Alternate broad glossy leathery cordate-ovate leaves with 5-7 prominent palmate nerves",
    reproductiveStructure: "Hanging pendulous catkin spikes bearing 20-30 tightly clustered round green, yellow, and red peppercorns",
    realPhotoUrl: "images/healthy_crops/blackpepper_healthy.jpg"
  },
  cardamom_clump: {
    numRows: 5, plantsPerRow: 10, rowStartY: 0.51, rowSpacing: 26,
    baseHeight: 65, fruitScale: 1.8, foliageScale: 2.2, stagger: true,
    realWorldHeight: "2.0 – 3.5 m (Lush Rainforest Clump)",
    botanicalName: "Elettaria cardamomum",
    botanicalFamily: "Zingiberaceae",
    stemTexture: "Dense clump of tall leafy pseudostems rising from subterranean rhizomes",
    foliageTexture: "Long lanceolate dark green leaves with silk-like sheen and pungent cardamom fragrance",
    reproductiveStructure: "Horizontal prostrate floral panicles creeping along the forest soil mulch bearing 3-sided green oval seed capsules",
    realPhotoUrl: "images/healthy_crops/cardamom_healthy.jpg"
  },
  marigold_flower: {
    numRows: 5, plantsPerRow: 14, rowStartY: 0.52, rowSpacing: 22,
    baseHeight: 46, fruitScale: 2.4, foliageScale: 1.6, stagger: true,
    realWorldHeight: "0.6 – 1.0 m (Bushy Pom-Pom Blossoms)",
    botanicalName: "Tagetes erecta",
    botanicalFamily: "Asteraceae",
    stemTexture: "Erect ribbed branching aromatic stems with glandular dots",
    foliageTexture: "Deeply pinnatisect fern-like aromatic dark green leaves with serrated leaflets",
    reproductiveStructure: "Huge dense globular ruffled pom-pom flower heads with vibrant golden-yellow and fiery orange ray florets",
    realPhotoUrl: "images/healthy_crops/marigold_healthy.jpg"
  },
  cauliflower_crop: {
    numRows: 5, plantsPerRow: 12, rowStartY: 0.53, rowSpacing: 24,
    baseHeight: 30, fruitScale: 2.6, foliageScale: 2.2, stagger: true,
    realWorldHeight: "0.3 – 0.45 m (Pure White Curd in Glaucous Wrapper)",
    botanicalName: "Brassica oleracea var. botrytis",
    botanicalFamily: "Brassicaceae",
    stemTexture: "Short stout fleshy stem resting on furrow bed",
    foliageTexture: "Erect oblong glaucous blue-green wrapper leaves with thick ivory midrib shielding the center",
    reproductiveStructure: "Dense, firm, dome-shaped crisp creamy-white floretted curd (hypertrophied pre-floral meristem)",
    realPhotoUrl: "images/healthy_crops/cauliflower_healthy.jpg"
  },
  garlic_crop: {
    numRows: 6, plantsPerRow: 18, rowStartY: 0.52, rowSpacing: 18,
    baseHeight: 32, fruitScale: 2.0, foliageScale: 1.3, stagger: false,
    realWorldHeight: "0.35 – 0.5 m (Segmented Clove Bulb & Flat Scapes)",
    botanicalName: "Allium sativum",
    botanicalFamily: "Amaryllidaceae",
    stemTexture: "Basal subterranean stem plate with fibrous white roots; solid unbranched scape",
    foliageTexture: "Flat linear keeled blue-green leaves folded lengthwise with pungent sulfurous aroma",
    reproductiveStructure: "Swollen subterranean composite bulb with 10-15 white papery cloves surrounding central core",
    realPhotoUrl: "images/healthy_crops/garlic_healthy.jpg"
  },
  radish_crop: {
    numRows: 6, plantsPerRow: 18, rowStartY: 0.52, rowSpacing: 18,
    baseHeight: 32, fruitScale: 2.2, foliageScale: 1.4, stagger: false,
    realWorldHeight: "0.3 – 0.5 m (Cylindrical White Taproot)",
    botanicalName: "Raphanus sativus",
    botanicalFamily: "Brassicaceae",
    stemTexture: "Short crown collar protruding from topsoil",
    foliageTexture: "Lyrate-pinnatifid basal rosette with rough hispid surface and crisp ribbed petioles",
    reproductiveStructure: "Protruding crisp elongated cylindrical white taproot with translucent skin and horizontal rootlets",
    realPhotoUrl: "images/healthy_crops/radish_healthy.jpg"
  },
  ginger_rhizome: {
    numRows: 5, plantsPerRow: 13, rowStartY: 0.52, rowSpacing: 22,
    baseHeight: 40, fruitScale: 1.6, foliageScale: 1.6, stagger: true,
    realWorldHeight: "0.6 – 0.9 m (Aromatic Multi-Fingered Rhizome)",
    botanicalName: "Zingiber officinale",
    botanicalFamily: "Zingiberaceae",
    stemTexture: "Erect annual pseudostem formed by tightly rolled sheaths; fleshy palmate subterranean rhizome fingers with circular rings",
    foliageTexture: "Distichous narrow linear-lanceolate grass-like glossy leaves with parallel-pinnate venation",
    reproductiveStructure: "Compact cone-like spike of green and yellow bracts",
    realPhotoUrl: "images/healthy_crops/ginger_healthy.jpg"
  },
  coriander_herb: {
    numRows: 6, plantsPerRow: 18, rowStartY: 0.52, rowSpacing: 18,
    baseHeight: 28, fruitScale: 1.4, foliageScale: 1.6, stagger: false,
    realWorldHeight: "0.25 – 0.45 m (Delicate Lace Herb)",
    botanicalName: "Coriandrum sativum",
    botanicalFamily: "Apiaceae",
    stemTexture: "Slender erect glabrous green stems branching delicately",
    foliageTexture: "Lower broad lobed fan leaves, upper finely dissected feathery lace leaves with aromatic essential oils",
    reproductiveStructure: "Compound umbels of small white and pale pink florets followed by spherical aromatic seeds",
    realPhotoUrl: "images/healthy_crops/coriander_healthy.jpg"
  },
  fenugreek_herb: {
    numRows: 6, plantsPerRow: 18, rowStartY: 0.52, rowSpacing: 18,
    baseHeight: 26, fruitScale: 1.4, foliageScale: 1.6, stagger: false,
    realWorldHeight: "0.25 – 0.45 m (Trifoliate Obovate Greens)",
    botanicalName: "Trigonella foenum-graecum",
    botanicalFamily: "Fabaceae",
    stemTexture: "Erect slender hollow stems branching from base",
    foliageTexture: "Distinct trifoliate leaves with 3 toothed obovate leaflets and characteristic herbal aroma",
    reproductiveStructure: "Yellowish-white axillary flowers; slender curved beaked seed pods",
    realPhotoUrl: "images/healthy_crops/fenugreek_healthy.jpg"
  },
  tulsi_plant: {
    numRows: 6, plantsPerRow: 16, rowStartY: 0.52, rowSpacing: 20,
    baseHeight: 38, fruitScale: 1.5, foliageScale: 1.5, stagger: true,
    realWorldHeight: "0.4 – 0.75 m (Aromatic Bush & Inflorescence Spikes)",
    botanicalName: "Ocimum tenuiflorum / Ocimum sanctum",
    botanicalFamily: "Lamiaceae",
    stemTexture: "Erect purple-green quadrangular stems branching profusely from base, covered with fine soft puberulent hairs",
    foliageTexture: "Opposite decussate aromatic ovate-elliptic leaves with serrated margins, gland dots releasing potent eugenol fragrance",
    reproductiveStructure: "Erect terminal racemes / verticillasters with whorls of small tubular purple and pink blossoms swaying gently",
    realPhotoUrl: "images/healthy_crops/tulsi_healthy.jpg"
  },
  ashwagandha_shrub: {
    numRows: 5, plantsPerRow: 13, rowStartY: 0.52, rowSpacing: 22,
    baseHeight: 46, fruitScale: 1.8, foliageScale: 1.6, stagger: true,
    realWorldHeight: "0.6 – 1.2 m (Ayurvedic Shrub & Papery Calyx Lanterns)",
    botanicalName: "Withania somnifera",
    botanicalFamily: "Solanaceae",
    stemTexture: "Erect woody tomentose branched stems with star-shaped stellate hairs and light ash-grey bark",
    foliageTexture: "Dull olive-green alternate elliptic-ovate leaves with fine velvety pubescence and distinct lateral veins",
    reproductiveStructure: "Axillary clusters of bell-shaped greenish-yellow flowers; inflated papery calyx lanterns enclosing bright orange-red berries",
    realPhotoUrl: "images/healthy_crops/ashwagandha_healthy.jpg"
  }
};

/* Module Exports */
exports.getCrop3DProfile = getCrop3DProfile;
