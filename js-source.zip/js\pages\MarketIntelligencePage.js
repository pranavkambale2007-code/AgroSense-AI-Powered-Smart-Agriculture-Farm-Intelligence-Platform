// AgroSense APMC Mandi Market Intelligence Page Component with Area Chart

import { getMandiPrices } from '../services/marketService.js';
import { drawAreaChart } from '../components/AnalyticsCharts.js';

export function renderMarketIntelligencePage(state) {
  const prices = getMandiPrices();

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="line-chart" class="w-6 h-6 text-emerald-400"></i>
            APMC Mandi Market Intelligence & Price Trends
          </h1>
          <p class="text-xs text-gray-400">Real-time APMC agricultural commodity prices across Maharashtra, Punjab, Gujarat & Karnataka</p>
        </div>
        <span class="prototype-badge">PROTOTYPE MARKET DATA</span>
      </div>

      <!-- Price Trend Summary Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        ${prices.slice(0, 3).map(p => `
          <div class="glass-card p-5 space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-gray-400">${p.market}</span>
              <span class="text-xs font-bold font-mono ${p.trend.startsWith('+') ? 'text-emerald-400' : 'text-red-400'}">${p.trend}</span>
            </div>
            <h3 class="text-lg font-bold text-white">${p.crop}</h3>
            <div class="text-2xl font-extrabold text-emerald-300 font-mono">₹${p.modalPrice.toLocaleString()} <span class="text-xs text-gray-400 font-normal">/ Qtl</span></div>
            <p class="text-[11px] text-gray-400">Min: ₹${p.minPrice} | Max: ₹${p.maxPrice}</p>
          </div>
        `).join('')}
      </div>

      <!-- DATA SCIENCE AREA CHART CARD: 90-DAY PRICE TREND -->
      <div class="glass-card p-6 space-y-3">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <i data-lucide="trending-up" class="w-5 h-5 text-emerald-400"></i>
            <h3 class="text-sm font-bold text-white">90-Day APMC Mandi Price Trend Area Chart (Wheat HD-2967)</h3>
          </div>
          <span class="text-[10px] text-gray-400 font-mono">Shaded Volatility Band</span>
        </div>
        <div class="h-56 w-full relative">
          <canvas id="market-area-chart" class="w-full h-full"></canvas>
        </div>
      </div>

      <!-- Price Table -->
      <div class="glass-card p-6 overflow-x-auto">
        <h3 class="text-sm font-bold text-white mb-4">Current APMC Mandi Price Ledger</h3>
        <table class="w-full text-left border-collapse text-xs">
          <thead>
            <tr class="border-b border-emerald-800/60 text-gray-400">
              <th class="p-3">Crop Name</th>
              <th class="p-3">APMC Mandi</th>
              <th class="p-3">State</th>
              <th class="p-3 font-mono text-right">Min Price</th>
              <th class="p-3 font-mono text-right">Max Price</th>
              <th class="p-3 font-mono text-right">Modal Price</th>
              <th class="p-3 text-right">Trend</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-emerald-950/60">
            ${prices.map(item => `
              <tr class="hover:bg-emerald-950/30">
                <td class="p-3 font-bold text-white">${item.crop}</td>
                <td class="p-3 text-gray-300">${item.market}</td>
                <td class="p-3 text-gray-400">${item.state}</td>
                <td class="p-3 font-mono text-right text-gray-300">₹${item.minPrice}</td>
                <td class="p-3 font-mono text-right text-gray-300">₹${item.maxPrice}</td>
                <td class="p-3 font-mono text-right text-emerald-400 font-bold">₹${item.modalPrice}</td>
                <td class="p-3 font-mono text-right font-bold ${item.trend.startsWith('+') ? 'text-emerald-400' : 'text-amber-400'}">${item.trend}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

export function initMarketHooks() {
  const dates = ['Jun 01', 'Jun 15', 'Jul 01', 'Jul 15', 'Aug 01', 'Aug 15', 'Sep 01', 'Sep 05'];
  const prices = [1950, 2010, 2080, 2120, 2190, 2220, 2250, 2275];

  drawAreaChart('market-area-chart', dates, prices);
}
