// AgroSense AI Weather Risk Detection & Early Warning Command Center
// Multi-hazard AI predictive scoring, spray window advisory, and interactive what-if microclimate simulator

import { evaluateAdvancedWeatherRisks } from '../services/weatherService.js';
import { renderGenericXAIExplanationCard } from '../components/XAIExplanationCard.js';

export function renderWeatherRiskPage(state) {
  const farm = state.activeFarm || {
    farmName: "Registered Farm Plot",
    currentCrop: "Wheat (HD-2967)"
  };

  const weather = state.weatherData || null;
  const selectedCrop = state.weatherRiskSelectedCrop || 'wheat';
  const simulation = state.weatherRiskSimulation || null;

  // Evaluate AI risks
  const assessment = evaluateAdvancedWeatherRisks(weather, selectedCrop, 'vegetative', simulation);
  const tel = assessment.currentTelemetry;

  const cropOptions = [
    { key: 'wheat', name: 'Wheat', icon: '🌾' },
    { key: 'tomato', name: 'Tomato', icon: '🍅' },
    { key: 'chilli', name: 'Chilli', icon: '🌶️' },
    { key: 'maize', name: 'Maize', icon: '🌽' },
    { key: 'potato', name: 'Potato', icon: '🥔' },
    { key: 'rice', name: 'Paddy / Rice', icon: '🌾' },
    { key: 'cotton', name: 'Cotton', icon: '☁️' },
    { key: 'groundnut', name: 'Groundnut / Soybean', icon: '🥜' }
  ];

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2 printable-weather-risk-report">
      <!-- Title Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2.5">
            <i data-lucide="shield-alert" class="w-7 h-7 text-amber-400"></i>
            <span>AI Weather Risk Detection & Early Warning Engine</span>
          </h1>
          <p class="text-xs text-gray-300 mt-1">
            Predictive meteorological risk detection for Heavy Rain, Heatwave, Spore Inoculum, Cold Wave, High Wind & Hailstorm
          </p>
        </div>

        <div class="flex flex-wrap items-center gap-2.5">
          <button id="btn-broadcast-weather-warning" type="button" class="px-3.5 py-1.5 rounded-xl bg-amber-900/60 hover:bg-amber-800 text-amber-200 border border-amber-500/40 text-xs font-bold font-mono transition flex items-center gap-1.5 cursor-pointer shadow">
            <i data-lucide="volume-2" class="w-4 h-4 text-amber-300"></i>
            <span>Broadcast Audio Advisory</span>
          </button>
          <a href="#/ai-assistant" class="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-400/40 text-xs font-bold font-mono transition flex items-center gap-1.5 cursor-pointer shadow">
            <i data-lucide="bot" class="w-4 h-4"></i>
            <span>Consult AI Copilot</span>
          </a>
          <button id="btn-print-weather-risk" type="button" class="px-3 py-1.5 rounded-xl bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 text-xs font-mono transition flex items-center gap-1.5 cursor-pointer">
            <i data-lucide="printer" class="w-4 h-4"></i>
            <span>Print Report</span>
          </button>
          <span class="prototype-badge text-[11px] font-mono">AI RISK MATRIX V2.5</span>
        </div>
      </div>

      <!-- Real-Time Microclimate Telemetry Ribbon -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div class="p-3.5 rounded-2xl bg-black/40 border border-emerald-900/50 space-y-1">
          <div class="flex items-center justify-between text-xs text-gray-400 font-mono">
            <span>Ambient Temp</span>
            <i data-lucide="thermometer" class="w-3.5 h-3.5 text-amber-400"></i>
          </div>
          <div class="text-xl font-black text-white font-mono">${tel.temp}°C</div>
          <div class="text-[10px] text-gray-400">Forecast Max: ${tel.maxTemp}°C</div>
        </div>

        <div class="p-3.5 rounded-2xl bg-black/40 border border-emerald-900/50 space-y-1">
          <div class="flex items-center justify-between text-xs text-gray-400 font-mono">
            <span>Air Humidity</span>
            <i data-lucide="droplet" class="w-3.5 h-3.5 text-blue-400"></i>
          </div>
          <div class="text-xl font-black text-white font-mono">${tel.humidity}%</div>
          <div class="text-[10px] ${tel.humidity > 70 ? 'text-amber-400 font-bold' : 'text-gray-400'}">
            ${tel.humidity > 70 ? 'High Foliar Wetness' : 'Nominal Range'}
          </div>
        </div>

        <div class="p-3.5 rounded-2xl bg-black/40 border border-emerald-900/50 space-y-1">
          <div class="flex items-center justify-between text-xs text-gray-400 font-mono">
            <span>Wind Velocity</span>
            <i data-lucide="wind" class="w-3.5 h-3.5 text-teal-400"></i>
          </div>
          <div class="text-xl font-black text-white font-mono">${tel.windSpeed} <span class="text-xs">km/h</span></div>
          <div class="text-[10px] ${tel.windSpeed > 15 ? 'text-red-400 font-bold' : 'text-emerald-400'}">
            ${tel.windSpeed > 15 ? 'Drift Hazard' : 'Gentle Breeze'}
          </div>
        </div>

        <div class="p-3.5 rounded-2xl bg-black/40 border border-emerald-900/50 space-y-1">
          <div class="flex items-center justify-between text-xs text-gray-400 font-mono">
            <span>Rain Probability</span>
            <i data-lucide="cloud-rain" class="w-3.5 h-3.5 text-blue-300"></i>
          </div>
          <div class="text-xl font-black text-white font-mono">${tel.maxRainProb}%</div>
          <div class="text-[10px] text-gray-400">Est. Volume: ${tel.maxRainSum} mm</div>
        </div>

        <div class="p-3.5 rounded-2xl bg-black/40 border border-emerald-900/50 space-y-1">
          <div class="flex items-center justify-between text-xs text-gray-400 font-mono">
            <span>Spore Index</span>
            <i data-lucide="biohazard" class="w-3.5 h-3.5 text-purple-400"></i>
          </div>
          <div class="text-xl font-black text-white font-mono">${tel.sporeIndex}</div>
          <div class="text-[10px] ${tel.sporeIndex > 0.5 ? 'text-red-400 font-bold' : 'text-gray-400'}">
            ${tel.sporeIndex > 0.5 ? 'Active Pathogen Risk' : 'Low Spore Growth'}
          </div>
        </div>

        <div class="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-700/60 space-y-1">
          <div class="flex items-center justify-between text-xs text-emerald-300 font-mono font-bold">
            <span>AI Risk Index</span>
            <i data-lucide="gauge" class="w-3.5 h-3.5 text-emerald-400"></i>
          </div>
          <div class="text-xl font-black font-mono ${assessment.compositeColor === 'red' ? 'text-red-400' : assessment.compositeColor === 'orange' ? 'text-orange-400' : assessment.compositeColor === 'amber' ? 'text-amber-400' : 'text-emerald-400'}">
            ${assessment.compositeRiskScore}/100
          </div>
          <div class="text-[10px] font-bold font-mono uppercase ${assessment.compositeColor === 'red' ? 'text-red-300' : assessment.compositeColor === 'orange' ? 'text-orange-300' : assessment.compositeColor === 'amber' ? 'text-amber-300' : 'text-emerald-300'}">
            ${assessment.compositeLevel} RISK
          </div>
        </div>
      </div>

      <!-- SPRAY SAFETY WINDOW & IRRIGATION GUIDANCE TWIN CARDS -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <!-- Card 1: Safe Spray Window Advisor -->
        <div class="glass-card-accent p-6 space-y-4 border-l-4 ${assessment.spraySafetyWindow.color === 'red' ? 'border-l-red-500' : assessment.spraySafetyWindow.color === 'amber' ? 'border-l-amber-500' : 'border-l-emerald-500'}">
          <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-900/60 pb-3">
            <div class="flex items-center gap-2.5">
              <div class="w-9 h-9 rounded-xl ${assessment.spraySafetyWindow.color === 'red' ? 'bg-red-500/20 text-red-400' : assessment.spraySafetyWindow.color === 'amber' ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'} flex items-center justify-center font-bold">
                <i data-lucide="${assessment.spraySafetyWindow.icon}" class="w-5 h-5"></i>
              </div>
              <div>
                <h3 class="text-base font-black text-white">Chemical & Pesticide Spray Window Advisor</h3>
                <p class="text-xs text-gray-400">Knapsack drift safety, foliar wash-off and phytotoxicity check</p>
              </div>
            </div>
            <span class="px-3 py-1 rounded-full text-xs font-mono font-black border ${
              assessment.spraySafetyWindow.color === 'red' ? 'bg-red-500/20 text-red-300 border-red-500/40 animate-pulse' :
              assessment.spraySafetyWindow.color === 'amber' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' :
              'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
            }">
              ${assessment.spraySafetyWindow.badgeText}
            </span>
          </div>

          <div class="p-3.5 rounded-xl bg-black/40 border border-emerald-950 space-y-1.5 text-xs">
            <div class="flex items-center gap-2 font-mono font-bold ${assessment.spraySafetyWindow.color === 'red' ? 'text-red-300' : assessment.spraySafetyWindow.color === 'amber' ? 'text-amber-300' : 'text-emerald-300'}">
              <i data-lucide="clock" class="w-4 h-4 shrink-0"></i>
              <span>Best Spraying Hours: ${assessment.spraySafetyWindow.bestHours}</span>
            </div>
            <p class="text-gray-200 leading-relaxed">
              ${assessment.spraySafetyWindow.reason}
            </p>
          </div>

          <div class="space-y-1.5 pt-1 text-xs">
            <span class="text-gray-400 font-mono text-[11px] block font-bold">MANDATORY SPRAY RULES:</span>
            <ul class="space-y-1 text-gray-300 text-[11px] list-disc list-inside">
              ${assessment.spraySafetyWindow.knapsackRules.slice(0, 3).map(r => `<li><span>${r}</span></li>`).join('')}
            </ul>
          </div>
        </div>

        <!-- Card 2: Smart Irrigation Timing Guidance -->
        <div class="glass-card-accent p-6 space-y-4 border-l-4 ${assessment.irrigationGuidance.color === 'blue' ? 'border-l-blue-500' : assessment.irrigationGuidance.color === 'orange' ? 'border-l-orange-500' : 'border-l-emerald-500'}">
          <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-900/60 pb-3">
            <div class="flex items-center gap-2.5">
              <div class="w-9 h-9 rounded-xl ${assessment.irrigationGuidance.color === 'blue' ? 'bg-blue-500/20 text-blue-400' : assessment.irrigationGuidance.color === 'orange' ? 'bg-orange-500/20 text-orange-400' : 'bg-emerald-500/20 text-emerald-400'} flex items-center justify-center font-bold">
                <i data-lucide="droplet" class="w-5 h-5"></i>
              </div>
              <div>
                <h3 class="text-base font-black text-white">Irrigation Scheduling AI Guidance</h3>
                <p class="text-xs text-gray-400">Soil moisture replenishment and energy saving recommendation</p>
              </div>
            </div>
            <span class="px-3 py-1 rounded-full text-xs font-mono font-black border ${
              assessment.irrigationGuidance.color === 'blue' ? 'bg-blue-500/20 text-blue-300 border-blue-500/40' :
              assessment.irrigationGuidance.color === 'orange' ? 'bg-orange-500/20 text-orange-300 border-orange-500/40' :
              'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
            }">
              ${assessment.irrigationGuidance.badge}
            </span>
          </div>

          <div class="p-3.5 rounded-xl bg-black/40 border border-emerald-950 space-y-1.5 text-xs">
            <div class="flex items-center gap-2 font-mono font-bold text-emerald-300">
              <i data-lucide="zap" class="w-4 h-4 shrink-0 text-emerald-400"></i>
              <span>Watering Protocol for ${selectedCrop.toUpperCase()}:</span>
            </div>
            <p class="text-gray-200 leading-relaxed">
              ${assessment.irrigationGuidance.advice}
            </p>
          </div>

          <!-- Quick Action Buttons -->
          <div class="flex flex-wrap items-center gap-3 pt-2">
            <a href="#/irrigation" class="px-3 py-1.5 rounded-lg bg-emerald-900/60 hover:bg-emerald-800 text-emerald-200 border border-emerald-500/40 text-xs font-mono font-bold transition flex items-center gap-1.5">
              <i data-lucide="sliders" class="w-3.5 h-3.5"></i>
              <span>Open Drip Controller</span>
            </a>
            <a href="#/crop-monitor" class="px-3 py-1.5 rounded-lg bg-teal-900/60 hover:bg-teal-800 text-teal-200 border border-teal-500/40 text-xs font-mono font-bold transition flex items-center gap-1.5">
              <i data-lucide="calendar" class="w-3.5 h-3.5"></i>
              <span>View Watering Calendar</span>
            </a>
          </div>
        </div>
      </div>

      <!-- Crop Sensitivity Selector Strip -->
      <div class="glass-card p-4 space-y-2.5">
        <div class="flex flex-wrap items-center justify-between gap-1 text-xs">
          <span class="text-emerald-300 font-bold font-mono flex items-center gap-1.5">
            <i data-lucide="sprout" class="w-3.5 h-3.5 text-emerald-400"></i>
            <span>Tailor Weather Risk Matrix for Specific Crop:</span>
          </span>
          <span class="text-[10px] font-mono text-gray-400">Click to recalculate crop-specific vulnerability thresholds</span>
        </div>
        <div class="flex flex-wrap gap-1.5">
          ${cropOptions.map(c => `
            <button 
              type="button" 
              data-weather-crop="${c.key}" 
              class="weather-crop-chip px-2.5 py-1 rounded-lg text-xs font-mono transition cursor-pointer border ${
                selectedCrop === c.key
                  ? 'bg-emerald-700 text-white font-bold border-emerald-400 shadow-sm'
                  : 'bg-emerald-950/60 text-gray-300 hover:text-white border-emerald-800/50 hover:bg-emerald-900'
              }"
            >
              ${c.icon} ${c.name.split('(')[0].trim()}
            </button>
          `).join('')}
        </div>
      </div>

      <!-- INTERACTIVE WEATHER WHAT-IF RISK SIMULATOR -->
      <div class="glass-card p-5 space-y-4 border border-amber-500/30">
        <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950 pb-3">
          <div class="flex items-center gap-2">
            <div class="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
              <i data-lucide="sliders-horizontal" class="w-4 h-4"></i>
            </div>
            <div>
              <h3 class="text-sm font-black text-white uppercase tracking-wider font-mono">
                Interactive Weather What-If Risk Simulator
              </h3>
              <p class="text-[11px] text-gray-400">Adjust meteorological variables to preview AI Risk scores and emergency alerts live</p>
            </div>
          </div>
          <button 
            type="button" 
            id="btn-reset-weather-sim" 
            class="px-2.5 py-1 rounded-lg bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs font-mono transition cursor-pointer"
          >
            Reset to Live Forecast
          </button>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-mono">
          <!-- Slider 1: Temperature -->
          <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
            <div class="flex justify-between items-center">
              <span class="text-gray-400">Max Temp:</span>
              <span id="label-sim-temp" class="text-amber-300 font-bold text-sm">${tel.maxTemp}°C</span>
            </div>
            <input 
              type="range" 
              id="slider-sim-temp" 
              min="15" 
              max="45" 
              value="${tel.maxTemp}" 
              step="1" 
              class="w-full accent-amber-500 cursor-pointer"
            />
          </div>

          <!-- Slider 2: Rain Probability -->
          <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
            <div class="flex justify-between items-center">
              <span class="text-gray-400">Rain Chance:</span>
              <span id="label-sim-rain" class="text-blue-300 font-bold text-sm">${tel.maxRainProb}%</span>
            </div>
            <input 
              type="range" 
              id="slider-sim-rain" 
              min="0" 
              max="100" 
              value="${tel.maxRainProb}" 
              step="5" 
              class="w-full accent-blue-500 cursor-pointer"
            />
          </div>

          <!-- Slider 3: Air Humidity -->
          <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
            <div class="flex justify-between items-center">
              <span class="text-gray-400">Relative Humidity:</span>
              <span id="label-sim-humidity" class="text-purple-300 font-bold text-sm">${tel.humidity}%</span>
            </div>
            <input 
              type="range" 
              id="slider-sim-humidity" 
              min="20" 
              max="100" 
              value="${tel.humidity}" 
              step="5" 
              class="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          <!-- Slider 4: Wind Speed -->
          <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
            <div class="flex justify-between items-center">
              <span class="text-gray-400">Wind Speed:</span>
              <span id="label-sim-wind" class="text-teal-300 font-bold text-sm">${tel.windSpeed} km/h</span>
            </div>
            <input 
              type="range" 
              id="slider-sim-wind" 
              min="0" 
              max="50" 
              value="${tel.windSpeed}" 
              step="2" 
              class="w-full accent-teal-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      <!-- 6 MULTI-HAZARD AI RISK DETECTION CARDS -->
      <div class="space-y-3">
        <div class="flex items-center justify-between">
          <h2 class="text-sm font-extrabold text-white uppercase tracking-wider font-mono flex items-center gap-2">
            <i data-lucide="layers" class="w-4 h-4 text-emerald-400"></i>
            <span>6-Vector Multi-Hazard Meteorological Threat Evaluation:</span>
          </h2>
          <span class="text-[10px] text-gray-400 font-mono">Updated in real-time</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          ${assessment.hazards.map((h, idx) => `
            <div class="glass-card p-5 space-y-4 border-l-4 ${
              h.color === 'red' ? 'border-l-red-500 bg-red-950/20' :
              h.color === 'orange' ? 'border-l-orange-500 bg-orange-950/15' :
              h.color === 'amber' ? 'border-l-amber-500 bg-amber-950/15' :
              'border-l-emerald-500'
            } flex flex-col justify-between">
              <div>
                <!-- Card Header -->
                <div class="flex items-center justify-between gap-2 mb-2">
                  <div class="flex items-center gap-2">
                    <div class="w-8 h-8 rounded-xl ${
                      h.color === 'red' ? 'bg-red-500/20 text-red-400' :
                      h.color === 'orange' ? 'bg-orange-500/20 text-orange-400' :
                      h.color === 'amber' ? 'bg-amber-500/20 text-amber-400' :
                      'bg-emerald-500/20 text-emerald-400'
                    } flex items-center justify-center font-bold">
                      <i data-lucide="${h.icon}" class="w-4 h-4"></i>
                    </div>
                    <div>
                      <h3 class="text-sm font-black text-white leading-tight">${h.title}</h3>
                      <div class="text-[10px] text-amber-300 font-sans">${h.titleVernacular.split('(')[0].trim()}</div>
                    </div>
                  </div>
                  <span class="px-2 py-0.5 rounded text-[10px] font-black font-mono tracking-wider border ${
                    h.color === 'red' ? 'bg-red-500/20 text-red-300 border-red-500/40 animate-pulse' :
                    h.color === 'orange' ? 'bg-orange-500/20 text-orange-300 border-orange-500/40' :
                    h.color === 'amber' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' :
                    'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  }">
                    ${h.level}
                  </span>
                </div>

                <!-- Risk Score Bar -->
                <div class="space-y-1 py-1">
                  <div class="flex justify-between text-[11px] font-mono">
                    <span class="text-gray-400">Hazard Threat Index:</span>
                    <span class="font-extrabold ${h.color === 'red' ? 'text-red-400' : h.color === 'orange' ? 'text-orange-400' : h.color === 'amber' ? 'text-amber-400' : 'text-emerald-400'}">
                      ${h.riskScore}/100
                    </span>
                  </div>
                  <div class="w-full h-1.5 rounded-full bg-gray-900 overflow-hidden">
                    <div class="h-full rounded-full transition-all duration-500 ${
                      h.color === 'red' ? 'bg-red-500' :
                      h.color === 'orange' ? 'bg-orange-500' :
                      h.color === 'amber' ? 'bg-amber-400' :
                      'bg-emerald-500'
                    }" style="width: ${h.riskScore}%"></div>
                  </div>
                </div>

                <!-- Telemetry & Formula -->
                <div class="p-2.5 rounded-xl bg-black/50 border border-emerald-950/80 space-y-1 text-[11px] font-mono mt-2">
                  <div class="text-gray-300 font-bold truncate">${h.currentValueStr}</div>
                  <div class="text-[10px] text-gray-400 truncate">Threshold: ${h.thresholdStr}</div>
                </div>

                <!-- Crop Vulnerability -->
                <div class="pt-2 text-xs text-gray-200 leading-relaxed">
                  <span class="text-[10px] font-mono text-emerald-400 font-bold block mb-0.5">CROP SENSITIVITY (${selectedCrop.toUpperCase()}):</span>
                  <p class="text-[11px] text-gray-300">${h.cropVulnerability}</p>
                </div>
              </div>

              <!-- Mitigation Action Bottom Block -->
              <div class="pt-3 border-t border-emerald-950/80 space-y-2 mt-3">
                <div class="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40 text-[11px] leading-relaxed">
                  <span class="font-bold text-emerald-300 block mb-0.5">PROACTIVE ACTION:</span>
                  <p class="text-emerald-100">${h.mitigationAction}</p>
                </div>

                <div class="flex items-center justify-between text-[10px] font-mono text-gray-400 pt-1">
                  <span>Formula: ${h.triggerFormula.split('|')[0].trim()}</span>
                  <button type="button" class="btn-ask-copilot-about-hazard text-emerald-400 hover:text-emerald-300 font-bold underline cursor-pointer" data-hazard-name="${h.title}">
                    Ask Copilot →
                  </button>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- Weather Risk Mathematical XAI Card -->
      ${renderGenericXAIExplanationCard(
        "Microclimate Infection & Multi-Hazard Weather Risk Mathematical Models",
        "How does the AgroSense AI Risk Engine evaluate Heavy Rain, Heat Stress & Spore Inoculum?",
        "Composite_Risk = 0.65 × max(H_i) + 0.35 × avg(H_i) | I_spore = f(RH, T_canopy)",
        assessment.hazards.map(h => ({
          label: h.title,
          value: `Index: ${h.riskScore}/100 (${h.level})`,
          note: `Trigger Formula: ${h.triggerFormula}`
        }))
      )}
    </div>
  `;
}

export function initWeatherRiskHooks(state, setState) {
  // 1. Crop Switcher Chips
  document.querySelectorAll('.weather-crop-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const crop = chip.getAttribute('data-weather-crop');
      if (setState && crop) {
        setState({ weatherRiskSelectedCrop: crop });
      }
    });
  });

  // 2. Interactive What-If Simulation Sliders
  const sliderTemp = document.getElementById('slider-sim-temp');
  const sliderRain = document.getElementById('slider-sim-rain');
  const sliderHumidity = document.getElementById('slider-sim-humidity');
  const sliderWind = document.getElementById('slider-sim-wind');
  const resetBtn = document.getElementById('btn-reset-weather-sim');

  const updateSimulation = () => {
    if (setState) {
      setState({
        weatherRiskSimulation: {
          temp: parseFloat(sliderTemp?.value) || 28,
          rainProb: parseFloat(sliderRain?.value) || 25,
          rainSum: (parseFloat(sliderRain?.value) || 25) > 50 ? 16.0 : 1.5,
          humidity: parseFloat(sliderHumidity?.value) || 68,
          windSpeed: parseFloat(sliderWind?.value) || 12
        }
      });
    }
  };

  sliderTemp?.addEventListener('input', (e) => {
    const lbl = document.getElementById('label-sim-temp');
    if (lbl) lbl.textContent = `${e.target.value}°C`;
  });
  sliderTemp?.addEventListener('change', updateSimulation);

  sliderRain?.addEventListener('input', (e) => {
    const lbl = document.getElementById('label-sim-rain');
    if (lbl) lbl.textContent = `${e.target.value}%`;
  });
  sliderRain?.addEventListener('change', updateSimulation);

  sliderHumidity?.addEventListener('input', (e) => {
    const lbl = document.getElementById('label-sim-humidity');
    if (lbl) lbl.textContent = `${e.target.value}%`;
  });
  sliderHumidity?.addEventListener('change', updateSimulation);

  sliderWind?.addEventListener('input', (e) => {
    const lbl = document.getElementById('label-sim-wind');
    if (lbl) lbl.textContent = `${e.target.value} km/h`;
  });
  sliderWind?.addEventListener('change', updateSimulation);

  resetBtn?.addEventListener('click', () => {
    if (setState) {
      setState({ weatherRiskSimulation: null });
    }
  });

  // 3. Broadcast Audio Advisory Button (Web Speech API)
  const broadcastBtn = document.getElementById('btn-broadcast-weather-warning');
  if (broadcastBtn && 'speechSynthesis' in window) {
    broadcastBtn.addEventListener('click', () => {
      const assessment = evaluateAdvancedWeatherRisks(state.weatherData, state.weatherRiskSelectedCrop || 'wheat');
      const textToSpeak = `AgroSense Weather Risk Warning. Overall farm risk is ${assessment.compositeLevel}. Top threat is ${assessment.topPriorityHazard.title}. Spray window status: ${assessment.spraySafetyWindow.badgeText}. Proactive action: ${assessment.topPriorityHazard.mitigationAction}`;
      const utterance = new SpeechSynthesisUtterance(textToSpeak);
      utterance.rate = 0.95;
      window.speechSynthesis.speak(utterance);
    });
  }

  // 4. Ask Copilot About Specific Hazard
  document.querySelectorAll('.btn-ask-copilot-about-hazard').forEach(btn => {
    btn.addEventListener('click', () => {
      const hazard = btn.getAttribute('data-hazard-name');
      if (setState) {
        setState({
          copilotInitialPrompt: `How should I manage ${hazard} on my ${state.weatherRiskSelectedCrop || 'crop'} farm right now?`
        });
        window.location.hash = '#/ai-assistant';
      }
    });
  });

  // 5. Print Report
  const printBtn = document.getElementById('btn-print-weather-risk');
  printBtn?.addEventListener('click', () => {
    window.print();
  });
}
