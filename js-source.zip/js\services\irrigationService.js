// AgroSense Smart Irrigation Service using FAO-56 Penman-Monteith Evapotranspiration Math

import { calculateFAO56PenmanMonteithET0, getCropCoefficientKc } from './agronomicEngine.js';

export function calculateIrrigationRecommendation(soilMoisture, cropType, growthStage, weatherForecast) {
  const tempC = 26.8;
  const humidityPct = 68;
  const windSpeedKmH = 12.4;

  // 1. Calculate Reference Evapotranspiration ET0 (mm/day)
  const et0 = calculateFAO56PenmanMonteithET0(tempC, humidityPct, windSpeedKmH);

  // 2. Calculate Crop Water Requirement ETc = ET0 * Kc
  const kc = getCropCoefficientKc(cropType, growthStage);
  const etcMmDay = parseFloat((et0 * kc).toFixed(2));

  // 3. Evaluate 24-Hour Effective Rainfall Offset
  const rainProb = weatherForecast && weatherForecast[1] ? weatherForecast[1].rainProb : 15;
  const rainForecastMm = weatherForecast && weatherForecast[1] ? weatherForecast[1].rainSum : 0;
  const effectiveRainMm = rainProb > 50 ? rainForecastMm * 0.8 : 0;

  // 4. Calculate Net Soil Water Deficit %
  const targetOptimalMoisture = 35; // %
  const soilMoistureDeficitPct = Math.max(0, targetOptimalMoisture - soilMoisture);

  let waterStatus = "Optimal";
  let urgency = "LOW";
  let recommendedVolumeLiters = 0;
  let recommendedPulseDurationMinutes = 0;
  let actionText = "";

  if (soilMoisture < 22) {
    waterStatus = "Dry / Water Deficient";
    urgency = "HIGH";
    recommendedVolumeLiters = 4500;
    recommendedPulseDurationMinutes = 45;
    actionText = "Immediate irrigation required. Soil moisture is below crop wilting point.";
  } else if (soilMoisture < 28) {
    waterStatus = "Slightly Dry";
    urgency = "MEDIUM";
    recommendedVolumeLiters = 2500;
    recommendedPulseDurationMinutes = 25;
    actionText = "Schedule drip pulse within next 12 hours.";
  } else if (soilMoisture > 45) {
    waterStatus = "Over-irrigated / Waterlogged";
    urgency = "WARNING";
    recommendedVolumeLiters = 0;
    recommendedPulseDurationMinutes = 0;
    actionText = "Stop irrigation immediately. Check field drainage to prevent root rot.";
  } else {
    waterStatus = "Optimal Moisture";
    urgency = "LOW";
    recommendedVolumeLiters = 0;
    recommendedPulseDurationMinutes = 0;
    actionText = "Soil moisture is in the optimal range. No artificial irrigation required today.";
  }

  // Rain Delay Override Rule
  if (effectiveRainMm > 5 && waterStatus !== "Dry / Water Deficient") {
    actionText += ` (Rain forecast of ${rainForecastMm}mm expected — holding pulse irrigation saves water).`;
    recommendedVolumeLiters = 0;
    recommendedPulseDurationMinutes = 0;
  }

  return {
    waterStatus,
    urgency,
    currentMoisture: soilMoisture,
    targetMoisture: targetOptimalMoisture,
    et0MmDay: et0,
    kc,
    etcMmDay,
    effectiveRainMm,
    soilMoistureDeficitPct,
    recommendedVolumeLiters,
    recommendedPulseDurationMinutes,
    actionText,
    xaiAttribution: {
      formula: `ET_c = ET_0 (${et0} mm/day) × K_c (${kc}) = ${etcMmDay} mm/day`,
      waterBalanceEquation: `Net Irrigation Duty = ET_c (${etcMmDay}mm) - Rain Offset (${effectiveRainMm.toFixed(1)}mm) = ${(Math.max(0, etcMmDay - effectiveRainMm)).toFixed(2)} mm/day`,
      factors: [
        { label: "FAO-56 ET0 Rate", value: `${et0} mm/day`, note: `Based on Temp ${tempC}°C, Humidity ${humidityPct}%, Wind ${windSpeedKmH} km/h` },
        { label: "Crop Coefficient (Kc)", value: `${kc}`, note: `Stage: ${growthStage}` },
        { label: "Daily Water Need (ETc)", value: `${etcMmDay} mm/day`, note: `Target per acre: ${(etcMmDay * 4046.86 / 1000).toFixed(0)} Liters` },
        { label: "24h Rain Forecast Offset", value: `-${effectiveRainMm.toFixed(1)} mm`, note: `Probability: ${rainProb}%` }
      ]
    },
    pipelineVisual: [
      { step: "SOIL MOISTURE", status: `${soilMoisture}%`, icon: "droplet" },
      { step: "FAO-56 ET0 MODEL", status: `${et0} mm/day`, icon: "cpu" },
      { step: "RAIN FORECAST", status: `${rainForecastMm} mm`, icon: "cloud" },
      { step: "AI WATER BALANCE", status: `${etcMmDay} mm/day ETc`, icon: "zap" },
      { step: "RECOMMENDATION", status: urgency === "HIGH" ? "Irrigate Now" : "Hold Irrigation", icon: "check-circle" }
    ]
  };
}

export function generateSensorTelemetry(timeframe = "24h") {
  let dataPointsCount = 24;
  let labelPrefix = "Hour";
  
  if (timeframe === "30m") {
    dataPointsCount = 10;
    labelPrefix = "Min";
  } else if (timeframe === "6h") {
    dataPointsCount = 12;
    labelPrefix = "30m";
  } else if (timeframe === "7d") {
    dataPointsCount = 7;
    labelPrefix = "Day";
  }

  const telemetry = [];
  let baseMoisture = 32;
  let baseTemp = 24;
  let basePh = 7.1;

  for (let i = 1; i <= dataPointsCount; i++) {
    const moistureVar = (Math.sin(i / 2) * 3) + (Math.random() * 1.5);
    const tempVar = (Math.cos(i / 3) * 2.5) + (Math.random() * 0.8);
    const phVar = (Math.random() * 0.1 - 0.05);

    telemetry.push({
      time: `${labelPrefix} ${i}`,
      moisture: parseFloat((baseMoisture + moistureVar).toFixed(1)),
      temperature: parseFloat((baseTemp + tempVar).toFixed(1)),
      ph: parseFloat((basePh + phVar).toFixed(2)),
      ec: parseFloat((0.85 + (Math.random() * 0.04 - 0.02)).toFixed(2)),
      humidity: Math.round(62 + (Math.sin(i / 2) * 8))
    });
  }

  return telemetry;
}
