// AgroSense Leaflet Farm Map Component
// Displays 4-Point Demarcated Boundary Polygon, Cardinal Corner Pins, Satellite Toggle & GIS Telemetry

import {
  calculatePolygonArea,
  calculateCentroid,
  getCardinalBearing,
  findNearestAgriPlace,
  getGoogleSatelliteUrl
} from '../services/geoService.js';

export function renderFarmMapContainer(farm) {
  const hasPolygon = Array.isArray(farm.boundaryPolygon) && farm.boundaryPolygon.length >= 3;
  const areaStats = hasPolygon ? calculatePolygonArea(farm.boundaryPolygon) : { acres: farm.sizeAcres, hectares: (farm.sizeAcres * 0.404686).toFixed(2), perimeterMeters: 0 };
  const centroid = hasPolygon ? calculateCentroid(farm.boundaryPolygon) : (farm.geoCoords || { lat: 18.5204, lng: 73.8567 });
  const place = findNearestAgriPlace(centroid.lat, centroid.lng);

  return `
    <div class="glass-card p-5 space-y-4 border border-emerald-800/40 shadow-xl shadow-emerald-950/50">
      
      <!-- Top Title & Location Bar -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-900/40 pb-3">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-md shadow-emerald-900/40">
            <i data-lucide="map" class="w-5 h-5 text-white"></i>
          </div>
          <div>
            <h3 class="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <span>${farm.name}</span>
              ${hasPolygon ? `
                <span class="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold flex items-center gap-1">
                  <i data-lucide="check" class="w-3 h-3 text-emerald-400"></i> 4 Corners Located
                </span>
              ` : ''}
            </h3>
            <p class="text-xs text-gray-400 flex items-center gap-1.5 flex-wrap">
              <span class="text-emerald-300 font-semibold flex items-center gap-1">
                <i data-lucide="map-pin" class="w-3 h-3"></i> ${farm.location || place.formattedLocation}
              </span>
              <span>• Farmer: <b class="text-white">${farm.farmerName || 'Registered Farmer'}</b></span>
              <span>• PIN: <b class="text-amber-300">${farm.pin || place.pin}</b></span>
            </p>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <!-- Satellite / Street Toggle -->
          <div class="flex items-center gap-1 bg-gray-900 p-1 rounded-xl border border-emerald-800/50">
            <button type="button" id="btn-farm-satellite" class="px-2.5 py-1 rounded-lg bg-emerald-700/60 text-emerald-200 font-bold text-xs flex items-center gap-1 transition" title="Switch to Satellite Aerial Imagery">
              <i data-lucide="satellite" class="w-3.5 h-3.5 text-emerald-300"></i>
              <span class="hidden sm:inline">Satellite</span>
            </button>
            <button type="button" id="btn-farm-street" class="px-2.5 py-1 rounded-lg text-gray-400 hover:text-white font-semibold text-xs flex items-center gap-1 transition" title="Switch to Street Map">
              <i data-lucide="map" class="w-3.5 h-3.5"></i>
              <span class="hidden sm:inline">Street</span>
            </button>
          </div>

          <div class="px-3 py-1.5 rounded-xl bg-emerald-950/80 border border-emerald-700/50 text-right">
            <span class="text-[10px] text-gray-400 uppercase tracking-wider block">Farm Area</span>
            <span class="text-xs sm:text-sm font-extrabold text-emerald-300">${areaStats.acres} Acres</span>
          </div>
          
          <a href="#/onboarding" class="px-3 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-semibold transition flex items-center gap-1.5" title="Re-plot or Add Farm">
            <i data-lucide="edit-3" class="w-3.5 h-3.5"></i>
            <span>Edit</span>
          </a>
        </div>
      </div>

      <!-- Map Container Element -->
      <div id="leaflet-farm-map" class="farm-map-wrapper z-10"></div>

      <!-- Map Layer Controls & GIS Legend -->
      <div class="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs border-t border-emerald-900/40 text-gray-300">
        <div class="flex flex-wrap items-center gap-4">
          <span class="flex items-center gap-1.5">
            <span class="w-3 h-3 rounded-full bg-emerald-500 inline-block shadow-sm shadow-emerald-500/50"></span> 
            <b>Farm Boundary Polygon</b> (${areaStats.acres} Acres)
          </span>
          <span class="flex items-center gap-1.5">
            <span class="w-4 h-4 rounded-full bg-emerald-600 text-white font-bold text-[9px] flex items-center justify-center border border-white">1</span>
            <b>4 Boundary Corners (NW, NE, SE, SW)</b>
          </span>
          <span class="flex items-center gap-1.5">
            <span class="w-3 h-3 rounded-full bg-blue-500 inline-block shadow-sm shadow-blue-500/50"></span> 
            <b>IoT Telemetry Node</b>
          </span>
        </div>
        <a href="${getGoogleSatelliteUrl(centroid.lat, centroid.lng)}" target="_blank" class="text-[11px] text-sky-400 hover:text-sky-300 hover:underline flex items-center gap-1 font-mono">
          <i data-lucide="external-link" class="w-3.5 h-3.5"></i> Open in Google Maps Satellite ↗
        </a>
      </div>
    </div>
  `;
}

export function initLeafletMap(farm) {
  const container = document.getElementById('leaflet-farm-map');
  if (!container || typeof L === 'undefined') return;

  // Clear previous instance if exists
  container._leaflet_id = null;

  const lat = farm.geoCoords ? farm.geoCoords.lat : 18.5204;
  const lng = farm.geoCoords ? farm.geoCoords.lng : 73.8567;

  const map = L.map('leaflet-farm-map', {
    scrollWheelZoom: true,
    zoomControl: true
  }).setView([lat, lng], 16);

  setTimeout(() => {
    if (map) map.invalidateSize();
  }, 100);
  setTimeout(() => {
    if (map) map.invalidateSize();
  }, 350);

  window.addEventListener('resize', () => {
    if (map) map.invalidateSize();
  });

  // Satellite layer (Esri World Imagery)
  const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri World Imagery'
  });

  // Street map layer (OpenStreetMap)
  const streetLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  });

  // Default to Satellite view
  satelliteLayer.addTo(map);

  // Wire layer toggle buttons
  const btnSatellite = document.getElementById('btn-farm-satellite');
  const btnStreet = document.getElementById('btn-farm-street');

  if (btnSatellite && btnStreet) {
    btnSatellite.addEventListener('click', () => {
      map.removeLayer(streetLayer);
      satelliteLayer.addTo(map);
      btnSatellite.className = 'px-2.5 py-1 rounded-lg bg-emerald-700/60 text-emerald-200 font-bold text-xs flex items-center gap-1 transition';
      btnStreet.className = 'px-2.5 py-1 rounded-lg text-gray-400 hover:text-white font-semibold text-xs flex items-center gap-1 transition';
    });
    btnStreet.addEventListener('click', () => {
      map.removeLayer(satelliteLayer);
      streetLayer.addTo(map);
      btnStreet.className = 'px-2.5 py-1 rounded-lg bg-emerald-700/60 text-emerald-200 font-bold text-xs flex items-center gap-1 transition';
      btnSatellite.className = 'px-2.5 py-1 rounded-lg text-gray-400 hover:text-white font-semibold text-xs flex items-center gap-1 transition';
    });
  }

  // Helper for numbered corner icon with cardinal indicator
  function createNumberedDivIcon(number, cardinalTag = '') {
    return L.divIcon({
      className: 'farm-corner-div-icon',
      html: `
        <div class="farm-corner-pin ${number === 4 ? 'final-point' : ''}">
          <span>${number}</span>
          ${cardinalTag ? `<span style="position: absolute; bottom: -14px; font-size: 8px; font-weight: 800; background: rgba(0,0,0,0.85); color: #34d399; padding: 1px 3px; border-radius: 4px; border: 1px solid #059669;">${cardinalTag}</span>` : ''}
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16],
      popupAnchor: [0, -18]
    });
  }

  // Draw Farm Boundary Polygon & Add 4 Corner Pins
  if (Array.isArray(farm.boundaryPolygon) && farm.boundaryPolygon.length >= 3) {
    const area = calculatePolygonArea(farm.boundaryPolygon);
    const center = calculateCentroid(farm.boundaryPolygon);
    const place = findNearestAgriPlace(center.lat, center.lng);

    const polygon = L.polygon(farm.boundaryPolygon, {
      color: '#10b981',
      fillColor: '#059669',
      fillOpacity: 0.35,
      weight: 3
    }).addTo(map);

    polygon.bindPopup(`
      <div style="font-family: 'Plus Jakarta Sans', sans-serif; padding: 4px; min-width: 210px;">
        <div style="font-size: 13px; font-weight: 800; color: #064e3b; margin-bottom: 2px;">${farm.name}</div>
        <div style="font-size: 11px; color: #4b5563; margin-bottom: 4px;">
          📍 Located at: <b>${farm.location || place.formattedLocation}</b>
        </div>
        <div style="padding: 4px 8px; background: #ecfdf5; border-radius: 6px; border: 1px solid #a7f3d0; margin-bottom: 6px;">
          <b style="font-size: 12px; color: #047857;">Area: ${area.acres} Acres (${area.hectares} Ha)</b><br/>
          <span style="font-size: 10px; color: #065f46;">Perimeter: ${area.perimeterMeters} m (${farm.boundaryPolygon.length} corners)</span>
        </div>
        <div style="font-size: 11px; color: #374151;">
          <b>Farmer:</b> ${farm.farmerName || 'Farmer'}<br/>
          <b>Crop:</b> ${farm.currentCrop}<br/>
          <b>Soil:</b> ${farm.soilType || 'Vertisol'} (Health: ${farm.healthScore || 82}/100)<br/>
          <b>Irrigation:</b> ${farm.irrigationType || 'Drip'}
        </div>
      </div>
    `);

    // Place Numbered Pin with Cardinal Direction on Each Corner Point
    farm.boundaryPolygon.forEach((pt, idx) => {
      const cornerNum = idx + 1;
      const cardinal = getCardinalBearing(center.lat, center.lng, pt[0], pt[1]);

      const cornerMarker = L.marker(pt, {
        icon: createNumberedDivIcon(cornerNum, cardinal.shortLabel)
      }).addTo(map);

      cornerMarker.bindPopup(`
        <div style="font-family: sans-serif; padding: 2px;">
          <b style="color: #047857; font-size: 12px;">Boundary Corner ${cornerNum} — ${cardinal.label}</b><br/>
          <span style="font-size: 11px; color: #4b5563;">Bearing: <b>${cardinal.bearingDeg}° (${cardinal.shortLabel})</b> from center</span><br/>
          <span style="font-size: 11px; color: #4b5563;">Latitude: <b>${pt[0].toFixed(6)}° N</b></span><br/>
          <span style="font-size: 11px; color: #4b5563;">Longitude: <b>${pt[1].toFixed(6)}° E</b></span>
        </div>
      `);
    });

    // Auto-fit map to polygon bounds
    map.fitBounds(polygon.getBounds(), { padding: [45, 45] });
  }

  // Add IoT Sensor Node Marker at centroid
  if (farm.soil) {
    const iotIcon = L.divIcon({
      className: 'iot-node-div-icon',
      html: `
        <div style="width: 28px; height: 28px; border-radius: 50%; background: linear-gradient(135deg, #0284c7, #0369a1); border: 2px solid white; display: flex; align-items: center; justify-content: center; color: white; box-shadow: 0 0 10px rgba(2, 132, 199, 0.8);">
          <span style="font-size: 12px;">📡</span>
        </div>
      `,
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });

    L.marker([lat, lng], { icon: iotIcon }).addTo(map)
      .bindPopup(`
        <div style="font-family: sans-serif; padding: 2px;">
          <b style="color: #0369a1; font-size: 12px;">AgroSense IoT Telemetry Node</b><br/>
          <span style="font-size: 11px; color: #374151;">Soil Moisture: <b>${farm.soil.moisture}%</b></span><br/>
          <span style="font-size: 11px; color: #374151;">Soil Temp: <b>${farm.soil.temperature}°C</b></span><br/>
          <span style="font-size: 11px; color: #374151;">Soil pH: <b>${farm.soil.ph}</b> | EC: <b>${farm.soil.electricalConductivity} dS/m</b></span>
        </div>
      `);
  }
}
