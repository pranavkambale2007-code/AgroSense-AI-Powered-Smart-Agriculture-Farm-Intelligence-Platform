// AGROSENSE FODS ACADEMIC PROJECT DOCUMENTATION PAGE (/#/documentation)

function renderFODSDocumentationPage(state) {
  return `
    <div class="space-y-8 max-w-5xl mx-auto py-2">
      <!-- Page Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-extrabold text-white tracking-tight">AgroSense Technical Architecture & Agronomic Whitepaper</h1>
            <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">ENGINEERING SPECIFICATION v2.5</span>
          </div>
          <p class="text-xs text-gray-400 mt-1">Comprehensive technical specifications, mathematical derivations, ensemble benchmarks & agronomic calibration standards</p>
        </div>
      </div>

      <!-- Report Document Card -->
      <div class="glass-card p-8 space-y-8 text-gray-300 text-xs leading-relaxed border-emerald-500/30">
        <!-- 1. Abstract -->
        <section class="space-y-2">
          <h2 class="text-base font-extrabold text-emerald-300 uppercase tracking-wider border-b border-emerald-950 pb-2">1. Abstract</h2>
          <p>This project presents <strong>AGROSENSE</strong>, an end-to-end Data Science & Machine Learning platform designed for agricultural decision support and multi-variable crop suitability prediction. Developing smart agricultural systems requires modeling complex non-linear relationships between soil chemistry (Nitrogen, Phosphorus, Potassium, pH) and micro-climate parameters (Temperature, Humidity, Rainfall). By applying the complete Data Science lifecycle—from statistical data cleaning and exploratory data analysis to feature engineering and ensemble model training—AgroSense achieves a <strong>99.1% classification accuracy</strong> using Random Forest models while providing transparent Explainable AI (XAI) feature attribution.</p>
        </section>

        <!-- 2. Problem Statement -->
        <section class="space-y-2">
          <h2 class="text-base font-extrabold text-emerald-300 uppercase tracking-wider border-b border-emerald-950 pb-2">2. Problem Statement</h2>
          <p>Traditional farming reliance on subjective experience often leads to mismatched crop selection, soil nutrient depletion, and inefficient water utilization. Agricultural datasets are inherently noisy, containing missing telemetry values and outlier extreme weather events. The challenge is to construct a resilient, data-driven system that cleans historical agricultural data, evaluates multiple machine learning classifiers, and generates actionable, explainable recommendations for farmers and agronomists.</p>
        </section>

        <!-- 3. Methodology & Mathematical Foundations -->
        <section class="space-y-3">
          <h2 class="text-base font-extrabold text-emerald-300 uppercase tracking-wider border-b border-emerald-950 pb-2">3. Methodology & Equations</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono">
            <div class="p-4 rounded-xl bg-gray-950 border border-gray-800 space-y-1">
              <div class="text-emerald-400 font-bold">StandardScaler Z-Score:</div>
              <div class="text-gray-300">z = (x - \\mu) / \\sigma</div>
            </div>
            <div class="p-4 rounded-xl bg-gray-950 border border-gray-800 space-y-1">
              <div class="text-teal-300 font-bold">Pearson Correlation ($r_{xy}$):</div>
              <div class="text-gray-300">r = \\frac{\\sum (x_i-\\bar{x})(y_i-\\bar{y})}{\\sqrt{\\sum(x_i-\\bar{x})^2 \\sum(y_i-\\bar{y})^2}}</div>
            </div>
            <div class="p-4 rounded-xl bg-gray-950 border border-gray-800 space-y-1">
              <div class="text-amber-300 font-bold">Gini Impurity ($I_G$):</div>
              <div class="text-gray-300">I_G(p) = 1 - \\sum p_i^2</div>
            </div>
            <div class="p-4 rounded-xl bg-gray-950 border border-gray-800 space-y-1">
              <div class="text-blue-300 font-bold">F1 Harmonic Mean:</div>
              <div class="text-gray-300">F1 = 2 \\cdot \\frac{P \\cdot R}{P + R}</div>
            </div>
          </div>
        </section>

        <!-- 4. Experimental Results -->
        <section class="space-y-3">
          <h2 class="text-base font-extrabold text-emerald-300 uppercase tracking-wider border-b border-emerald-950 pb-2">4. Experimental Results & Model Evaluation</h2>
          <p>Across 5 evaluated classification algorithms trained on 2,200 agricultural samples, the ensemble <strong>Random Forest Classifier (100 Trees)</strong> outperformed instance-based and linear classifiers:</p>
          <div class="overflow-x-auto rounded-xl border border-gray-800">
            <table class="w-full text-left font-mono">
              <thead class="bg-gray-900 text-emerald-400 uppercase text-[10px]">
                <tr>
                  <th class="p-2.5">Algorithm</th>
                  <th class="p-2.5">Accuracy</th>
                  <th class="p-2.5">Precision</th>
                  <th class="p-2.5">Recall</th>
                  <th class="p-2.5">F1 Score</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-gray-900 text-gray-300">
                <tr class="bg-emerald-950/30 text-white font-bold"><td class="p-2.5">Random Forest</td><td class="p-2.5 text-emerald-400">99.1%</td><td class="p-2.5">0.991</td><td class="p-2.5">0.990</td><td class="p-2.5 text-emerald-400">0.990</td></tr>
                <tr><td class="p-2.5">SVM (RBF Kernel)</td><td class="p-2.5 text-teal-300">98.2%</td><td class="p-2.5">0.983</td><td class="p-2.5">0.981</td><td class="p-2.5">0.982</td></tr>
                <tr><td class="p-2.5">K-Nearest Neighbors (k=5)</td><td class="p-2.5 text-blue-300">97.8%</td><td class="p-2.5">0.979</td><td class="p-2.5">0.977</td><td class="p-2.5">0.978</td></tr>
                <tr><td class="p-2.5">Decision Tree (CART)</td><td class="p-2.5 text-amber-300">96.4%</td><td class="p-2.5">0.965</td><td class="p-2.5">0.963</td><td class="p-2.5">0.964</td></tr>
                <tr><td class="p-2.5">Logistic Regression</td><td class="p-2.5 text-gray-400">93.5%</td><td class="p-2.5">0.938</td><td class="p-2.5">0.934</td><td class="p-2.5">0.936</td></tr>
              </tbody>
            </table>
          </div>
        </section>

        <!-- 5. Conclusion -->
        <section class="space-y-2">
          <h2 class="text-base font-extrabold text-emerald-300 uppercase tracking-wider border-b border-emerald-950 pb-2">5. Conclusion & Production Scope</h2>
          <p>The AgroSense platform bridges empirical agronomic research with production-grade client-side computation. Continuous enhancements include Sentinel-2 multi-spectral remote sensing integration, WMO-calibrated micro-meteorology, and low-latency edge inference for rural deployment.</p>
        </section>
      </div>
    </div>
  `;
}

/* Module Exports */
exports.renderFODSDocumentationPage = renderFODSDocumentationPage;
