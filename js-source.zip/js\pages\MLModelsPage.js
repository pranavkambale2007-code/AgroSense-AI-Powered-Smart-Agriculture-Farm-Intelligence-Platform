// AGROSENSE MACHINE LEARNING MODELS & BENCHMARKS PAGE (/#/ml-models)

import { trainAndBenchmarkModels } from '../ml/fodsMLEngine.js';
import { drawBarChart } from '../components/AnalyticsCharts.js';

export function renderMLModelsPage(state) {
  const models = trainAndBenchmarkModels();
  const bestModel = models.find(m => m.best) || models[0];

  return `
    <div class="space-y-8 max-w-7xl mx-auto py-2">
      <!-- Page Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-extrabold text-white tracking-tight">Machine Learning Models & Classification Benchmarks</h1>
            <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">AGRONOMIC CLASSIFICATION BENCHMARKS</span>
          </div>
          <p class="text-xs text-gray-400 mt-1">Multi-model benchmark evaluation comparing Accuracy, Precision, Recall, F1 Score & Confusion Matrix</p>
        </div>
      </div>

      <!-- Best Model Winner Banner -->
      <div class="glass-card p-6 border-l-4 border-l-emerald-500 flex flex-wrap items-center justify-between gap-4">
        <div class="space-y-1">
          <span class="px-2.5 py-0.5 rounded text-[10px] font-mono font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase">Top Performing Classifier</span>
          <h2 class="text-xl font-extrabold text-white">${bestModel.name}</h2>
          <p class="text-xs text-gray-300 max-w-2xl">${bestModel.desc}</p>
        </div>
        <div class="text-right">
          <div class="text-3xl font-extrabold text-emerald-400 font-mono">${bestModel.accuracy}%</div>
          <span class="text-xs text-gray-400 font-mono">Test Set Accuracy</span>
        </div>
      </div>

      <!-- Model Performance Comparison Bar Chart -->
      <div class="glass-card p-6 space-y-4">
        <h3 class="text-sm font-bold text-white flex items-center gap-2">
          <i data-lucide="bar-chart-3" class="w-4 h-4 text-emerald-400"></i>
          Classification Accuracy Comparison (%)
        </h3>
        <div class="w-full h-[280px] flex items-center justify-center">
          <canvas id="ml-models-bar-canvas" class="w-full h-full block"></canvas>
        </div>
      </div>

      <!-- Detailed Metrics & Confusion Matrix Cards -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        ${models.map(m => `
          <div class="glass-card p-6 space-y-4 ${m.best ? 'border-emerald-500/40' : ''}">
            <div class="flex items-center justify-between">
              <h4 class="text-sm font-bold text-white">${m.name}</h4>
              ${m.best ? '<span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500 text-black">BEST MODEL</span>' : ''}
            </div>

            <div class="grid grid-cols-4 gap-2 font-mono text-center text-xs">
              <div class="p-2 rounded bg-gray-900 border border-gray-800"><div class="text-emerald-400 font-bold">${m.accuracy}%</div><div class="text-[9px] text-gray-400">Accuracy</div></div>
              <div class="p-2 rounded bg-gray-900 border border-gray-800"><div class="text-teal-300 font-bold">${m.precision}</div><div class="text-[9px] text-gray-400">Precision</div></div>
              <div class="p-2 rounded bg-gray-900 border border-gray-800"><div class="text-blue-300 font-bold">${m.recall}</div><div class="text-[9px] text-gray-400">Recall</div></div>
              <div class="p-2 rounded bg-gray-900 border border-gray-800"><div class="text-amber-300 font-bold">${m.f1Score}</div><div class="text-[9px] text-gray-400">F1 Score</div></div>
            </div>

            <!-- Mini Confusion Matrix -->
            <div class="space-y-1">
              <div class="text-[10px] font-mono text-gray-400 uppercase">Sample Confusion Matrix (5 Crops)</div>
              <div class="overflow-x-auto rounded bg-black/40 p-2 border border-gray-800">
                <table class="w-full text-center font-mono text-[10px]">
                  <thead>
                    <tr class="text-gray-400">
                      <th></th>
                      ${m.classNames.map(c => `<th>${c.slice(0, 3)}</th>`).join('')}
                    </tr>
                  </thead>
                  <tbody>
                    ${m.confusionMatrix.map((row, rIdx) => `
                      <tr>
                        <td class="text-gray-400 font-bold text-left">${m.classNames[rIdx].slice(0, 3)}</td>
                        ${row.map((val, cIdx) => `
                          <td class="${rIdx === cIdx ? 'bg-emerald-500/30 text-emerald-300 font-bold' : val > 0 ? 'bg-amber-500/20 text-amber-300' : 'text-gray-600'} p-1 rounded">
                            ${val}
                          </td>
                        `).join('')}
                      </tr>
                    `).join('')}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

export function initMLModelsHooks(state) {
  const models = trainAndBenchmarkModels();
  drawBarChart(
    'ml-models-bar-canvas',
    models.map(m => m.name.split(' ')[0]),
    models.map(m => m.accuracy),
    ['#10b981', '#14b8a6', '#3b82f6', '#f59e0b', '#8b5cf6'],
    100
  );
}
