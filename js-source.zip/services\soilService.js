// AgroSense Soil Intelligence & Chemistry Analysis Service

const { calculatePhosphorusBioAvailability } = require('js/services/agronomicEngine.js');

function analyzeSoilHealth(soilInputs) {
  const { nitrogen, phosphorus, potassium, ph, organicCarbon, electricalConductivity, moisture } = soilInputs;

  let baseScore = 100;
  const deductions = [];

  // 1. Nitrogen Penalty (Ideal: 280-560 kg/ha)
  let nStatus = "Good";
  let nScore = 85;
  let nAdvice = "Nitrogen levels are within optimal range for standard crops.";
  if (nitrogen < 200) {
    nStatus = "Deficient";
    nScore = 55;
    const penalty = 18;
    baseScore -= penalty;
    deductions.push({ parameter: "Nitrogen Deficit", pointsLost: penalty, formula: `280 - ${nitrogen} kg/ha deficit`, reason: "Low nitrogen restricts chlorophyll synthesis and vegetative biomass." });
    nAdvice = "Nitrogen is below the recommended range. Consider nitrogen management according to local agricultural guidance.";
  } else if (nitrogen > 500) {
    nStatus = "High / Excessive";
    nScore = 70;
    const penalty = 10;
    baseScore -= penalty;
    deductions.push({ parameter: "Excess Nitrogen", pointsLost: penalty, formula: `${nitrogen} > 500 kg/ha`, reason: "Excessive urea leads to vegetative lodging and root burning." });
    nAdvice = "Nitrogen is high. Reduce urea top-dressing to prevent vegetative lodging.";
  }

  // 2. Phosphorus Bio-availability Penalty
  const pBioFactor = calculatePhosphorusBioAvailability(ph);
  const effectiveP = Math.round(phosphorus * pBioFactor);
  let pStatus = "Optimal";
  let pScore = 90;
  let pAdvice = `Phosphorus level (${phosphorus} kg/ha) supports root development. (Bio-availability factor: ${pBioFactor} at pH ${ph}).`;
  if (effectiveP < 20) {
    pStatus = "Low (Bound)";
    pScore = 60;
    const penalty = 12;
    baseScore -= penalty;
    deductions.push({ parameter: "Phosphorus Fixation", pointsLost: penalty, formula: `${phosphorus} kg/ha × ${pBioFactor} factor = ${effectiveP} effective P`, reason: "Soil pH fixes phosphorus into insoluble aluminum/calcium phosphates." });
    pAdvice = "Bio-available phosphorus is low due to pH binding. Single Super Phosphate (SSP) or organic amendment recommended.";
  }

  // 3. Potassium Status (Ideal: 140-280 kg/ha)
  let kStatus = "High";
  let kScore = 92;
  let kAdvice = "Potassium levels are robust, promoting stomatal regulation and drought tolerance.";

  // 4. pH Penalty (Optimal: 6.5 - 7.5)
  let phStatus = "Optimal";
  let phScore = 95;
  let phAdvice = "pH level is ideal for maximum nutrient bioavailability.";
  if (ph < 6.0) {
    phStatus = "Acidic";
    phScore = 65;
    const penalty = 15;
    baseScore -= penalty;
    deductions.push({ parameter: "Soil Acidity", pointsLost: penalty, formula: `pH ${ph} < 6.0`, reason: "Acidic soil causes aluminum toxicity and reduces NPK absorption." });
    phAdvice = "Soil is acidic. Agricultural lime application may be advised by KVK.";
  } else if (ph > 8.0) {
    phStatus = "Alkaline";
    phScore = 65;
    const penalty = 15;
    baseScore -= penalty;
    deductions.push({ parameter: "Soil Alkalinity", pointsLost: penalty, formula: `pH ${ph} > 8.0`, reason: "Alkaline soil causes micronutrient (Zinc, Iron) deficiency." });
    phAdvice = "Soil is alkaline. Gypsum or organic compost application helps normalize pH.";
  }

  // 5. Organic Carbon Penalty (Ideal: > 0.50%)
  if (organicCarbon < 0.50) {
    const penalty = 10;
    baseScore -= penalty;
    deductions.push({ parameter: "Low Organic Carbon", pointsLost: penalty, formula: `${organicCarbon}% < 0.50%`, reason: "Low organic matter reduces soil cation exchange capacity (CEC) and moisture holding capacity." });
  }

  // Calculate Final Soil Score
  const overallScore = Math.max(40, Math.min(100, Math.round(baseScore)));

  return {
    overallScore,
    statusSummary: overallScore > 80 ? "Healthy Soil" : overallScore > 65 ? "Moderate Fertility" : "Requires Amendment",
    breakdown: [
      { name: "Nitrogen (N)", value: nitrogen, unit: "kg/ha", status: nStatus, score: nScore, ideal: "280 - 560", advice: nAdvice },
      { name: "Phosphorus (P)", value: phosphorus, unit: "kg/ha", status: pStatus, score: pScore, ideal: "23 - 56", advice: pAdvice },
      { name: "Potassium (K)", value: potassium, unit: "kg/ha", status: kStatus, score: kScore, ideal: "140 - 280", advice: kAdvice },
      { name: "pH Level", value: ph, unit: "pH", status: phStatus, score: phScore, ideal: "6.5 - 7.5", advice: phAdvice },
      { name: "Organic Carbon (OC)", value: organicCarbon, unit: "%", status: organicCarbon >= 0.5 ? "Good" : "Low", score: organicCarbon >= 0.5 ? 85 : 60, ideal: "> 0.50%", advice: "FYM or compost addition enhances organic matter." },
      { name: "Electrical Conductivity (EC)", value: electricalConductivity, unit: "dS/m", status: "Normal", score: 90, ideal: "< 1.0", advice: "Salinity level is safe for sensitive crops." }
    ],
    xaiAttribution: {
      formula: `Score = 100 - ∑(Penalties) = 100 - ${100 - overallScore} = ${overallScore}`,
      deductions
    },
    summaryAdvice: `Soil Fertility Score is ${overallScore}/100. ${nAdvice}`
  };
}

/* Module Exports */
exports.analyzeSoilHealth = analyzeSoilHealth;
