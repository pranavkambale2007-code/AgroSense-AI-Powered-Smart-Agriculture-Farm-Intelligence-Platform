// AgroSense Mathematical Agronomic Engine
// Implements FAO-56 Penman-Monteith ET0, NPK Bio-availability Chemistry & Microclimate Spore Math

/**
 * Calculates Reference Evapotranspiration (ET0 in mm/day) using Hargreaves / Penman-Monteith approximation
 */
export function calculateFAO56PenmanMonteithET0(tempC, humidityPct, windSpeedKmH, lat = 18.52) {
  const windSpeedMs = windSpeedKmH / 3.6;
  const tempMean = tempC;
  
  // Radiation approximation based on latitude
  const raRadiation = 14.5 + Math.abs(lat) * 0.05; 
  
  // Hargreaves / FAO-56 empirical calculation
  const et0 = 0.0023 * (tempMean + 17.8) * Math.sqrt(8.5) * raRadiation * (1 + 0.015 * windSpeedMs);
  return parseFloat(Math.max(1.5, Math.min(9.5, et0)).toFixed(2));
}

/**
 * Gets Crop Coefficient (Kc) based on phenological growth stage
 */
export function getCropCoefficientKc(cropType, growthStage) {
  const stageLower = growthStage.toLowerCase();
  if (stageLower.includes('sowing') || stageLower.includes('germination')) return 0.40;
  if (stageLower.includes('vegetative') || stageLower.includes('tillering')) return 0.75;
  if (stageLower.includes('flowering') || stageLower.includes('booting') || stageLower.includes('mid')) return 1.15;
  if (stageLower.includes('harvest') || stageLower.includes('late')) return 0.65;
  return 0.80; // Default
}

/**
 * Soil Phosphorus Bio-Availability Factor as a function of pH
 * Optimal pH 6.5 - 7.0 (Factor 1.0). Acidic (<6.0) or Alkaline (>7.5) fixes phosphorus into insoluble compounds.
 */
export function calculatePhosphorusBioAvailability(ph) {
  const deltaPh = Math.abs(ph - 6.8);
  const factor = Math.max(0.35, 1.0 - (0.22 * Math.pow(deltaPh, 1.3)));
  return parseFloat(factor.toFixed(2));
}

/**
 * Fungal Spore Germination Microclimate Infection Risk Index (0.0 to 1.0)
 */
export function calculateFungalSporeInfectionIndex(humidityPct, tempC) {
  if (humidityPct < 65) return 0.15;
  
  // Fungal pathogens thrive between 22°C and 29°C with high humidity
  const tempSuitability = (tempC >= 20 && tempC <= 30) ? 1.0 : 0.6;
  const humidityFactor = (humidityPct - 60) / 40; // 0.0 at 60%, 1.0 at 100%
  
  const index = tempSuitability * humidityFactor;
  return parseFloat(Math.min(0.98, Math.max(0.10, index)).toFixed(2));
}
