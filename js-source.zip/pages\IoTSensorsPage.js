// AgroSense IoT Telemetry Dashboard Page Component

const { renderSensorChartContainer, drawSensorChart } = require('js/components/SensorChart.js');

function renderIoTSensorsPage(state) {
  const timeframe = state.sensorTimeframe || '24h';

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="cpu" class="w-6 h-6 text-emerald-400"></i>
            IoT Sensor Telemetry Dashboard
          </h1>
          <p class="text-xs text-gray-400">Live soil probes, microclimate sensors, and groundwater level telemetry streams</p>
        </div>
        <span class="prototype-badge">SIMULATED SENSOR DATA</span>
      </div>

      <!-- Telemetry Chart Component -->
      ${renderSensorChartContainer(timeframe)}

      <!-- Individual Sensor Node Status Cards -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="glass-card p-4 space-y-2">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-gray-400">Node 01 — Soil Probe</span>
            <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-mono font-bold">ONLINE</span>
          </div>
          <div class="text-xl font-bold text-white font-mono">Moisture: 32.4% | pH: 7.2</div>
          <p class="text-[11px] text-gray-400">Last telemetry frame: 12 seconds ago</p>
        </div>

        <div class="glass-card p-4 space-y-2">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-gray-400">Node 02 — Microclimate station</span>
            <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-mono font-bold">ONLINE</span>
          </div>
          <div class="text-xl font-bold text-amber-300 font-mono">Temp: 24.5°C | Hum: 68%</div>
          <p class="text-[11px] text-gray-400">Last telemetry frame: 8 seconds ago</p>
        </div>

        <div class="glass-card p-4 space-y-2">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-gray-400">Node 03 — Borewell level</span>
            <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-mono font-bold">ONLINE</span>
          </div>
          <div class="text-xl font-bold text-blue-300 font-mono">Water Table: 18.5 m</div>
          <p class="text-[11px] text-gray-400">Last telemetry frame: 45 seconds ago</p>
        </div>
      </div>
    </div>
  `;
}

function initIoTSensorHooks(state) {
  drawSensorChart(state.sensorTimeframe || '24h');
}

/* Module Exports */
exports.renderIoTSensorsPage = renderIoTSensorsPage; exports.initIoTSensorHooks = initIoTSensorHooks;
