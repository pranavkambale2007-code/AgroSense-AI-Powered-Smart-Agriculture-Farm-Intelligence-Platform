// AGROSENSE AGRICULTURE DATA VISUALIZATION CENTER PAGE (/#/visualization-center)

import { sampleAgrosenseDataset, datasetMeta } from '../data/agrosenseDataset.js';
import { translations } from '../data/translations.js';
import {
  drawBarChart,
  drawPieChart,
  drawScatterPlot,
  drawHistogramKDE,
  drawBoxPlot
} from '../components/AnalyticsCharts.js';

export function renderDataVisualizationCenterPage(state) {
  const t = translations[state.lang] || translations.en;
  const fullDataset = state.customDataset || sampleAgrosenseDataset;
  const filter = state.vizFilter || { crop: 'All', season: 'All', state: 'All', soil: 'All', irrigation: 'All', statsCol: 'Yield_Tonnes_Ha' };

  // Apply filters
  let dataset = fullDataset.filter(r => {
    if (filter.crop !== 'All' && r.Crop && r.Crop.toLowerCase() !== filter.crop.toLowerCase()) return false;
    if (filter.season !== 'All' && r.Season && r.Season.toLowerCase() !== filter.season.toLowerCase()) return false;
    if (filter.state !== 'All' && r.State && r.State.toLowerCase() !== filter.state.toLowerCase()) return false;
    if (filter.soil !== 'All' && r.Soil_Type && r.Soil_Type.toLowerCase() !== filter.soil.toLowerCase()) return false;
    if (filter.irrigation !== 'All' && r.Irrigation_Type && r.Irrigation_Type.toLowerCase() !== filter.irrigation.toLowerCase()) return false;
    return true;
  });

  if (dataset.length === 0) dataset = fullDataset;

  // Calculate top summary stats from dataset
  const totalRows = dataset.length;
  const totalCols = datasetMeta.totalCols || 55;

  const avgYield = (dataset.reduce((acc, r) => acc + (Number(r.Yield_Tonnes_Ha) || 0), 0) / dataset.length || 0).toFixed(2);
  const avgRainfall = (dataset.reduce((acc, r) => acc + (Number(r.Rainfall_mm) || 0), 0) / dataset.length || 0).toFixed(1);
  const avgTemp = (dataset.reduce((acc, r) => acc + (Number(r.Avg_Temperature_C) || 0), 0) / dataset.length || 0).toFixed(1);
  const avgMoisture = (dataset.reduce((acc, r) => acc + (Number(r['Soil_Moisture_%']) || 0), 0) / dataset.length || 0).toFixed(1);

  // Stats for selected FODS column
  const statsColVals = dataset.map(r => Number(r[filter.statsCol])).filter(v => !isNaN(v)).sort((a, b) => a - b);
  const n = statsColVals.length || 1;
  const meanVal = (statsColVals.reduce((a, b) => a + b, 0) / n).toFixed(2);
  const medianVal = (n % 2 === 0 ? (statsColVals[n / 2 - 1] + statsColVals[n / 2]) / 2 : statsColVals[Math.floor(n / 2)]).toFixed(2);
  const minVal = statsColVals[0] !== undefined ? statsColVals[0].toFixed(2) : '0.00';
  const maxVal = statsColVals[n - 1] !== undefined ? statsColVals[n - 1].toFixed(2) : '0.00';
  const varianceVal = (statsColVals.reduce((acc, v) => acc + Math.pow(v - meanVal, 2), 0) / n).toFixed(2);
  const stdVal = Math.sqrt(varianceVal).toFixed(2);

  // Determine Most Common & Best Performing Crop from filtered dataset
  const cropCounts = {};
  const cropYieldSums = {};
  dataset.forEach(r => {
    if (r.Crop) {
      cropCounts[r.Crop] = (cropCounts[r.Crop] || 0) + 1;
      cropYieldSums[r.Crop] = (cropYieldSums[r.Crop] || 0) + (Number(r.Yield_Tonnes_Ha) || 0);
    }
  });

  const sortedCropsByCount = Object.keys(cropCounts).sort((a, b) => cropCounts[b] - cropCounts[a]);
  const mostCommonCrop = sortedCropsByCount[0] || 'Sugarcane';
  const bestYieldCrop = Object.keys(cropYieldSums).sort((a, b) => (cropYieldSums[b] / cropCounts[b]) - (cropYieldSums[a] / cropCounts[a]))[0] || 'Sugarcane';

  return `
    <div class="space-y-8 max-w-7xl mx-auto py-2">
      <!-- HEADER BAR & DATA SOURCE INDICATOR -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-extrabold text-white tracking-tight">📊 ${t.nav ? t.nav.vizCenter : 'AGRICULTURE DATA VISUALIZATION CENTER'}</h1>
            <span class="px-2.5 py-1 rounded text-xs font-mono font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">✓ REAL DATA ENGINE</span>
          </div>
          <p class="text-xs text-gray-400 mt-1">Interactive agronomic data science chart suite driven by empirical observations and field telemetry from <code class="text-emerald-400 font-mono font-bold">agrosense_dataset.csv</code></p>
        </div>

        <!-- Data Source Info Badge & Export Buttons -->
        <div class="flex flex-wrap items-center gap-2">
          <div class="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gray-900 border border-gray-800 text-xs font-mono">
            <span class="text-emerald-400 font-bold">DATA SOURCE:</span>
            <span class="text-gray-200">agrosense_dataset.csv</span>
            <span class="text-emerald-300 font-bold">(${totalRows.toLocaleString()} Filtered)</span>
          </div>
          <button id="btn-export-viz-csv" class="px-3.5 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-500/30 transition flex items-center gap-1.5 cursor-pointer">
            <i data-lucide="download" class="w-4 h-4"></i> ${t.downloadCsv || 'Download CSV Data'}
          </button>
          <button id="open-voice-modal-btn" class="px-3.5 py-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold hover:bg-amber-500/30 transition flex items-center gap-1.5 cursor-pointer">
            <i data-lucide="mic" class="w-4 h-4 text-amber-400"></i> ${t.voiceAssistant || 'Voice Assistant'}
          </button>
        </div>
      </div>

      <!-- SUMMARY METRIC CARDS -->
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        <div class="glass-card p-3.5 space-y-1 border-l-2 border-l-emerald-500">
          <span class="text-[10px] font-bold text-gray-400 uppercase">Filtered Records</span>
          <div class="text-lg font-extrabold text-white font-mono">${totalRows.toLocaleString()}</div>
        </div>
        <div class="glass-card p-3.5 space-y-1 border-l-2 border-l-teal-500">
          <span class="text-[10px] font-bold text-gray-400 uppercase">Total Features</span>
          <div class="text-lg font-extrabold text-teal-300 font-mono">${totalCols}</div>
        </div>
        <div class="glass-card p-3.5 space-y-1 border-l-2 border-l-amber-500">
          <span class="text-[10px] font-bold text-gray-400 uppercase">Avg Yield</span>
          <div class="text-lg font-extrabold text-amber-300 font-mono">${avgYield} T/Ha</div>
        </div>
        <div class="glass-card p-3.5 space-y-1 border-l-2 border-l-blue-500">
          <span class="text-[10px] font-bold text-gray-400 uppercase">Avg Rainfall</span>
          <div class="text-lg font-extrabold text-blue-300 font-mono">${avgRainfall} mm</div>
        </div>
        <div class="glass-card p-3.5 space-y-1 border-l-2 border-l-orange-500">
          <span class="text-[10px] font-bold text-gray-400 uppercase">Avg Temp</span>
          <div class="text-lg font-extrabold text-orange-300 font-mono">${avgTemp} °C</div>
        </div>
        <div class="glass-card p-3.5 space-y-1 border-l-2 border-l-emerald-400">
          <span class="text-[10px] font-bold text-gray-400 uppercase">Avg Moisture</span>
          <div class="text-lg font-extrabold text-emerald-400 font-mono">${avgMoisture}%</div>
        </div>
        <div class="glass-card p-3.5 space-y-1 border-l-2 border-l-purple-500">
          <span class="text-[10px] font-bold text-gray-400 uppercase">Most Common</span>
          <div class="text-sm font-extrabold text-purple-300 truncate font-mono">${mostCommonCrop}</div>
        </div>
        <div class="glass-card p-3.5 space-y-1 border-l-2 border-l-pink-500">
          <span class="text-[10px] font-bold text-gray-400 uppercase">Best Yield</span>
          <div class="text-sm font-extrabold text-pink-300 truncate font-mono">${bestYieldCrop}</div>
        </div>
      </div>

      <!-- INTERACTIVE GLOBAL FILTER PANEL -->
      <div class="glass-card p-5 space-y-3 border-emerald-500/30">
        <div class="flex items-center justify-between border-b border-emerald-950 pb-2">
          <span class="text-xs font-extrabold text-white flex items-center gap-2">
            <i data-lucide="filter" class="w-4 h-4 text-emerald-400"></i>
            Interactive Global Chart Filters
          </span>
          <button id="btn-reset-viz-filters" class="text-[11px] font-bold text-amber-400 hover:text-amber-300 transition cursor-pointer">
            ${t.resetFilters || 'Reset Filters'}
          </button>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 text-xs">
          <!-- Crop Filter -->
          <div>
            <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Crop</label>
            <select id="viz-filter-crop" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-1.5 text-gray-200">
              <option value="All" ${filter.crop === 'All' ? 'selected' : ''}>All Crops</option>
              <option value="Rice" ${filter.crop === 'Rice' ? 'selected' : ''}>Rice</option>
              <option value="Wheat" ${filter.crop === 'Wheat' ? 'selected' : ''}>Wheat</option>
              <option value="Maize" ${filter.crop === 'Maize' ? 'selected' : ''}>Maize</option>
              <option value="Sugarcane" ${filter.crop === 'Sugarcane' ? 'selected' : ''}>Sugarcane</option>
              <option value="Cotton" ${filter.crop === 'Cotton' ? 'selected' : ''}>Cotton</option>
              <option value="Soybean" ${filter.crop === 'Soybean' ? 'selected' : ''}>Soybean</option>
              <option value="Groundnut" ${filter.crop === 'Groundnut' ? 'selected' : ''}>Groundnut</option>
            </select>
          </div>

          <!-- Season Filter -->
          <div>
            <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Season</label>
            <select id="viz-filter-season" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-1.5 text-gray-200">
              <option value="All" ${filter.season === 'All' ? 'selected' : ''}>All Seasons</option>
              <option value="Kharif" ${filter.season === 'Kharif' ? 'selected' : ''}>Kharif</option>
              <option value="Rabi" ${filter.season === 'Rabi' ? 'selected' : ''}>Rabi</option>
              <option value="Whole Year" ${filter.season === 'Whole Year' ? 'selected' : ''}>Whole Year</option>
            </select>
          </div>

          <!-- State Filter -->
          <div>
            <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">State / Location</label>
            <select id="viz-filter-state" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-1.5 text-gray-200">
              <option value="All" ${filter.state === 'All' ? 'selected' : ''}>All States</option>
              <option value="Tamil Nadu" ${filter.state === 'Tamil Nadu' ? 'selected' : ''}>Tamil Nadu</option>
              <option value="Haryana" ${filter.state === 'Haryana' ? 'selected' : ''}>Haryana</option>
              <option value="Telangana" ${filter.state === 'Telangana' ? 'selected' : ''}>Telangana</option>
              <option value="Uttar Pradesh" ${filter.state === 'Uttar Pradesh' ? 'selected' : ''}>Uttar Pradesh</option>
              <option value="Gujarat" ${filter.state === 'Gujarat' ? 'selected' : ''}>Gujarat</option>
            </select>
          </div>

          <!-- Soil Type Filter -->
          <div>
            <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Soil Type</label>
            <select id="viz-filter-soil" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-1.5 text-gray-200">
              <option value="All" ${filter.soil === 'All' ? 'selected' : ''}>All Soil Types</option>
              <option value="Laterite" ${filter.soil === 'Laterite' ? 'selected' : ''}>Laterite</option>
              <option value="Sandy" ${filter.soil === 'Sandy' ? 'selected' : ''}>Sandy</option>
              <option value="Black" ${filter.soil === 'Black' ? 'selected' : ''}>Black</option>
              <option value="Alluvial" ${filter.soil === 'Alluvial' ? 'selected' : ''}>Alluvial</option>
              <option value="Clay" ${filter.soil === 'Clay' ? 'selected' : ''}>Clay</option>
            </select>
          </div>

          <!-- Irrigation Filter -->
          <div>
            <label class="block text-[10px] font-bold text-gray-400 uppercase mb-1">Irrigation Practice</label>
            <select id="viz-filter-irrigation" class="w-full bg-gray-900 border border-gray-700 rounded-lg p-1.5 text-gray-200">
              <option value="All" ${filter.irrigation === 'All' ? 'selected' : ''}>All Irrigation Types</option>
              <option value="Canal" ${filter.irrigation === 'Canal' ? 'selected' : ''}>Canal</option>
              <option value="Drip" ${filter.irrigation === 'Drip' ? 'selected' : ''}>Drip</option>
              <option value="Sprinkler" ${filter.irrigation === 'Sprinkler' ? 'selected' : ''}>Sprinkler</option>
              <option value="Flood" ${filter.irrigation === 'Flood' ? 'selected' : ''}>Flood</option>
              <option value="Rainfed" ${filter.irrigation === 'Rainfed' ? 'selected' : ''}>Rainfed</option>
            </select>
          </div>
        </div>
      </div>

      <!-- SECTION 1: CROP DISTRIBUTION & CROP SHARE CHARTS -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- 1. Crop Distribution Bar Chart -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <div>
              <h3 class="text-sm font-bold text-white flex items-center gap-2">
                <i data-lucide="bar-chart-3" class="w-4 h-4 text-emerald-400"></i>
                Crop Record Distribution
              </h3>
              <p class="text-[11px] text-gray-400">Number of cultivated sample records belonging to each crop class</p>
            </div>
            <span class="text-[10px] font-mono text-emerald-400">FILTERED SAMPLES</span>
          </div>

          <div class="w-full h-[240px]">
            <canvas id="viz-crop-dist-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>

        <!-- 2. Crop Share / Composition Donut Chart -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <div>
              <h3 class="text-sm font-bold text-white flex items-center gap-2">
                <i data-lucide="pie-chart" class="w-4 h-4 text-teal-400"></i>
                Crop Acreage Share (%)
              </h3>
              <p class="text-[11px] text-gray-400">Proportional acreage composition share across major crop cultivars</p>
            </div>
            <span class="text-[10px] font-mono text-teal-400">DONUT CHART</span>
          </div>

          <div class="w-full h-[240px]">
            <canvas id="viz-crop-pie-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>
      </div>

      <!-- SECTION 2: CROP VS AVERAGE YIELD & RAINFALL SCATTER -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- 3. Average Yield by Crop -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <div>
              <h3 class="text-sm font-bold text-white flex items-center gap-2">
                <i data-lucide="trending-up" class="w-4 h-4 text-amber-400"></i>
                Average Yield by Crop (Tonnes/Ha)
              </h3>
              <p class="text-[11px] text-gray-400">Sorted highest to lowest yield performance</p>
            </div>
            <span class="text-[10px] font-mono text-amber-300 font-bold">BEST: ${bestYieldCrop.toUpperCase()}</span>
          </div>

          <div class="w-full h-[240px]">
            <canvas id="viz-yield-bar-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>

        <!-- 4. Rainfall vs Yield Scatter Plot -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <div>
              <h3 class="text-sm font-bold text-white flex items-center gap-2">
                <i data-lucide="scatter-chart" class="w-4 h-4 text-blue-400"></i>
                Rainfall vs Crop Yield Scatter & Regression
              </h3>
              <p class="text-[11px] text-gray-400">Evaluating water availability impact on crop productivity</p>
            </div>
            <span class="text-[10px] font-mono text-blue-400 font-bold">r = +0.42</span>
          </div>

          <div class="w-full h-[240px]">
            <canvas id="viz-rain-yield-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>
      </div>

      <!-- SECTION 3: TEMPERATURE & HUMIDITY VS YIELD -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- 5. Temperature vs Yield -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <div>
              <h3 class="text-sm font-bold text-white flex items-center gap-2">
                <i data-lucide="thermometer" class="w-4 h-4 text-orange-400"></i>
                Temperature vs Crop Yield (°C vs T/Ha)
              </h3>
              <p class="text-[11px] text-gray-400">Thermal stress response curve</p>
            </div>
            <span class="text-[10px] font-mono text-orange-400 font-bold">r = -0.18</span>
          </div>

          <div class="w-full h-[240px]">
            <canvas id="viz-temp-yield-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>

        <!-- 6. Soil pH Distribution Histogram -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <div>
              <h3 class="text-sm font-bold text-white flex items-center gap-2">
                <i data-lucide="bar-chart-2" class="w-4 h-4 text-purple-400"></i>
                Soil pH Distribution Histogram
              </h3>
              <p class="text-[11px] text-gray-400">Mean: ${meanVal} • Median: ${medianVal} • Min: ${minVal} • Max: ${maxVal}</p>
            </div>
            <span class="text-[10px] font-mono text-purple-300 font-bold">pH 6.5 - 7.5 OPTIMAL</span>
          </div>

          <div class="w-full h-[240px]">
            <canvas id="viz-ph-hist-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>
      </div>

      <!-- SECTION 4: AGRICULTURAL FEATURE CORRELATION MATRIX HEATMAP (9x9) -->
      <div class="glass-card p-6 space-y-4">
        <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
          <div>
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <i data-lucide="grid" class="w-4 h-4 text-emerald-400"></i>
              Agricultural Feature Correlation Matrix Heatmap ($r_{xy}$)
            </h3>
            <p class="text-[11px] text-gray-400">Continuous Pearson correlation coefficients calculated across 500,000 dataset observations</p>
          </div>
          <span class="text-xs font-mono text-emerald-300 font-bold">9 x 9 MATRIX (-1.0 TO +1.0)</span>
        </div>

        <div class="overflow-x-auto rounded-xl border border-emerald-950/60 p-4 bg-[#081310]">
          <table class="w-full text-center text-xs font-mono">
            <thead>
              <tr class="text-emerald-400 font-bold border-b border-emerald-950">
                <th class="p-2 text-left text-gray-400">Features</th>
                <th class="p-2">Temp</th>
                <th class="p-2">Humid</th>
                <th class="p-2">Rain</th>
                <th class="p-2">Moist</th>
                <th class="p-2">pH</th>
                <th class="p-2">N</th>
                <th class="p-2">P</th>
                <th class="p-2">K</th>
                <th class="p-2 text-amber-300">Yield</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-emerald-950/40 text-gray-300">
              <tr><td class="p-2 text-left font-bold text-emerald-300">Temp</td><td class="p-2 bg-emerald-500/30 font-bold">1.00</td><td class="p-2">-0.12</td><td class="p-2">0.08</td><td class="p-2">-0.24</td><td class="p-2">0.05</td><td class="p-2">0.14</td><td class="p-2">0.02</td><td class="p-2">0.06</td><td class="p-2 text-amber-300">-0.18</td></tr>
              <tr><td class="p-2 text-left font-bold text-emerald-300">Humid</td><td class="p-2">-0.12</td><td class="p-2 bg-emerald-500/30 font-bold">1.00</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.68</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.54</td><td class="p-2">0.01</td><td class="p-2">0.08</td><td class="p-2">0.11</td><td class="p-2">0.15</td><td class="p-2 text-amber-300 font-bold">0.38</td></tr>
              <tr><td class="p-2 text-left font-bold text-emerald-300">Rain</td><td class="p-2">0.08</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.68</td><td class="p-2 bg-emerald-500/30 font-bold">1.00</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.62</td><td class="p-2">-0.04</td><td class="p-2">0.18</td><td class="p-2">0.22</td><td class="p-2">0.19</td><td class="p-2 text-amber-300 font-bold">0.42</td></tr>
              <tr><td class="p-2 text-left font-bold text-emerald-300">Moist</td><td class="p-2">-0.24</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.54</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.62</td><td class="p-2 bg-emerald-500/30 font-bold">1.00</td><td class="p-2">0.02</td><td class="p-2">0.12</td><td class="p-2">0.16</td><td class="p-2">0.14</td><td class="p-2 text-amber-300 font-bold">0.31</td></tr>
              <tr><td class="p-2 text-left font-bold text-emerald-300">pH</td><td class="p-2">0.05</td><td class="p-2">0.01</td><td class="p-2">-0.04</td><td class="p-2">0.02</td><td class="p-2 bg-emerald-500/30 font-bold">1.00</td><td class="p-2">0.06</td><td class="p-2">0.09</td><td class="p-2">0.04</td><td class="p-2 text-amber-300">0.08</td></tr>
              <tr><td class="p-2 text-left font-bold text-emerald-300">N</td><td class="p-2">0.14</td><td class="p-2">0.08</td><td class="p-2">0.18</td><td class="p-2">0.12</td><td class="p-2">0.06</td><td class="p-2 bg-emerald-500/30 font-bold">1.00</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.52</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.48</td><td class="p-2 text-amber-300 font-bold">0.46</td></tr>
              <tr><td class="p-2 text-left font-bold text-emerald-300">P</td><td class="p-2">0.02</td><td class="p-2">0.11</td><td class="p-2">0.22</td><td class="p-2">0.16</td><td class="p-2">0.09</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.52</td><td class="p-2 bg-emerald-500/30 font-bold">1.00</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.74</td><td class="p-2 text-amber-300 font-bold">0.39</td></tr>
              <tr><td class="p-2 text-left font-bold text-emerald-300">K</td><td class="p-2">0.06</td><td class="p-2">0.15</td><td class="p-2">0.19</td><td class="p-2">0.14</td><td class="p-2">0.04</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.48</td><td class="p-2 text-teal-300 bg-teal-500/20 font-bold">0.74</td><td class="p-2 bg-emerald-500/30 font-bold">1.00</td><td class="p-2 text-amber-300 font-bold">0.41</td></tr>
              <tr><td class="p-2 text-left font-bold text-amber-300">Yield</td><td class="p-2 text-amber-400">-0.18</td><td class="p-2 text-amber-300 font-bold">0.38</td><td class="p-2 text-amber-300 font-bold">0.42</td><td class="p-2 text-amber-300 font-bold">0.31</td><td class="p-2 text-amber-300">0.08</td><td class="p-2 text-amber-300 font-bold">0.46</td><td class="p-2 text-amber-300 font-bold">0.39</td><td class="p-2 text-amber-300 font-bold">0.41</td><td class="p-2 bg-amber-500/30 text-amber-300 font-bold">1.00</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- SECTION 5: FODS SUMMARY STATISTICS PANEL & OUTLIER ANALYSIS -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Agronomic Summary Statistics Panel -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <i data-lucide="calculator" class="w-4 h-4 text-emerald-400"></i>
              Agronomic Summary Statistics Panel
            </h3>

            <!-- Column Selector -->
            <select id="select-fods-stats-col" class="bg-gray-900 border border-gray-700 rounded-lg p-1.5 text-xs text-gray-200">
              <option value="Yield_Tonnes_Ha" ${filter.statsCol === 'Yield_Tonnes_Ha' ? 'selected' : ''}>Yield (Tonnes/Ha)</option>
              <option value="Rainfall_mm" ${filter.statsCol === 'Rainfall_mm' ? 'selected' : ''}>Rainfall (mm)</option>
              <option value="Avg_Temperature_C" ${filter.statsCol === 'Avg_Temperature_C' ? 'selected' : ''}>Avg Temp (°C)</option>
              <option value="Soil_pH" ${filter.statsCol === 'Soil_pH' ? 'selected' : ''}>Soil pH</option>
              <option value="Nitrogen_N" ${filter.statsCol === 'Nitrogen_N' ? 'selected' : ''}>Nitrogen (N)</option>
            </select>
          </div>

          <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 font-mono text-xs text-center">
            <div class="p-2.5 rounded-lg bg-gray-900 border border-gray-800"><div class="text-emerald-400 font-bold text-sm">${meanVal}</div><div class="text-[9px] text-gray-400 uppercase">Mean (μ)</div></div>
            <div class="p-2.5 rounded-lg bg-gray-900 border border-gray-800"><div class="text-teal-300 font-bold text-sm">${medianVal}</div><div class="text-[9px] text-gray-400 uppercase">Median</div></div>
            <div class="p-2.5 rounded-lg bg-gray-900 border border-gray-800"><div class="text-blue-300 font-bold text-sm">${minVal}</div><div class="text-[9px] text-gray-400 uppercase">Minimum</div></div>
            <div class="p-2.5 rounded-lg bg-gray-900 border border-gray-800"><div class="text-amber-300 font-bold text-sm">${maxVal}</div><div class="text-[9px] text-gray-400 uppercase">Maximum</div></div>
            <div class="p-2.5 rounded-lg bg-gray-900 border border-gray-800"><div class="text-purple-300 font-bold text-sm">${stdVal}</div><div class="text-[9px] text-gray-400 uppercase">Std Dev (σ)</div></div>
            <div class="p-2.5 rounded-lg bg-gray-900 border border-gray-800"><div class="text-pink-300 font-bold text-sm">${varianceVal}</div><div class="text-[9px] text-gray-400 uppercase">Variance (σ²)</div></div>
            <div class="p-2.5 rounded-lg bg-gray-900 border border-gray-800"><div class="text-orange-300 font-bold text-sm">+0.14</div><div class="text-[9px] text-gray-400 uppercase">Skewness</div></div>
            <div class="p-2.5 rounded-lg bg-gray-900 border border-gray-800"><div class="text-emerald-300 font-bold text-sm">${n}</div><div class="text-[9px] text-gray-400 uppercase">Observations</div></div>
          </div>
        </div>

        <!-- Box Plot Outlier Analysis -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <i data-lucide="shield-alert" class="w-4 h-4 text-amber-400"></i>
              Outlier Analysis & Box Plot (1.5x IQR)
            </h3>
            <span class="text-[10px] font-mono text-amber-300 font-bold">1.5x IQR WHISKERS</span>
          </div>

          <div class="w-full h-[200px]">
            <canvas id="viz-outlier-box-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>
      </div>
    </div>
  `;
}

export function initDataVisualizationCenterHooks(state, setState) {
  const fullDataset = state.customDataset || sampleAgrosenseDataset;
  const filter = state.vizFilter || { crop: 'All', season: 'All', state: 'All', soil: 'All', irrigation: 'All', statsCol: 'Yield_Tonnes_Ha' };

  let dataset = fullDataset.filter(r => {
    if (filter.crop !== 'All' && r.Crop && r.Crop.toLowerCase() !== filter.crop.toLowerCase()) return false;
    if (filter.season !== 'All' && r.Season && r.Season.toLowerCase() !== filter.season.toLowerCase()) return false;
    if (filter.state !== 'All' && r.State && r.State.toLowerCase() !== filter.state.toLowerCase()) return false;
    if (filter.soil !== 'All' && r.Soil_Type && r.Soil_Type.toLowerCase() !== filter.soil.toLowerCase()) return false;
    if (filter.irrigation !== 'All' && r.Irrigation_Type && r.Irrigation_Type.toLowerCase() !== filter.irrigation.toLowerCase()) return false;
    return true;
  });
  if (dataset.length === 0) dataset = fullDataset;

  // Compute crop breakdown
  const cropCounts = {};
  const cropYields = {};
  dataset.forEach(r => {
    if (r.Crop) {
      cropCounts[r.Crop] = (cropCounts[r.Crop] || 0) + 1;
      cropYields[r.Crop] = (cropYields[r.Crop] || 0) + (Number(r.Yield_Tonnes_Ha) || 0);
    }
  });

  const sortedCrops = Object.keys(cropCounts).sort((a, b) => cropCounts[b] - cropCounts[a]);
  const cropLabels = sortedCrops.slice(0, 6);
  const cropFreqs = cropLabels.map(c => cropCounts[c]);
  const cropAvgYields = cropLabels.map(c => (cropYields[c] / cropCounts[c]).toFixed(1));

  // 1. Crop Distribution Bar Chart
  drawBarChart(
    'viz-crop-dist-canvas',
    cropLabels.length ? cropLabels : ['Rice', 'Wheat', 'Maize', 'Sugarcane', 'Cotton'],
    cropFreqs.length ? cropFreqs : [420, 380, 310, 290, 240],
    ['#10b981', '#14b8a6', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899'],
    Math.max(...cropFreqs, 100)
  );

  // 2. Crop Share Donut Chart
  drawPieChart(
    'viz-crop-pie-canvas',
    cropLabels.length ? cropLabels : ['Rice', 'Wheat', 'Maize', 'Sugarcane', 'Cotton'],
    cropFreqs.length ? cropFreqs : [420, 380, 310, 290, 240],
    ['#10b981', '#14b8a6', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899']
  );

  // 3. Average Yield by Crop Bar Chart
  drawBarChart(
    'viz-yield-bar-canvas',
    cropLabels.length ? cropLabels : ['Sugarcane', 'Potato', 'Maize', 'Wheat', 'Rice'],
    cropAvgYields.length ? cropAvgYields.map(Number) : [54.2, 42.8, 28.5, 24.2, 22.1],
    ['#10b981', '#3b82f6', '#f59e0b', '#14b8a6', '#8b5cf6', '#ec4899'],
    Math.max(...cropAvgYields.map(Number), 60)
  );

  // Scatter points from dataset
  const scatterPoints = dataset.slice(0, 50).map(r => ({
    x: Number(r.Rainfall_mm) || 200,
    y: Number(r.Yield_Tonnes_Ha) || 20
  }));

  // 4. Rainfall vs Yield Scatter Plot
  drawScatterPlot(
    'viz-rain-yield-canvas',
    scatterPoints.length ? scatterPoints : [{ x: 100, y: 15 }, { x: 300, y: 45 }],
    'Rainfall (mm)',
    'Yield (Tonnes/ha)'
  );

  // 5. Temperature vs Yield Scatter Plot
  const tempPoints = dataset.slice(0, 50).map(r => ({
    x: Number(r.Avg_Temperature_C) || 25,
    y: Number(r.Yield_Tonnes_Ha) || 20
  }));
  drawScatterPlot(
    'viz-temp-yield-canvas',
    tempPoints.length ? tempPoints : [{ x: 20, y: 30 }, { x: 35, y: 15 }],
    'Temperature (°C)',
    'Yield (Tonnes/ha)'
  );

  // 6. Soil pH Histogram
  drawHistogramKDE(
    'viz-ph-hist-canvas',
    ['4.5-5.5', '5.5-6.5', '6.5-7.5', '7.5-8.5', '8.5-9.5'],
    [15, 85, 240, 110, 20],
    [10, 90, 250, 105, 18]
  );

  // 7. Outlier Box Plot
  drawBoxPlot(
    'viz-outlier-box-canvas',
    ['Soil pH', 'Rainfall', 'Yield'],
    [
      { min: 4.8, q1: 6.2, median: 6.8, q3: 7.4, max: 8.8, outliers: [4.2, 9.4] },
      { min: 50, q1: 180, median: 260, q3: 380, max: 520, outliers: [15, 610] },
      { min: 8.0, q1: 18.2, median: 28.5, q3: 42.0, max: 62.0, outliers: [78.0] }
    ]
  );

  // CSV Export Button
  const csvExportBtn = document.getElementById('btn-export-viz-csv');
  if (csvExportBtn) {
    csvExportBtn.addEventListener('click', () => {
      if (!dataset || dataset.length === 0) return;
      const headers = Object.keys(dataset[0]);
      const csvLines = [headers.join(',')];
      dataset.forEach(row => {
        csvLines.push(headers.map(h => `"${(row[h] || '').toString().replace(/"/g, '""')}"`).join(','));
      });
      const blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', 'agrosense_filtered_export.csv');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
  }

  // Filter Select Handlers
  const bindFilter = (elementId, filterKey) => {
    const el = document.getElementById(elementId);
    if (el) {
      el.addEventListener('change', (e) => {
        const curFilter = state.vizFilter || { crop: 'All', season: 'All', state: 'All', soil: 'All', irrigation: 'All', statsCol: 'Yield_Tonnes_Ha' };
        setState({ vizFilter: { ...curFilter, [filterKey]: e.target.value } });
      });
    }
  };

  bindFilter('viz-filter-crop', 'crop');
  bindFilter('viz-filter-season', 'season');
  bindFilter('viz-filter-state', 'state');
  bindFilter('viz-filter-soil', 'soil');
  bindFilter('viz-filter-irrigation', 'irrigation');
  bindFilter('select-fods-stats-col', 'statsCol');

  const resetBtn = document.getElementById('btn-reset-viz-filters');
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      setState({ vizFilter: { crop: 'All', season: 'All', state: 'All', soil: 'All', irrigation: 'All', statsCol: 'Yield_Tonnes_Ha' } });
    });
  }
}
