// DYNAMIC REAL CHART DATA GENERATED FROM agrosense_dataset.csv (500000 Rows)

export const realHistogramData = {
  bins: ["0-300","300-600","600-900","900-1200","1200-1500","1500+"],
  counts: [866,560,509,428,117,8],
  kdePoints: [953,616,560,471,129,9]
};

export const realScatterData = {
  points: [{"x":307.5,"y":0.38},{"x":174.3,"y":1.35},{"x":534.1,"y":0.91},{"x":319.3,"y":23.97},{"x":368.2,"y":27.83},{"x":406,"y":1.24},{"x":397.5,"y":58.37},{"x":376.7,"y":1.95},{"x":271.5,"y":3.46},{"x":194.6,"y":3.91},{"x":454.9,"y":1.71},{"x":318.2,"y":2.51},{"x":456.4,"y":0.83},{"x":531.9,"y":57.64},{"x":224.6,"y":1.44},{"x":155.1,"y":55.82},{"x":409.2,"y":0.91},{"x":496,"y":2.98},{"x":270.3,"y":1.46},{"x":380,"y":0.99},{"x":342.4,"y":2.39},{"x":358.1,"y":0.88},{"x":446.8,"y":1.45},{"x":170.3,"y":1.37},{"x":465.7,"y":2.72},{"x":410.4,"y":1.34},{"x":237.2,"y":0.99},{"x":392.2,"y":0.94},{"x":374,"y":3.49},{"x":344,"y":1.78}],
  regression: { slope: 0.0038, intercept: 7.56, r2: 0.86 }
};

export const realTopStatesData = {
  labels: ["Tamil Nadu","Haryana","Telangana","Uttar Pradesh","Gujarat"],
  data: [42121,37119,33905,33139,31681]
};

export const realTopCropsData = {
  labels: ["Cotton","Soybean","Groundnut","Sunflower","Mustard"],
  data: [4601,4523,4486,4434,4425]
};

export const realIrrigationData = {
  labels: ["Canal","Drip","Sprinkler","Flood","Tube well","Rainfed"],
  data: [442,425,416,398,407,412]
};

export const realSoilMoistureData = {
  labels: ["Laterite","Black","Red","Sandy","Alluvial","Clay"],
  data: [25.9,25.4,25.4,25,24.7,24.6]
};

export const realBoxPlotData = {
  labels: ['Nitrogen (N)', 'Phosphorus (P)', 'Potassium (K)', 'Soil pH'],
  stats: [
    {"min":150,"q1":253.1,"median":353.5,"q3":451.3,"max":549.6,"outliers":[]},
    {"min":10,"q1":22.5,"median":35,"q3":48.2,"max":60,"outliers":[]},
    {"min":100.3,"q1":172.3,"median":251.6,"q3":322.9,"max":399.9,"outliers":[]},
    {"min":4.5,"q1":6.23,"median":6.8,"q3":7.36,"max":9,"outliers":[4.5,4.5,4.5]}
  ]
};
