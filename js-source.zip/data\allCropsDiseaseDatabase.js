// AgroSense Universal Plant Pathology & Agricultural Crop Disease Database
// Covers all genuine agricultural crops (cereals, pulses, oilseeds, cash crops, vegetables, spices, medicinal plants, fruits)

const { fruitCropsList, fruitDiseases, fruitHealthyReferenceModels } = require('js/data/fruitCropsDiseaseData.js');

const baseAgrosenseCropsList = [
  {
    "id": "c-01",
    "cropKey": "wheat",
    "name": "Wheat (गेहूं / गहू)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Wheat",
    "keyPests": "Yellow Rust, Karnal Bunt, Aphids",
    "agronomicTip": "Apply crown root initiation (CRI) irrigation at 21 DAS for maximum tillering."
  },
  {
    "id": "c-02",
    "cropKey": "rice",
    "name": "Paddy / Rice (धान / भात)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Paddy / Rice",
    "keyPests": "Stem Borer, Brown Planthopper, Blast",
    "agronomicTip": "Adopt alternate wetting and drying (AWD) to conserve up to 30% irrigation water."
  },
  {
    "id": "c-03",
    "cropKey": "basmati-rice",
    "name": "Basmati Rice (बासमती चावल)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Basmati Rice",
    "keyPests": "Bacterial Leaf Blight, Sheath Rot, Leaf Folder",
    "agronomicTip": "Ensure uniform transplantation with 20x15 cm spacing for aromatic grain elongation."
  },
  {
    "id": "c-04",
    "cropKey": "maize",
    "name": "Maize / Corn (मक्का / मका)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Maize / Corn",
    "keyPests": "Fall Armyworm, Stem Borer",
    "agronomicTip": "Install pheromone traps early for Fall Armyworm surveillance and biopesticide control."
  },
  {
    "id": "c-05",
    "cropKey": "barley",
    "name": "Barley (जौ / जाऊ)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Barley",
    "keyPests": "Covered Smut, Aphids",
    "agronomicTip": "Highly resilient to moderate soil salinity; excellent rotation crop after rice."
  },
  {
    "id": "c-06",
    "cropKey": "jowar",
    "name": "Sorghum / Jowar (ज्वार / ज्वारी)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Sorghum / Jowar",
    "keyPests": "Shoot Fly, Stem Borer, Earhead Bug",
    "agronomicTip": "Complete sowing within 15 days of monsoon onset to escape shoot fly infestation."
  },
  {
    "id": "c-07",
    "cropKey": "bajra",
    "name": "Pearl Millet / Bajra (बाजरा / बाजरी)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Pearl Millet / Bajra",
    "keyPests": "Downy Mildew, Ergot",
    "agronomicTip": "Extremely drought-hardy nutri-cereal; requires minimal irrigation after establishment."
  },
  {
    "id": "c-08",
    "cropKey": "ragi",
    "name": "Finger Millet / Ragi (रागी / नाचणी)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Finger Millet / Ragi",
    "keyPests": "Blast, Grasshopper",
    "agronomicTip": "Calcium-rich superfood; transplanting 21-day seedlings yields 25% higher than direct seeding."
  },
  {
    "id": "c-09",
    "cropKey": "foxtail-millet",
    "name": "Foxtail Millet (कंगनी / राळा)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Foxtail Millet",
    "keyPests": "Rust, Leaf Blast",
    "agronomicTip": "Short-duration climate-resilient crop ideal for emergency delayed monsoon conditions."
  },
  {
    "id": "c-10",
    "cropKey": "kodo-millet",
    "name": "Kodo Millet (कोदो / कोद्रा)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Kodo Millet",
    "keyPests": "Head Smut",
    "agronomicTip": "Requires lowest fertilizer inputs; excellent for tribal and dryland rainfed belts."
  },
  {
    "id": "c-11",
    "cropKey": "little-millet",
    "name": "Little Millet (कुटकी / सावा)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Little Millet",
    "keyPests": "Leaf Rust",
    "agronomicTip": "Fastest maturing cereal, ready in under 80 days with low water footprint."
  },
  {
    "id": "c-12",
    "cropKey": "barnyard-millet",
    "name": "Barnyard Millet (सांवा / भगरी)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Barnyard Millet",
    "keyPests": "Smut",
    "agronomicTip": "Extremely high in digestible fiber; thrives in hill terraces and flood plains."
  },
  {
    "id": "c-13",
    "cropKey": "proso-millet",
    "name": "Proso Millet (चेना / वरी)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Proso Millet",
    "keyPests": "Shoot Bug",
    "agronomicTip": "Ultra-fast catch crop; ideal to utilize short summer fallow periods between seasons."
  },
  {
    "id": "c-14",
    "cropKey": "oats",
    "name": "Oats (जई / ओट्स)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Oats",
    "keyPests": "Crown Rust",
    "agronomicTip": "Excellent dual-purpose fodder and grain crop with surging urban breakfast demand."
  },
  {
    "id": "c-15",
    "cropKey": "quinoa",
    "name": "Quinoa (कीनवा)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Quinoa",
    "keyPests": "Downy Mildew, Stem Borers",
    "agronomicTip": "High-value superfood; rinse seeds thoroughly at post-harvest to remove natural saponin."
  },
  {
    "id": "c-16",
    "cropKey": "c-16",
    "name": "Amaranth Grain / Rajgira (राजगिरा)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Amaranth Grain / Rajgira",
    "keyPests": "Stem Weevil",
    "agronomicTip": "Complete protein profile containing lysine; dual harvest for leafy greens and seeds."
  },
  {
    "id": "c-17",
    "cropKey": "sweet-corn",
    "name": "Sweet Corn (स्वीट कॉर्न)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Sweet Corn",
    "keyPests": "Corn Earworm, Aphids",
    "agronomicTip": "Harvest in milk stage early morning; market cobs within 24h to retain sugar brix."
  },
  {
    "id": "c-18",
    "cropKey": "baby-corn",
    "name": "Baby Corn (बेबी कॉर्न)",
    "category": "Cereals & Grains",
    "icon": "🌾",
    "commonName": "Baby Corn",
    "keyPests": "Shoot Borer",
    "agronomicTip": "Pluck unfertilized ears within 2-3 days of silk emergence; high hotel/restaurant demand."
  },
  {
    "id": "p-01",
    "cropKey": "chickpea",
    "name": "Chickpea / Desi Chana (चना / हरभरा)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Chickpea / Desi Chana",
    "keyPests": "Pod Borer (Helicoverpa), Wilt",
    "agronomicTip": "Inoculate seeds with Rhizobium & PSB; install bird perches to naturally control pod borers."
  },
  {
    "id": "p-02",
    "cropKey": "kabuli-chana",
    "name": "Kabuli Chana / Dollar Gram (काबुली चना)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Kabuli Chana / Dollar Gram",
    "keyPests": "Fusarium Wilt, Ascochyta Blight",
    "agronomicTip": "Commands high export price for bold grain size; avoid excessive irrigation to prevent wilt."
  },
  {
    "id": "p-03",
    "cropKey": "pigeon-pea",
    "name": "Pigeon Pea / Arhar / Tur (तूर / अरहर)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Pigeon Pea / Arhar / Tur",
    "keyPests": "Pod Fly, Blister Beetle, Wilt",
    "agronomicTip": "Deep taproot breaks hard soil pans; excellent intercropping with Soybean or Cotton (1:2)."
  },
  {
    "id": "p-04",
    "cropKey": "green-gram",
    "name": "Green Gram / Mung Bean (मूंग)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Green Gram / Mung Bean",
    "keyPests": "Yellow Mosaic Virus (Whitefly vector)",
    "agronomicTip": "Spray neem oil at early stage to control whitefly; fast 65-day cash rotation crop."
  },
  {
    "id": "p-05",
    "cropKey": "black-gram",
    "name": "Black Gram / Urad Bean (उड़द)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Black Gram / Urad Bean",
    "keyPests": "Pod Borer, Powdery Mildew",
    "agronomicTip": "Fixes up to 40 kg N/ha; residues enrich soil fertility for subsequent Rabi wheat."
  },
  {
    "id": "p-06",
    "cropKey": "red-lentil",
    "name": "Red Lentil / Masoor (मसूर)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Red Lentil / Masoor",
    "keyPests": "Rust, Wilt, Aphids",
    "agronomicTip": "Extremely cold-tolerant pulse; performs exceptionally well under zero-tillage after paddy."
  },
  {
    "id": "p-07",
    "cropKey": "soybean",
    "name": "Soybean (सोयाबीन)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Soybean",
    "keyPests": "Girdle Beetle, Stem Fly, Yellow Mosaic",
    "agronomicTip": "Ensure seed inoculation with Bradyrhizobium japonicum for maximum root nodulation."
  },
  {
    "id": "p-08",
    "cropKey": "cowpea",
    "name": "Cowpea / Lobia (लोबिया / चवळी)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Cowpea / Lobia",
    "keyPests": "Aphids, Pod Borer",
    "agronomicTip": "Tolerates high summer temperatures and moisture stress; dual vegetable and dry pulse."
  },
  {
    "id": "p-09",
    "cropKey": "field-pea",
    "name": "Field Pea / Matar (मटर)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Field Pea / Matar",
    "keyPests": "Powdery Mildew, Leaf Miner",
    "agronomicTip": "Spray wettable sulphur at first sign of powdery mildew; harvest when pods are well filled."
  },
  {
    "id": "p-10",
    "cropKey": "horse-gram",
    "name": "Horse Gram (कुलथी / हुलगा)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Horse Gram",
    "keyPests": "Dry Root Rot",
    "agronomicTip": "Renowned for medicinal anti-urolithiatic properties; thrives in harshest drought terrain."
  },
  {
    "id": "p-11",
    "cropKey": "kidney-bean",
    "name": "Kidney Bean / Rajma (राजमा)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Kidney Bean / Rajma",
    "keyPests": "Bean Anthracnose, Whitefly",
    "agronomicTip": "Unlike other legumes, Rajma lacks native nodulation in plains; requires 100 kg/ha basal N."
  },
  {
    "id": "p-12",
    "cropKey": "moth-bean",
    "name": "Moth Bean (मटकी)",
    "category": "Pulses & Legumes",
    "icon": "🫘",
    "commonName": "Moth Bean",
    "keyPests": "Jassids, Pod Borer",
    "agronomicTip": "Most heat and drought-tolerant legume in India; primary ingredient in Bikaneri Bhujia."
  },
  {
    "id": "o-01",
    "cropKey": "mustard",
    "name": "Mustard / Rapeseed (सरसों / मोहरी)",
    "category": "Oilseeds",
    "icon": "🌻",
    "commonName": "Mustard / Rapeseed",
    "keyPests": "Mustard Aphid, White Rust",
    "agronomicTip": "Apply elemental sulphur at 20 kg/ha to boost seed oil content by 2-3%."
  },
  {
    "id": "o-02",
    "cropKey": "green-gram",
    "name": "Groundnut / Peanut (मूंगफली / भुईमूग)",
    "category": "Oilseeds",
    "icon": "🌻",
    "commonName": "Groundnut / Peanut",
    "keyPests": "Tikka Leaf Spot, Collar Rot, White Grub",
    "agronomicTip": "Apply 200 kg gypsum/ha at pegging stage to provide calcium for pod filling."
  },
  {
    "id": "o-03",
    "cropKey": "sunflower",
    "name": "Sunflower (सूरजमुखी / सूर्यफूल)",
    "category": "Oilseeds",
    "icon": "🌻",
    "commonName": "Sunflower",
    "keyPests": "Helicoverpa, Alternaria Blight",
    "agronomicTip": "Maintain beehives (4 colonies/ha) during anthesis to ensure complete seed setting."
  },
  {
    "id": "o-04",
    "cropKey": "sesame",
    "name": "Sesame / Til (तिल / तीळ)",
    "category": "Oilseeds",
    "icon": "🌻",
    "commonName": "Sesame / Til",
    "keyPests": "Phyllody (Leafhopper vector)",
    "agronomicTip": "High-value export commodity; avoid waterlogging as sesame cannot survive standing water."
  },
  {
    "id": "o-05",
    "cropKey": "safflower",
    "name": "Safflower / Kardi (करडी)",
    "category": "Oilseeds",
    "icon": "🌻",
    "commonName": "Safflower / Kardi",
    "keyPests": "Safflower Aphid",
    "agronomicTip": "Deep taproots extract residual subsoil moisture; excellent border trap crop against cattle."
  },
  {
    "id": "o-06",
    "cropKey": "castor",
    "name": "Castor Seed (अरंडी / एरंडी)",
    "category": "Oilseeds",
    "icon": "🌻",
    "commonName": "Castor Seed",
    "keyPests": "Castor Semilooper, Capsule Borer",
    "agronomicTip": "India produces 85% of global castor oil exports; nip secondary shoots for uniform spikes."
  },
  {
    "id": "o-07",
    "cropKey": "linseed",
    "name": "Linseed / Flaxseed (अलसी / जवस)",
    "category": "Oilseeds",
    "icon": "🌻",
    "commonName": "Linseed / Flaxseed",
    "keyPests": "Rust, Powdery Mildew, Linseed Gall Midge",
    "agronomicTip": "Rich in Omega-3 alpha-linolenic acid (ALA); surging health food industrial demand."
  },
  {
    "id": "o-08",
    "cropKey": "sesame",
    "name": "Niger Seed (रामतिल / कारळे)",
    "category": "Oilseeds",
    "icon": "🌻",
    "commonName": "Niger Seed",
    "keyPests": "Caterpillar, Cuscuta parasite",
    "agronomicTip": "Key ingredient in Maharashtrian chutney & high-value birdseed exports to USA & EU."
  },
  {
    "id": "cash-01",
    "cropKey": "sugarcane",
    "name": "Sugarcane (गन्ना / ऊस)",
    "category": "Commercial & Cash Crops",
    "icon": "💰",
    "commonName": "Sugarcane",
    "keyPests": "Early Shoot Borer, Top Borer, Red Rot",
    "agronomicTip": "Sub-surface drip fertigation saves 45% water and increases cane sugar brix recovery."
  },
  {
    "id": "cash-02",
    "cropKey": "cotton",
    "name": "Cotton (कपास / कापूस)",
    "category": "Commercial & Cash Crops",
    "icon": "💰",
    "commonName": "Cotton",
    "keyPests": "Pink Bollworm, Whitefly, Jassids",
    "agronomicTip": "Plant non-Bt refuge border rows and install pheromone lures to suppress Pink Bollworm."
  },
  {
    "id": "cash-03",
    "cropKey": "tea",
    "name": "Tea (चाय / चहा)",
    "category": "Commercial & Cash Crops",
    "icon": "💰",
    "commonName": "Tea",
    "keyPests": "Tea Mosquito Bug, Red Spider Mite",
    "agronomicTip": "Regular 7-10 day fine plucking (two leaves and a bud) produces premier orthodox cup quality."
  },
  {
    "id": "cash-04",
    "cropKey": "coffee",
    "name": "Coffee (कॉफी - अरेबिका / रोबस्टा)",
    "category": "Commercial & Cash Crops",
    "icon": "💰",
    "commonName": "Coffee",
    "keyPests": "Coffee Berry Borer, White Stem Borer",
    "agronomicTip": "Shade-grown under native forest trees (Silver Oak, Fig) preserves biodiversity and cup aroma."
  },
  {
    "id": "cash-05",
    "cropKey": "coconut",
    "name": "Coconut (नारियल / नारळ)",
    "category": "Commercial & Cash Crops",
    "icon": "💰",
    "commonName": "Coconut",
    "keyPests": "Rhinoceros Beetle, Red Palm Weevil",
    "agronomicTip": "Release parasitoid wasps (Goniozus nephantidis) to manage black-headed caterpillar."
  },
  {
    "id": "v-01",
    "cropKey": "tomato",
    "name": "Tomato (टमाटर / टोमॅटो)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Tomato",
    "keyPests": "Tomato Leaf Curl Virus, Fruit Borer",
    "agronomicTip": "Trellising plants on bamboo wire stakes improves fruit grade and prevents fungal soil rot."
  },
  {
    "id": "v-02",
    "cropKey": "potato",
    "name": "Potato (आलू / बटाटा)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Potato",
    "keyPests": "Late Blight (Phytophthora)",
    "agronomicTip": "Earthing up tubers at 30 & 45 DAS prevents greening from direct sunlight exposure."
  },
  {
    "id": "v-03",
    "cropKey": "onion",
    "name": "Onion (प्याज / कांदा)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Onion",
    "keyPests": "Thrips, Purple Blotch",
    "agronomicTip": "Withhold irrigation 15 days before harvest and cure bulbs under shade to ensure 6-month shelf life."
  },
  {
    "id": "v-04",
    "cropKey": "garlic",
    "name": "Garlic (लहसुन / लसूण)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Garlic",
    "keyPests": "Thrips, Stemphylium Blight",
    "agronomicTip": "Plant healthy plump outer cloves; commands exceptionally high off-season culinary prices."
  },
  {
    "id": "v-05",
    "cropKey": "brinjal",
    "name": "Brinjal / Eggplant (बैंगन / वांगे)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Brinjal / Eggplant",
    "keyPests": "Shoot and Fruit Borer",
    "agronomicTip": "Install pheromone Lucinlure traps at 20 traps/ha for non-chemical fruit borer management."
  },
  {
    "id": "v-06",
    "cropKey": "okra",
    "name": "Okra / Ladyfinger (भिंडी)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Okra / Ladyfinger",
    "keyPests": "Yellow Vein Mosaic Virus",
    "agronomicTip": "Select YVMV-resistant hybrid varieties (e.g. Parbhani Kranti, Kashi Kranti) for Kharif season."
  },
  {
    "id": "v-07",
    "cropKey": "chilli",
    "name": "Green Chilli (हरी मिर्च / मिरची)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Green Chilli",
    "keyPests": "Thrips, Mites, Leaf Curl Virus",
    "agronomicTip": "Spray spinosad or neem formulations to suppress thrips vectors causing leaf curl."
  },
  {
    "id": "s-01",
    "cropKey": "turmeric",
    "name": "Turmeric (हल्दी / हळद)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Turmeric",
    "keyPests": "Rhizome Rot, Shoot Borer",
    "agronomicTip": "Cultivate high curcumin (5%+) varieties like Salem, Waigaon or Rajapore for export premium."
  },
  {
    "id": "s-02",
    "cropKey": "ginger",
    "name": "Ginger (अदरक / आले)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Ginger",
    "keyPests": "Soft Rot (Pythium)",
    "agronomicTip": "Provide raised beds (15 cm high) and heavy mulch with green leaves to prevent rhizome rot."
  },
  {
    "id": "s-03",
    "cropKey": "cumin",
    "name": "Cumin / Jeera (जीरा)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Cumin / Jeera",
    "keyPests": "Blight (Alternaria burnsii)",
    "agronomicTip": "Extremely sensitive to cloudy weather and drizzle at flowering; avoid late irrigations."
  },
  {
    "id": "s-04",
    "cropKey": "coriander",
    "name": "Coriander / Dhaniya (धनिया / धने)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Coriander / Dhaniya",
    "keyPests": "Powdery Mildew, Stem Gall",
    "agronomicTip": "Split seed into two mericarps by gentle rubbing before sowing to enhance germination."
  },
  {
    "id": "s-05",
    "cropKey": "black-pepper",
    "name": "Black Pepper (काली मिर्च / मिरी)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Black Pepper",
    "keyPests": "Quick Wilt (Phytophthora foot rot)",
    "agronomicTip": "Interplanted on Arecanut/Silver Oak standards in Western Ghats; king of Indian spices."
  },
  {
    "id": "s-06",
    "cropKey": "small-cardamom",
    "name": "Small Cardamom (छोटी इलायची / वेलची)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Small Cardamom",
    "keyPests": "Cardamom Thrips, Rhizome Rot",
    "agronomicTip": "Requires filtered 50% evergreen tree shade and high relative humidity (80%+) to thrive."
  },
  {
    "id": "m-01",
    "cropKey": "ashwagandha",
    "name": "Ashwagandha (अश्वगंधा)",
    "category": "Medicinal & Aromatic",
    "icon": "🍃",
    "commonName": "Ashwagandha",
    "keyPests": "Root Rot, Leaf Spot",
    "agronomicTip": "Premier adaptogenic Ayurvedic root; requires dry sunny weather during root thickening."
  },
  {
    "id": "m-02",
    "cropKey": "tulsi",
    "name": "Tulsi / Holy Basil (तुलसी)",
    "category": "Medicinal & Aromatic",
    "icon": "🍃",
    "commonName": "Tulsi / Holy Basil",
    "keyPests": "Leaf Blight",
    "agronomicTip": "Multi-cut medicinal crop harvested every 75 days; high demand from herbal tea and pharma."
  },
  {
    "id": "m-03",
    "cropKey": "lemongrass",
    "name": "Lemongrass (लेमनग्रास)",
    "category": "Medicinal & Aromatic",
    "icon": "🍃",
    "commonName": "Lemongrass",
    "keyPests": "Rust",
    "agronomicTip": "On-farm steam distillation unit yields high citral oil used in perfumes and pharma."
  },
  {
    "id": "c-spec-77",
    "cropKey": "watermelon",
    "name": "Watermelon (तरबूज / टरबूज)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Watermelon",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-78",
    "cropKey": "muskmelon",
    "name": "Muskmelon (खरबूज)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Muskmelon",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-79",
    "cropKey": "bottle-gourd",
    "name": "Bottle Gourd / Lauki (लौकी / दुधी)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Bottle Gourd / Lauki",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-80",
    "cropKey": "bitter-gourd",
    "name": "Bitter Gourd / Karela (करेला / कारले)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Bitter Gourd / Karela",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-81",
    "cropKey": "ridge-gourd",
    "name": "Ridge Gourd / Turai (तुरई / दोडका)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Ridge Gourd / Turai",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-82",
    "cropKey": "cucumber",
    "name": "Cucumber (खीरा / काकडी)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Cucumber",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-83",
    "cropKey": "spinach",
    "name": "Spinach / Palak (पालक)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Spinach / Palak",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-84",
    "cropKey": "fenugreek-leaves",
    "name": "Fenugreek Leaves / Methi (मेथी)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Fenugreek Leaves / Methi",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-85",
    "cropKey": "carrot",
    "name": "Carrot (गाजर)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Carrot",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-86",
    "cropKey": "radish",
    "name": "Radish / Mooli (मूली / मुळा)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Radish / Mooli",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-87",
    "cropKey": "beetroot",
    "name": "Beetroot (चुकंदर)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Beetroot",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-88",
    "cropKey": "sweet-potato",
    "name": "Sweet Potato (शकरकंद / रताळे)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Sweet Potato",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-89",
    "cropKey": "cassava",
    "name": "Cassava / Tapioca (साबूदाना)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Cassava / Tapioca",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-90",
    "cropKey": "elephant-foot-yam",
    "name": "Elephant Foot Yam (सूरन)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Elephant Foot Yam",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-91",
    "cropKey": "drumstick",
    "name": "Drumstick / Moringa (सहजन / शेवगा)",
    "category": "Vegetables",
    "icon": "🥦",
    "commonName": "Drumstick / Moringa",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-92",
    "cropKey": "nutmeg",
    "name": "Nutmeg & Mace (जायफल)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Nutmeg & Mace",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-93",
    "cropKey": "clove",
    "name": "Clove (लौंग / लवंग)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Clove",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-94",
    "cropKey": "cinnamon",
    "name": "Cinnamon (दालचीनी)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Cinnamon",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-95",
    "cropKey": "fenugreek-seeds",
    "name": "Fenugreek Seeds / Methi (मेथी दाना)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Fenugreek Seeds / Methi",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-96",
    "cropKey": "ajwain",
    "name": "Ajwain / Carom Seeds (अजवायन / ओवा)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Ajwain / Carom Seeds",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-97",
    "cropKey": "cumin",
    "name": "Kalonji / Black Cumin (कलौंजी)",
    "category": "Spices & Condiments",
    "icon": "🌿",
    "commonName": "Kalonji / Black Cumin",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-98",
    "cropKey": "aloe-vera",
    "name": "Aloe Vera (एलोवेरा)",
    "category": "Medicinal & Aromatic",
    "icon": "🍃",
    "commonName": "Aloe Vera",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-99",
    "cropKey": "stevia",
    "name": "Stevia Sweet Herb (स्टीविया)",
    "category": "Medicinal & Aromatic",
    "icon": "🍃",
    "commonName": "Stevia Sweet Herb",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-100",
    "cropKey": "isabgol",
    "name": "Isabgol / Psyllium Husk (इसबगोल)",
    "category": "Medicinal & Aromatic",
    "icon": "🍃",
    "commonName": "Isabgol / Psyllium Husk",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-101",
    "cropKey": "senna",
    "name": "Senna / Sonamukhi (सनाय)",
    "category": "Medicinal & Aromatic",
    "icon": "🍃",
    "commonName": "Senna / Sonamukhi",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  },
  {
    "id": "c-spec-108",
    "cropKey": "areca-palm",
    "name": "Areca Palm (एरेका पाम)",
    "category": "Commercial & Cash Crops",
    "icon": "💰",
    "commonName": "Areca Palm",
    "keyPests": "Leaf Spot, Sucking Pests",
    "agronomicTip": "Follow integrated nutrient and pest management (INM/IPM) with organic mulching."
  }
];

const allAgrosenseCropsList = exports.allAgrosenseCropsList = [...baseAgrosenseCropsList, ...fruitCropsList];

const allCropsKeyMap = exports.allCropsKeyMap = {
  "banana": "banana", "kela": "banana", "केला": "banana", "केळी": "banana",
  "mango": "mango", "aam": "mango", "आम": "mango", "आंबा": "mango",
  "apple": "apple", "seb": "apple", "सेब": "apple", "सफरचंद": "apple",
  "grapes": "grapes", "grape": "grapes", "angoor": "grapes", "अंगूर": "grapes", "द्राक्षे": "grapes",
  "citrus": "citrus", "lemon": "citrus", "orange": "citrus", "संतरा": "citrus", "नीबू": "citrus", "लिंबू": "citrus",
  "pomegranate": "pomegranate", "anar": "pomegranate", "अनार": "pomegranate", "डाळिंब": "pomegranate",
  "papaya": "papaya", "papita": "papaya", "पपीता": "papaya", "पपई": "papaya",
  "guava": "guava", "amrood": "guava", "अमरूद": "guava", "पेरू": "guava",
  "sarson": "mustard", "chana": "chickpea", "ganna": "sugarcane", "tamatar": "tomato", "aloo": "potato",
  "c-01": "wheat",
  "wheat": "wheat",
  "Wheat (गेहूं / गहू)": "wheat",
  "wheat (गेहूं / गहू)": "wheat",
  "गेहूं": "wheat",
  "गहू": "wheat",
  "c-02": "rice",
  "rice": "rice",
  "Paddy / Rice (धान / भात)": "rice",
  "paddy / rice (धान / भात)": "rice",
  "paddy / rice": "rice",
  "धान": "rice",
  "भात": "rice",
  "c-03": "basmati-rice",
  "basmati-rice": "basmati-rice",
  "Basmati Rice (बासमती चावल)": "basmati-rice",
  "basmati rice (बासमती चावल)": "basmati-rice",
  "basmati rice": "basmati-rice",
  "बासमती चावल": "basmati-rice",
  "c-04": "maize",
  "maize": "maize",
  "Maize / Corn (मक्का / मका)": "maize",
  "maize / corn (मक्का / मका)": "maize",
  "maize / corn": "maize",
  "मक्का": "maize",
  "मका": "maize",
  "c-05": "barley",
  "barley": "barley",
  "Barley (जौ / जाऊ)": "barley",
  "barley (जौ / जाऊ)": "barley",
  "जौ": "barley",
  "जाऊ": "barley",
  "c-06": "jowar",
  "jowar": "jowar",
  "Sorghum / Jowar (ज्वार / ज्वारी)": "jowar",
  "sorghum / jowar (ज्वार / ज्वारी)": "jowar",
  "sorghum / jowar": "jowar",
  "ज्वार": "jowar",
  "ज्वारी": "jowar",
  "c-07": "bajra",
  "bajra": "bajra",
  "Pearl Millet / Bajra (बाजरा / बाजरी)": "bajra",
  "pearl millet / bajra (बाजरा / बाजरी)": "bajra",
  "pearl millet / bajra": "bajra",
  "बाजरा": "bajra",
  "बाजरी": "bajra",
  "c-08": "ragi",
  "ragi": "ragi",
  "Finger Millet / Ragi (रागी / नाचणी)": "ragi",
  "finger millet / ragi (रागी / नाचणी)": "ragi",
  "finger millet / ragi": "ragi",
  "रागी": "ragi",
  "नाचणी": "ragi",
  "c-09": "foxtail-millet",
  "foxtail-millet": "foxtail-millet",
  "Foxtail Millet (कंगनी / राळा)": "foxtail-millet",
  "foxtail millet (कंगनी / राळा)": "foxtail-millet",
  "foxtail millet": "foxtail-millet",
  "कंगनी": "foxtail-millet",
  "राळा": "foxtail-millet",
  "c-10": "kodo-millet",
  "kodo-millet": "kodo-millet",
  "Kodo Millet (कोदो / कोद्रा)": "kodo-millet",
  "kodo millet (कोदो / कोद्रा)": "kodo-millet",
  "kodo millet": "kodo-millet",
  "कोदो": "kodo-millet",
  "कोद्रा": "kodo-millet",
  "c-11": "little-millet",
  "little-millet": "little-millet",
  "Little Millet (कुटकी / सावा)": "little-millet",
  "little millet (कुटकी / सावा)": "little-millet",
  "little millet": "little-millet",
  "कुटकी": "little-millet",
  "सावा": "little-millet",
  "c-12": "barnyard-millet",
  "barnyard-millet": "barnyard-millet",
  "Barnyard Millet (सांवा / भगरी)": "barnyard-millet",
  "barnyard millet (सांवा / भगरी)": "barnyard-millet",
  "barnyard millet": "barnyard-millet",
  "सांवा": "barnyard-millet",
  "भगरी": "barnyard-millet",
  "c-13": "proso-millet",
  "proso-millet": "proso-millet",
  "Proso Millet (चेना / वरी)": "proso-millet",
  "proso millet (चेना / वरी)": "proso-millet",
  "proso millet": "proso-millet",
  "चेना": "proso-millet",
  "वरी": "proso-millet",
  "c-14": "oats",
  "oats": "oats",
  "Oats (जई / ओट्स)": "oats",
  "oats (जई / ओट्स)": "oats",
  "जई": "oats",
  "ओट्स": "oats",
  "c-15": "quinoa",
  "quinoa": "quinoa",
  "Quinoa (कीनवा)": "quinoa",
  "quinoa (कीनवा)": "quinoa",
  "कीनवा": "quinoa",
  "c-16": "c-16",
  "Amaranth Grain / Rajgira (राजगिरा)": "c-16",
  "amaranth grain / rajgira (राजगिरा)": "c-16",
  "amaranth grain / rajgira": "c-16",
  "राजगिरा": "c-16",
  "c-17": "sweet-corn",
  "sweet-corn": "sweet-corn",
  "Sweet Corn (स्वीट कॉर्न)": "sweet-corn",
  "sweet corn (स्वीट कॉर्न)": "sweet-corn",
  "sweet corn": "sweet-corn",
  "स्वीट कॉर्न": "sweet-corn",
  "c-18": "baby-corn",
  "baby-corn": "baby-corn",
  "Baby Corn (बेबी कॉर्न)": "baby-corn",
  "baby corn (बेबी कॉर्न)": "baby-corn",
  "baby corn": "baby-corn",
  "बेबी कॉर्न": "baby-corn",
  "p-01": "chickpea",
  "chickpea": "chickpea",
  "Chickpea / Desi Chana (चना / हरभरा)": "chickpea",
  "chickpea / desi chana (चना / हरभरा)": "chickpea",
  "chickpea / desi chana": "chickpea",
  "चना": "chickpea",
  "हरभरा": "chickpea",
  "p-02": "kabuli-chana",
  "kabuli-chana": "kabuli-chana",
  "Kabuli Chana / Dollar Gram (काबुली चना)": "kabuli-chana",
  "kabuli chana / dollar gram (काबुली चना)": "kabuli-chana",
  "kabuli chana / dollar gram": "kabuli-chana",
  "काबुली चना": "kabuli-chana",
  "p-03": "pigeon-pea",
  "pigeon-pea": "pigeon-pea",
  "Pigeon Pea / Arhar / Tur (तूर / अरहर)": "pigeon-pea",
  "pigeon pea / arhar / tur (तूर / अरहर)": "pigeon-pea",
  "pigeon pea / arhar / tur": "pigeon-pea",
  "तूर": "pigeon-pea",
  "अरहर": "pigeon-pea",
  "p-04": "green-gram",
  "green-gram": "green-gram",
  "Green Gram / Mung Bean (मूंग)": "green-gram",
  "green gram / mung bean (मूंग)": "green-gram",
  "green gram / mung bean": "green-gram",
  "मूंग": "green-gram",
  "p-05": "black-gram",
  "black-gram": "black-gram",
  "Black Gram / Urad Bean (उड़द)": "black-gram",
  "black gram / urad bean (उड़द)": "black-gram",
  "black gram / urad bean": "black-gram",
  "उड़द": "black-gram",
  "p-06": "red-lentil",
  "red-lentil": "red-lentil",
  "Red Lentil / Masoor (मसूर)": "red-lentil",
  "red lentil / masoor (मसूर)": "red-lentil",
  "red lentil / masoor": "red-lentil",
  "मसूर": "red-lentil",
  "p-07": "soybean",
  "soybean": "soybean",
  "Soybean (सोयाबीन)": "soybean",
  "soybean (सोयाबीन)": "soybean",
  "सोयाबीन": "soybean",
  "p-08": "cowpea",
  "cowpea": "cowpea",
  "Cowpea / Lobia (लोबिया / चवळी)": "cowpea",
  "cowpea / lobia (लोबिया / चवळी)": "cowpea",
  "cowpea / lobia": "cowpea",
  "लोबिया": "cowpea",
  "चवळी": "cowpea",
  "p-09": "field-pea",
  "field-pea": "field-pea",
  "Field Pea / Matar (मटर)": "field-pea",
  "field pea / matar (मटर)": "field-pea",
  "field pea / matar": "field-pea",
  "मटर": "field-pea",
  "p-10": "horse-gram",
  "horse-gram": "horse-gram",
  "Horse Gram (कुलथी / हुलगा)": "horse-gram",
  "horse gram (कुलथी / हुलगा)": "horse-gram",
  "horse gram": "horse-gram",
  "कुलथी": "horse-gram",
  "हुलगा": "horse-gram",
  "p-11": "kidney-bean",
  "kidney-bean": "kidney-bean",
  "Kidney Bean / Rajma (राजमा)": "kidney-bean",
  "kidney bean / rajma (राजमा)": "kidney-bean",
  "kidney bean / rajma": "kidney-bean",
  "राजमा": "kidney-bean",
  "p-12": "moth-bean",
  "moth-bean": "moth-bean",
  "Moth Bean (मटकी)": "moth-bean",
  "moth bean (मटकी)": "moth-bean",
  "moth bean": "moth-bean",
  "मटकी": "moth-bean",
  "o-01": "mustard",
  "mustard": "mustard",
  "Mustard / Rapeseed (सरसों / मोहरी)": "mustard",
  "mustard / rapeseed (सरसों / मोहरी)": "mustard",
  "mustard / rapeseed": "mustard",
  "सरसों": "mustard",
  "मोहरी": "mustard",
  "o-02": "green-gram",
  "Groundnut / Peanut (मूंगफली / भुईमूग)": "green-gram",
  "groundnut / peanut (मूंगफली / भुईमूग)": "green-gram",
  "groundnut / peanut": "green-gram",
  "मूंगफली": "green-gram",
  "भुईमूग": "green-gram",
  "o-03": "sunflower",
  "sunflower": "sunflower",
  "Sunflower (सूरजमुखी / सूर्यफूल)": "sunflower",
  "sunflower (सूरजमुखी / सूर्यफूल)": "sunflower",
  "सूरजमुखी": "sunflower",
  "सूर्यफूल": "sunflower",
  "o-04": "sesame",
  "sesame": "sesame",
  "Sesame / Til (तिल / तीळ)": "sesame",
  "sesame / til (तिल / तीळ)": "sesame",
  "sesame / til": "sesame",
  "तिल": "sesame",
  "तीळ": "sesame",
  "o-05": "safflower",
  "safflower": "safflower",
  "Safflower / Kardi (करडी)": "safflower",
  "safflower / kardi (करडी)": "safflower",
  "safflower / kardi": "safflower",
  "करडी": "safflower",
  "o-06": "castor",
  "castor": "castor",
  "Castor Seed (अरंडी / एरंडी)": "castor",
  "castor seed (अरंडी / एरंडी)": "castor",
  "castor seed": "castor",
  "अरंडी": "castor",
  "एरंडी": "castor",
  "o-07": "linseed",
  "linseed": "linseed",
  "Linseed / Flaxseed (अलसी / जवस)": "linseed",
  "linseed / flaxseed (अलसी / जवस)": "linseed",
  "linseed / flaxseed": "linseed",
  "अलसी": "linseed",
  "जवस": "linseed",
  "o-08": "sesame",
  "Niger Seed (रामतिल / कारळे)": "sesame",
  "niger seed (रामतिल / कारळे)": "sesame",
  "niger seed": "sesame",
  "रामतिल": "sesame",
  "कारळे": "sesame",
  "cash-01": "sugarcane",
  "sugarcane": "sugarcane",
  "Sugarcane (गन्ना / ऊस)": "sugarcane",
  "sugarcane (गन्ना / ऊस)": "sugarcane",
  "गन्ना": "sugarcane",
  "ऊस": "sugarcane",
  "cash-02": "cotton",
  "cotton": "cotton",
  "Cotton (कपास / कापूस)": "cotton",
  "cotton (कपास / कापूस)": "cotton",
  "कपास": "cotton",
  "कापूस": "cotton",
  "cash-03": "tea",
  "tea": "tea",
  "Tea (चाय / चहा)": "tea",
  "tea (चाय / चहा)": "tea",
  "चाय": "tea",
  "चहा": "tea",
  "cash-04": "coffee",
  "coffee": "coffee",
  "Coffee (कॉफी - अरेबिका / रोबस्टा)": "coffee",
  "coffee (कॉफी - अरेबिका / रोबस्टा)": "coffee",
  "कॉफी - अरेबिका": "coffee",
  "रोबस्टा": "coffee",
  "cash-05": "coconut",
  "coconut": "coconut",
  "Coconut (नारियल / नारळ)": "coconut",
  "coconut (नारियल / नारळ)": "coconut",
  "नारियल": "coconut",
  "नारळ": "coconut",
  "v-01": "tomato",
  "tomato": "tomato",
  "Tomato (टमाटर / टोमॅटो)": "tomato",
  "tomato (टमाटर / टोमॅटो)": "tomato",
  "टमाटर": "tomato",
  "टोमॅटो": "tomato",
  "v-02": "potato",
  "potato": "potato",
  "Potato (आलू / बटाटा)": "potato",
  "potato (आलू / बटाटा)": "potato",
  "आलू": "potato",
  "बटाटा": "potato",
  "v-03": "onion",
  "onion": "onion",
  "Onion (प्याज / कांदा)": "onion",
  "onion (प्याज / कांदा)": "onion",
  "प्याज": "onion",
  "कांदा": "onion",
  "v-04": "garlic",
  "garlic": "garlic",
  "Garlic (लहसुन / लसूण)": "garlic",
  "garlic (लहसुन / लसूण)": "garlic",
  "लहसुन": "garlic",
  "लसूण": "garlic",
  "v-05": "brinjal",
  "brinjal": "brinjal",
  "Brinjal / Eggplant (बैंगन / वांगे)": "brinjal",
  "brinjal / eggplant (बैंगन / वांगे)": "brinjal",
  "brinjal / eggplant": "brinjal",
  "बैंगन": "brinjal",
  "वांगे": "brinjal",
  "v-06": "okra",
  "okra": "okra",
  "Okra / Ladyfinger (भिंडी)": "okra",
  "okra / ladyfinger (भिंडी)": "okra",
  "okra / ladyfinger": "okra",
  "भिंडी": "okra",
  "v-07": "chilli",
  "chilli": "chilli",
  "Green Chilli (हरी मिर्च / मिरची)": "chilli",
  "green chilli (हरी मिर्च / मिरची)": "chilli",
  "green chilli": "chilli",
  "हरी मिर्च": "chilli",
  "मिरची": "chilli",
  "s-01": "turmeric",
  "turmeric": "turmeric",
  "Turmeric (हल्दी / हळद)": "turmeric",
  "turmeric (हल्दी / हळद)": "turmeric",
  "हल्दी": "turmeric",
  "हळद": "turmeric",
  "s-02": "ginger",
  "ginger": "ginger",
  "Ginger (अदरक / आले)": "ginger",
  "ginger (अदरक / आले)": "ginger",
  "अदरक": "ginger",
  "आले": "ginger",
  "s-03": "cumin",
  "cumin": "cumin",
  "Cumin / Jeera (जीरा)": "cumin",
  "cumin / jeera (जीरा)": "cumin",
  "cumin / jeera": "cumin",
  "जीरा": "cumin",
  "s-04": "coriander",
  "coriander": "coriander",
  "Coriander / Dhaniya (धनिया / धने)": "coriander",
  "coriander / dhaniya (धनिया / धने)": "coriander",
  "coriander / dhaniya": "coriander",
  "धनिया": "coriander",
  "धने": "coriander",
  "s-05": "black-pepper",
  "black-pepper": "black-pepper",
  "Black Pepper (काली मिर्च / मिरी)": "black-pepper",
  "black pepper (काली मिर्च / मिरी)": "black-pepper",
  "black pepper": "black-pepper",
  "काली मिर्च": "black-pepper",
  "मिरी": "black-pepper",
  "s-06": "small-cardamom",
  "small-cardamom": "small-cardamom",
  "Small Cardamom (छोटी इलायची / वेलची)": "small-cardamom",
  "small cardamom (छोटी इलायची / वेलची)": "small-cardamom",
  "small cardamom": "small-cardamom",
  "छोटी इलायची": "small-cardamom",
  "वेलची": "small-cardamom",
  "m-01": "ashwagandha",
  "ashwagandha": "ashwagandha",
  "Ashwagandha (अश्वगंधा)": "ashwagandha",
  "ashwagandha (अश्वगंधा)": "ashwagandha",
  "अश्वगंधा": "ashwagandha",
  "m-02": "tulsi",
  "tulsi": "tulsi",
  "Tulsi / Holy Basil (तुलसी)": "tulsi",
  "tulsi / holy basil (तुलसी)": "tulsi",
  "tulsi / holy basil": "tulsi",
  "तुलसी": "tulsi",
  "m-03": "lemongrass",
  "lemongrass": "lemongrass",
  "Lemongrass (लेमनग्रास)": "lemongrass",
  "lemongrass (लेमनग्रास)": "lemongrass",
  "लेमनग्रास": "lemongrass",
  "c-spec-77": "watermelon",
  "watermelon": "watermelon",
  "Watermelon (तरबूज / टरबूज)": "watermelon",
  "watermelon (तरबूज / टरबूज)": "watermelon",
  "तरबूज": "watermelon",
  "टरबूज": "watermelon",
  "c-spec-78": "muskmelon",
  "muskmelon": "muskmelon",
  "Muskmelon (खरबूज)": "muskmelon",
  "muskmelon (खरबूज)": "muskmelon",
  "खरबूज": "muskmelon",
  "c-spec-79": "bottle-gourd",
  "bottle-gourd": "bottle-gourd",
  "Bottle Gourd / Lauki (लौकी / दुधी)": "bottle-gourd",
  "bottle gourd / lauki (लौकी / दुधी)": "bottle-gourd",
  "bottle gourd / lauki": "bottle-gourd",
  "लौकी": "bottle-gourd",
  "दुधी": "bottle-gourd",
  "c-spec-80": "bitter-gourd",
  "bitter-gourd": "bitter-gourd",
  "Bitter Gourd / Karela (करेला / कारले)": "bitter-gourd",
  "bitter gourd / karela (करेला / कारले)": "bitter-gourd",
  "bitter gourd / karela": "bitter-gourd",
  "करेला": "bitter-gourd",
  "कारले": "bitter-gourd",
  "c-spec-81": "ridge-gourd",
  "ridge-gourd": "ridge-gourd",
  "Ridge Gourd / Turai (तुरई / दोडका)": "ridge-gourd",
  "ridge gourd / turai (तुरई / दोडका)": "ridge-gourd",
  "ridge gourd / turai": "ridge-gourd",
  "तुरई": "ridge-gourd",
  "दोडका": "ridge-gourd",
  "c-spec-82": "cucumber",
  "cucumber": "cucumber",
  "Cucumber (खीरा / काकडी)": "cucumber",
  "cucumber (खीरा / काकडी)": "cucumber",
  "खीरा": "cucumber",
  "काकडी": "cucumber",
  "c-spec-83": "spinach",
  "spinach": "spinach",
  "Spinach / Palak (पालक)": "spinach",
  "spinach / palak (पालक)": "spinach",
  "spinach / palak": "spinach",
  "पालक": "spinach",
  "c-spec-84": "fenugreek-leaves",
  "fenugreek-leaves": "fenugreek-leaves",
  "Fenugreek Leaves / Methi (मेथी)": "fenugreek-leaves",
  "fenugreek leaves / methi (मेथी)": "fenugreek-leaves",
  "fenugreek leaves / methi": "fenugreek-leaves",
  "मेथी": "fenugreek-leaves",
  "c-spec-85": "carrot",
  "carrot": "carrot",
  "Carrot (गाजर)": "carrot",
  "carrot (गाजर)": "carrot",
  "गाजर": "carrot",
  "c-spec-86": "radish",
  "radish": "radish",
  "Radish / Mooli (मूली / मुळा)": "radish",
  "radish / mooli (मूली / मुळा)": "radish",
  "radish / mooli": "radish",
  "मूली": "radish",
  "मुळा": "radish",
  "c-spec-87": "beetroot",
  "beetroot": "beetroot",
  "Beetroot (चुकंदर)": "beetroot",
  "beetroot (चुकंदर)": "beetroot",
  "चुकंदर": "beetroot",
  "c-spec-88": "sweet-potato",
  "sweet-potato": "sweet-potato",
  "Sweet Potato (शकरकंद / रताळे)": "sweet-potato",
  "sweet potato (शकरकंद / रताळे)": "sweet-potato",
  "sweet potato": "sweet-potato",
  "शकरकंद": "sweet-potato",
  "रताळे": "sweet-potato",
  "c-spec-89": "cassava",
  "cassava": "cassava",
  "Cassava / Tapioca (साबूदाना)": "cassava",
  "cassava / tapioca (साबूदाना)": "cassava",
  "cassava / tapioca": "cassava",
  "साबूदाना": "cassava",
  "c-spec-90": "elephant-foot-yam",
  "elephant-foot-yam": "elephant-foot-yam",
  "Elephant Foot Yam (सूरन)": "elephant-foot-yam",
  "elephant foot yam (सूरन)": "elephant-foot-yam",
  "elephant foot yam": "elephant-foot-yam",
  "सूरन": "elephant-foot-yam",
  "c-spec-91": "drumstick",
  "drumstick": "drumstick",
  "Drumstick / Moringa (सहजन / शेवगा)": "drumstick",
  "drumstick / moringa (सहजन / शेवगा)": "drumstick",
  "drumstick / moringa": "drumstick",
  "सहजन": "drumstick",
  "शेवगा": "drumstick",
  "c-spec-92": "nutmeg",
  "nutmeg": "nutmeg",
  "Nutmeg & Mace (जायफल)": "nutmeg",
  "nutmeg & mace (जायफल)": "nutmeg",
  "nutmeg & mace": "nutmeg",
  "जायफल": "nutmeg",
  "c-spec-93": "clove",
  "clove": "clove",
  "Clove (लौंग / लवंग)": "clove",
  "clove (लौंग / लवंग)": "clove",
  "लौंग": "clove",
  "लवंग": "clove",
  "c-spec-94": "cinnamon",
  "cinnamon": "cinnamon",
  "Cinnamon (दालचीनी)": "cinnamon",
  "cinnamon (दालचीनी)": "cinnamon",
  "दालचीनी": "cinnamon",
  "c-spec-95": "fenugreek-seeds",
  "fenugreek-seeds": "fenugreek-seeds",
  "Fenugreek Seeds / Methi (मेथी दाना)": "fenugreek-seeds",
  "fenugreek seeds / methi (मेथी दाना)": "fenugreek-seeds",
  "fenugreek seeds / methi": "fenugreek-seeds",
  "मेथी दाना": "fenugreek-seeds",
  "c-spec-96": "ajwain",
  "ajwain": "ajwain",
  "Ajwain / Carom Seeds (अजवायन / ओवा)": "ajwain",
  "ajwain / carom seeds (अजवायन / ओवा)": "ajwain",
  "ajwain / carom seeds": "ajwain",
  "अजवायन": "ajwain",
  "ओवा": "ajwain",
  "c-spec-97": "cumin",
  "Kalonji / Black Cumin (कलौंजी)": "cumin",
  "kalonji / black cumin (कलौंजी)": "cumin",
  "kalonji / black cumin": "cumin",
  "कलौंजी": "cumin",
  "c-spec-98": "aloe-vera",
  "aloe-vera": "aloe-vera",
  "Aloe Vera (एलोवेरा)": "aloe-vera",
  "aloe vera (एलोवेरा)": "aloe-vera",
  "aloe vera": "aloe-vera",
  "एलोवेरा": "aloe-vera",
  "c-spec-99": "stevia",
  "stevia": "stevia",
  "Stevia Sweet Herb (स्टीविया)": "stevia",
  "stevia sweet herb (स्टीविया)": "stevia",
  "stevia sweet herb": "stevia",
  "स्टीविया": "stevia",
  "c-spec-100": "isabgol",
  "isabgol": "isabgol",
  "Isabgol / Psyllium Husk (इसबगोल)": "isabgol",
  "isabgol / psyllium husk (इसबगोल)": "isabgol",
  "isabgol / psyllium husk": "isabgol",
  "इसबगोल": "isabgol",
  "c-spec-101": "senna",
  "senna": "senna",
  "Senna / Sonamukhi (सनाय)": "senna",
  "senna / sonamukhi (सनाय)": "senna",
  "senna / sonamukhi": "senna",
  "सनाय": "senna",
  "c-spec-108": "areca-palm",
  "areca-palm": "areca-palm",
  "Areca Palm (एरेका पाम)": "areca-palm",
  "areca palm (एरेका पाम)": "areca-palm",
  "areca palm": "areca-palm",
  "एरेका पाम": "areca-palm",
  "Chilli (हरी मिर्च / मिरची)": "chilli",
  "mirch": "chilli",
  "mirchi": "chilli",
  "haldi": "turmeric",
  "adrak": "ginger"
};

const baseExpandedPlantDiseaseDatabase = [
  {
    "id": "wheat-disease-primary",
    "crop": "Wheat (गेहूं / गहू)",
    "cropKey": "wheat",
    "diseaseName": "Wheat Yellow Rust (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.12,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.26
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Yellow Rust spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Wheat.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Apply crown root initiation (CRI) irrigation at 21 DAS for maximum tillering.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "wheat-disease-secondary",
    "crop": "Wheat (गेहूं / गहू)",
    "cropKey": "wheat",
    "diseaseName": "Wheat Karnal Bunt",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Karnal Bunt appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "wheat-healthy",
    "crop": "Wheat (गेहूं / गहू)",
    "cropKey": "wheat",
    "diseaseName": "Wheat Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "rice-disease-primary",
    "crop": "Paddy / Rice (धान / भात)",
    "cropKey": "rice",
    "diseaseName": "Paddy / Rice Stem Borer (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Stem Borer spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Paddy / Rice.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Adopt alternate wetting and drying (AWD) to conserve up to 30% irrigation water.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "rice-disease-secondary",
    "crop": "Paddy / Rice (धान / भात)",
    "cropKey": "rice",
    "diseaseName": "Paddy / Rice Brown Planthopper",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Brown Planthopper appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "rice-healthy",
    "crop": "Paddy / Rice (धान / भात)",
    "cropKey": "rice",
    "diseaseName": "Paddy / Rice Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "basmati-rice-disease-primary",
    "crop": "Basmati Rice (बासमती चावल)",
    "cropKey": "basmati-rice",
    "diseaseName": "Basmati Rice Bacterial Leaf Blight (Pathogen Complex)",
    "pathogenType": "Bacterial Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Bacterial Leaf Blight spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Basmati Rice.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Ensure uniform transplantation with 20x15 cm spacing for aromatic grain elongation.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "basmati-rice-disease-secondary",
    "crop": "Basmati Rice (बासमती चावल)",
    "cropKey": "basmati-rice",
    "diseaseName": "Basmati Rice Sheath Rot",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sheath Rot appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "basmati-rice-healthy",
    "crop": "Basmati Rice (बासमती चावल)",
    "cropKey": "basmati-rice",
    "diseaseName": "Basmati Rice Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "maize-disease-primary",
    "crop": "Maize / Corn (मक्का / मका)",
    "cropKey": "maize",
    "diseaseName": "Maize / Corn Fall Armyworm (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Fall Armyworm spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Maize / Corn.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Install pheromone traps early for Fall Armyworm surveillance and biopesticide control.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "maize-healthy",
    "crop": "Maize / Corn (मक्का / मका)",
    "cropKey": "maize",
    "diseaseName": "Maize / Corn Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "barley-disease-primary",
    "crop": "Barley (जौ / जाऊ)",
    "cropKey": "barley",
    "diseaseName": "Barley Covered Smut (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Covered Smut spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Barley.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Highly resilient to moderate soil salinity) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "barley-disease-secondary",
    "crop": "Barley (जौ / जाऊ)",
    "cropKey": "barley",
    "diseaseName": "Barley Aphids",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Aphids appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "barley-healthy",
    "crop": "Barley (जौ / जाऊ)",
    "cropKey": "barley",
    "diseaseName": "Barley Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "jowar-disease-primary",
    "crop": "Sorghum / Jowar (ज्वार / ज्वारी)",
    "cropKey": "jowar",
    "diseaseName": "Sorghum / Jowar Shoot Fly (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Shoot Fly spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Sorghum / Jowar.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Complete sowing within 15 days of monsoon onset to escape shoot fly infestation.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "jowar-healthy",
    "crop": "Sorghum / Jowar (ज्वार / ज्वारी)",
    "cropKey": "jowar",
    "diseaseName": "Sorghum / Jowar Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "bajra-disease-primary",
    "crop": "Pearl Millet / Bajra (बाजरा / बाजरी)",
    "cropKey": "bajra",
    "diseaseName": "Pearl Millet / Bajra Downy Mildew (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.28,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Downy Mildew spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Pearl Millet / Bajra.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Extremely drought-hardy nutri-cereal) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "bajra-disease-secondary",
    "crop": "Pearl Millet / Bajra (बाजरा / बाजरी)",
    "cropKey": "bajra",
    "diseaseName": "Pearl Millet / Bajra Ergot",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Ergot appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "bajra-healthy",
    "crop": "Pearl Millet / Bajra (बाजरा / बाजरी)",
    "cropKey": "bajra",
    "diseaseName": "Pearl Millet / Bajra Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "ragi-disease-primary",
    "crop": "Finger Millet / Ragi (रागी / नाचणी)",
    "cropKey": "ragi",
    "diseaseName": "Finger Millet / Ragi Blast (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Blast spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Finger Millet / Ragi.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Calcium-rich superfood) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "ragi-disease-secondary",
    "crop": "Finger Millet / Ragi (रागी / नाचणी)",
    "cropKey": "ragi",
    "diseaseName": "Finger Millet / Ragi Grasshopper",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Grasshopper appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "ragi-healthy",
    "crop": "Finger Millet / Ragi (रागी / नाचणी)",
    "cropKey": "ragi",
    "diseaseName": "Finger Millet / Ragi Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "foxtail-millet-disease-primary",
    "crop": "Foxtail Millet (कंगनी / राळा)",
    "cropKey": "foxtail-millet",
    "diseaseName": "Foxtail Millet Rust (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.12,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.26
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Rust spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Foxtail Millet.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Short-duration climate-resilient crop ideal for emergency delayed monsoon conditions.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "foxtail-millet-disease-secondary",
    "crop": "Foxtail Millet (कंगनी / राळा)",
    "cropKey": "foxtail-millet",
    "diseaseName": "Foxtail Millet Leaf Blast",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Leaf Blast appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "foxtail-millet-healthy",
    "crop": "Foxtail Millet (कंगनी / राळा)",
    "cropKey": "foxtail-millet",
    "diseaseName": "Foxtail Millet Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "kodo-millet-disease-primary",
    "crop": "Kodo Millet (कोदो / कोद्रा)",
    "cropKey": "kodo-millet",
    "diseaseName": "Kodo Millet Head Smut (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Head Smut spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Kodo Millet.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Requires lowest fertilizer inputs) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "kodo-millet-disease-secondary",
    "crop": "Kodo Millet (कोदो / कोद्रा)",
    "cropKey": "kodo-millet",
    "diseaseName": "Kodo Millet Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "kodo-millet-healthy",
    "crop": "Kodo Millet (कोदो / कोद्रा)",
    "cropKey": "kodo-millet",
    "diseaseName": "Kodo Millet Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "little-millet-disease-primary",
    "crop": "Little Millet (कुटकी / सावा)",
    "cropKey": "little-millet",
    "diseaseName": "Little Millet Leaf Rust (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.12,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.26
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Rust spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Little Millet.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Fastest maturing cereal, ready in under 80 days with low water footprint.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "little-millet-disease-secondary",
    "crop": "Little Millet (कुटकी / सावा)",
    "cropKey": "little-millet",
    "diseaseName": "Little Millet Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "little-millet-healthy",
    "crop": "Little Millet (कुटकी / सावा)",
    "cropKey": "little-millet",
    "diseaseName": "Little Millet Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "barnyard-millet-disease-primary",
    "crop": "Barnyard Millet (सांवा / भगरी)",
    "cropKey": "barnyard-millet",
    "diseaseName": "Barnyard Millet Smut (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Smut spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Barnyard Millet.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Extremely high in digestible fiber) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "barnyard-millet-disease-secondary",
    "crop": "Barnyard Millet (सांवा / भगरी)",
    "cropKey": "barnyard-millet",
    "diseaseName": "Barnyard Millet Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "barnyard-millet-healthy",
    "crop": "Barnyard Millet (सांवा / भगरी)",
    "cropKey": "barnyard-millet",
    "diseaseName": "Barnyard Millet Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "proso-millet-disease-primary",
    "crop": "Proso Millet (चेना / वरी)",
    "cropKey": "proso-millet",
    "diseaseName": "Proso Millet Shoot Bug (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Shoot Bug spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Proso Millet.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Ultra-fast catch crop) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "proso-millet-disease-secondary",
    "crop": "Proso Millet (चेना / वरी)",
    "cropKey": "proso-millet",
    "diseaseName": "Proso Millet Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "proso-millet-healthy",
    "crop": "Proso Millet (चेना / वरी)",
    "cropKey": "proso-millet",
    "diseaseName": "Proso Millet Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "oats-disease-primary",
    "crop": "Oats (जई / ओट्स)",
    "cropKey": "oats",
    "diseaseName": "Oats Crown Rust (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.12,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.26
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Crown Rust spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Oats.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Excellent dual-purpose fodder and grain crop with surging urban breakfast demand.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "oats-disease-secondary",
    "crop": "Oats (जई / ओट्स)",
    "cropKey": "oats",
    "diseaseName": "Oats Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "oats-healthy",
    "crop": "Oats (जई / ओट्स)",
    "cropKey": "oats",
    "diseaseName": "Oats Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "quinoa-disease-primary",
    "crop": "Quinoa (कीनवा)",
    "cropKey": "quinoa",
    "diseaseName": "Quinoa Downy Mildew (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.28,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Downy Mildew spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Quinoa.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (High-value superfood) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "quinoa-healthy",
    "crop": "Quinoa (कीनवा)",
    "cropKey": "quinoa",
    "diseaseName": "Quinoa Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "c-16-disease-primary",
    "crop": "Amaranth Grain / Rajgira (राजगिरा)",
    "cropKey": "c-16",
    "diseaseName": "Amaranth Grain / Rajgira Stem Weevil (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Stem Weevil spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Amaranth Grain / Rajgira.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Complete protein profile containing lysine) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "c-16-disease-secondary",
    "crop": "Amaranth Grain / Rajgira (राजगिरा)",
    "cropKey": "c-16",
    "diseaseName": "Amaranth Grain / Rajgira Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "c-16-healthy",
    "crop": "Amaranth Grain / Rajgira (राजगिरा)",
    "cropKey": "c-16",
    "diseaseName": "Amaranth Grain / Rajgira Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "sweet-corn-disease-primary",
    "crop": "Sweet Corn (स्वीट कॉर्न)",
    "cropKey": "sweet-corn",
    "diseaseName": "Sweet Corn Corn Earworm (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Corn Earworm spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Sweet Corn.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Harvest in milk stage early morning) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "sweet-corn-disease-secondary",
    "crop": "Sweet Corn (स्वीट कॉर्न)",
    "cropKey": "sweet-corn",
    "diseaseName": "Sweet Corn Aphids",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Aphids appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "sweet-corn-healthy",
    "crop": "Sweet Corn (स्वीट कॉर्न)",
    "cropKey": "sweet-corn",
    "diseaseName": "Sweet Corn Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "baby-corn-disease-primary",
    "crop": "Baby Corn (बेबी कॉर्न)",
    "cropKey": "baby-corn",
    "diseaseName": "Baby Corn Shoot Borer (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Shoot Borer spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Baby Corn.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Pluck unfertilized ears within 2-3 days of silk emergence) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "baby-corn-disease-secondary",
    "crop": "Baby Corn (बेबी कॉर्न)",
    "cropKey": "baby-corn",
    "diseaseName": "Baby Corn Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "baby-corn-healthy",
    "crop": "Baby Corn (बेबी कॉर्न)",
    "cropKey": "baby-corn",
    "diseaseName": "Baby Corn Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "chickpea-disease-primary",
    "crop": "Chickpea / Desi Chana (चना / हरभरा)",
    "cropKey": "chickpea",
    "diseaseName": "Chickpea / Desi Chana Pod Borer (Helicoverpa) (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Pod Borer (Helicoverpa) spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Chickpea / Desi Chana.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Inoculate seeds with Rhizobium & PSB) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "chickpea-disease-secondary",
    "crop": "Chickpea / Desi Chana (चना / हरभरा)",
    "cropKey": "chickpea",
    "diseaseName": "Chickpea / Desi Chana Wilt",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Wilt appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "chickpea-healthy",
    "crop": "Chickpea / Desi Chana (चना / हरभरा)",
    "cropKey": "chickpea",
    "diseaseName": "Chickpea / Desi Chana Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "kabuli-chana-disease-primary",
    "crop": "Kabuli Chana / Dollar Gram (काबुली चना)",
    "cropKey": "kabuli-chana",
    "diseaseName": "Kabuli Chana / Dollar Gram Fusarium Wilt (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Fusarium Wilt spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Kabuli Chana / Dollar Gram.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Commands high export price for bold grain size) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "kabuli-chana-disease-secondary",
    "crop": "Kabuli Chana / Dollar Gram (काबुली चना)",
    "cropKey": "kabuli-chana",
    "diseaseName": "Kabuli Chana / Dollar Gram Ascochyta Blight",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Ascochyta Blight appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "kabuli-chana-healthy",
    "crop": "Kabuli Chana / Dollar Gram (काबुली चना)",
    "cropKey": "kabuli-chana",
    "diseaseName": "Kabuli Chana / Dollar Gram Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "pigeon-pea-disease-primary",
    "crop": "Pigeon Pea / Arhar / Tur (तूर / अरहर)",
    "cropKey": "pigeon-pea",
    "diseaseName": "Pigeon Pea / Arhar / Tur Pod Fly (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Pod Fly spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Pigeon Pea / Arhar / Tur.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Deep taproot breaks hard soil pans) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "pigeon-pea-disease-secondary",
    "crop": "Pigeon Pea / Arhar / Tur (तूर / अरहर)",
    "cropKey": "pigeon-pea",
    "diseaseName": "Pigeon Pea / Arhar / Tur Blister Beetle",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Blister Beetle appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "pigeon-pea-healthy",
    "crop": "Pigeon Pea / Arhar / Tur (तूर / अरहर)",
    "cropKey": "pigeon-pea",
    "diseaseName": "Pigeon Pea / Arhar / Tur Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "green-gram-disease-primary",
    "crop": "Green Gram / Mung Bean (मूंग)",
    "cropKey": "green-gram",
    "diseaseName": "Green Gram / Mung Bean Yellow Mosaic Virus (Whitefly vector) (Pathogen Complex)",
    "pathogenType": "Viral Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Yellow Mosaic Virus (Whitefly vector) spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Green Gram / Mung Bean.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Spray neem oil at early stage to control whitefly) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "green-gram-disease-secondary",
    "crop": "Green Gram / Mung Bean (मूंग)",
    "cropKey": "green-gram",
    "diseaseName": "Green Gram / Mung Bean Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "green-gram-healthy",
    "crop": "Green Gram / Mung Bean (मूंग)",
    "cropKey": "green-gram",
    "diseaseName": "Green Gram / Mung Bean Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "black-gram-disease-primary",
    "crop": "Black Gram / Urad Bean (उड़द)",
    "cropKey": "black-gram",
    "diseaseName": "Black Gram / Urad Bean Pod Borer (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Pod Borer spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Black Gram / Urad Bean.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Fixes up to 40 kg N/ha) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "black-gram-disease-secondary",
    "crop": "Black Gram / Urad Bean (उड़द)",
    "cropKey": "black-gram",
    "diseaseName": "Black Gram / Urad Bean Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "black-gram-healthy",
    "crop": "Black Gram / Urad Bean (उड़द)",
    "cropKey": "black-gram",
    "diseaseName": "Black Gram / Urad Bean Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "red-lentil-disease-primary",
    "crop": "Red Lentil / Masoor (मसूर)",
    "cropKey": "red-lentil",
    "diseaseName": "Red Lentil / Masoor Rust (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.12,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.26
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Rust spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Red Lentil / Masoor.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Extremely cold-tolerant pulse) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "red-lentil-disease-secondary",
    "crop": "Red Lentil / Masoor (मसूर)",
    "cropKey": "red-lentil",
    "diseaseName": "Red Lentil / Masoor Wilt",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Wilt appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "red-lentil-healthy",
    "crop": "Red Lentil / Masoor (मसूर)",
    "cropKey": "red-lentil",
    "diseaseName": "Red Lentil / Masoor Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "soybean-disease-primary",
    "crop": "Soybean (सोयाबीन)",
    "cropKey": "soybean",
    "diseaseName": "Soybean Girdle Beetle (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Girdle Beetle spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Soybean.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Ensure seed inoculation with Bradyrhizobium japonicum for maximum root nodulation.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "soybean-healthy",
    "crop": "Soybean (सोयाबीन)",
    "cropKey": "soybean",
    "diseaseName": "Soybean Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "cowpea-disease-primary",
    "crop": "Cowpea / Lobia (लोबिया / चवळी)",
    "cropKey": "cowpea",
    "diseaseName": "Cowpea / Lobia Aphids (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Aphids spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Cowpea / Lobia.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Tolerates high summer temperatures and moisture stress) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "cowpea-healthy",
    "crop": "Cowpea / Lobia (लोबिया / चवळी)",
    "cropKey": "cowpea",
    "diseaseName": "Cowpea / Lobia Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "field-pea-disease-primary",
    "crop": "Field Pea / Matar (मटर)",
    "cropKey": "field-pea",
    "diseaseName": "Field Pea / Matar Powdery Mildew (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.28,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Powdery Mildew spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Field Pea / Matar.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Spray wettable sulphur at first sign of powdery mildew) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "field-pea-disease-secondary",
    "crop": "Field Pea / Matar (मटर)",
    "cropKey": "field-pea",
    "diseaseName": "Field Pea / Matar Leaf Miner",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Leaf Miner appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "field-pea-healthy",
    "crop": "Field Pea / Matar (मटर)",
    "cropKey": "field-pea",
    "diseaseName": "Field Pea / Matar Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "horse-gram-disease-primary",
    "crop": "Horse Gram (कुलथी / हुलगा)",
    "cropKey": "horse-gram",
    "diseaseName": "Horse Gram Dry Root Rot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Dry Root Rot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Horse Gram.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Renowned for medicinal anti-urolithiatic properties) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "horse-gram-disease-secondary",
    "crop": "Horse Gram (कुलथी / हुलगा)",
    "cropKey": "horse-gram",
    "diseaseName": "Horse Gram Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "horse-gram-healthy",
    "crop": "Horse Gram (कुलथी / हुलगा)",
    "cropKey": "horse-gram",
    "diseaseName": "Horse Gram Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "kidney-bean-disease-primary",
    "crop": "Kidney Bean / Rajma (राजमा)",
    "cropKey": "kidney-bean",
    "diseaseName": "Kidney Bean / Rajma Bean Anthracnose (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Bean Anthracnose spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Kidney Bean / Rajma.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Unlike other legumes, Rajma lacks native nodulation in plains) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "kidney-bean-healthy",
    "crop": "Kidney Bean / Rajma (राजमा)",
    "cropKey": "kidney-bean",
    "diseaseName": "Kidney Bean / Rajma Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "moth-bean-disease-primary",
    "crop": "Moth Bean (मटकी)",
    "cropKey": "moth-bean",
    "diseaseName": "Moth Bean Jassids (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Jassids spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Moth Bean.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Most heat and drought-tolerant legume in India) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "moth-bean-healthy",
    "crop": "Moth Bean (मटकी)",
    "cropKey": "moth-bean",
    "diseaseName": "Moth Bean Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "mustard-disease-primary",
    "crop": "Mustard / Rapeseed (सरसों / मोहरी)",
    "cropKey": "mustard",
    "diseaseName": "Mustard / Rapeseed Mustard Aphid (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Mustard Aphid spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Mustard / Rapeseed.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Apply elemental sulphur at 20 kg/ha to boost seed oil content by 2-3%.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "mustard-disease-secondary",
    "crop": "Mustard / Rapeseed (सरसों / मोहरी)",
    "cropKey": "mustard",
    "diseaseName": "Mustard / Rapeseed White Rust",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.22
    },
    "symptoms": [
      "Characteristic foliar symptoms of White Rust appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "mustard-healthy",
    "crop": "Mustard / Rapeseed (सरसों / मोहरी)",
    "cropKey": "mustard",
    "diseaseName": "Mustard / Rapeseed Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "green-gram-disease-primary",
    "crop": "Groundnut / Peanut (मूंगफली / भुईमूग)",
    "cropKey": "green-gram",
    "diseaseName": "Groundnut / Peanut Tikka Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Tikka Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Groundnut / Peanut.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Apply 200 kg gypsum/ha at pegging stage to provide calcium for pod filling.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "green-gram-disease-secondary",
    "crop": "Groundnut / Peanut (मूंगफली / भुईमूग)",
    "cropKey": "green-gram",
    "diseaseName": "Groundnut / Peanut Collar Rot",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Collar Rot appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "green-gram-healthy",
    "crop": "Groundnut / Peanut (मूंगफली / भुईमूग)",
    "cropKey": "green-gram",
    "diseaseName": "Groundnut / Peanut Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "sunflower-disease-primary",
    "crop": "Sunflower (सूरजमुखी / सूर्यफूल)",
    "cropKey": "sunflower",
    "diseaseName": "Sunflower Helicoverpa (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Helicoverpa spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Sunflower.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Maintain beehives (4 colonies/ha) during anthesis to ensure complete seed setting.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "sunflower-disease-secondary",
    "crop": "Sunflower (सूरजमुखी / सूर्यफूल)",
    "cropKey": "sunflower",
    "diseaseName": "Sunflower Alternaria Blight",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Alternaria Blight appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "sunflower-healthy",
    "crop": "Sunflower (सूरजमुखी / सूर्यफूल)",
    "cropKey": "sunflower",
    "diseaseName": "Sunflower Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "sesame-disease-primary",
    "crop": "Sesame / Til (तिल / तीळ)",
    "cropKey": "sesame",
    "diseaseName": "Sesame / Til Phyllody (Leafhopper vector) (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Phyllody (Leafhopper vector) spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Sesame / Til.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (High-value export commodity) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "sesame-disease-secondary",
    "crop": "Sesame / Til (तिल / तीळ)",
    "cropKey": "sesame",
    "diseaseName": "Sesame / Til Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "sesame-healthy",
    "crop": "Sesame / Til (तिल / तीळ)",
    "cropKey": "sesame",
    "diseaseName": "Sesame / Til Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "safflower-disease-primary",
    "crop": "Safflower / Kardi (करडी)",
    "cropKey": "safflower",
    "diseaseName": "Safflower / Kardi Safflower Aphid (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Safflower Aphid spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Safflower / Kardi.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Deep taproots extract residual subsoil moisture) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "safflower-disease-secondary",
    "crop": "Safflower / Kardi (करडी)",
    "cropKey": "safflower",
    "diseaseName": "Safflower / Kardi Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "safflower-healthy",
    "crop": "Safflower / Kardi (करडी)",
    "cropKey": "safflower",
    "diseaseName": "Safflower / Kardi Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "castor-disease-primary",
    "crop": "Castor Seed (अरंडी / एरंडी)",
    "cropKey": "castor",
    "diseaseName": "Castor Seed Castor Semilooper (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Castor Semilooper spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Castor Seed.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (India produces 85% of global castor oil exports) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "castor-healthy",
    "crop": "Castor Seed (अरंडी / एरंडी)",
    "cropKey": "castor",
    "diseaseName": "Castor Seed Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "linseed-disease-primary",
    "crop": "Linseed / Flaxseed (अलसी / जवस)",
    "cropKey": "linseed",
    "diseaseName": "Linseed / Flaxseed Rust (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.12,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.26
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Rust spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Linseed / Flaxseed.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Rich in Omega-3 alpha-linolenic acid (ALA)) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "linseed-disease-secondary",
    "crop": "Linseed / Flaxseed (अलसी / जवस)",
    "cropKey": "linseed",
    "diseaseName": "Linseed / Flaxseed Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "linseed-healthy",
    "crop": "Linseed / Flaxseed (अलसी / जवस)",
    "cropKey": "linseed",
    "diseaseName": "Linseed / Flaxseed Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "sesame-disease-primary",
    "crop": "Niger Seed (रामतिल / कारळे)",
    "cropKey": "sesame",
    "diseaseName": "Niger Seed Caterpillar (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Caterpillar spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Niger Seed.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Key ingredient in Maharashtrian chutney & high-value birdseed exports to USA & EU.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "sesame-disease-secondary",
    "crop": "Niger Seed (रामतिल / कारळे)",
    "cropKey": "sesame",
    "diseaseName": "Niger Seed Cuscuta parasite",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Cuscuta parasite appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "sesame-healthy",
    "crop": "Niger Seed (रामतिल / कारळे)",
    "cropKey": "sesame",
    "diseaseName": "Niger Seed Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "sugarcane-disease-primary",
    "crop": "Sugarcane (गन्ना / ऊस)",
    "cropKey": "sugarcane",
    "diseaseName": "Sugarcane Early Shoot Borer (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Early Shoot Borer spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Sugarcane.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Sub-surface drip fertigation saves 45% water and increases cane sugar brix recovery.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "sugarcane-healthy",
    "crop": "Sugarcane (गन्ना / ऊस)",
    "cropKey": "sugarcane",
    "diseaseName": "Sugarcane Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "cotton-disease-primary",
    "crop": "Cotton (कपास / कापूस)",
    "cropKey": "cotton",
    "diseaseName": "Cotton Pink Bollworm (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Pink Bollworm spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Cotton.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Plant non-Bt refuge border rows and install pheromone lures to suppress Pink Bollworm.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "cotton-healthy",
    "crop": "Cotton (कपास / कापूस)",
    "cropKey": "cotton",
    "diseaseName": "Cotton Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "tea-disease-primary",
    "crop": "Tea (चाय / चहा)",
    "cropKey": "tea",
    "diseaseName": "Tea Tea Mosquito Bug (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Tea Mosquito Bug spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Tea.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Regular 7-10 day fine plucking (two leaves and a bud) produces premier orthodox cup quality.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "tea-disease-secondary",
    "crop": "Tea (चाय / चहा)",
    "cropKey": "tea",
    "diseaseName": "Tea Red Spider Mite",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Red Spider Mite appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "tea-healthy",
    "crop": "Tea (चाय / चहा)",
    "cropKey": "tea",
    "diseaseName": "Tea Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "coffee-disease-primary",
    "crop": "Coffee (कॉफी - अरेबिका / रोबस्टा)",
    "cropKey": "coffee",
    "diseaseName": "Coffee Coffee Berry Borer (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Coffee Berry Borer spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Coffee.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Shade-grown under native forest trees (Silver Oak, Fig) preserves biodiversity and cup aroma.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "coffee-healthy",
    "crop": "Coffee (कॉफी - अरेबिका / रोबस्टा)",
    "cropKey": "coffee",
    "diseaseName": "Coffee Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "coconut-disease-primary",
    "crop": "Coconut (नारियल / नारळ)",
    "cropKey": "coconut",
    "diseaseName": "Coconut Rhinoceros Beetle (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Rhinoceros Beetle spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Coconut.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Release parasitoid wasps (Goniozus nephantidis) to manage black-headed caterpillar.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "coconut-disease-secondary",
    "crop": "Coconut (नारियल / नारळ)",
    "cropKey": "coconut",
    "diseaseName": "Coconut Red Palm Weevil",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Red Palm Weevil appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "coconut-healthy",
    "crop": "Coconut (नारियल / नारळ)",
    "cropKey": "coconut",
    "diseaseName": "Coconut Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "tomato-disease-primary",
    "crop": "Tomato (टमाटर / टोमॅटो)",
    "cropKey": "tomato",
    "diseaseName": "Tomato Tomato Leaf Curl Virus (Pathogen Complex)",
    "pathogenType": "Viral Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Tomato Leaf Curl Virus spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Tomato.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Trellising plants on bamboo wire stakes improves fruit grade and prevents fungal soil rot.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "tomato-healthy",
    "crop": "Tomato (टमाटर / टोमॅटो)",
    "cropKey": "tomato",
    "diseaseName": "Tomato Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "potato-disease-primary",
    "crop": "Potato (आलू / बटाटा)",
    "cropKey": "potato",
    "diseaseName": "Potato Late Blight (Phytophthora) (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Late Blight (Phytophthora) spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Potato.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Earthing up tubers at 30 & 45 DAS prevents greening from direct sunlight exposure.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "potato-disease-secondary",
    "crop": "Potato (आलू / बटाटा)",
    "cropKey": "potato",
    "diseaseName": "Potato Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "potato-healthy",
    "crop": "Potato (आलू / बटाटा)",
    "cropKey": "potato",
    "diseaseName": "Potato Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "onion-disease-primary",
    "crop": "Onion (प्याज / कांदा)",
    "cropKey": "onion",
    "diseaseName": "Onion Thrips (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Thrips spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Onion.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Withhold irrigation 15 days before harvest and cure bulbs under shade to ensure 6-month shelf life.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "onion-disease-secondary",
    "crop": "Onion (प्याज / कांदा)",
    "cropKey": "onion",
    "diseaseName": "Onion Purple Blotch",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Purple Blotch appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "onion-healthy",
    "crop": "Onion (प्याज / कांदा)",
    "cropKey": "onion",
    "diseaseName": "Onion Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "garlic-disease-primary",
    "crop": "Garlic (लहसुन / लसूण)",
    "cropKey": "garlic",
    "diseaseName": "Garlic Thrips (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Thrips spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Garlic.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Plant healthy plump outer cloves) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "garlic-disease-secondary",
    "crop": "Garlic (लहसुन / लसूण)",
    "cropKey": "garlic",
    "diseaseName": "Garlic Stemphylium Blight",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Stemphylium Blight appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "garlic-healthy",
    "crop": "Garlic (लहसुन / लसूण)",
    "cropKey": "garlic",
    "diseaseName": "Garlic Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "brinjal-disease-primary",
    "crop": "Brinjal / Eggplant (बैंगन / वांगे)",
    "cropKey": "brinjal",
    "diseaseName": "Brinjal / Eggplant Shoot and Fruit Borer (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Shoot and Fruit Borer spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Brinjal / Eggplant.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Install pheromone Lucinlure traps at 20 traps/ha for non-chemical fruit borer management.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "brinjal-disease-secondary",
    "crop": "Brinjal / Eggplant (बैंगन / वांगे)",
    "cropKey": "brinjal",
    "diseaseName": "Brinjal / Eggplant Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "brinjal-healthy",
    "crop": "Brinjal / Eggplant (बैंगन / वांगे)",
    "cropKey": "brinjal",
    "diseaseName": "Brinjal / Eggplant Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "okra-disease-primary",
    "crop": "Okra / Ladyfinger (भिंडी)",
    "cropKey": "okra",
    "diseaseName": "Okra / Ladyfinger Yellow Vein Mosaic Virus (Pathogen Complex)",
    "pathogenType": "Viral Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Yellow Vein Mosaic Virus spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Okra / Ladyfinger.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Select YVMV-resistant hybrid varieties (e.g. Parbhani Kranti, Kashi Kranti) for Kharif season.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "okra-disease-secondary",
    "crop": "Okra / Ladyfinger (भिंडी)",
    "cropKey": "okra",
    "diseaseName": "Okra / Ladyfinger Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "okra-healthy",
    "crop": "Okra / Ladyfinger (भिंडी)",
    "cropKey": "okra",
    "diseaseName": "Okra / Ladyfinger Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "chilli-disease-primary",
    "crop": "Green Chilli (हरी मिर्च / मिरची)",
    "cropKey": "chilli",
    "diseaseName": "Green Chilli Thrips (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Thrips spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Green Chilli.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Spray spinosad or neem formulations to suppress thrips vectors causing leaf curl.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "chilli-disease-secondary",
    "crop": "Green Chilli (हरी मिर्च / मिरची)",
    "cropKey": "chilli",
    "diseaseName": "Green Chilli Mites",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Mites appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "chilli-healthy",
    "crop": "Green Chilli (हरी मिर्च / मिरची)",
    "cropKey": "chilli",
    "diseaseName": "Green Chilli Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "turmeric-disease-primary",
    "crop": "Turmeric (हल्दी / हळद)",
    "cropKey": "turmeric",
    "diseaseName": "Turmeric Rhizome Rot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Rhizome Rot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Turmeric.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Cultivate high curcumin (5%+) varieties like Salem, Waigaon or Rajapore for export premium.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "turmeric-healthy",
    "crop": "Turmeric (हल्दी / हळद)",
    "cropKey": "turmeric",
    "diseaseName": "Turmeric Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "ginger-disease-primary",
    "crop": "Ginger (अदरक / आले)",
    "cropKey": "ginger",
    "diseaseName": "Ginger Soft Rot (Pythium) (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Soft Rot (Pythium) spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Ginger.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Provide raised beds (15 cm high) and heavy mulch with green leaves to prevent rhizome rot.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "ginger-disease-secondary",
    "crop": "Ginger (अदरक / आले)",
    "cropKey": "ginger",
    "diseaseName": "Ginger Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "ginger-healthy",
    "crop": "Ginger (अदरक / आले)",
    "cropKey": "ginger",
    "diseaseName": "Ginger Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "cumin-disease-primary",
    "crop": "Cumin / Jeera (जीरा)",
    "cropKey": "cumin",
    "diseaseName": "Cumin / Jeera Blight (Alternaria burnsii) (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Blight (Alternaria burnsii) spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Cumin / Jeera.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Extremely sensitive to cloudy weather and drizzle at flowering) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "cumin-disease-secondary",
    "crop": "Cumin / Jeera (जीरा)",
    "cropKey": "cumin",
    "diseaseName": "Cumin / Jeera Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "cumin-healthy",
    "crop": "Cumin / Jeera (जीरा)",
    "cropKey": "cumin",
    "diseaseName": "Cumin / Jeera Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "coriander-disease-primary",
    "crop": "Coriander / Dhaniya (धनिया / धने)",
    "cropKey": "coriander",
    "diseaseName": "Coriander / Dhaniya Powdery Mildew (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.28,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Powdery Mildew spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Coriander / Dhaniya.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Split seed into two mericarps by gentle rubbing before sowing to enhance germination.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "coriander-disease-secondary",
    "crop": "Coriander / Dhaniya (धनिया / धने)",
    "cropKey": "coriander",
    "diseaseName": "Coriander / Dhaniya Stem Gall",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Stem Gall appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "coriander-healthy",
    "crop": "Coriander / Dhaniya (धनिया / धने)",
    "cropKey": "coriander",
    "diseaseName": "Coriander / Dhaniya Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "black-pepper-disease-primary",
    "crop": "Black Pepper (काली मिर्च / मिरी)",
    "cropKey": "black-pepper",
    "diseaseName": "Black Pepper Quick Wilt (Phytophthora foot rot) (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Quick Wilt (Phytophthora foot rot) spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Black Pepper.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Interplanted on Arecanut/Silver Oak standards in Western Ghats) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "black-pepper-disease-secondary",
    "crop": "Black Pepper (काली मिर्च / मिरी)",
    "cropKey": "black-pepper",
    "diseaseName": "Black Pepper Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "black-pepper-healthy",
    "crop": "Black Pepper (काली मिर्च / मिरी)",
    "cropKey": "black-pepper",
    "diseaseName": "Black Pepper Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "small-cardamom-disease-primary",
    "crop": "Small Cardamom (छोटी इलायची / वेलची)",
    "cropKey": "small-cardamom",
    "diseaseName": "Small Cardamom Cardamom Thrips (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Cardamom Thrips spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Small Cardamom.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Requires filtered 50% evergreen tree shade and high relative humidity (80%+) to thrive.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "small-cardamom-disease-secondary",
    "crop": "Small Cardamom (छोटी इलायची / वेलची)",
    "cropKey": "small-cardamom",
    "diseaseName": "Small Cardamom Rhizome Rot",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Rhizome Rot appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "small-cardamom-healthy",
    "crop": "Small Cardamom (छोटी इलायची / वेलची)",
    "cropKey": "small-cardamom",
    "diseaseName": "Small Cardamom Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "ashwagandha-disease-primary",
    "crop": "Ashwagandha (अश्वगंधा)",
    "cropKey": "ashwagandha",
    "diseaseName": "Ashwagandha Root Rot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Root Rot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Ashwagandha.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Premier adaptogenic Ayurvedic root) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "ashwagandha-disease-secondary",
    "crop": "Ashwagandha (अश्वगंधा)",
    "cropKey": "ashwagandha",
    "diseaseName": "Ashwagandha Leaf Spot",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Leaf Spot appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "ashwagandha-healthy",
    "crop": "Ashwagandha (अश्वगंधा)",
    "cropKey": "ashwagandha",
    "diseaseName": "Ashwagandha Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "tulsi-disease-primary",
    "crop": "Tulsi / Holy Basil (तुलसी)",
    "cropKey": "tulsi",
    "diseaseName": "Tulsi / Holy Basil Leaf Blight (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Blight spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Tulsi / Holy Basil.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Multi-cut medicinal crop harvested every 75 days) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "tulsi-disease-secondary",
    "crop": "Tulsi / Holy Basil (तुलसी)",
    "cropKey": "tulsi",
    "diseaseName": "Tulsi / Holy Basil Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "tulsi-healthy",
    "crop": "Tulsi / Holy Basil (तुलसी)",
    "cropKey": "tulsi",
    "diseaseName": "Tulsi / Holy Basil Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "lemongrass-disease-primary",
    "crop": "Lemongrass (लेमनग्रास)",
    "cropKey": "lemongrass",
    "diseaseName": "Lemongrass Rust (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.12,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.26
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Rust spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Lemongrass.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (On-farm steam distillation unit yields high citral oil used in perfumes and pharma.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "lemongrass-disease-secondary",
    "crop": "Lemongrass (लेमनग्रास)",
    "cropKey": "lemongrass",
    "diseaseName": "Lemongrass Powdery Mildew",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.32,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Powdery Mildew appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "lemongrass-healthy",
    "crop": "Lemongrass (लेमनग्रास)",
    "cropKey": "lemongrass",
    "diseaseName": "Lemongrass Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "watermelon-disease-primary",
    "crop": "Watermelon (तरबूज / टरबूज)",
    "cropKey": "watermelon",
    "diseaseName": "Watermelon Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Watermelon.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "watermelon-disease-secondary",
    "crop": "Watermelon (तरबूज / टरबूज)",
    "cropKey": "watermelon",
    "diseaseName": "Watermelon Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "watermelon-healthy",
    "crop": "Watermelon (तरबूज / टरबूज)",
    "cropKey": "watermelon",
    "diseaseName": "Watermelon Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "muskmelon-disease-primary",
    "crop": "Muskmelon (खरबूज)",
    "cropKey": "muskmelon",
    "diseaseName": "Muskmelon Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Muskmelon.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "muskmelon-disease-secondary",
    "crop": "Muskmelon (खरबूज)",
    "cropKey": "muskmelon",
    "diseaseName": "Muskmelon Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "muskmelon-healthy",
    "crop": "Muskmelon (खरबूज)",
    "cropKey": "muskmelon",
    "diseaseName": "Muskmelon Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "bottle-gourd-disease-primary",
    "crop": "Bottle Gourd / Lauki (लौकी / दुधी)",
    "cropKey": "bottle-gourd",
    "diseaseName": "Bottle Gourd / Lauki Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Bottle Gourd / Lauki.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "bottle-gourd-disease-secondary",
    "crop": "Bottle Gourd / Lauki (लौकी / दुधी)",
    "cropKey": "bottle-gourd",
    "diseaseName": "Bottle Gourd / Lauki Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "bottle-gourd-healthy",
    "crop": "Bottle Gourd / Lauki (लौकी / दुधी)",
    "cropKey": "bottle-gourd",
    "diseaseName": "Bottle Gourd / Lauki Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "bitter-gourd-disease-primary",
    "crop": "Bitter Gourd / Karela (करेला / कारले)",
    "cropKey": "bitter-gourd",
    "diseaseName": "Bitter Gourd / Karela Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Bitter Gourd / Karela.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "bitter-gourd-disease-secondary",
    "crop": "Bitter Gourd / Karela (करेला / कारले)",
    "cropKey": "bitter-gourd",
    "diseaseName": "Bitter Gourd / Karela Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "bitter-gourd-healthy",
    "crop": "Bitter Gourd / Karela (करेला / कारले)",
    "cropKey": "bitter-gourd",
    "diseaseName": "Bitter Gourd / Karela Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "ridge-gourd-disease-primary",
    "crop": "Ridge Gourd / Turai (तुरई / दोडका)",
    "cropKey": "ridge-gourd",
    "diseaseName": "Ridge Gourd / Turai Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Ridge Gourd / Turai.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "ridge-gourd-disease-secondary",
    "crop": "Ridge Gourd / Turai (तुरई / दोडका)",
    "cropKey": "ridge-gourd",
    "diseaseName": "Ridge Gourd / Turai Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "ridge-gourd-healthy",
    "crop": "Ridge Gourd / Turai (तुरई / दोडका)",
    "cropKey": "ridge-gourd",
    "diseaseName": "Ridge Gourd / Turai Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "cucumber-disease-primary",
    "crop": "Cucumber (खीरा / काकडी)",
    "cropKey": "cucumber",
    "diseaseName": "Cucumber Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Cucumber.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "cucumber-disease-secondary",
    "crop": "Cucumber (खीरा / काकडी)",
    "cropKey": "cucumber",
    "diseaseName": "Cucumber Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "cucumber-healthy",
    "crop": "Cucumber (खीरा / काकडी)",
    "cropKey": "cucumber",
    "diseaseName": "Cucumber Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "spinach-disease-primary",
    "crop": "Spinach / Palak (पालक)",
    "cropKey": "spinach",
    "diseaseName": "Spinach / Palak Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Spinach / Palak.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "spinach-disease-secondary",
    "crop": "Spinach / Palak (पालक)",
    "cropKey": "spinach",
    "diseaseName": "Spinach / Palak Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "spinach-healthy",
    "crop": "Spinach / Palak (पालक)",
    "cropKey": "spinach",
    "diseaseName": "Spinach / Palak Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "fenugreek-leaves-disease-primary",
    "crop": "Fenugreek Leaves / Methi (मेथी)",
    "cropKey": "fenugreek-leaves",
    "diseaseName": "Fenugreek Leaves / Methi Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Fenugreek Leaves / Methi.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "fenugreek-leaves-disease-secondary",
    "crop": "Fenugreek Leaves / Methi (मेथी)",
    "cropKey": "fenugreek-leaves",
    "diseaseName": "Fenugreek Leaves / Methi Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "fenugreek-leaves-healthy",
    "crop": "Fenugreek Leaves / Methi (मेथी)",
    "cropKey": "fenugreek-leaves",
    "diseaseName": "Fenugreek Leaves / Methi Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "carrot-disease-primary",
    "crop": "Carrot (गाजर)",
    "cropKey": "carrot",
    "diseaseName": "Carrot Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Carrot.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "carrot-disease-secondary",
    "crop": "Carrot (गाजर)",
    "cropKey": "carrot",
    "diseaseName": "Carrot Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "carrot-healthy",
    "crop": "Carrot (गाजर)",
    "cropKey": "carrot",
    "diseaseName": "Carrot Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "radish-disease-primary",
    "crop": "Radish / Mooli (मूली / मुळा)",
    "cropKey": "radish",
    "diseaseName": "Radish / Mooli Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Radish / Mooli.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "radish-disease-secondary",
    "crop": "Radish / Mooli (मूली / मुळा)",
    "cropKey": "radish",
    "diseaseName": "Radish / Mooli Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "radish-healthy",
    "crop": "Radish / Mooli (मूली / मुळा)",
    "cropKey": "radish",
    "diseaseName": "Radish / Mooli Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "beetroot-disease-primary",
    "crop": "Beetroot (चुकंदर)",
    "cropKey": "beetroot",
    "diseaseName": "Beetroot Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Beetroot.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "beetroot-disease-secondary",
    "crop": "Beetroot (चुकंदर)",
    "cropKey": "beetroot",
    "diseaseName": "Beetroot Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "beetroot-healthy",
    "crop": "Beetroot (चुकंदर)",
    "cropKey": "beetroot",
    "diseaseName": "Beetroot Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "sweet-potato-disease-primary",
    "crop": "Sweet Potato (शकरकंद / रताळे)",
    "cropKey": "sweet-potato",
    "diseaseName": "Sweet Potato Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Sweet Potato.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "sweet-potato-disease-secondary",
    "crop": "Sweet Potato (शकरकंद / रताळे)",
    "cropKey": "sweet-potato",
    "diseaseName": "Sweet Potato Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "sweet-potato-healthy",
    "crop": "Sweet Potato (शकरकंद / रताळे)",
    "cropKey": "sweet-potato",
    "diseaseName": "Sweet Potato Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "cassava-disease-primary",
    "crop": "Cassava / Tapioca (साबूदाना)",
    "cropKey": "cassava",
    "diseaseName": "Cassava / Tapioca Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Cassava / Tapioca.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "cassava-disease-secondary",
    "crop": "Cassava / Tapioca (साबूदाना)",
    "cropKey": "cassava",
    "diseaseName": "Cassava / Tapioca Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "cassava-healthy",
    "crop": "Cassava / Tapioca (साबूदाना)",
    "cropKey": "cassava",
    "diseaseName": "Cassava / Tapioca Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "elephant-foot-yam-disease-primary",
    "crop": "Elephant Foot Yam (सूरन)",
    "cropKey": "elephant-foot-yam",
    "diseaseName": "Elephant Foot Yam Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Elephant Foot Yam.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "elephant-foot-yam-disease-secondary",
    "crop": "Elephant Foot Yam (सूरन)",
    "cropKey": "elephant-foot-yam",
    "diseaseName": "Elephant Foot Yam Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "elephant-foot-yam-healthy",
    "crop": "Elephant Foot Yam (सूरन)",
    "cropKey": "elephant-foot-yam",
    "diseaseName": "Elephant Foot Yam Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "drumstick-disease-primary",
    "crop": "Drumstick / Moringa (सहजन / शेवगा)",
    "cropKey": "drumstick",
    "diseaseName": "Drumstick / Moringa Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Drumstick / Moringa.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "drumstick-disease-secondary",
    "crop": "Drumstick / Moringa (सहजन / शेवगा)",
    "cropKey": "drumstick",
    "diseaseName": "Drumstick / Moringa Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "drumstick-healthy",
    "crop": "Drumstick / Moringa (सहजन / शेवगा)",
    "cropKey": "drumstick",
    "diseaseName": "Drumstick / Moringa Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "nutmeg-disease-primary",
    "crop": "Nutmeg & Mace (जायफल)",
    "cropKey": "nutmeg",
    "diseaseName": "Nutmeg & Mace Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Nutmeg & Mace.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "nutmeg-disease-secondary",
    "crop": "Nutmeg & Mace (जायफल)",
    "cropKey": "nutmeg",
    "diseaseName": "Nutmeg & Mace Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "nutmeg-healthy",
    "crop": "Nutmeg & Mace (जायफल)",
    "cropKey": "nutmeg",
    "diseaseName": "Nutmeg & Mace Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "clove-disease-primary",
    "crop": "Clove (लौंग / लवंग)",
    "cropKey": "clove",
    "diseaseName": "Clove Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Clove.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "clove-disease-secondary",
    "crop": "Clove (लौंग / लवंग)",
    "cropKey": "clove",
    "diseaseName": "Clove Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "clove-healthy",
    "crop": "Clove (लौंग / लवंग)",
    "cropKey": "clove",
    "diseaseName": "Clove Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "cinnamon-disease-primary",
    "crop": "Cinnamon (दालचीनी)",
    "cropKey": "cinnamon",
    "diseaseName": "Cinnamon Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Cinnamon.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "cinnamon-disease-secondary",
    "crop": "Cinnamon (दालचीनी)",
    "cropKey": "cinnamon",
    "diseaseName": "Cinnamon Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "cinnamon-healthy",
    "crop": "Cinnamon (दालचीनी)",
    "cropKey": "cinnamon",
    "diseaseName": "Cinnamon Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "fenugreek-seeds-disease-primary",
    "crop": "Fenugreek Seeds / Methi (मेथी दाना)",
    "cropKey": "fenugreek-seeds",
    "diseaseName": "Fenugreek Seeds / Methi Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Fenugreek Seeds / Methi.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "fenugreek-seeds-disease-secondary",
    "crop": "Fenugreek Seeds / Methi (मेथी दाना)",
    "cropKey": "fenugreek-seeds",
    "diseaseName": "Fenugreek Seeds / Methi Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "fenugreek-seeds-healthy",
    "crop": "Fenugreek Seeds / Methi (मेथी दाना)",
    "cropKey": "fenugreek-seeds",
    "diseaseName": "Fenugreek Seeds / Methi Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "ajwain-disease-primary",
    "crop": "Ajwain / Carom Seeds (अजवायन / ओवा)",
    "cropKey": "ajwain",
    "diseaseName": "Ajwain / Carom Seeds Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Ajwain / Carom Seeds.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "ajwain-disease-secondary",
    "crop": "Ajwain / Carom Seeds (अजवायन / ओवा)",
    "cropKey": "ajwain",
    "diseaseName": "Ajwain / Carom Seeds Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "ajwain-healthy",
    "crop": "Ajwain / Carom Seeds (अजवायन / ओवा)",
    "cropKey": "ajwain",
    "diseaseName": "Ajwain / Carom Seeds Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "cumin-disease-primary",
    "crop": "Kalonji / Black Cumin (कलौंजी)",
    "cropKey": "cumin",
    "diseaseName": "Kalonji / Black Cumin Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Kalonji / Black Cumin.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "cumin-disease-secondary",
    "crop": "Kalonji / Black Cumin (कलौंजी)",
    "cropKey": "cumin",
    "diseaseName": "Kalonji / Black Cumin Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "cumin-healthy",
    "crop": "Kalonji / Black Cumin (कलौंजी)",
    "cropKey": "cumin",
    "diseaseName": "Kalonji / Black Cumin Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "aloe-vera-disease-primary",
    "crop": "Aloe Vera (एलोवेरा)",
    "cropKey": "aloe-vera",
    "diseaseName": "Aloe Vera Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Aloe Vera.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "aloe-vera-disease-secondary",
    "crop": "Aloe Vera (एलोवेरा)",
    "cropKey": "aloe-vera",
    "diseaseName": "Aloe Vera Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "aloe-vera-healthy",
    "crop": "Aloe Vera (एलोवेरा)",
    "cropKey": "aloe-vera",
    "diseaseName": "Aloe Vera Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "stevia-disease-primary",
    "crop": "Stevia Sweet Herb (स्टीविया)",
    "cropKey": "stevia",
    "diseaseName": "Stevia Sweet Herb Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Stevia Sweet Herb.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "stevia-disease-secondary",
    "crop": "Stevia Sweet Herb (स्टीविया)",
    "cropKey": "stevia",
    "diseaseName": "Stevia Sweet Herb Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "stevia-healthy",
    "crop": "Stevia Sweet Herb (स्टीविया)",
    "cropKey": "stevia",
    "diseaseName": "Stevia Sweet Herb Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "isabgol-disease-primary",
    "crop": "Isabgol / Psyllium Husk (इसबगोल)",
    "cropKey": "isabgol",
    "diseaseName": "Isabgol / Psyllium Husk Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Isabgol / Psyllium Husk.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "isabgol-disease-secondary",
    "crop": "Isabgol / Psyllium Husk (इसबगोल)",
    "cropKey": "isabgol",
    "diseaseName": "Isabgol / Psyllium Husk Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "isabgol-healthy",
    "crop": "Isabgol / Psyllium Husk (इसबगोल)",
    "cropKey": "isabgol",
    "diseaseName": "Isabgol / Psyllium Husk Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "senna-disease-primary",
    "crop": "Senna / Sonamukhi (सनाय)",
    "cropKey": "senna",
    "diseaseName": "Senna / Sonamukhi Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Senna / Sonamukhi.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "senna-disease-secondary",
    "crop": "Senna / Sonamukhi (सनाय)",
    "cropKey": "senna",
    "diseaseName": "Senna / Sonamukhi Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "senna-healthy",
    "crop": "Senna / Sonamukhi (सनाय)",
    "cropKey": "senna",
    "diseaseName": "Senna / Sonamukhi Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  },
  {
    "id": "areca-palm-disease-primary",
    "crop": "Areca Palm (एरेका पाम)",
    "cropKey": "areca-palm",
    "diseaseName": "Areca Palm Leaf Spot (Pathogen Complex)",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.48,
      "necrotic": 0.32,
      "chlorosis": 0.16,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Prominent foliar lesions characteristic of Leaf Spot spreading along leaf margins and interveinal sectors.",
      "Loss of green chlorophyll density with visible necrotic discoloration and water-soaked halo boundaries.",
      "Premature drying of heavily infected foliage causing reduced photosynthetic translocation and yield reduction.",
      "In advanced stages, lesions coalesce into extensive scorched patches across the canopy."
    ],
    "whyThisHappens": {
      "pathogenCause": "Infection initiated by foliar pathogen causing localized tissue breakdown and vascular blockage in Areca Palm.",
      "weatherTriggers": "High ambient humidity (>80% RH), cloudy overcast skies, and prolonged foliar wetness (dew/rain) exceeding 6-8 continuous hours.",
      "transmissionMode": "Windborne conidia, splashing rainfall droplets, or insect vectors (whiteflies, thrips, aphids) transmitting infectious propagules across the field.",
      "riskFactors": "Excessive vegetative canopy density, high chemical nitrogen / urea overdosing, overhead sprinkler irrigation, and lack of crop rotation."
    },
    "culturalMeasures": [
      "Promptly prune and rogue out infected leaves and destroy them away from the cropping area.",
      "Avoid overhead sprinkler irrigation in late afternoon; switch to drip or furrow irrigation to minimize leaf wetness duration.",
      "Ensure proper plant spacing (Follow integrated nutrient and pest management (INM/IPM) with organic mulching.) to maximize solar penetration and air circulation."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5 g / Liter water at 10-14 day intervals.",
      "Neem oil emulsion (Azadirachtin 10,000 ppm) @ 2.5 ml / Liter water with mild surfactant for organic bio-protection."
    ],
    "chemicalControl": [
      {
        "chemical": "Mancozeb 75% WP (Dithane M-45 / Indofil M-45)",
        "dosage": "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        "timing": "Protective multi-site contact spray; apply at first appearance of symptoms and repeat after 10-12 days."
      },
      {
        "chemical": "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Curative systemic translaminar spray for rapid suppression of progressing foliar lesions."
      }
    ],
    "preventiveCare": [
      "Treat certified seeds with Thiram 75% WP or Carbendazim @ 2.5 g/kg seed before sowing.",
      "Follow balanced NPK fertilization avoiding excessive vegetative flush during high disease pressure periods."
    ],
    "kvkHelpline": "Local Krishi Vigyan Kendra (KVK) Plant Health Clinic: 1800-180-1551."
  },
  {
    "id": "areca-palm-disease-secondary",
    "crop": "Areca Palm (एरेका पाम)",
    "cropKey": "areca-palm",
    "diseaseName": "Areca Palm Sucking Pests",
    "pathogenType": "Fungal Pathogen",
    "targetBiomarkers": {
      "green": 0.52,
      "necrotic": 0.24,
      "chlorosis": 0.18,
      "powdery": 0.02,
      "rust": 0.02
    },
    "symptoms": [
      "Characteristic foliar symptoms of Sucking Pests appearing on upper or lower leaf surfaces.",
      "Foliar chlorotic mottling, localized necrotic spotting, and gradual leaf senescence."
    ],
    "whyThisHappens": {
      "pathogenCause": "Secondary fungal or bacterial pathogen taking advantage of favorable canopy microclimate and host susceptibility.",
      "weatherTriggers": "Fluctuating temperatures between 20°C and 30°C coupled with intermittent rainfall or dense early morning dew.",
      "transmissionMode": "Airborne spores transported on air currents or secondary splash dispersal from soil-borne inoculum.",
      "riskFactors": "Monoculture cropping, shade stress under dense canopies, and un-sanitized agricultural implements."
    },
    "culturalMeasures": [
      "Maintain weed-free field borders to eliminate collateral hosts.",
      "Deep summer ploughing to expose dormant resting structures to solar heat."
    ],
    "biologicalControl": [
      "Foliar spray with Pseudomonas fluorescens @ 10 g / Liter of water.",
      "Bio-fungicide spray with Bacillus subtilis @ 3 ml / Liter."
    ],
    "chemicalControl": [
      {
        "chemical": "Propiconazole 25% EC (Tilt)",
        "dosage": "15 ml / 15L knapsack pump (1.0 ml/L)",
        "timing": "Systemic triazole fungicide spray targeting mid-canopy foliar infections."
      }
    ],
    "preventiveCare": [
      "Incorporate well-decomposed Farmyard Manure (FYM) enriched with Trichoderma @ 5 kg/tonne at field preparation."
    ],
    "kvkHelpline": "State Agricultural Extension Directorate: 1800-180-1551."
  },
  {
    "id": "areca-palm-healthy",
    "crop": "Areca Palm (एरेका पाम)",
    "cropKey": "areca-palm",
    "diseaseName": "Areca Palm Healthy Foliage (Nominal Baseline)",
    "pathogenType": "Healthy Foliage",
    "targetBiomarkers": {
      "green": 0.96,
      "necrotic": 0.01,
      "chlorosis": 0.03,
      "powdery": 0,
      "rust": 0
    },
    "symptoms": [
      "Vigorous photosynthetic green leaf lamina with uniform chlorophyll distribution.",
      "Zero necrotic lesions, water-soaked margins, viral mottling, or fungal mycelia.",
      "Intact foliar cuticular layer with optimal leaf turgor and erect vegetative architecture."
    ],
    "whyThisHappens": {
      "pathogenCause": "Absence of pathogenic infection; plant possesses fully functional immunological defense barriers and balanced cell wall lignification.",
      "weatherTriggers": "Optimal ambient temperature and moderate relative humidity within the crop's physiological comfort zone.",
      "transmissionMode": "No pathogen transmission active.",
      "riskFactors": "Maintain regular field scouting and prophylactic bio-protection."
    },
    "culturalMeasures": [
      "Continue standard scientific irrigation scheduling avoiding drought stress or root-zone waterlogging.",
      "Maintain clean weed-free bunds and field borders."
    ],
    "biologicalControl": [
      "Prophylactic foliar spray with Neem oil (10,000 ppm) @ 2 ml/L every 20-25 days for general pest repellence."
    ],
    "chemicalControl": [],
    "preventiveCare": [
      "Monitor crop foliage weekly for early signs of pathogen ingress.",
      "Maintain balanced micro-nutrient foliar spray (Zinc, Boron, Ferrous) during active vegetative growth."
    ],
    "kvkHelpline": "Kisan Call Center: 1800-180-1551."
  }
];

const expandedPlantDiseaseDatabase = exports.expandedPlantDiseaseDatabase = [...baseExpandedPlantDiseaseDatabase, ...fruitDiseases];

const baseAllCropsHealthyReferenceModels = {
  "wheat": {
    "cropKey": "wheat",
    "cropName": "Wheat (गेहूं / गहू)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/wheat_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Wheat displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refwheat\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refwheat)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "rice": {
    "cropKey": "rice",
    "cropName": "Paddy / Rice (धान / भात)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Paddy / Rice displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refrice\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refrice)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "basmati-rice": {
    "cropKey": "basmati-rice",
    "cropName": "Basmati Rice (बासमती चावल)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Basmati Rice displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refbasmatirice\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refbasmatirice)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "maize": {
    "cropKey": "maize",
    "cropName": "Maize / Corn (मक्का / मका)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/maize_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Maize / Corn displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refmaize\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refmaize)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "barley": {
    "cropKey": "barley",
    "cropName": "Barley (जौ / जाऊ)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Barley displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refbarley\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refbarley)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "jowar": {
    "cropKey": "jowar",
    "cropName": "Sorghum / Jowar (ज्वार / ज्वारी)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Sorghum / Jowar displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refjowar\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refjowar)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "bajra": {
    "cropKey": "bajra",
    "cropName": "Pearl Millet / Bajra (बाजरा / बाजरी)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Pearl Millet / Bajra displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refbajra\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refbajra)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "ragi": {
    "cropKey": "ragi",
    "cropName": "Finger Millet / Ragi (रागी / नाचणी)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Finger Millet / Ragi displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refragi\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refragi)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "foxtail-millet": {
    "cropKey": "foxtail-millet",
    "cropName": "Foxtail Millet (कंगनी / राळा)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Foxtail Millet displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"reffoxtailmillet\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#reffoxtailmillet)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "kodo-millet": {
    "cropKey": "kodo-millet",
    "cropName": "Kodo Millet (कोदो / कोद्रा)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Kodo Millet displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refkodomillet\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refkodomillet)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "little-millet": {
    "cropKey": "little-millet",
    "cropName": "Little Millet (कुटकी / सावा)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Little Millet displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"reflittlemillet\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#reflittlemillet)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "barnyard-millet": {
    "cropKey": "barnyard-millet",
    "cropName": "Barnyard Millet (सांवा / भगरी)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Barnyard Millet displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refbarnyardmillet\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refbarnyardmillet)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "proso-millet": {
    "cropKey": "proso-millet",
    "cropName": "Proso Millet (चेना / वरी)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Proso Millet displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refprosomillet\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refprosomillet)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "oats": {
    "cropKey": "oats",
    "cropName": "Oats (जई / ओट्स)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Oats displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refoats\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refoats)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "quinoa": {
    "cropKey": "quinoa",
    "cropName": "Quinoa (कीनवा)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Quinoa displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refquinoa\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refquinoa)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "c-16": {
    "cropKey": "c-16",
    "cropName": "Amaranth Grain / Rajgira (राजगिरा)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Amaranth Grain / Rajgira displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refc16\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refc16)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "sweet-corn": {
    "cropKey": "sweet-corn",
    "cropName": "Sweet Corn (स्वीट कॉर्न)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/maize_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Sweet Corn displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refsweetcorn\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refsweetcorn)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "baby-corn": {
    "cropKey": "baby-corn",
    "cropName": "Baby Corn (बेबी कॉर्न)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/maize_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Baby Corn displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refbabycorn\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refbabycorn)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "chickpea": {
    "cropKey": "chickpea",
    "cropName": "Chickpea / Desi Chana (चना / हरभरा)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Chickpea / Desi Chana displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refchickpea\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refchickpea)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "kabuli-chana": {
    "cropKey": "kabuli-chana",
    "cropName": "Kabuli Chana / Dollar Gram (काबुली चना)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Kabuli Chana / Dollar Gram displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refkabulichana\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refkabulichana)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "pigeon-pea": {
    "cropKey": "pigeon-pea",
    "cropName": "Pigeon Pea / Arhar / Tur (तूर / अरहर)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Pigeon Pea / Arhar / Tur displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refpigeonpea\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refpigeonpea)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "green-gram": {
    "cropKey": "green-gram",
    "cropName": "Green Gram / Mung Bean (मूंग)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Green Gram / Mung Bean displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refgreengram\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refgreengram)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "black-gram": {
    "cropKey": "black-gram",
    "cropName": "Black Gram / Urad Bean (उड़द)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Black Gram / Urad Bean displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refblackgram\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refblackgram)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "red-lentil": {
    "cropKey": "red-lentil",
    "cropName": "Red Lentil / Masoor (मसूर)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Red Lentil / Masoor displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refredlentil\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refredlentil)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "soybean": {
    "cropKey": "soybean",
    "cropName": "Soybean (सोयाबीन)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Soybean displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refsoybean\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refsoybean)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "cowpea": {
    "cropKey": "cowpea",
    "cropName": "Cowpea / Lobia (लोबिया / चवळी)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Cowpea / Lobia displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcowpea\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcowpea)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "field-pea": {
    "cropKey": "field-pea",
    "cropName": "Field Pea / Matar (मटर)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Field Pea / Matar displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"reffieldpea\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#reffieldpea)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "horse-gram": {
    "cropKey": "horse-gram",
    "cropName": "Horse Gram (कुलथी / हुलगा)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Horse Gram displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refhorsegram\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refhorsegram)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "kidney-bean": {
    "cropKey": "kidney-bean",
    "cropName": "Kidney Bean / Rajma (राजमा)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Kidney Bean / Rajma displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refkidneybean\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refkidneybean)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "moth-bean": {
    "cropKey": "moth-bean",
    "cropName": "Moth Bean (मटकी)",
    "botanicalClass": "Dicotyledonae (Fabaceae)",
    "leafMorphology": "Pinnately compound or trifoliate leaf with elliptical-obovate leaflets",
    "marginType": "Entire smooth rounded margin",
    "aspectRatioDescriptor": "Trifoliate / Obovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Moth Bean displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refmothbean\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refmothbean)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "mustard": {
    "cropKey": "mustard",
    "cropName": "Mustard / Rapeseed (सरसों / मोहरी)",
    "botanicalClass": "Dicotyledonae (Brassicaceae / Asteraceae)",
    "leafMorphology": "Broad lyrately pinnatifid or ovate blade with prominent reticulate venation",
    "marginType": "Wavy to shallowly dentate margin",
    "aspectRatioDescriptor": "Broad Ovate / Lobe (1.4 : 1 to 2.4 : 1)",
    "typicalElongation": 1.7,
    "marginRoughness": 34,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Mustard / Rapeseed displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refmustard\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refmustard)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "sunflower": {
    "cropKey": "sunflower",
    "cropName": "Sunflower (सूरजमुखी / सूर्यफूल)",
    "botanicalClass": "Dicotyledonae (Brassicaceae / Asteraceae)",
    "leafMorphology": "Broad lyrately pinnatifid or ovate blade with prominent reticulate venation",
    "marginType": "Wavy to shallowly dentate margin",
    "aspectRatioDescriptor": "Broad Ovate / Lobe (1.4 : 1 to 2.4 : 1)",
    "typicalElongation": 1.7,
    "marginRoughness": 34,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Sunflower displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refsunflower\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refsunflower)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "sesame": {
    "cropKey": "sesame",
    "cropName": "Sesame / Til (तिल / तीळ)",
    "botanicalClass": "Dicotyledonae (Brassicaceae / Asteraceae)",
    "leafMorphology": "Broad lyrately pinnatifid or ovate blade with prominent reticulate venation",
    "marginType": "Wavy to shallowly dentate margin",
    "aspectRatioDescriptor": "Broad Ovate / Lobe (1.4 : 1 to 2.4 : 1)",
    "typicalElongation": 1.7,
    "marginRoughness": 34,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Sesame / Til displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refsesame\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refsesame)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "safflower": {
    "cropKey": "safflower",
    "cropName": "Safflower / Kardi (करडी)",
    "botanicalClass": "Dicotyledonae (Brassicaceae / Asteraceae)",
    "leafMorphology": "Broad lyrately pinnatifid or ovate blade with prominent reticulate venation",
    "marginType": "Wavy to shallowly dentate margin",
    "aspectRatioDescriptor": "Broad Ovate / Lobe (1.4 : 1 to 2.4 : 1)",
    "typicalElongation": 1.7,
    "marginRoughness": 34,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Safflower / Kardi displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refsafflower\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refsafflower)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "castor": {
    "cropKey": "castor",
    "cropName": "Castor Seed (अरंडी / एरंडी)",
    "botanicalClass": "Dicotyledonae (Brassicaceae / Asteraceae)",
    "leafMorphology": "Broad lyrately pinnatifid or ovate blade with prominent reticulate venation",
    "marginType": "Wavy to shallowly dentate margin",
    "aspectRatioDescriptor": "Broad Ovate / Lobe (1.4 : 1 to 2.4 : 1)",
    "typicalElongation": 1.7,
    "marginRoughness": 34,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Castor Seed displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcastor\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcastor)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "linseed": {
    "cropKey": "linseed",
    "cropName": "Linseed / Flaxseed (अलसी / जवस)",
    "botanicalClass": "Dicotyledonae (Brassicaceae / Asteraceae)",
    "leafMorphology": "Broad lyrately pinnatifid or ovate blade with prominent reticulate venation",
    "marginType": "Wavy to shallowly dentate margin",
    "aspectRatioDescriptor": "Broad Ovate / Lobe (1.4 : 1 to 2.4 : 1)",
    "typicalElongation": 1.7,
    "marginRoughness": 34,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/groundnut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Linseed / Flaxseed displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"reflinseed\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#reflinseed)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "sugarcane": {
    "cropKey": "sugarcane",
    "cropName": "Sugarcane (गन्ना / ऊस)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Sugarcane displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refsugarcane\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refsugarcane)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "cotton": {
    "cropKey": "cotton",
    "cropName": "Cotton (कपास / कापूस)",
    "botanicalClass": "Dicotyledonae (Malvaceae)",
    "leafMorphology": "Broad cordate leaf with 3 to 5 deeply pointed palmate lobes",
    "marginType": "Deeply lobed palmate margin",
    "aspectRatioDescriptor": "Palmate / Star-shaped (1.0 : 1 to 1.4 : 1)",
    "typicalElongation": 1.15,
    "marginRoughness": 55,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/cotton_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Cotton displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcotton\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcotton)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "tea": {
    "cropKey": "tea",
    "cropName": "Tea (चाय / चहा)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/tea_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Tea displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"reftea\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#reftea)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "coffee": {
    "cropKey": "coffee",
    "cropName": "Coffee (कॉफी - अरेबिका / रोबस्टा)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/coffee_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Coffee displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcoffee\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcoffee)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "coconut": {
    "cropKey": "coconut",
    "cropName": "Coconut (नारियल / नारळ)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/coconut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Coconut displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcoconut\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcoconut)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "tomato": {
    "cropKey": "tomato",
    "cropName": "Tomato (टमाटर / टोमॅटो)",
    "botanicalClass": "Dicotyledonae (Solanaceae)",
    "leafMorphology": "Odd-pinnately compound leaf with serrated dentate leaflets",
    "marginType": "Serrated / Dentate lobed margin",
    "aspectRatioDescriptor": "Moderate Ovate (1.3 : 1 to 2.4 : 1)",
    "typicalElongation": 1.8,
    "marginRoughness": 48,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/onion_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Tomato displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"reftomato\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#reftomato)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "potato": {
    "cropKey": "potato",
    "cropName": "Potato (आलू / बटाटा)",
    "botanicalClass": "Dicotyledonae (Solanaceae)",
    "leafMorphology": "Compound pinnate leaf with broad rounded ovate leaflets",
    "marginType": "Entire smooth to wavy margin",
    "aspectRatioDescriptor": "Broad Ovate / Rounded (1.1 : 1 to 1.6 : 1)",
    "typicalElongation": 1.35,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/potato_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Potato displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refpotato\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refpotato)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "onion": {
    "cropKey": "onion",
    "cropName": "Onion (प्याज / कांदा)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/garlic_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Onion displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refonion\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refonion)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "garlic": {
    "cropKey": "garlic",
    "cropName": "Garlic (लहसुन / लसूण)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/turmeric_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Garlic displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refgarlic\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refgarlic)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "brinjal": {
    "cropKey": "brinjal",
    "cropName": "Brinjal / Eggplant (बैंगन / वांगे)",
    "botanicalClass": "Dicotyledonae (Solanaceae)",
    "leafMorphology": "Simple lanceolate spear-shaped blade with pointed acuminate apex",
    "marginType": "Entire smooth to wavy margin",
    "aspectRatioDescriptor": "Moderate Ovate (1.3 : 1 to 2.4 : 1)",
    "typicalElongation": 1.8,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/chilli_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Brinjal / Eggplant displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refbrinjal\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refbrinjal)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "okra": {
    "cropKey": "okra",
    "cropName": "Okra / Ladyfinger (भिंडी)",
    "botanicalClass": "Dicotyledonae (Malvaceae)",
    "leafMorphology": "Broad cordate leaf with 3 to 5 deeply pointed palmate lobes",
    "marginType": "Deeply lobed palmate margin",
    "aspectRatioDescriptor": "Palmate / Star-shaped (1.0 : 1 to 1.4 : 1)",
    "typicalElongation": 1.15,
    "marginRoughness": 55,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/cotton_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Okra / Ladyfinger displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refokra\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refokra)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "chilli": {
    "cropKey": "chilli",
    "cropName": "Green Chilli (हरी मिर्च / मिरची)",
    "botanicalClass": "Dicotyledonae (Solanaceae)",
    "leafMorphology": "Simple lanceolate spear-shaped blade with pointed acuminate apex",
    "marginType": "Entire smooth to wavy margin",
    "aspectRatioDescriptor": "Slender Lanceolate (1.8 : 1 to 3.0 : 1)",
    "typicalElongation": 2.5,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/chilli_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Green Chilli displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refchilli\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refchilli)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "turmeric": {
    "cropKey": "turmeric",
    "cropName": "Turmeric (हल्दी / हळद)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/ginger_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Turmeric displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refturmeric\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refturmeric)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "ginger": {
    "cropKey": "ginger",
    "cropName": "Ginger (अदरक / आले)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/coriander_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Ginger displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refginger\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refginger)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "cumin": {
    "cropKey": "cumin",
    "cropName": "Cumin / Jeera (जीरा)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/coriander_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Cumin / Jeera displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcumin\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcumin)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "coriander": {
    "cropKey": "coriander",
    "cropName": "Coriander / Dhaniya (धनिया / धने)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/blackpepper_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Coriander / Dhaniya displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcoriander\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcoriander)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "black-pepper": {
    "cropKey": "black-pepper",
    "cropName": "Black Pepper (काली मिर्च / मिरी)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/cardamom_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Black Pepper displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refblackpepper\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refblackpepper)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "small-cardamom": {
    "cropKey": "small-cardamom",
    "cropName": "Small Cardamom (छोटी इलायची / वेलची)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/watermelon_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Small Cardamom displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refsmallcardamom\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refsmallcardamom)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "ashwagandha": {
    "cropKey": "ashwagandha",
    "cropName": "Ashwagandha (अश्वगंधा)",
    "botanicalClass": "Dicotyledonae (Solanaceae)",
    "leafMorphology": "Simple lanceolate spear-shaped blade with pointed acuminate apex",
    "marginType": "Entire smooth to wavy margin",
    "aspectRatioDescriptor": "Moderate Ovate (1.3 : 1 to 2.4 : 1)",
    "typicalElongation": 1.8,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/ashwagandha_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Ashwagandha displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refashwagandha\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refashwagandha)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "tulsi": {
    "cropKey": "tulsi",
    "cropName": "Tulsi / Holy Basil (तुलसी)",
    "botanicalClass": "Lamiaceae",
    "leafMorphology": "Opposite decussate ovate-elliptic blade with gland dots and aromatic eugenol fragrance",
    "marginType": "Serrated to gently dentate margin",
    "aspectRatioDescriptor": "Moderate Ovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.5,
    "marginRoughness": 32,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/tulsi_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Tulsi / Holy Basil displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"reftulsi\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#reftulsi)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "lemongrass": {
    "cropKey": "lemongrass",
    "cropName": "Lemongrass (लेमनग्रास)",
    "botanicalClass": "Monocotyledonae (Poaceae)",
    "leafMorphology": "Linear upright strap blade with parallel venation and central vascular bundle",
    "marginType": "Entire smooth margin with micro-silica striations",
    "aspectRatioDescriptor": "Linear Strap Blade (4.0 : 1 to 10.0 : 1)",
    "typicalElongation": 5.5,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/rice_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Lemongrass displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"reflemongrass\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#reflemongrass)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "watermelon": {
    "cropKey": "watermelon",
    "cropName": "Watermelon (तरबूज / टरबूज)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/watermelon_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Watermelon displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refwatermelon\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refwatermelon)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "muskmelon": {
    "cropKey": "muskmelon",
    "cropName": "Muskmelon (खरबूज)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/watermelon_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Muskmelon displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refmuskmelon\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refmuskmelon)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "bottle-gourd": {
    "cropKey": "bottle-gourd",
    "cropName": "Bottle Gourd / Lauki (लौकी / दुधी)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/watermelon_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Bottle Gourd / Lauki displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refbottlegourd\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refbottlegourd)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "bitter-gourd": {
    "cropKey": "bitter-gourd",
    "cropName": "Bitter Gourd / Karela (करेला / कारले)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/watermelon_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Bitter Gourd / Karela displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refbittergourd\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refbittergourd)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "ridge-gourd": {
    "cropKey": "ridge-gourd",
    "cropName": "Ridge Gourd / Turai (तुरई / दोडका)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/watermelon_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Ridge Gourd / Turai displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refridgegourd\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refridgegourd)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "cucumber": {
    "cropKey": "cucumber",
    "cropName": "Cucumber (खीरा / काकडी)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/spinach_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Cucumber displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcucumber\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcucumber)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "spinach": {
    "cropKey": "spinach",
    "cropName": "Spinach / Palak (पालक)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/fenugreek_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Spinach / Palak displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refspinach\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refspinach)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "fenugreek-leaves": {
    "cropKey": "fenugreek-leaves",
    "cropName": "Fenugreek Leaves / Methi (मेथी)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/carrot_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Fenugreek Leaves / Methi displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"reffenugreekleaves\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#reffenugreekleaves)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "carrot": {
    "cropKey": "carrot",
    "cropName": "Carrot (गाजर)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/radish_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Carrot displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcarrot\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcarrot)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "radish": {
    "cropKey": "radish",
    "cropName": "Radish / Mooli (मूली / मुळा)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/radish_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Radish / Mooli displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refradish\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refradish)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "beetroot": {
    "cropKey": "beetroot",
    "cropName": "Beetroot (चुकंदर)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/potato_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Beetroot displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refbeetroot\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refbeetroot)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "sweet-potato": {
    "cropKey": "sweet-potato",
    "cropName": "Sweet Potato (शकरकंद / रताळे)",
    "botanicalClass": "Dicotyledonae (Solanaceae)",
    "leafMorphology": "Compound pinnate leaf with broad rounded ovate leaflets",
    "marginType": "Entire smooth to wavy margin",
    "aspectRatioDescriptor": "Broad Ovate / Rounded (1.1 : 1 to 1.6 : 1)",
    "typicalElongation": 1.35,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/potato_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Sweet Potato displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refsweetpotato\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refsweetpotato)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "cassava": {
    "cropKey": "cassava",
    "cropName": "Cassava / Tapioca (साबूदाना)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/potato_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Cassava / Tapioca displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcassava\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcassava)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "elephant-foot-yam": {
    "cropKey": "elephant-foot-yam",
    "cropName": "Elephant Foot Yam (सूरन)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/drumstick_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Elephant Foot Yam displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refelephantfootyam\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refelephantfootyam)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "drumstick": {
    "cropKey": "drumstick",
    "cropName": "Drumstick / Moringa (सहजन / शेवगा)",
    "botanicalClass": "Dicotyledonae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/coffee_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Drumstick / Moringa displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refdrumstick\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refdrumstick)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "nutmeg": {
    "cropKey": "nutmeg",
    "cropName": "Nutmeg & Mace (जायफल)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/tea_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Nutmeg & Mace displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refnutmeg\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refnutmeg)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "clove": {
    "cropKey": "clove",
    "cropName": "Clove (लौंग / लवंग)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/coffee_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Clove displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refclove\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refclove)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "cinnamon": {
    "cropKey": "cinnamon",
    "cropName": "Cinnamon (दालचीनी)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/fenugreek_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Cinnamon displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refcinnamon\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refcinnamon)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "fenugreek-seeds": {
    "cropKey": "fenugreek-seeds",
    "cropName": "Fenugreek Seeds / Methi (मेथी दाना)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/coriander_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Fenugreek Seeds / Methi displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"reffenugreekseeds\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#reffenugreekseeds)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "ajwain": {
    "cropKey": "ajwain",
    "cropName": "Ajwain / Carom Seeds (अजवायन / ओवा)",
    "botanicalClass": "Angiospermae",
    "leafMorphology": "Broad spreading leaf blade with reticulate veins and active photosynthetic mesophyll",
    "marginType": "Smooth to gently crenulate entire margin",
    "aspectRatioDescriptor": "Broad Foliar Blade (1.2 : 1 to 2.5 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 30,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/coriander_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Ajwain / Carom Seeds displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refajwain\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refajwain)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "aloe-vera": {
    "cropKey": "aloe-vera",
    "cropName": "Aloe Vera (एलोवेरा)",
    "botanicalClass": "Asphodelaceae (Succulent)",
    "leafMorphology": "Thick fleshy succulent lanceolate leaves in basal rosette containing transparent gel",
    "marginType": "Spiny toothed marginal dentition",
    "aspectRatioDescriptor": "Fleshy Lanceolate (3.0 : 1 to 6.0 : 1)",
    "typicalElongation": 3.8,
    "marginRoughness": 36,
    "greenTone": "Glaucous Pea Green (RGB 34, 197, 94)",
    "realPhotoUrl": "images/healthy_crops/aloe_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Aloe Vera displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refaloevera\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refaloevera)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "stevia": {
    "cropKey": "stevia",
    "cropName": "Stevia Sweet Herb (स्टीविया)",
    "botanicalClass": "Asteraceae",
    "leafMorphology": "Opposite lanceolate to oblong-elliptic leaves with sweet steviol glycoside glandular hairs",
    "marginType": "Serrated to crenate upper margin",
    "aspectRatioDescriptor": "Moderate Ovate (1.3 : 1 to 2.2 : 1)",
    "typicalElongation": 1.6,
    "marginRoughness": 32,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/spinach_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Stevia Sweet Herb displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refstevia\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refstevia)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "isabgol": {
    "cropKey": "isabgol",
    "cropName": "Isabgol / Psyllium Husk (इसबगोल)",
    "botanicalClass": "Plantaginaceae",
    "leafMorphology": "Narrow linear-lanceolate rosette leaves with prominent longitudinal parallel veins",
    "marginType": "Entire smooth margin",
    "aspectRatioDescriptor": "Linear Spikes (3.0 : 1 to 5.5 : 1)",
    "typicalElongation": 3.5,
    "marginRoughness": 22,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/bajra_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Isabgol / Psyllium Husk displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refisabgol\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refisabgol)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "senna": {
    "cropKey": "senna",
    "cropName": "Senna / Sonamukhi (सनाय)",
    "botanicalClass": "Fabaceae",
    "leafMorphology": "Even-pinnate compound leaves with 3-7 pairs of lanceolate acute glabrous leaflets",
    "marginType": "Entire smooth margin",
    "aspectRatioDescriptor": "Pinnate Foliage (1.5 : 1 to 2.5 : 1)",
    "typicalElongation": 1.8,
    "marginRoughness": 26,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/mustard_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Senna / Sonamukhi displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refsenna\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refsenna)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  },
  "areca-palm": {
    "cropKey": "areca-palm",
    "cropName": "Areca Palm (एरेका पाम)",
    "botanicalClass": "Arecaceae (Palm)",
    "leafMorphology": "Pinnate feathery fronds with rigid linear leaflets arranged in V-shape",
    "marginType": "Entire smooth frond margin",
    "aspectRatioDescriptor": "Pinnate Palm (3.0 : 1 to 6.0 : 1)",
    "typicalElongation": 3.8,
    "marginRoughness": 28,
    "greenTone": "Vibrant Leaf Green (RGB 22, 163, 74)",
    "realPhotoUrl": "images/healthy_crops/arecanut_healthy.jpg",
    "realPhotoDescription": "Real-world healthy foliage reference for Areca Palm displaying nominal chlorophyll distribution, intact cuticular barrier, and optimal vegetative vigor.",
    "healthyBiomarkers": {
      "green": 96,
      "necrotic": 1,
      "chlorosis": 3,
      "powdery": 0,
      "rust": 0
    },
    "healthyTraits": [
      "Uniform chlorophyll pigmentation across photosynthetic mesophyll",
      "Intact cuticular epidermal barrier preventing fungal germ-tube ingress",
      "Zero necrotic lesions, water-soaked marginal scorch, or chlorotic halos",
      "Turgid erect foliar posture facilitating optimal solar radiation capture"
    ],
    "svg": "<svg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\">\n      <defs>\n        <radialGradient id=\"refarecapalm\" cx=\"45%\" cy=\"35%\" r=\"65%\">\n          <stop offset=\"0%\" stop-color=\"#4ade80\" />\n          <stop offset=\"50%\" stop-color=\"#16a34a\" />\n          <stop offset=\"100%\" stop-color=\"#14532d\" />\n        </radialGradient>\n      </defs>\n      <path d=\"M 100,14 C 145,30 165,80 150,148 C 134,176 112,190 100,194 C 88,190 66,176 50,148 C 35,80 55,30 100,14 Z\" fill=\"url(#refarecapalm)\" stroke=\"#14532d\" stroke-width=\"2\"/>\n      <path d=\"M 100,18 L 100,190\" stroke=\"#dcfce7\" stroke-width=\"2.2\" opacity=\"0.85\"/>\n      <path d=\"M 100,55 Q 128,46 142,62 M 100,55 Q 72,46 58,62\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,100 Q 130,90 144,110 M 100,100 Q 70,90 56,110\" stroke=\"#dcfce7\" stroke-width=\"1.4\" opacity=\"0.65\"/>\n      <path d=\"M 100,142 Q 124,134 134,150 M 100,142 Q 76,134 66,150\" stroke=\"#dcfce7\" stroke-width=\"1.2\" opacity=\"0.65\"/>\n    </svg>"
  }
};

const allCropsHealthyReferenceModels = exports.allCropsHealthyReferenceModels = {
  ...baseAllCropsHealthyReferenceModels,
  ...fruitHealthyReferenceModels
};
