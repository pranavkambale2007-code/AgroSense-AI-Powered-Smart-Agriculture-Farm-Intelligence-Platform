// AgroSense Complete Crop Lifecycle, Water, Spray, Harvest & Mandi Intelligence Database
// Provides actionable monitoring from Seed Sowing -> Irrigation -> Pesticide Spraying -> Harvesting -> Local Mandi Selling

import { expandedAllCropLifecycles } from './expandedCropLifecycleData.js';

export const cropLifecycleDatabase = {
  wheat: {
    cropKey: "wheat",
    cropName: "Wheat",
    vernacularName: "गेहूं",
    season: "Rabi (Winter)",
    totalDurationDays: 125,
    optimalSowingWindow: "1 November – 25 November (Ideal Soil Temp: 20-22°C)",
    seedRate: "40 – 45 kg / Acre (Line sowing with seed drill)",
    seedTreatment: "Carboxin 37.5% + Thiram 37.5% DS (Vitavax Power) @ 2.5 g/kg seed + Azotobacter bio-culture @ 250 g/10kg seed",
    spacing: "20 cm row-to-row × 5 cm plant-to-plant; Sowing depth 4-5 cm in moist soil zone",
    soilPrep: "1 deep summer ploughing followed by 2 cross-harrowings; apply 4 tonnes/acre well-decomposed FYM + 50 kg DAP + 25 kg MOP at sowing",

    // 1. SEED SOWING STAGE
    sowingDetails: {
      dasRange: "DAS 0 – 7",
      title: "Seed Sowing & Germination",
      description: "Treat certified seed (HD-2967, PBW-550, GW-322) before drill-sowing in firm moist seedbed.",
      keyActions: [
        "Ensure soil moisture is at Field Capacity (Wapsa condition) before drilling seeds.",
        "Mix Azotobacter and PSB culture with jaggery water to treat seeds 30 mins before sowing.",
        "Calibrate seed drill to deliver 40-42 kg/acre at uniform 4-5 cm depth."
      ],
      warning: "Do not sow deeper than 6 cm as it severely delays coleoptile emergence and reduces tillering."
    },

    // 2. WHEN WATER GIVES (CRITICAL IRRIGATION STAGES)
    irrigationSchedule: [
      {
        stageName: "CRI Stage (Crown Root Initiation)",
        das: 21,
        dasRange: "DAS 20 – 25",
        waterVolume: "50,000 Liters / Acre (~50 mm depth)",
        importance: "Critical (Top Priority)",
        guidance: "Most critical irrigation of wheat! Missing this stage reduces grain yield by 25-30% due to poor crown root anchoring."
      },
      {
        stageName: "Active Tillering",
        das: 42,
        dasRange: "DAS 40 – 45",
        waterVolume: "45,000 Liters / Acre (~45 mm depth)",
        importance: "High",
        guidance: "Stimulates effective ear-bearing tillers. Apply first urea top-dressing (25 kg/acre) right before or immediately after this irrigation."
      },
      {
        stageName: "Late Jointing / Booting",
        das: 65,
        dasRange: "DAS 62 – 68",
        waterVolume: "45,000 Liters / Acre (~45 mm depth)",
        importance: "High",
        guidance: "Supports flag leaf development and spikelet differentiation. Moisture stress here causes stunted spikes with fewer grains."
      },
      {
        stageName: "Flowering & Anthesis",
        das: 85,
        dasRange: "DAS 82 – 88",
        waterVolume: "40,000 Liters / Acre (~40 mm depth)",
        importance: "Critical",
        guidance: "Ensures uniform pollen germination and fertilization. Avoid heavy flooded watering during windy days to prevent lodging."
      },
      {
        stageName: "Milk & Dough Grain Filling",
        das: 105,
        dasRange: "DAS 102 – 108",
        waterVolume: "35,000 Liters / Acre (~35 mm depth)",
        importance: "Moderate",
        guidance: "Plumps grain weight and prevents premature shriveling from spring heat. Stop all irrigation 12-15 days prior to harvest."
      }
    ],

    // 3. WHEN PESTICIDE / FUNGICIDE SPRAY GIVES
    spraySchedule: [
      {
        sprayNumber: "Spray 1 (Weed & Early Pest Control)",
        das: 30,
        dasRange: "DAS 28 – 35",
        targetProblem: "Phalaris minor (Gulli Danda) & Broadleaf Weeds",
        chemical: "Clodinafop-propargyl 15% WP + Metsulfuron-methyl 20% WP",
        dosagePer15L: "16 g + 1.5 g per 15L Knapsack Pump (flat fan nozzle)",
        phi: "60 Days",
        weatherRule: "Spray on clear sunny days with wind speed < 8 km/h. Do not spray if rain is forecast within 6 hours."
      },
      {
        sprayNumber: "Spray 2 (Rust & Blight Prophylactic)",
        das: 60,
        dasRange: "DAS 55 – 65",
        targetProblem: "Yellow / Brown Rust (Puccinia) & Foliar Blight",
        chemical: "Propiconazole 25% EC (Tilt)",
        dosagePer15L: "15 ml per 15L Knapsack Pump (1 ml / L water)",
        phi: "30 Days",
        weatherRule: "Inspect field for yellow pustule stripes on lower canopy; spray immediately when morning fog is heavy."
      },
      {
        sprayNumber: "Spray 3 (Aphid & Flag Leaf Protector)",
        das: 85,
        dasRange: "DAS 80 – 90",
        targetProblem: "Wheat Aphids (Mahoo) & Head Blight",
        chemical: "Thiamethoxam 25% WG + Tebuconazole 25.9% EC",
        dosagePer15L: "5 g + 15 ml per 15L Knapsack Pump",
        phi: "21 Days",
        weatherRule: "Spray between 7:00 AM – 10:30 AM before aphid pollinators are active. Respect 21-day Pre-Harvest Interval."
      }
    ],

    // 4. WHEN CUT CROPS (HARVESTING & CUTTING)
    harvestingSchedule: {
      dasRange: "DAS 120 – 135",
      maturityIndicators: [
        "85-90% of wheat ears and straw turn golden-yellow straw color.",
        "Grain moisture content drops to 12% – 14% (grain cracks crisply when bitten between front teeth).",
        "Straw becomes brittle and snaps easily at the base."
      ],
      harvestingMethod: "Harvest with combine harvester with cutting blade set at 10-12 cm above ground, or manual sickle cutting at ground level.",
      postHarvestDrying: "Sun dry harvested grain on clean tarpaulin sheets for 2 sunny days until moisture drops below 12% before storage.",
      storageWarning: "Storing wheat above 12% moisture leads to Khapra beetle infestation and Aspergillus mold rot."
    },

    // 5. WHEN & WHERE TO SELL TO LOCAL MANDI
    mandiSellingGuide: {
      mspGovt: "₹2,275 – ₹2,425 / Quintal (Govt of India Minimum Support Price)",
      currentMandiRate: "₹2,450 – ₹2,680 / Quintal",
      bestSellingWindow: "Sell 4 to 8 weeks post-harvest (Mid-May to July). Prices during harvest peak (April) are usually 8-12% lower due to heavy arrivals.",
      gradingChecklist: [
        "Clean winnowing to remove chaff, weed seeds, and broken grains (dockage < 1%).",
        "Moisture must be strictly below 12% to prevent mandi deduction dockage.",
        "Grade A uniform bold grains fetch a ₹120-180/Qtl premium from private flour millers (Atta mills)."
      ],
      nearbyMandis: [
        { name: "Khanna APMC Mandi (Punjab)", distance: "Local / Regional", rate: "₹2,520/Qtl" },
        { name: "Karnal Grain Market (Haryana)", distance: "Regional Hub", rate: "₹2,510/Qtl" },
        { name: "Pune APMC Market Yard (Maharashtra)", distance: "Western Hub", rate: "₹2,680/Qtl" },
        { name: "Indore APMC Mandi (Madhya Pradesh)", distance: "Central Hub", rate: "₹2,620/Qtl" }
      ],
      mandiTips: "Obtain an e-NAM farmer registration gate-pass before vehicle entry to avoid agent commission deduction."
    }
  },

  maize: {
    cropKey: "maize",
    cropName: "Maize / Corn",
    vernacularName: "मक्का",
    season: "Kharif & Rabi",
    totalDurationDays: 110,
    optimalSowingWindow: "15 June – 10 July (Kharif) or 15 Oct – 15 Nov (Rabi)",
    seedRate: "7 – 8 kg / Acre for hybrids (Single cross hybrids like Pioneer, Syngenta, DKC)",
    seedTreatment: "Cyantraniliprole 19.8% + Thiamethoxam 19.8% FS (Fortenza Duo) @ 4 ml/kg seed (Essential against Fall Armyworm) + Thiram @ 2.5 g/kg",
    spacing: "60 cm row-to-row × 20 cm plant-to-plant; Sowing depth 3-4 cm",
    soilPrep: "Deep ploughed fertile loamy soil with excellent drainage; apply 5 tonnes FYM + 40kg DAP + 20kg Potash at planting",

    sowingDetails: {
      dasRange: "DAS 0 – 5",
      title: "Ridge & Furrow Sowing",
      description: "Sow seeds on the side of the ridges at 2/3rd height to prevent waterlogging during monsoon downpours.",
      keyActions: [
        "Sow 1 seed per hill at 20 cm distance to maintain 30,000-33,000 plant population/acre.",
        "Seed treatment with Fortenza Duo is compulsory to protect 15-day seedlings from Fall Armyworm.",
        "Apply pre-emergence Atrazine 50% WP @ 500g/acre within 48 hours of sowing."
      ],
      warning: "Maize is extremely sensitive to water stagnation at germination; water logging for >24 hours kills the seedlings."
    },

    irrigationSchedule: [
      {
        stageName: "Seedling Establishment",
        das: 15,
        dasRange: "DAS 12 – 18",
        waterVolume: "35,000 Liters / Acre",
        importance: "Moderate",
        guidance: "Light irrigation to promote uniform root penetration; drain excess standing water immediately."
      },
      {
        stageName: "Knee-High Vegetative Stage",
        das: 35,
        dasRange: "DAS 30 – 38",
        waterVolume: "45,000 Liters / Acre",
        importance: "High",
        guidance: "Fastest vegetative growth period. Apply 1st Urea top-dressing (35 kg/acre) + Earthing up (ridging soil around stem)."
      },
      {
        stageName: "Tasseling Stage",
        das: 55,
        dasRange: "DAS 50 – 58",
        waterVolume: "55,000 Liters / Acre",
        importance: "Critical (Top Priority)",
        guidance: "Water stress at tasseling causes pollen desiccation and barren cobs. Maintain constant soil moisture."
      },
      {
        stageName: "Silking & Cob Development",
        das: 70,
        dasRange: "DAS 65 – 75",
        waterVolume: "50,000 Liters / Acre",
        importance: "Critical (Top Priority)",
        guidance: "Determines grain number per cob. Drought stress here reduces yield by 40-50%."
      },
      {
        stageName: "Grain Dough / Milk Stage",
        das: 90,
        dasRange: "DAS 85 – 95",
        waterVolume: "40,000 Liters / Acre",
        importance: "Moderate",
        guidance: "Final watering to ensure maximum grain test weight. Cut off irrigation 10 days before harvesting."
      }
    ],

    spraySchedule: [
      {
        sprayNumber: "Spray 1 (Fall Armyworm Early Whorl Spray)",
        das: 20,
        dasRange: "DAS 18 – 24",
        targetProblem: "Fall Armyworm (Spodoptera frugiperda)",
        chemical: "Chlorantraniliprole 18.5% SC (Coragen)",
        dosagePer15L: "6 ml per 15L Knapsack Pump (Direct spray inside leaf whorls)",
        phi: "21 Days",
        weatherRule: "Direct nozzle straight down into central leaf whorl where larvae hide."
      },
      {
        sprayNumber: "Spray 2 (Turcicum Leaf Blight & Rust Control)",
        das: 45,
        dasRange: "DAS 42 – 50",
        targetProblem: "Northern Corn Leaf Blight (Exserohilum) & Common Rust",
        chemical: "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        dosagePer15L: "15 ml per 15L Knapsack Pump",
        phi: "28 Days",
        weatherRule: "Ensure thorough coverage of both upper and lower leaf surfaces."
      },
      {
        sprayNumber: "Spray 3 (Cob Borer & Late Armyworm Guard)",
        das: 68,
        dasRange: "DAS 65 – 72",
        targetProblem: "Corn Earworm & Second Brood Armyworm",
        chemical: "Emamectin Benzoate 5% SG (Proclaim)",
        dosagePer15L: "8 – 10 g per 15L Knapsack Pump",
        phi: "14 Days",
        weatherRule: "Spray directly onto developing silk and cob tips."
      }
    ],

    harvestingSchedule: {
      dasRange: "DAS 100 – 115",
      maturityIndicators: [
        "Cob husk leaves turn completely dry, papery, and straw-yellow.",
        "Black layer (abscission zone) develops at the base of the maize kernel.",
        "Grain moisture drops to 15% – 18%."
      ],
      harvestingMethod: "De-husk cobs by hand or use tractor-drawn maize sheller / combine harvester.",
      postHarvestDrying: "Sun dry cobs on concrete threshing floor for 3-4 days until kernel moisture reaches 12-13% before shelling.",
      storageWarning: "Shelling wet maize above 16% moisture breaks the grain embryo and invites aflatoxin fungus."
    },

    mandiSellingGuide: {
      mspGovt: "₹2,090 – ₹2,225 / Quintal (Govt of India Minimum Support Price)",
      currentMandiRate: "₹2,180 – ₹2,420 / Quintal (Poultry feed & starch mill demand)",
      bestSellingWindow: "Sell in December-January (Kharif) or June-July (Rabi) when poultry and starch factories purchase bulk supplies.",
      gradingChecklist: [
        "Kernel moisture must be ≤ 14% to avoid deductions at the mandi scale.",
        "Zero damaged / fungus-affected grains (Poultry mills penalize aflatoxin > 20 ppb).",
        "Bright yellow bold grains command a ₹80-120/Qtl premium over mixed varieties."
      ],
      nearbyMandis: [
        { name: "Davangere APMC Mandi (Karnataka)", distance: "South Hub", rate: "₹2,380/Qtl" },
        { name: "Gultekdi APMC Market (Pune)", distance: "Regional Hub", rate: "₹2,420/Qtl" },
        { name: "Chhindwara APMC Mandi (MP)", distance: "Central Hub", rate: "₹2,240/Qtl" },
        { name: "Nandyal APMC Market (AP)", distance: "South Hub", rate: "₹2,310/Qtl" }
      ],
      mandiTips: "Poultry feed manufacturers directly procure at 5-8% higher than open mandi brokers if moisture is certified <13%."
    }
  },

  tomato: {
    cropKey: "tomato",
    cropName: "Tomato",
    vernacularName: "टमाटर",
    season: "Kharif, Rabi & Summer",
    totalDurationDays: 135,
    optimalSowingWindow: "Nursery Sowing: June-July (Kharif) or Oct-Nov (Rabi); Transplant 25 days later",
    seedRate: "60 – 80 g / Acre for indeterminate hybrids (Arka Rakshak, US-440, Abhinav, Saaho)",
    seedTreatment: "Trichoderma viride @ 5g/kg seed + Imidacloprid 70% WS @ 3g/kg seed to prevent early whiteflies and virus",
    spacing: "90 cm row-to-row × 45-60 cm plant-to-plant on raised beds with silver-black plastic mulch",
    soilPrep: "Deep tilth red loam / black soil; apply 8 tonnes FYM + 50kg 10:26:26 + 10kg Micronutrient mixture per acre",

    sowingDetails: {
      dasRange: "DAS 0 – 25",
      title: "Nursery Raising & Pro-tray Sowing",
      description: "Raise seedlings in 98-cell pro-trays under 50% shade net using sterile cocopeat + vermicompost.",
      keyActions: [
        "Transplant 22-25 day old sturdy seedlings with 4-5 true leaves into the main field.",
        "Dip seedling roots in Pseudomonas fluorescens (10g/L) for 15 minutes before planting.",
        "Plant in late afternoon to prevent transplanting shock from hot mid-day sun."
      ],
      warning: "Never transplant overgrown root-bound seedlings (>35 days) as they suffer severe blossom drop."
    },

    irrigationSchedule: [
      {
        stageName: "Establishment Stage",
        das: 5,
        dasRange: "DAS 1 – 10 (After transplanting)",
        waterVolume: "15,000 Liters / Acre / day via Drip",
        importance: "Critical",
        guidance: "Provide daily light drip pulses (45 mins) to establish feeder root system in plastic mulch."
      },
      {
        stageName: "Vegetative Branching & Staking",
        das: 30,
        dasRange: "DAS 25 – 40",
        waterVolume: "22,000 Liters / Acre every 2nd day",
        importance: "High",
        guidance: "Stake vines with bamboo poles and trellising wire. Start fertigation with 19:19:19 soluble fertilizer."
      },
      {
        stageName: "Flowering & Fruit Setting",
        das: 55,
        dasRange: "DAS 50 – 65",
        waterVolume: "28,000 Liters / Acre every 2nd day",
        importance: "Critical (Top Priority)",
        guidance: "Maintain uniform soil moisture. Moisture fluctuation causes Blossom End Rot (Calcium deficiency) and fruit cracking."
      },
      {
        stageName: "Fruit Expansion",
        das: 75,
        dasRange: "DAS 70 – 90",
        waterVolume: "32,000 Liters / Acre every 2nd day",
        importance: "High",
        guidance: "Heavy water demand. Fertigate with 0:0:50 (Potassium Sulphate) + Boron @ 1g/L to enhance fruit sheen and wall thickness."
      },
      {
        stageName: "Harvesting Phase",
        das: 105,
        dasRange: "DAS 95 – 135",
        waterVolume: "20,000 Liters / Acre",
        importance: "Moderate",
        guidance: "Irrigate immediately after each picking cycle to support the next flush of green fruits."
      }
    ],

    spraySchedule: [
      {
        sprayNumber: "Spray 1 (Whitefly & Leaf Curl Vector Guard)",
        das: 15,
        dasRange: "DAS 12 – 18",
        targetProblem: "Whiteflies (Bemisia tabaci) transmitting Tomato Leaf Curl Virus",
        chemical: "Diafenthiuron 50% WP (Pegasus) or Acetamiprid 20% SP",
        dosagePer15L: "18 g or 4 g per 15L Knapsack Pump",
        phi: "14 Days",
        weatherRule: "Install 25 yellow sticky traps per acre; spray early morning when whiteflies rest under leaves."
      },
      {
        sprayNumber: "Spray 2 (Early Blight & Bacterial Spot Defense)",
        das: 40,
        dasRange: "DAS 35 – 45",
        targetProblem: "Early Blight (Alternaria) & Bacterial Spot (Xanthomonas)",
        chemical: "Mancozeb 75% WP + Streptocycline (Plantomycin)",
        dosagePer15L: "35 g + 1.5 g per 15L Knapsack Pump",
        phi: "7 Days",
        weatherRule: "Spray bottom 45cm foliage thoroughly before canopy completely closes."
      },
      {
        sprayNumber: "Spray 3 (Late Blight & Fruit Borer Protection)",
        das: 65,
        dasRange: "DAS 60 – 70",
        targetProblem: "Late Blight (Phytophthora) & Fruit Borer (Helicoverpa)",
        chemical: "Metalaxyl-M 4% + Mancozeb 64% WP (Ridomil Gold) + Flubendiamide 39.35% SC (Fame)",
        dosagePer15L: "35 g + 4 ml per 15L Knapsack Pump",
        phi: "5 Days",
        weatherRule: "Crucial spray if cold foggy morning is followed by afternoon rain. Respect 5-day PHI."
      }
    ],

    harvestingSchedule: {
      dasRange: "DAS 75 – 135 (Multiple Pickings every 4-5 days)",
      maturityIndicators: [
        "For distant local mandi / interstate transport: Pick at 'Breaker Stage' (turning pink at blossom end).",
        "For local town consumption: Pick at 'Pink / Light Red Stage'.",
        "Firm skin with zero skin wrinkling or sunscald blemishes."
      ],
      harvestingMethod: "Twist fruit gently with stalk attached in early morning; place directly into plastic crates with foam padding.",
      postHarvestDrying: "Never expose picked crates to direct sun; pre-cool in shaded packing shed at 18-20°C.",
      storageWarning: "Never pack damaged or cracked tomatoes in the same crate as ethylene gas will rot the entire lot in 24 hours."
    },

    mandiSellingGuide: {
      mspGovt: "Perishable Crop (No MSP — Covered under Operation Greens / TOP Scheme)",
      currentMandiRate: "₹1,800 – ₹3,400 / Quintal (₹18 – ₹34 / kg depending on crate grade)",
      bestSellingWindow: "Sell early morning (4:00 AM – 7:30 AM) at APMC Auction. Avoid hot noon arrivals when commission agents discount prices.",
      gradingChecklist: [
        "Grade 1 (Super Bold): 80-100g uniform red tomatoes packed in 25kg plastic crates (Fetches top rate).",
        "Grade 2 (Medium): 60-80g clean tomatoes for daily household consumption.",
        "Grade 3 (Processing / Sauce): Irregular shapes sold to ketchup / puree manufacturers."
      ],
      nearbyMandis: [
        { name: "Pimpalgaon APMC Mandi (Nashik)", distance: "Maharashtra Hub", rate: "₹2,600/Qtl" },
        { name: "Kolar APMC Market (Karnataka)", distance: "South Asia Hub", rate: "₹2,900/Qtl" },
        { name: "Madanapalle APMC (Andhra Pradesh)", distance: "Major Hub", rate: "₹2,750/Qtl" },
        { name: "Azadpur APMC Mandi (Delhi)", distance: "Northern Mega Hub", rate: "₹3,200/Qtl" }
      ],
      mandiTips: "Check real-time Agmarknet mobile portal prices before loading the transport pickup to select the highest-paying mandi within a 60km radius."
    }
  },

  chilli: {
    cropKey: "chilli",
    cropName: "Chilli",
    vernacularName: "मिर्च",
    season: "Kharif & Rabi",
    totalDurationDays: 150,
    optimalSowingWindow: "Nursery: May-June (Kharif) or Sept-Oct (Rabi); Transplant after 35-40 days",
    seedRate: "80 – 100 g / Acre for green/dry hybrids (Armour, Sitara, Teja, G4, Byadgi)",
    seedTreatment: "Thiamethoxam 30% FS @ 5 ml/kg seed + Trichoderma harzianum @ 10 g/kg seed to prevent damping-off",
    spacing: "75-90 cm row-to-row × 45 cm plant-to-plant on raised beds with drip irrigation and silver-black mulch",
    soilPrep: "Deep well-drained sandy loam or black soil rich in organic matter; 6 tonnes FYM + 40kg DAP + 30kg Potash/acre",

    sowingDetails: {
      dasRange: "DAS 0 – 35",
      title: "Nursery Raising & Sowing",
      description: "Raise seedlings under 40-mesh insect-proof nylon net to prevent thrips and whitefly attacks during early nursery phase.",
      keyActions: [
        "Transplant stocky seedlings (35-40 days old) with deep root dip in Imidacloprid (0.5ml/L).",
        "Plant border crop of 2 rows of Maize or Jowar around chilli field to act as live barrier against sucking pests.",
        "Install 30 blue sticky traps (for Thrips) and 30 yellow sticky traps (for Whiteflies) per acre."
      ],
      warning: "Transplanting without insect net borders almost always leads to 60-80% Chilli Leaf Curl Virus infection."
    },

    irrigationSchedule: [
      {
        stageName: "Transplanting & Establishment",
        das: 5,
        dasRange: "DAS 1 – 15",
        waterVolume: "18,000 Liters / Acre every 2nd day",
        importance: "Critical",
        guidance: "Maintain uniform moist rhizosphere under mulch; avoid excess flooding which causes phytophthora collar rot."
      },
      {
        stageName: "Vegetative Canopy & Branching",
        das: 35,
        dasRange: "DAS 30 – 45",
        waterVolume: "24,000 Liters / Acre every 2-3 days",
        importance: "High",
        guidance: "Promote side branch flushes. Fertigate with 12:61:00 (Mono Ammonium Phosphate) for rapid root spread."
      },
      {
        stageName: "Flowering & Fruit Pinning",
        das: 65,
        dasRange: "DAS 60 – 75",
        waterVolume: "28,000 Liters / Acre every 2 days",
        importance: "Critical (Top Priority)",
        guidance: "Water stress during flowering causes massive flower and young bud drop. Maintain regular drip cycles."
      },
      {
        stageName: "Pod Development & Elongation",
        das: 90,
        dasRange: "DAS 85 – 105",
        waterVolume: "30,000 Liters / Acre every 2 days",
        importance: "High",
        guidance: "Fertigate with 13:00:45 (Potassium Nitrate) + Calcium Nitrate to improve capsaicin pungency and fruit shine."
      },
      {
        stageName: "Picking / Ripening Phase",
        das: 120,
        dasRange: "DAS 110 – 160",
        waterVolume: "22,000 Liters / Acre",
        importance: "Moderate",
        guidance: "Slightly reduce watering 5 days before picking to concentrate fruit solids and color."
      }
    ],

    spraySchedule: [
      {
        sprayNumber: "Spray 1 (Black Thrips & Murda Rog Shield)",
        das: 25,
        dasRange: "DAS 20 – 30",
        targetProblem: "Chilli Thrips (Scirtothrips dorsalis) & Black Thrips (Thrips parvispinus)",
        chemical: "Spinetoram 11.7% SC (Delegate) or Fipronil 5% SC",
        dosagePer15L: "14 ml or 30 ml per 15L Knapsack Pump",
        phi: "14 Days",
        weatherRule: "Spray in late evening when thrips feed actively inside flower buds."
      },
      {
        sprayNumber: "Spray 2 (Anthracnose / Dieback & Mite Guard)",
        das: 55,
        dasRange: "DAS 50 – 60",
        targetProblem: "Anthracnose / Fruit Rot (Colletotrichum) & Yellow Mites",
        chemical: "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top) + Spiromesifen 22.9% SC (Oberon)",
        dosagePer15L: "15 ml + 15 ml per 15L Knapsack Pump",
        phi: "7 Days",
        weatherRule: "Ensure complete wash of foliage; spray both upper and lower leaf surfaces."
      },
      {
        sprayNumber: "Spray 3 (Bacterial Spot & Fruit Borer Protection)",
        das: 80,
        dasRange: "DAS 75 – 85",
        targetProblem: "Bacterial Leaf Spot & Tobacco Caterpillar",
        chemical: "Copper Oxychloride 50% WP (Blitox) + Streptocycline + Emamectin Benzoate 5% SG",
        dosagePer15L: "35 g + 1.5 g + 8 g per 15L Knapsack Pump",
        phi: "5 Days",
        weatherRule: "Spray after monsoon shower breaks to prevent bacterial spot expansion."
      }
    ],

    harvestingSchedule: {
      dasRange: "DAS 75 – 150 (6 to 8 Pickings for Green; 2-3 Pickings for Red Dry)",
      maturityIndicators: [
        "For Green Chilli: Pick when fruits are firm, glossy dark green, and fully elongated (every 8-10 days).",
        "For Red Dry Chilli: Harvest when pods are completely bright deep red and partially dry on the plant.",
        "Stalk should snap cleanly from the branch without tearing bark."
      ],
      harvestingMethod: "Manual hand-snapping with pedicel intact; keep separate grades for straight vs curled pods.",
      postHarvestDrying: "For dry chilli: Spread red pods on clean cement drying floor or polythene sheets for 10-14 days until moisture drops to 10% (pods rattle when shaken).",
      storageWarning: "Do not dry chilli on bare mud ground as fungus contaminates the pods with carcinogenic aflatoxins."
    },

    mandiSellingGuide: {
      mspGovt: "Commercial Cash Crop (No MSP — Driven by domestic & export spice market)",
      currentMandiRate: "Green Chilli: ₹2,500 – ₹4,200 / Qtl | Red Dry Chilli: ₹18,500 – ₹24,000 / Qtl (Teja / Guntur)",
      bestSellingWindow: "For dry chilli: Best selling window is February to May at peak export procurement.",
      gradingChecklist: [
        "Grade 1 (Super Export): Bright deep red, unbroken pods with intact stalks, length > 8 cm.",
        "Discolored, yellowed, or broken pods fetch 30-40% lower prices as 'Talu' grade.",
        "Pack in moisture-resistant clean jute bags (40 kg each)."
      ],
      nearbyMandis: [
        { name: "Guntur Chilli Yard (Andhra Pradesh)", distance: "Asia's Largest Spice Mandi", rate: "₹22,500/Qtl" },
        { name: "Byadgi APMC Mandi (Karnataka)", distance: "Color Oleoresin Hub", rate: "₹23,800/Qtl" },
        { name: "Warangal APMC Market (Telangana)", distance: "Major Regional Hub", rate: "₹21,000/Qtl" },
        { name: "Nagpur Cotton & Spice Market (MH)", distance: "Central Hub", rate: "₹20,500/Qtl" }
      ],
      mandiTips: "Selling at Guntur or Byadgi e-NAM platforms gives direct access to spice exporters like ITC and Synthite without local commission cuts."
    }
  },

  potato: {
    cropKey: "potato",
    cropName: "Potato",
    vernacularName: "आलू",
    season: "Rabi (Winter)",
    totalDurationDays: 95,
    optimalSowingWindow: "15 October – 10 November (When night temperatures drop below 20°C)",
    seedRate: "12 – 15 Quintals / Acre (Certified seed tubers of 35-45g weight with 2-3 active eyes)",
    seedTreatment: "Dip tubers in Carboxin + Thiram (Vitavax) @ 2.5g/L water for 10 mins or treat with Trichoderma viride @ 5g/L",
    spacing: "60 cm row-to-row × 20 cm tuber-to-tuber on high earthen ridges (depth 7-8 cm)",
    soilPrep: "Deep pulverized friable sandy loam; apply 10 tonnes FYM + 60kg DAP + 40kg MOP (Sulphate of Potash preferred for high starch)",

    sowingDetails: {
      dasRange: "DAS 0 – 10",
      title: "Tuber Planting & Earthing Up",
      description: "Plant sprouted seed tubers on flat ground or shallow furrows followed immediately by earthing-up.",
      keyActions: [
        "Remove cold-storage tubers 7-10 days before planting and keep in diffused shade to develop green sprouts.",
        "Cut large tubers longitudinally ensuring each piece has at least 2 viable eyes; dry cut surfaces before planting.",
        "Perform first earthing-up 25-30 days after planting to prevent developing tubers from turning green due to sun exposure."
      ],
      warning: "Exposed tubers exposed to sunlight turn green and produce toxic Solanine alkaloid, rendering them unsellable."
    },

    irrigationSchedule: [
      {
        stageName: "First Irrigation",
        das: 3,
        dasRange: "DAS 2 – 5",
        waterVolume: "40,000 Liters / Acre",
        importance: "Critical",
        guidance: "Light irrigation reaching 2/3rd height of ridges; never submerge the ridge top to prevent tuber rotting."
      },
      {
        stageName: "Stolon Formation & Tuber Initiation",
        das: 30,
        dasRange: "DAS 25 – 35",
        waterVolume: "45,000 Liters / Acre",
        importance: "Critical (Top Priority)",
        guidance: "Most critical stage! Stolon tips swell into tubers. Water stress here drastically cuts tuber number per hill."
      },
      {
        stageName: "Tuber Bulking Stage",
        das: 55,
        dasRange: "DAS 50 – 65",
        waterVolume: "50,000 Liters / Acre",
        importance: "Critical",
        guidance: "Peak water consumption phase. Maintain 65-75% available soil moisture for maximum starch accumulation."
      },
      {
        stageName: "Late Bulking",
        das: 75,
        dasRange: "DAS 70 – 80",
        waterVolume: "35,000 Liters / Acre",
        importance: "Moderate",
        guidance: "Light irrigation. Stop all irrigation 10-12 days before haulm cutting (dehaulming) to allow tuber skin to harden."
      }
    ],

    spraySchedule: [
      {
        sprayNumber: "Spray 1 (Late Blight Preventive Prophylactic)",
        das: 40,
        dasRange: "DAS 35 – 45",
        targetProblem: "Potato Late Blight (Phytophthora infestans) Prophylaxis",
        chemical: "Mancozeb 75% WP (Dithane M-45) or Chlorothalonil 75% WP (Kavach)",
        dosagePer15L: "35 – 40 g per 15L Knapsack Pump",
        phi: "14 Days",
        weatherRule: "Mandatory prophylactic spray before overcast cloudy weather or dew formation occurs."
      },
      {
        sprayNumber: "Spray 2 (Systemic Late Blight Emergency Curative)",
        das: 60,
        dasRange: "DAS 55 – 65",
        targetProblem: "Active Late Blight Outbreak / Stem Rot",
        chemical: "Cymoxanil 8% + Mancozeb 64% WP (Curzate) or Dimethomorph 50% WP",
        dosagePer15L: "30 g or 15 g per 15L Knapsack Pump",
        phi: "10 Days",
        weatherRule: "Spray within 48 hours of infection; provides translaminar kickback action."
      },
      {
        sprayNumber: "Spray 3 (Aphid & Tuber Moth Shield)",
        das: 75,
        dasRange: "DAS 70 – 80",
        targetProblem: "Aphids (Myzus persicae) transmitting Potato Leafroll Virus",
        chemical: "Thiamethoxam 25% WG",
        dosagePer15L: "5 g per 15L Knapsack Pump",
        phi: "14 Days",
        weatherRule: "Essential for seed-potato growers to maintain virus-free status."
      }
    ],

    harvestingSchedule: {
      dasRange: "DAS 85 – 100",
      maturityIndicators: [
        "Foliage turns completely yellow and dies down.",
        "Haulm cutting (dehaulming) done 10-12 days before digging to harden tuber skin (Periderm).",
        "Tuber skin does not peel off when rubbed firmly with thumb."
      ],
      harvestingMethod: "Tractor-drawn potato digger-elevator or manual tractor ploughing in dry soil condition.",
      postHarvestDrying: "Cure harvested tubers in a cool, dark, well-ventilated shed for 10-15 days at 15-18°C and 85% RH for skin wound healing.",
      storageWarning: "Never expose dug tubers to direct sun for >1 hour as it causes sun scald and rapid rot in storage."
    },

    mandiSellingGuide: {
      mspGovt: "Perishable Vegetable (No Central MSP — State Market Intervention Scheme ₹700-900/Qtl)",
      currentMandiRate: "₹1,200 – ₹1,850 / Quintal (Table Potato) | ₹1,900 – ₹2,400 / Qtl (Chipsona processing variety)",
      bestSellingWindow: "Fresh harvest sales in Feb-March fetch baseline rates. Cold-storage potatoes sold in July-October typically fetch 40-70% higher rates.",
      gradingChecklist: [
        "Grade A (Large): 55mm+ diameter, clean oval shape without scab or cut marks.",
        "Grade B (Medium): 40-55mm diameter for general cooking.",
        "Grade C (Small / Gulla): <40mm diameter sold for seed or canning at lower prices."
      ],
      nearbyMandis: [
        { name: "Agra APMC Mandi (Uttar Pradesh)", distance: "India's Potato Capital", rate: "₹1,450/Qtl" },
        { name: "Farrukhabad APMC Market (UP)", distance: "Major Northern Hub", rate: "₹1,380/Qtl" },
        { name: "Pune APMC Market Yard (MH)", distance: "Western Hub", rate: "₹1,850/Qtl" },
        { name: "Vashi APMC Navi Mumbai", distance: "Metropolitan Mega Mandi", rate: "₹1,950/Qtl" }
      ],
      mandiTips: "Processing varieties (Kufri Chipsona-1, Chipsona-3, Frysona) can be pre-contracted with potato chip companies (PepsiCo, Balaji) for guaranteed ₹1,600-1,800/Qtl."
    }
  },

  rice: {
    cropKey: "rice",
    cropName: "Paddy / Rice",
    vernacularName: "धान",
    season: "Kharif (Monsoon)",
    totalDurationDays: 130,
    optimalSowingWindow: "Nursery: 25 May – 20 June; Transplant 21-25 days later into puddled field",
    seedRate: "12 – 15 kg / Acre for transplanted inbreds (18-20 kg/acre for direct seeded rice / DSR)",
    seedTreatment: "Carbendazim 50% WP @ 2g/kg seed + Streptocycline @ 1g/10kg seed soaked in water for 24 hours",
    spacing: "20 cm row-to-row × 15 cm hill-to-hill (2-3 seedlings per hill)",
    soilPrep: "Puddle field thoroughly with cage wheels; incorporate 5 tonnes FYM + 50kg DAP + 25kg MOP + 10kg Zinc Sulphate per acre",

    sowingDetails: {
      dasRange: "DAS 0 – 25",
      title: "Nursery Sowing & Puddled Transplanting",
      description: "Raise healthy mat-nursery or wet-bed nursery; transplant 21-day seedlings into 2-3 cm standing water.",
      keyActions: [
        "Dip roots of seedlings in Chlorpyrifos (2ml/L) to prevent early stem borer attacks.",
        "Maintain 2-3 cm shallow standing water during transplanting for easy establishment.",
        "Apply Zinc Sulphate 21% @ 10 kg/acre at final puddling to prevent Khaira disease."
      ],
      warning: "Never transplant older seedlings (>30 days) as tillering capacity drops drastically."
    },

    irrigationSchedule: [
      {
        stageName: "Transplanting to Tillering",
        das: 15,
        dasRange: "DAS 1 – 35",
        waterVolume: "Standing water of 2 – 4 cm depth",
        importance: "Critical",
        guidance: "Maintain continuous shallow standing water (2-3 cm) to suppress weeds and promote tillering."
      },
      {
        stageName: "Panicle Initiation",
        das: 60,
        dasRange: "DAS 55 – 65",
        waterVolume: "5 cm standing water",
        importance: "Critical (Top Priority)",
        guidance: "Water stress at panicle initiation causes high spikelet sterility. Never let soil dry out."
      },
      {
        stageName: "Booting & Flowering",
        das: 85,
        dasRange: "DAS 80 – 95",
        waterVolume: "5 cm standing water",
        importance: "Critical",
        guidance: "Maintains floral hydration and anthesis. Water stress causes empty grains (papey)."
      },
      {
        stageName: "Milk & Dough Stage",
        das: 105,
        dasRange: "DAS 100 – 115",
        waterVolume: "Alternate wetting and drying (AWD)",
        importance: "Moderate",
        guidance: "Apply light water; drain field completely 12-15 days before harvest to facilitate combine harvesting."
      }
    ],

    spraySchedule: [
      {
        sprayNumber: "Spray 1 (Stem Borer & Leaf Folder Control)",
        das: 35,
        dasRange: "DAS 30 – 40",
        targetProblem: "Yellow Stem Borer (Dead Heart) & Leaf Folder",
        chemical: "Cartap Hydrochloride 50% SP (Padan) or Chlorantraniliprole 0.4% GR (Ferterra)",
        dosagePer15L: "25 g per 15L Knapsack Pump (or 4kg/acre granules in standing water)",
        phi: "28 Days",
        weatherRule: "Apply when dead hearts exceed 5% or leaf damage exceeds 10%."
      },
      {
        sprayNumber: "Spray 2 (Blast & Sheath Blight Defense)",
        das: 65,
        dasRange: "DAS 60 – 70",
        targetProblem: "Rice Blast (Pyricularia) & Sheath Blight (Rhizoctonia)",
        chemical: "Tricyclazole 75% WP (Beam / Baan) or Trifloxystrobin 25% + Tebuconazole 50% WG (Nativo)",
        dosagePer15L: "10 g or 8 g per 15L Knapsack Pump",
        phi: "21 Days",
        weatherRule: "Crucial spray at neck blast emergence stage; spray top foliage thoroughly."
      },
      {
        sprayNumber: "Spray 3 (Brown Plant Hopper / BPH Shield)",
        das: 90,
        dasRange: "DAS 85 – 95",
        targetProblem: "Brown Plant Hopper (BPH / Hopper Burn)",
        chemical: "Pymetrozine 50% WG (Chess) or Triflumezopyrim 10% SC (Pexalon)",
        dosagePer15L: "12 g or 9.4 ml per 15L Knapsack Pump",
        phi: "14 Days",
        weatherRule: "Direct spray nozzle strictly towards the base/stem of paddy hills where hoppers congregate."
      }
    ],

    harvestingSchedule: {
      dasRange: "DAS 120 – 135",
      maturityIndicators: [
        "85-90% grains on the panicle turn golden-yellow straw color.",
        "Grains on the lowest part of the panicle reach hard dough stage.",
        "Grain moisture reaches 20% – 22% at harvest."
      ],
      harvestingMethod: "Combine harvester or manual sickle harvesting 10 cm above ground level.",
      postHarvestDrying: "Thresh immediately and sun dry paddy on tarpaulin for 2-3 sunny days until moisture drops to 13-14% for milling.",
      storageWarning: "Storing moist paddy causes yellowing, milling breakage (broken rice), and bitter flavor."
    },

    mandiSellingGuide: {
      mspGovt: "Common Grade: ₹2,300/Qtl | Grade A: ₹2,320/Qtl (Govt of India Minimum Support Price)",
      currentMandiRate: "₹2,350 – ₹2,750 / Qtl (Non-Basmati) | ₹3,400 – ₹4,800 / Qtl (Basmati 1121 / 1509)",
      bestSellingWindow: "Government procurement centers (FCI / State Agencies) purchase at full MSP from October to January.",
      gradingChecklist: [
        "Moisture must be strictly ≤ 17% for government procurement without deduction.",
        "Foreign matter / chaff must be < 1%.",
        "Clean, golden, uniform long grains fetch a ₹150-250/Qtl bonus in private rice mills."
      ],
      nearbyMandis: [
        { name: "Karnal Rice Market (Haryana)", distance: "Basmati Mega Hub", rate: "₹3,850/Qtl" },
        { name: "Gondia APMC Mandi (Maharashtra)", distance: "Central Rice Hub", rate: "₹2,550/Qtl" },
        { name: "Taran Taran Grain Market (Punjab)", distance: "Major Northern Hub", rate: "₹2,480/Qtl" },
        { name: "Burdwan APMC Mandi (West Bengal)", distance: "Eastern Rice Bowl", rate: "₹2,420/Qtl" }
      ],
      mandiTips: "Sell directly to state procurement centers (PDS) to get direct bank transfer (DBT) of full MSP into Aadhaar-linked account within 48 hours."
    }
  },

  cotton: {
    cropKey: "cotton",
    cropName: "Cotton",
    vernacularName: "कपास",
    season: "Kharif (Monsoon)",
    totalDurationDays: 160,
    optimalSowingWindow: "25 May – 20 June (Pre-monsoon or early monsoon)",
    seedRate: "2 packets (900g total) Bt-cotton hybrids per acre",
    seedTreatment: "Bt-cotton seeds come pre-treated with Imidacloprid 70% WS; add Trichoderma viride @ 5g/kg seed",
    spacing: "90-120 cm row-to-row × 45-60 cm plant-to-plant",
    soilPrep: "Deep black cotton soil (Vertisol) with high water-holding capacity; apply 5 tonnes FYM + 50kg 10:26:26 + 10kg Zinc",

    sowingDetails: {
      dasRange: "DAS 0 – 7",
      title: "Dibbling Sowing",
      description: "Dibble 1 seed per hill at 3-4 cm depth in moist soil ridges.",
      keyActions: [
        "Sow 2 rows of Pigeonpea (Tur) or Marigold as refuge / trap crop on field borders.",
        "Gap filling must be done within 7 days of emergence to maintain 5,500-7,000 plants/acre.",
        "Nipping (terminal bud de-topping) at 80-90 DAS to encourage lateral sympodial fruiting branches."
      ],
      warning: "Avoid water stagnation during seedling phase as it causes seedling wilt."
    },

    irrigationSchedule: [
      {
        stageName: "Early Vegetative Growth",
        das: 30,
        dasRange: "DAS 25 – 35",
        waterVolume: "40,000 Liters / Acre",
        importance: "Moderate",
        guidance: "Usually rainfed in Kharif; provide protective irrigation if dry spell exceeds 15 days."
      },
      {
        stageName: "Square Formation",
        das: 55,
        dasRange: "DAS 50 – 60",
        waterVolume: "50,000 Liters / Acre",
        importance: "High",
        guidance: "Moisture stress causes square shedding. Maintain uniform soil moisture."
      },
      {
        stageName: "Flowering & Boll Development",
        das: 80,
        dasRange: "DAS 75 – 95",
        waterVolume: "55,000 Liters / Acre",
        importance: "Critical (Top Priority)",
        guidance: "Most critical stage! Peak boll enlargement. Severe drought causes small bolls and premature opening."
      },
      {
        stageName: "Boll Bursting & Maturity",
        das: 120,
        dasRange: "DAS 115 – 140",
        waterVolume: "30,000 Liters / Acre (Dry spell needed)",
        importance: "Low (Dry weather preferred)",
        guidance: "Withhold irrigation during boll bursting to ensure clean, white lint without mold staining."
      }
    ],

    spraySchedule: [
      {
        sprayNumber: "Spray 1 (Sucking Pest Management)",
        das: 35,
        dasRange: "DAS 30 – 40",
        targetProblem: "Jassids (Amrasca), Thrips & Aphids",
        chemical: "Flonicamid 50% WG (Ulala) or Dinotefuran 20% SG",
        dosagePer15L: "6 g or 8 g per 15L Knapsack Pump",
        phi: "21 Days",
        weatherRule: "Spray when leaf edges turn yellow/curled (Hopper burn symptoms)."
      },
      {
        sprayNumber: "Spray 2 (Whitefly & Bacterial Blight Control)",
        das: 65,
        dasRange: "DAS 60 – 70",
        targetProblem: "Whiteflies & Angular Leaf Spot (Xanthomonas)",
        chemical: "Pyriproxyfen 10% + Bifenthrin 10% EC + Copper Oxychloride 50% WP",
        dosagePer15L: "25 ml + 30 g per 15L Knapsack Pump",
        phi: "14 Days",
        weatherRule: "Spray lower leaf surfaces where whitefly nymphs produce honeydew."
      },
      {
        sprayNumber: "Spray 3 (Pink Bollworm Management)",
        das: 95,
        dasRange: "DAS 90 – 105",
        targetProblem: "Pink Bollworm (Pectinophora gossypiella)",
        chemical: "Chlorantraniliprole 9.3% + Lambda-cyhalothrin 4.6% ZC (Ampligo)",
        dosagePer15L: "10 ml per 15L Knapsack Pump",
        phi: "14 Days",
        weatherRule: "Install 5 pheromone traps per acre; spray when 8 moths/trap/night are trapped for 3 consecutive days."
      }
    ],

    harvestingSchedule: {
      dasRange: "DAS 130 – 170 (3 to 4 Pickings)",
      maturityIndicators: [
        "Bolls burst completely open exposing fluffy white cotton lint.",
        "Pick on sunny dry afternoons when morning dew has evaporated completely.",
        "Do not pick stained, insect-damaged, or immature bolls together."
      ],
      harvestingMethod: "Manual hand picking of clean seed cotton (Kapas) directly into clean cotton cloths.",
      postHarvestDrying: "Sun dry seed cotton on clean tarpaulin for 2 days until moisture drops below 8% before bagging.",
      storageWarning: "Never store cotton in plastic bags or damp godowns; always use breathable jute or cotton boras."
    },

    mandiSellingGuide: {
      mspGovt: "Medium Staple: ₹7,121/Qtl | Long Staple: ₹7,521/Qtl (Govt of India Minimum Support Price)",
      currentMandiRate: "₹7,450 – ₹8,200 / Quintal (Cotton Corporation of India / Private ginners)",
      bestSellingWindow: "Sell December to February when ginning mills operate at full capacity and export demand peaks.",
      gradingChecklist: [
        "Moisture must be strictly between 7% and 8% (CCI rejects cotton above 12% moisture).",
        "Clean lint with < 2% trash content (bract leaves/dirt) earns highest price tier.",
        "Bright white color without yellow/gray weather stains."
      ],
      nearbyMandis: [
        { name: "Yavatmal APMC Mandi (Maharashtra)", distance: "Vidarbha Cotton Hub", rate: "₹7,850/Qtl" },
        { name: "Warangal Cotton Yard (Telangana)", distance: "South India Hub", rate: "₹7,920/Qtl" },
        { name: "Rajkot APMC Mandi (Gujarat)", distance: "Saurashtra White Gold Hub", rate: "₹8,150/Qtl" },
        { name: "Abohar Grain & Cotton Market (Punjab)", distance: "North Cotton Belt", rate: "₹7,650/Qtl" }
      ],
      mandiTips: "CCI (Cotton Corporation of India) procurement centers purchase directly at full MSP without trader commission."
    }
  },

  grapes: {
    cropKey: "grapes",
    cropName: "Grapes",
    vernacularName: "अंगूर",
    season: "Perennial (Foundation pruning in April, Forward pruning in Oct)",
    totalDurationDays: 145,
    optimalSowingWindow: "Forward Pruning (Fruit Pruning): 1 October – 25 October (Maharashtra & Karnataka)",
    seedRate: "Grafted Rootstock (Dogridge / Salt Creek) @ 800 – 1000 vines / acre",
    seedTreatment: "Paste pruning cuts with Copper Oxychloride (50g) + Carbendazim (10g) in 1L water to prevent dead-arm fungus",
    spacing: "3.0 m row-to-row × 1.8 m vine-to-vine on Y-trellis or Bower / Mandap system with drip irrigation",
    soilPrep: "Deep, well-drained sandy loam or black soil with EC < 1.0 dS/m; apply 15 tonnes FYM + 100kg DAP + 50kg SOP per acre",

    sowingDetails: {
      dasRange: "Pruning Day 0 – 15",
      title: "Pruning & Cane Management",
      description: "Perform 4-5 bud fruit pruning in October; spray Hydrogen Cyanamide (Dormex @ 30-35ml/L) to break bud dormancy.",
      keyActions: [
        "Apply Dormex within 24 hours of pruning for uniform bud burst.",
        "Clean vineyard floor of all pruned trimmings and incinerate to destroy overwintering mildew spores.",
        "Tie canes firmly to the trellis wire at 45-degree angle."
      ],
      warning: "Avoid pruning during rains as wet cuts invite immediate bacterial and fungal gummosis."
    },

    irrigationSchedule: [
      {
        stageName: "Bud Burst to Shoot Growth",
        das: 20,
        dasRange: "Days 10 – 30 after pruning",
        waterVolume: "12,000 – 15,000 Liters / Acre / day via Drip",
        importance: "High",
        guidance: "Promote rapid, uniform shoot elongation and inflorescence emergence."
      },
      {
        stageName: "Flowering & Cap Fall",
        das: 45,
        dasRange: "Days 40 – 55 after pruning",
        waterVolume: "8,000 – 10,000 Liters / Acre / day",
        importance: "Critical (Controlled stress)",
        guidance: "Reduce irrigation by 25-30% during flowering to promote uniform berry set and prevent flower drop."
      },
      {
        stageName: "Berry Setting & 4mm Stage",
        das: 65,
        dasRange: "Days 60 – 75 after pruning",
        waterVolume: "18,000 – 22,000 Liters / Acre / day",
        importance: "Critical (Top Priority)",
        guidance: "First GA3 (Gibberellic Acid @ 40 ppm) berry elongation dipping; daily drip irrigation is essential."
      },
      {
        stageName: "Berry Bulking & Softening",
        das: 95,
        dasRange: "Days 90 – 115 after pruning",
        waterVolume: "24,000 Liters / Acre / day",
        importance: "High",
        guidance: "Sugar accumulation stage (Veraison). Maintain consistent soil moisture to prevent berry cracking."
      },
      {
        stageName: "Pre-Harvest Ripening",
        das: 130,
        dasRange: "Days 125 – 145 after pruning",
        waterVolume: "6,000 – 8,000 Liters / Acre (Tapered down)",
        importance: "Moderate",
        guidance: "Reduce water gradually 10 days before harvest to concentrate Brix sugars (>18° Brix)."
      }
    ],

    spraySchedule: [
      {
        sprayNumber: "Spray 1 (Downy Mildew Pre-Bloom Shield)",
        das: 30,
        dasRange: "Days 25 – 35",
        targetProblem: "Downy Mildew (Plasmopara viticola) & Flea Beetle",
        chemical: "Mandipropamid 23.4% SC (Revus) or Metalaxyl + Mancozeb",
        dosagePer15L: "12 ml or 35 g per 15L Knapsack Pump",
        phi: "60 Days",
        weatherRule: "Mandatory protective cover before morning dew or unseasonal October rain."
      },
      {
        sprayNumber: "Spray 2 (Powdery Mildew & Thrips Defense)",
        das: 60,
        dasRange: "Days 55 – 65",
        targetProblem: "Powdery Mildew (Uncinula necator) & Berry Thrips",
        chemical: "Fluxapyroxad + Pyraclostrobin (Merivon) or Penconazole 10% EC (Topas)",
        dosagePer15L: "6 ml or 7.5 ml per 15L Knapsack Pump",
        phi: "45 Days",
        weatherRule: "Spray early morning; inspect cluster centers for white powdery mycelia."
      },
      {
        sprayNumber: "Spray 3 (Anthracnose & Botrytis Bunch Rot Guard)",
        das: 100,
        dasRange: "Days 95 – 105",
        targetProblem: "Botrytis Bunch Rot & Anthracnose",
        chemical: "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        dosagePer15L: "15 ml per 15L Knapsack Pump",
        phi: "28 Days",
        weatherRule: "Spray with fine mist hollow cone nozzle; ensure cluster penetration."
      }
    ],

    harvestingSchedule: {
      dasRange: "Days 135 – 150 after pruning (Jan – April)",
      maturityIndicators: [
        "Total Soluble Solids (TSS) reach 18° to 20° Brix measured with digital refractometer.",
        "Acidity drops to 0.5% – 0.6% (Brix-Acid ratio > 25:1).",
        "Uniform amber-green color for Thomson Seedless / deep black for Sharad Seedless."
      ],
      harvestingMethod: "Clip bunches using curved grape scissors by the peduncle; never touch the berries to preserve the natural white waxy bloom.",
      postHarvestDrying: "Pre-cool bunches immediately at 4°C in forced-air cooling room within 4 hours of harvest.",
      storageWarning: "Keep cold-storage at -0.5°C to 0°C with 95% RH and SO2 grape guard paper sheets to prevent Botrytis rot."
    },

    mandiSellingGuide: {
      mspGovt: "High-Value Horticultural Crop (No MSP — Export & Domestic Market Driven)",
      currentMandiRate: "Domestic Table Grapes: ₹45 – ₹85 / kg (₹4,500 – ₹8,500 / Qtl) | European Export: ₹110 – ₹140 / kg",
      bestSellingWindow: "February to April. Early February harvest commands highest domestic metro market prices.",
      gradingChecklist: [
        "Export Grade (GrapeNet Certified): Berry size 18mm+ diameter, uniform bunch weight 400-600g, zero MRL chemical residues.",
        "Domestic Premium: 16-18mm berry diameter, packed in 5kg corrugated boxes.",
        "Raisin Grade: Small berries diverted for kishmish / raisin making on shaded drying racks."
      ],
      nearbyMandis: [
        { name: "Pimpalgaon Baswant APMC (Nashik)", distance: "India's Grape Capital", rate: "₹6,800/Qtl" },
        { name: "Tasgaon APMC Mandi (Sangli)", distance: "Raisin & Table Hub", rate: "₹7,200/Qtl" },
        { name: "Vashi Fruit Market (Navi Mumbai)", distance: "Mega Export & Metro Terminal", rate: "₹8,500/Qtl" },
        { name: "Vijayapura APMC Market (Karnataka)", distance: "Southern Grape Hub", rate: "₹6,400/Qtl" }
      ],
      mandiTips: "Enroll in APEDA GrapeNet certification 90 days before harvest to sell directly to Dutch, UK, and Gulf supermarket exporters."
    }
  },

  groundnut: {
    cropKey: "groundnut",
    cropName: "Groundnut / Soybean",
    vernacularName: "मूंगफली / सोयाबीन",
    season: "Kharif & Rabi-Summer",
    totalDurationDays: 115,
    optimalSowingWindow: "15 June – 15 July (Kharif) or 15 Dec – 15 Jan (Summer)",
    seedRate: "45 – 50 kg / Acre kernel (TG-37A, TAG-24, JL-501, Kadiri-6)",
    seedTreatment: "Carboxin + Thiram (Vitavax Power) @ 2.5 g/kg seed + Rhizobium & PSB culture @ 250 g/10kg seed",
    spacing: "30 cm row-to-row × 10 cm plant-to-plant; Sowing depth 4-5 cm in well-aerated soil",
    soilPrep: "Light friable sandy loam rich in calcium; apply 5 tonnes FYM + 25kg DAP + 200 kg Gypsum/acre (split: 100kg at sowing, 100kg at flowering)",

    sowingDetails: {
      dasRange: "DAS 0 – 7",
      title: "Sowing & Seed Inoculation",
      description: "Sow bold viable kernels in moist friable soil using groundnut planter or bullock-drawn drill.",
      keyActions: [
        "Inoculate kernels with Rhizobium leguminosarum for biological nitrogen fixation nodules.",
        "Gypsum application is compulsory: Calcium is needed for pod shell formation and prevents 'pops' (empty pods).",
        "Maintain uniform planting depth (4-5 cm) for synchronized emergence."
      ],
      warning: "Heavy clay soils become hard upon drying, preventing pegs from penetrating the ground."
    },

    irrigationSchedule: [
      {
        stageName: "Germination & Vegetative",
        das: 20,
        dasRange: "DAS 15 – 25",
        waterVolume: "35,000 Liters / Acre",
        importance: "Moderate",
        guidance: "Provide light irrigation if dry spell occurs; slight moisture stress early encourages deeper root anchoring."
      },
      {
        stageName: "Flowering Stage",
        das: 40,
        dasRange: "DAS 35 – 45",
        waterVolume: "45,000 Liters / Acre",
        importance: "High",
        guidance: "Apply 2nd dose of Gypsum (100 kg/acre) close to the root zone right before this irrigation."
      },
      {
        stageName: "Pegging Stage",
        das: 60,
        dasRange: "DAS 55 – 68",
        waterVolume: "50,000 Liters / Acre",
        importance: "Critical (Top Priority)",
        guidance: "Most critical stage! Flower needles (pegs) enter the soil to form pods. Hard crust prevents peg penetration."
      },
      {
        stageName: "Pod Development",
        das: 80,
        dasRange: "DAS 75 – 90",
        waterVolume: "45,000 Liters / Acre",
        importance: "Critical",
        guidance: "Kernel filling period. Moisture stress leads to shriveled kernels and low oil content."
      },
      {
        stageName: "Pod Maturation",
        das: 105,
        dasRange: "DAS 100 – 110",
        waterVolume: "25,000 Liters / Acre",
        importance: "Moderate",
        guidance: "Apply light irrigation 2-3 days before harvest to moisten the soil so pods do not break off underground during pulling."
      }
    ],

    spraySchedule: [
      {
        sprayNumber: "Spray 1 (Stem Rot / Collar Rot Defense)",
        das: 30,
        dasRange: "DAS 25 – 35",
        targetProblem: "Collar Rot (Aspergillus niger) & Sucking Pests",
        chemical: "Tebuconazole 25.9% EC (Folicur)",
        dosagePer15L: "15 ml per 15L Knapsack Pump",
        phi: "30 Days",
        weatherRule: "Direct spray at soil collar region."
      },
      {
        sprayNumber: "Spray 2 (Tikka Disease & Rust Control)",
        das: 55,
        dasRange: "DAS 50 – 62",
        targetProblem: "Tikka Leaf Spot (Cercospora) & Groundnut Rust",
        chemical: "Hexaconazole 5% SC (Contaf) or Chlorothalonil 75% WP",
        dosagePer15L: "30 ml or 35 g per 15L Knapsack Pump",
        phi: "21 Days",
        weatherRule: "Inspect lower foliage for circular dark spots with yellow halos."
      },
      {
        sprayNumber: "Spray 3 (Late Tikka & Spodoptera Guard)",
        das: 80,
        dasRange: "DAS 75 – 85",
        targetProblem: "Late Leaf Spot & Defoliator Caterpillar",
        chemical: "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        dosagePer15L: "15 ml per 15L Knapsack Pump",
        phi: "14 Days",
        weatherRule: "Thorough spray ensures leaves stay green for maximum oil synthesis."
      }
    ],

    harvestingSchedule: {
      dasRange: "DAS 110 – 120",
      maturityIndicators: [
        "Leaves turn yellow and begin to shed naturally.",
        "Inner pod shell turns dark brown or blackish inside when cracked open.",
        "Kernels exhibit their characteristic pink seed coat and separate easily from the shell."
      ],
      harvestingMethod: "Pull vines by hand or tractor groundnut digger; shake off soil and strip pods immediately.",
      postHarvestDrying: "Sun dry pods on clean tarpaulins for 5-7 days until moisture drops to 8-9% (kernel rattles when shaken).",
      storageWarning: "Storing groundnut pods above 9% moisture triggers Aspergillus flavus mold which produces lethal aflatoxin toxins."
    },

    mandiSellingGuide: {
      mspGovt: "₹6,783 / Quintal (Govt of India Minimum Support Price for Groundnut in Shell)",
      currentMandiRate: "₹6,850 – ₹7,600 / Quintal (Oil millers & bold kernel export demand)",
      bestSellingWindow: "Sell November to January (Kharif) or May to July (Summer). Oil millers pay premium for clean dry pods.",
      gradingChecklist: [
        "Shelling turnout must be ≥ 70% (70 kg kernel from 100 kg pods).",
        "Pod moisture must be strictly ≤ 8%.",
        "Bold 2-kernel pods without pop cavities fetch a ₹250-400/Qtl premium."
      ],
      nearbyMandis: [
        { name: "Rajkot APMC Mandi (Gujarat)", distance: "India's Groundnut Capital", rate: "₹7,450/Qtl" },
        { name: "Gondal APMC Market (Gujarat)", distance: "Major Oilseed Hub", rate: "₹7,520/Qtl" },
        { name: "Latur APMC Mandi (Maharashtra)", distance: "Central Oilseed Hub", rate: "₹7,280/Qtl" },
        { name: "Bikaner APMC Mandi (Rajasthan)", distance: "North-West Hub", rate: "₹7,150/Qtl" }
      ],
      mandiTips: "Crack open 10 pods in front of the commission agent to verify black inner shell and full pink kernels to claim top auction grade."
    }
  },

  apple: {
    cropKey: "apple",
    cropName: "Apple",
    vernacularName: "सेब",
    season: "Perennial Temperate (Harvest July to October)",
    totalDurationDays: 150,
    optimalSowingWindow: "Winter Dormant Pruning: December – February (Chilling Requirement: 800-1200 hours < 7°C)",
    seedRate: "Grafted Rootstock (M9, MM106, seedling) @ 200 – 400 trees / acre",
    seedTreatment: "Apply Chaubatia paste (Copper Carbonate 800g + Red Lead 800g in 1L linseed oil) on pruning cuts and tree wounds",
    spacing: "3.5 m × 2.0 m for high-density trellis (or 6m × 6m for standard seedling trees)",
    soilPrep: "Deep, well-drained loamy soil with pH 6.0-6.8; apply 25 kg FYM + 500g 12:32:16 + 50g Borax per mature tree basin",

    sowingDetails: {
      dasRange: "Winter Dormancy (Dec – Feb)",
      title: "Winter Pruning & Tree Basin Sanitation",
      description: "Prune weak, diseased, and crossing branches; clear all dropped leaves from orchard floor to eradicate overwintering apple scab.",
      keyActions: [
        "Spray 5% Urea solution on dropped autumn leaves to accelerate fungal decomposition.",
        "Apply Dormant Tree Spray Oil (Horticultural Mineral Oil @ 20ml/L) in February against San Jose Scale and mite eggs.",
        "Ensure honeybee hives (2-3 boxes/acre) are placed for cross-pollination during pink bud stage."
      ],
      warning: "Never prune during freezing spells or snowy days as wood tears and develops silver leaf disease."
    },

    irrigationSchedule: [
      {
        stageName: "Silver Tip to Green Tip",
        das: 20,
        dasRange: "March (Bud Swell)",
        waterVolume: "100 Liters / Tree / week",
        importance: "High",
        guidance: "Initiates root sap flow and uniform bud break."
      },
      {
        stageName: "Pink Bud to Petal Fall",
        das: 45,
        dasRange: "April (Full Bloom)",
        waterVolume: "150 Liters / Tree / week",
        importance: "Critical (Top Priority)",
        guidance: "Supports pollen tube growth and initial fruitlet set. Avoid soil drought."
      },
      {
        stageName: "Fruitlet Development & June Drop",
        das: 75,
        dasRange: "May – June (Fruit thinning)",
        waterVolume: "200 Liters / Tree / week via Drip",
        importance: "Critical",
        guidance: "Cell division phase. Manual thinning to 1 fruit per spur cluster ensures large marketable fruit size."
      },
      {
        stageName: "Fruit Bulking & Color Development",
        das: 115,
        dasRange: "July – August (Pre-harvest)",
        waterVolume: "180 Liters / Tree / week",
        importance: "High",
        guidance: "Foliar spray of Calcium Chloride @ 0.5% (5g/L) to prevent Bitter Pit physiological disorder."
      }
    ],

    spraySchedule: [
      {
        sprayNumber: "Spray 1 (Apple Scab Green Tip Guard)",
        das: 25,
        dasRange: "Green Tip Stage (Late March)",
        targetProblem: "Apple Scab (Venturia inaequalis)",
        chemical: "Mancozeb 75% WP or Dodine 65% WP",
        dosagePer15L: "35 g or 15 g per 15L Knapsack Pump",
        phi: "60 Days",
        weatherRule: "Mandatory protective cover before primary ascospore discharge during spring rains."
      },
      {
        sprayNumber: "Spray 2 (Petal Fall Scab & Powdery Mildew)",
        das: 50,
        dasRange: "Petal Fall Stage (Late April)",
        targetProblem: "Apple Scab & Powdery Mildew (Podosphaera)",
        chemical: "Difenoconazole 25% EC (Score) or Fluxapyroxad + Pyraclostrobin",
        dosagePer15L: "5 ml or 6 ml per 15L Knapsack Pump",
        phi: "35 Days",
        weatherRule: "Spray within 72 hours of rain infection period for curative kickback."
      },
      {
        sprayNumber: "Spray 3 (Flyspeck, Sooty Blotch & Fruit Borer)",
        das: 90,
        dasRange: "Fruit Development (Late June)",
        targetProblem: "Fruit Rot, Flyspeck & San Jose Scale Crawlers",
        chemical: "Kresoxim-methyl 44.3% SC or Tebuconazole 25.9% EC",
        dosagePer15L: "7.5 ml or 10 ml per 15L Knapsack Pump",
        phi: "21 Days",
        weatherRule: "Spray thoroughly into tree canopy ensuring fruit clusters are covered."
      }
    ],

    harvestingSchedule: {
      dasRange: "July – October (Depending on Elevation & Cultivar)",
      maturityIndicators: [
        "Ground color of fruit changes from dull green to yellowish-white.",
        "Starch-iodine test shows 60-70% starch conversion into sugars.",
        "Fruit separates easily from spur when tilted upwards with a slight twist.",
        "Seed color turns from white to dark chestnut brown inside."
      ],
      harvestingMethod: "Gentle manual hand picking using two hands; place in cloth-lined picking bags; never pull downwards.",
      postHarvestDrying: "Pre-cool harvested fruit within 12 hours to 4°C in grading shed.",
      storageWarning: "Grading must discard bruised fruits; Bruised fruit releases ethylene which triggers rapid breakdown in cold storage."
    },

    mandiSellingGuide: {
      mspGovt: "Market Intervention Scheme (MIS) by HPMC / J&K Govt: ₹12 – ₹15 / kg for processing grade",
      currentMandiRate: "Fresh Table Grade: ₹70 – ₹140 / kg (₹7,000 – ₹14,000 / Qtl for Royal Delicious / Gala)",
      bestSellingWindow: "August to November. Controlled Atmosphere (CA) stored apples sold in March-May fetch ₹140-180/kg.",
      gradingChecklist: [
        "Extra Fancy / Super: 70mm+ diameter, 80%+ red blush color, packed in 20kg telescopic carton with moulded trays.",
        "Fancy Grade: 60-70mm diameter, 50-80% red color.",
        "Culled / Processing Grade: Sold to HPMC for apple juice concentrate."
      ],
      nearbyMandis: [
        { name: "Shimla APMC Mandi (Dhali, HP)", distance: "Himachal Apple Hub", rate: "₹9,500/Qtl" },
        { name: "Sopore Fruit Mandi (Kashmir)", distance: "Asia's 2nd Largest Fruit Mandi", rate: "₹8,800/Qtl" },
        { name: "Azadpur Fruit Mandi (Delhi)", distance: "National Terminal Market", rate: "₹11,500/Qtl" },
        { name: "Chandigarh Fruit Market (Sector 26)", distance: "Northern Transit Hub", rate: "₹10,200/Qtl" }
      ],
      mandiTips: "CA (Controlled Atmosphere) cold-stored apples fetch 40-60% premium during off-season months (February to May)."
    }
  }
};

// Merge all expanded crops into cropLifecycleDatabase
if (expandedAllCropLifecycles && typeof expandedAllCropLifecycles === 'object') {
  Object.assign(cropLifecycleDatabase, expandedAllCropLifecycles);
}

// Aliases for seamless matching across different transliterations and common names
const cropAliases = {
  'basmati-rice': 'rice',
  'paddy': 'rice',
  'corn': 'maize',
  'sweet-corn': 'maize',
  'baby-corn': 'maize',
  'chana': 'chickpea',
  'gram': 'chickpea',
  'desi-chana': 'chickpea',
  'kabuli-chana': 'chickpea',
  'tur': 'pigeon-pea',
  'arhar': 'pigeon-pea',
  'moong': 'green-gram',
  'mung': 'green-gram',
  'urad': 'black-gram',
  'masoor': 'lentil',
  'eggplant': 'brinjal',
  'baingan': 'brinjal',
  'bhindi': 'okra',
  'ladyfinger': 'okra',
  'sarson': 'mustard',
  'rapeseed': 'mustard',
  'sorghum': 'jowar',
  'til': 'sesame',
  'haldi': 'turmeric',
  'adrak': 'ginger',
  'jeera': 'cumin',
  'dhaniya': 'coriander',
  'methi': 'fenugreek',
  'peanut': 'groundnut',
  'ganna': 'sugarcane',
  'kela': 'banana',
  'aam': 'mango',
  'tarbooz': 'watermelon'
};

for (const [alias, target] of Object.entries(cropAliases)) {
  if (!cropLifecycleDatabase[alias] && cropLifecycleDatabase[target]) {
    cropLifecycleDatabase[alias] = cropLifecycleDatabase[target];
  }
}

// Backward-compatibility and convenience aliases for harvest stage
for (const c of Object.values(cropLifecycleDatabase)) {
  if (c.harvestingSchedule) {
    c.harvestDetails = c.harvestingSchedule;
    if (c.harvestingSchedule.maturityIndicators && !c.harvestingSchedule.maturitySigns) {
      c.harvestingSchedule.maturitySigns = c.harvestingSchedule.maturityIndicators;
    }
  }
}

/**
 * Robust helper to resolve any crop key, name, or variation to its lifecycle profile
 */
export function getCropLifecycle(cropKey) {
  if (!cropKey) return cropLifecycleDatabase.wheat;
  if (cropLifecycleDatabase[cropKey]) return cropLifecycleDatabase[cropKey];

  const lower = String(cropKey).toLowerCase().trim();
  if (cropLifecycleDatabase[lower]) return cropLifecycleDatabase[lower];

  const clean = lower.replace(/[^a-z0-9]/g, '');
  for (const [k, crop] of Object.entries(cropLifecycleDatabase)) {
    const kClean = k.replace(/[^a-z0-9]/g, '');
    if (clean === kClean || clean.includes(kClean) || kClean.includes(clean)) {
      return crop;
    }
    const nameClean = crop.cropName.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (clean.includes(nameClean) || nameClean.includes(clean)) {
      return crop;
    }
  }

  return cropLifecycleDatabase.wheat;
}

/**
 * Helper to compute dynamic calendar dates based on user's sowing date
 */
export function calculateDynamicCropCalendar(cropKey, sowingDateStr) {
  const crop = getCropLifecycle(cropKey);
  const sowingDate = new Date(sowingDateStr || Date.now());

  const addDays = (d, days) => {
    const res = new Date(d);
    res.setDate(res.getDate() + days);
    return res.toISOString().split('T')[0];
  };

  const dynamicIrrigation = crop.irrigationSchedule.map((item, idx) => ({
    ...item,
    scheduledDate: addDays(sowingDate, item.das),
    isCompleted: (Date.now() - sowingDate.getTime()) > (item.das * 86400000),
    isCurrent: Math.abs((Date.now() - sowingDate.getTime()) - (item.das * 86400000)) < (4 * 86400000)
  }));

  const dynamicSprays = crop.spraySchedule.map((item, idx) => ({
    ...item,
    scheduledDate: addDays(sowingDate, item.das),
    isCompleted: (Date.now() - sowingDate.getTime()) > (item.das * 86400000),
    isCurrent: Math.abs((Date.now() - sowingDate.getTime()) - (item.das * 86400000)) < (4 * 86400000)
  }));

  const harvestStartDate = addDays(sowingDate, crop.totalDurationDays - 10);
  const harvestEndDate = addDays(sowingDate, crop.totalDurationDays + 10);

  const mandiStartDate = addDays(sowingDate, crop.totalDurationDays + 5);
  const mandiBestEndDate = addDays(sowingDate, crop.totalDurationDays + 60);

  return {
    crop,
    sowingDateStr: sowingDate.toISOString().split('T')[0],
    dynamicIrrigation,
    dynamicSprays,
    harvestWindow: {
      startDate: harvestStartDate,
      endDate: harvestEndDate,
      dasSpan: `${crop.totalDurationDays - 10} – ${crop.totalDurationDays + 10} DAS`
    },
    mandiWindow: {
      startDate: mandiStartDate,
      bestEndDate: mandiBestEndDate,
      status: (Date.now() > new Date(harvestStartDate).getTime()) ? "Ready for Mandi Sale" : "Upcoming Post-Harvest"
    }
  };
}
