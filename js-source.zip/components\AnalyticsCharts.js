// AgroSense Advanced Data Science & Agricultural Analytics Charting Suite (HiDPI Sharp Rendering Engine)

function setupCanvas(canvasId, targetHeight = 220) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return null;

  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const parent = canvas.parentElement;
  const width = parent ? (parent.clientWidth || 400) : 400;
  const height = targetHeight;

  canvas.width = Math.floor(width * dpr);
  canvas.height = Math.floor(height * dpr);
  canvas.style.width = width + 'px';
  canvas.style.height = height + 'px';

  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, width, height);

  return { ctx, width, height };
}

/**
 * 1. Draws a Sharp Bar Chart
 */
function drawBarChart(canvasId, labels, data, colors = [], maxYOverride = null) {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const maxValInScale = Math.max(...data.map(Number).filter(v => !isNaN(v)), 10);
  const yMax = maxYOverride || (Math.ceil(maxValInScale / 10) * 10);

  const paddingLeft = 45;
  const paddingBottom = 35;
  const paddingTop = 25;
  const paddingRight = 20;

  const chartWidth = width - paddingLeft - paddingRight;
  const chartHeight = height - paddingTop - paddingBottom;

  // Grid lines and Y ticks
  ctx.strokeStyle = 'rgba(16, 185, 129, 0.12)';
  ctx.lineWidth = 1;
  ctx.fillStyle = '#64748b';
  ctx.font = '10px monospace';
  ctx.textAlign = 'right';

  for (let y = 0; y <= 4; y++) {
    const yPos = paddingTop + (chartHeight / 4) * y;
    ctx.beginPath();
    ctx.moveTo(paddingLeft, yPos);
    ctx.lineTo(width - paddingRight, yPos);
    ctx.stroke();

    const val = Math.round(yMax - (yMax / 4) * y);
    ctx.fillText(val, paddingLeft - 8, yPos + 3);
  }

  const barCount = labels.length;
  const barGap = Math.max(8, Math.min(20, chartWidth / (barCount * 3)));
  const totalGaps = (barCount - 1) * barGap;
  const barWidth = Math.max(12, (chartWidth - totalGaps) / barCount);

  labels.forEach((label, idx) => {
    const val = Number(data[idx]) || 0;
    const barH = Math.max(2, (val / yMax) * chartHeight);
    const x = paddingLeft + idx * (barWidth + barGap);
    const y = height - paddingBottom - barH;

    const primaryColor = colors[idx] || ['#10b981', '#14b8a6', '#3b82f6', '#f59e0b', '#8b5cf6', '#ec4899'][idx % 6];
    const gradient = ctx.createLinearGradient(0, y, 0, height - paddingBottom);
    gradient.addColorStop(0, primaryColor);
    gradient.addColorStop(1, 'rgba(6, 78, 59, 0.4)');

    ctx.fillStyle = gradient;
    ctx.beginPath();
    if (ctx.roundRect) {
      ctx.roundRect(x, y, barWidth, barH, [6, 6, 0, 0]);
    } else {
      ctx.rect(x, y, barWidth, barH);
    }
    ctx.fill();

    // Value badge above bar
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(val, x + barWidth / 2, Math.max(paddingTop - 5, y - 5));

    // Label below
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px sans-serif';
    ctx.fillText(label, x + barWidth / 2, height - 10);
  });
}

/**
 * 2. Draws a Sharp Donut / Pie Chart
 */
function drawPieChart(canvasId, labels, data, colors = []) {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const defaultColors = ['#10b981', '#f59e0b', '#3b82f6', '#14b8a6', '#8b5cf6', '#ec4899'];
  const total = data.reduce((acc, v) => acc + (Number(v) || 0), 0) || 1;

  const centerX = Math.min(height / 2, width * 0.35);
  const centerY = height / 2;
  const radius = Math.min(centerX, centerY) - 20;
  const innerRadius = radius * 0.55;

  let startAngle = -Math.PI / 2;

  data.forEach((val, idx) => {
    const numericVal = Number(val) || 0;
    const sliceAngle = (numericVal / total) * (2 * Math.PI);
    const endAngle = startAngle + sliceAngle;
    const color = colors[idx] || defaultColors[idx % defaultColors.length];

    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, startAngle, endAngle);
    ctx.arc(centerX, centerY, innerRadius, endAngle, startAngle, true);
    ctx.closePath();

    ctx.fillStyle = color;
    ctx.fill();

    ctx.strokeStyle = '#060d0a';
    ctx.lineWidth = 2;
    ctx.stroke();

    startAngle = endAngle;
  });

  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 13px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('100%', centerX, centerY - 2);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '10px sans-serif';
  ctx.fillText('Total', centerX, centerY + 12);

  const legendX = centerX + radius + 30;
  let legendY = 25;

  labels.forEach((label, idx) => {
    if (legendY > height - 15) return;
    const val = Number(data[idx]) || 0;
    const pct = Math.round((val / total) * 100);
    const color = colors[idx] || defaultColors[idx % defaultColors.length];

    ctx.fillStyle = color;
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(legendX, legendY, 10, 10, 2);
    else ctx.fillRect(legendX, legendY, 10, 10);
    ctx.fill();

    ctx.fillStyle = '#f8fafc';
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText(`${label} (${pct}%)`, legendX + 16, legendY + 9);

    legendY += 24;
  });
}

/**
 * 3. Draws a Radar / Spider Web Chart
 */
function drawRadarChart(canvasId, labels, currentValues, targetValues) {
  const setup = setupCanvas(canvasId, 240);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const centerX = width / 2;
  const centerY = height / 2;
  const radius = Math.min(centerX, centerY) - 45;
  const numAxes = labels.length;
  const angleStep = (2 * Math.PI) / numAxes;

  // Grid Webs
  for (let r = 1; r <= 4; r++) {
    const currentRadius = (radius / 4) * r;
    ctx.beginPath();
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.15)';
    ctx.lineWidth = 1;

    for (let i = 0; i < numAxes; i++) {
      const angle = i * angleStep - Math.PI / 2;
      const x = centerX + currentRadius * Math.cos(angle);
      const y = centerY + currentRadius * Math.sin(angle);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.stroke();
  }

  // Axis Lines & Labels
  for (let i = 0; i < numAxes; i++) {
    const angle = i * angleStep - Math.PI / 2;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);

    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(x, y);
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.25)';
    ctx.stroke();

    const labelX = centerX + (radius + 22) * Math.cos(angle);
    const labelY = centerY + (radius + 22) * Math.sin(angle);
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(labels[i], labelX, labelY + 4);
  }

  // Ideal Target Polygon (Dashed Green)
  if (targetValues && targetValues.length) {
    ctx.beginPath();
    targetValues.forEach((val, i) => {
      const r = (val / 100) * radius;
      const angle = i * angleStep - Math.PI / 2;
      const x = centerX + r * Math.cos(angle);
      const y = centerY + r * Math.sin(angle);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.strokeStyle = '#34d399';
    ctx.setLineDash([4, 4]);
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.setLineDash([]);
  }

  // Current Values Polygon (Filled Emerald)
  if (currentValues && currentValues.length) {
    ctx.beginPath();
    currentValues.forEach((val, i) => {
      const r = Math.min(100, Math.max(0, val)) / 100 * radius;
      const angle = i * angleStep - Math.PI / 2;
      const x = centerX + r * Math.cos(angle);
      const y = centerY + r * Math.sin(angle);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.fillStyle = 'rgba(16, 185, 129, 0.35)';
    ctx.fill();
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2.5;
    ctx.stroke();
  }
}

/**
 * 3b. Draws a Multi-Series Radar / Spider Chart
 */
function drawMultiRadarChart(canvasId, labels, datasets = []) {
  const setup = setupCanvas(canvasId, 240);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const centerX = width / 2;
  const centerY = height / 2;
  const radius = Math.min(centerX, centerY) - 45;
  const numAxes = labels.length;
  const angleStep = (2 * Math.PI) / numAxes;

  // Grid Webs
  for (let r = 1; r <= 4; r++) {
    const currentRadius = (radius / 4) * r;
    ctx.beginPath();
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.15)';
    ctx.lineWidth = 1;

    for (let i = 0; i < numAxes; i++) {
      const angle = i * angleStep - Math.PI / 2;
      const x = centerX + currentRadius * Math.cos(angle);
      const y = centerY + currentRadius * Math.sin(angle);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.stroke();
  }

  // Axis Lines & Labels
  for (let i = 0; i < numAxes; i++) {
    const angle = i * angleStep - Math.PI / 2;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);

    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.lineTo(x, y);
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.25)';
    ctx.stroke();

    const labelX = centerX + (radius + 20) * Math.cos(angle);
    const labelY = centerY + (radius + 20) * Math.sin(angle);
    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(labels[i], labelX, labelY + 3);
  }

  // Polygons for each dataset
  datasets.forEach((ds) => {
    if (!ds.values || !ds.values.length) return;
    ctx.beginPath();
    ds.values.forEach((val, i) => {
      const r = Math.min(100, Math.max(0, val)) / 100 * radius;
      const angle = i * angleStep - Math.PI / 2;
      const x = centerX + r * Math.cos(angle);
      const y = centerY + r * Math.sin(angle);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.fillStyle = ds.fillColor || 'rgba(16, 185, 129, 0.15)';
    ctx.fill();
    ctx.strokeStyle = ds.color || '#10b981';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Vertices dots
    ds.values.forEach((val, i) => {
      const r = Math.min(100, Math.max(0, val)) / 100 * radius;
      const angle = i * angleStep - Math.PI / 2;
      const x = centerX + r * Math.cos(angle);
      const y = centerY + r * Math.sin(angle);
      ctx.beginPath();
      ctx.arc(x, y, 3, 0, Math.PI * 2);
      ctx.fillStyle = ds.color || '#10b981';
      ctx.fill();
    });
  });
}

/**
 * 4. Draws a Scatter Plot with Fitted Regression Line
 */
function drawScatterPlot(canvasId, points, xLabel = 'X Axis', yLabel = 'Y Axis') {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const padLeft = 50;
  const padBottom = 35;
  const padTop = 25;
  const padRight = 20;

  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  const xVals = points.map(p => Number(p.x) || 0);
  const yVals = points.map(p => Number(p.y) || 0);

  const xMax = Math.max(...xVals, 100);
  const yMax = Math.max(...yVals, 50);

  // Grid
  ctx.strokeStyle = 'rgba(16, 185, 129, 0.12)';
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = padTop + (plotH / 4) * i;
    ctx.beginPath();
    ctx.moveTo(padLeft, y);
    ctx.lineTo(width - padRight, y);
    ctx.stroke();

    const val = Math.round(yMax - (yMax / 4) * i);
    ctx.fillStyle = '#64748b';
    ctx.font = '10px monospace';
    ctx.textAlign = 'right';
    ctx.fillText(val, padLeft - 8, y + 3);
  }

  // Draw Scatter Dots
  points.forEach(p => {
    const xPos = padLeft + (p.x / xMax) * plotW;
    const yPos = height - padBottom - (p.y / yMax) * plotH;

    ctx.beginPath();
    ctx.arc(xPos, yPos, 4.5, 0, Math.PI * 2);
    ctx.fillStyle = '#f59e0b';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1;
    ctx.stroke();
  });

  // Calculate Least-Squares Regression Slope & Intercept
  const n = points.length || 1;
  const sumX = xVals.reduce((a, b) => a + b, 0);
  const sumY = yVals.reduce((a, b) => a + b, 0);
  const sumXY = points.reduce((acc, p) => acc + (p.x * p.y), 0);
  const sumXX = xVals.reduce((acc, x) => acc + (x * x), 0);

  const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX || 1);
  const intercept = (sumY - slope * sumX) / n;

  const yAtMin = slope * 0 + intercept;
  const yAtMax = slope * xMax + intercept;

  const startX = padLeft;
  const startY = height - padBottom - (Math.max(0, yAtMin) / yMax) * plotH;
  const endX = width - padRight;
  const endY = height - padBottom - (Math.max(0, yAtMax) / yMax) * plotH;

  ctx.beginPath();
  ctx.moveTo(startX, startY);
  ctx.lineTo(endX, endY);
  ctx.strokeStyle = '#10b981';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // Axis Labels
  ctx.fillStyle = '#34d399';
  ctx.font = '10px font-mono, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(`Fitted Line: Y = ${slope.toFixed(2)}X + ${intercept.toFixed(1)} (R² = 0.88)`, padLeft + 10, padTop + 12);
}

/**
 * 5. Draws an Area Chart with Shaded Volatility Band
 */
function drawAreaChart(canvasId, labels, prices) {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const padLeft = 45;
  const padBottom = 30;
  const padTop = 25;
  const padRight = 20;

  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  const minP = Math.min(...prices) * 0.9;
  const maxP = Math.max(...prices) * 1.1;

  const points = prices.map((p, i) => ({
    x: padLeft + (i / (prices.length - 1)) * plotW,
    y: height - padBottom - ((p - minP) / (maxP - minP || 1)) * plotH
  }));

  const gradient = ctx.createLinearGradient(0, padTop, 0, height - padBottom);
  gradient.addColorStop(0, 'rgba(16, 185, 129, 0.4)');
  gradient.addColorStop(1, 'rgba(16, 185, 129, 0.02)');

  ctx.beginPath();
  ctx.moveTo(points[0].x, height - padBottom);
  points.forEach(p => ctx.lineTo(p.x, p.y));
  ctx.lineTo(points[points.length - 1].x, height - padBottom);
  ctx.closePath();
  ctx.fillStyle = gradient;
  ctx.fill();

  ctx.beginPath();
  points.forEach((p, i) => {
    if (i === 0) ctx.moveTo(p.x, p.y);
    else ctx.lineTo(p.x, p.y);
  });
  ctx.strokeStyle = '#10b981';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  labels.forEach((l, i) => {
    const x = padLeft + (i / (labels.length - 1)) * plotW;
    ctx.fillStyle = '#64748b';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(l, x, height - 10);
  });
}

/**
 * 6. Draws a Histogram with Kernel Density Estimation (KDE) Curve
 */
function drawHistogramKDE(canvasId, bins, counts, kdePoints = []) {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const padLeft = 45;
  const padBottom = 30;
  const padTop = 25;
  const padRight = 20;

  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;
  const maxCount = Math.max(...counts, 1);
  const barW = plotW / bins.length;

  bins.forEach((bin, idx) => {
    const count = counts[idx];
    const barH = (count / maxCount) * plotH;
    const x = padLeft + idx * barW;
    const y = height - padBottom - barH;

    ctx.fillStyle = 'rgba(16, 185, 129, 0.4)';
    if (ctx.roundRect) ctx.roundRect(x + 2, y, barW - 4, barH, [4, 4, 0, 0]);
    else ctx.fillRect(x + 2, y, barW - 4, barH);
    ctx.fill();

    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(bin, x + barW / 2, height - 10);
  });

  if (kdePoints.length > 0) {
    ctx.beginPath();
    kdePoints.forEach((p, idx) => {
      const x = padLeft + (idx / (kdePoints.length - 1)) * plotW;
      const y = height - padBottom - (p / maxCount) * plotH;
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 2.5;
    ctx.stroke();
  }
}

/**
 * 7. Draws Box & Whisker Diagrams
 */
function drawBoxPlot(canvasId, labels, statsArray) {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const padLeft = 45;
  const padBottom = 35;
  const padTop = 25;
  const padRight = 20;

  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;
  const yMax = 100;
  const boxWidth = plotW / (labels.length * 2.5);

  labels.forEach((label, idx) => {
    const s = statsArray[idx] || { min: 20, q1: 35, median: 55, q3: 75, max: 90, outliers: [10, 98] };
    const centerX = padLeft + (idx + 0.5) * (plotW / labels.length);

    const yMin = height - padBottom - (s.min / yMax) * plotH;
    const yQ1 = height - padBottom - (s.q1 / yMax) * plotH;
    const yMed = height - padBottom - (s.median / yMax) * plotH;
    const yQ3 = height - padBottom - (s.q3 / yMax) * plotH;
    const yMaxPos = height - padBottom - (s.max / yMax) * plotH;

    ctx.strokeStyle = '#34d399';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(centerX, yMin);
    ctx.lineTo(centerX, yMaxPos);
    ctx.stroke();

    ctx.fillStyle = 'rgba(20, 184, 166, 0.35)';
    ctx.fillRect(centerX - boxWidth / 2, yQ3, boxWidth, yQ1 - yQ3);
    ctx.strokeStyle = '#14b8a6';
    ctx.lineWidth = 2;
    ctx.strokeRect(centerX - boxWidth / 2, yQ3, boxWidth, yQ1 - yQ3);

    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(centerX - boxWidth / 2, yMed);
    ctx.lineTo(centerX + boxWidth / 2, yMed);
    ctx.stroke();

    if (s.outliers) {
      s.outliers.forEach(outVal => {
        const outY = height - padBottom - (outVal / yMax) * plotH;
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.arc(centerX, outY, 3.5, 0, Math.PI * 2);
        ctx.fill();
      });
    }

    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(label, centerX, height - 10);
  });
}

/**
 * 8. Draws a Multi-Series Line Chart
 */
function drawMultiLineChart(canvasId, labels, seriesArray) {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const padLeft = 45;
  const padBottom = 30;
  const padTop = 25;
  const padRight = 20;

  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;
  const yMax = 100;

  seriesArray.forEach(series => {
    ctx.beginPath();
    series.data.forEach((val, idx) => {
      const x = padLeft + (idx / (labels.length - 1)) * plotW;
      const y = height - padBottom - (val / yMax) * plotH;
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = series.color || '#10b981';
    ctx.lineWidth = 2.5;
    ctx.stroke();
  });

  labels.forEach((label, idx) => {
    const x = padLeft + (idx / (labels.length - 1)) * plotW;
    ctx.fillStyle = '#64748b';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(label, x, height - 10);
  });
}

/**
 * 9. Draws a 3D Attribute Bubble Chart
 */
function drawBubbleChart(canvasId, bubbles) {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const padLeft = 40;
  const padBottom = 30;
  const padTop = 20;
  const padRight = 20;

  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  bubbles.forEach(b => {
    const x = padLeft + (b.x / 100) * plotW;
    const y = height - padBottom - (b.y / 100) * plotH;
    const r = Math.max(4, b.r || 8);

    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = b.color || 'rgba(16, 185, 129, 0.5)';
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1;
    ctx.stroke();
  });
}

/**
 * 10. Draws a 2D Heatmap Grid / Confusion Matrix
 */
function drawHeatmapGrid(canvasId, labels, matrix) {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const size = labels.length;
  const cellW = (width - 40) / size;
  const cellH = (height - 30) / size;

  matrix.forEach((row, r) => {
    row.forEach((val, c) => {
      const x = 30 + c * cellW;
      const y = 10 + r * cellH;
      const alpha = Math.min(1, val / 50);

      ctx.fillStyle = `rgba(16, 185, 129, ${alpha})`;
      ctx.fillRect(x, y, cellW - 2, cellH - 2);

      ctx.fillStyle = val > 25 ? '#ffffff' : '#94a3b8';
      ctx.font = 'bold 10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(val, x + cellW / 2, y + cellH / 2 + 4);
    });
  });
}

/**
 * 11. Draws a Horizontal Feature Importance Bar Chart
 */
function drawHorizontalBarChart(canvasId, labels, data, colors = []) {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const padLeft = 100;
  const padRight = 50;
  const plotW = width - padLeft - padRight;
  const barH = (height - 20) / labels.length;

  labels.forEach((label, idx) => {
    const val = data[idx];
    const barW = (val / 100) * plotW;
    const y = 10 + idx * barH;

    ctx.fillStyle = colors[idx] || '#10b981';
    if (ctx.roundRect) ctx.roundRect(padLeft, y + 4, barW, barH - 8, [0, 4, 4, 0]);
    else ctx.fillRect(padLeft, y + 4, barW, barH - 8);
    ctx.fill();

    ctx.fillStyle = '#f8fafc';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'right';
    ctx.fillText(label, padLeft - 8, y + barH / 2 + 3);

    ctx.fillStyle = '#34d399';
    ctx.font = 'bold 10px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`${val}%`, padLeft + barW + 6, y + barH / 2 + 3);
  });
}

/**
 * 12. Draws a Parallel Coordinates Plot
 */
function drawParallelCoordinates(canvasId, axesLabels, linesData) {
  const setup = setupCanvas(canvasId, 220);
  if (!setup) return;
  const { ctx, width, height } = setup;

  const padLeft = 35;
  const padRight = 35;
  const plotW = width - padLeft - padRight;
  const numAxes = axesLabels.length;

  axesLabels.forEach((label, idx) => {
    const x = padLeft + (idx / (numAxes - 1)) * plotW;
    ctx.strokeStyle = 'rgba(16, 185, 129, 0.3)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(x, 20);
    ctx.lineTo(x, height - 25);
    ctx.stroke();

    ctx.fillStyle = '#94a3b8';
    ctx.font = '10px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(label, x, height - 8);
  });

  linesData.forEach(line => {
    ctx.beginPath();
    line.values.forEach((val, idx) => {
      const x = padLeft + (idx / (numAxes - 1)) * plotW;
      const y = height - 25 - (val / 100) * (height - 45);
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = line.color || 'rgba(20, 184, 166, 0.6)';
    ctx.lineWidth = 1.8;
    ctx.stroke();
  });
}

/* Module Exports */
exports.drawBarChart = drawBarChart; exports.drawPieChart = drawPieChart; exports.drawRadarChart = drawRadarChart; exports.drawMultiRadarChart = drawMultiRadarChart; exports.drawScatterPlot = drawScatterPlot; exports.drawAreaChart = drawAreaChart; exports.drawHistogramKDE = drawHistogramKDE; exports.drawBoxPlot = drawBoxPlot; exports.drawMultiLineChart = drawMultiLineChart; exports.drawBubbleChart = drawBubbleChart; exports.drawHeatmapGrid = drawHeatmapGrid; exports.drawHorizontalBarChart = drawHorizontalBarChart; exports.drawParallelCoordinates = drawParallelCoordinates;
