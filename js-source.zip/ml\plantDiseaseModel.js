// AgroSense AI Computer Vision Plant Pathology Screening Engine & Knowledge Base
// Multi-crop leaf disease classification, biomarker extraction, dynamic lesion localization & actionable farmer solutions

const { allAgrosenseCropsList,
  allCropsHealthyReferenceModels,
  allCropsKeyMap,
  expandedPlantDiseaseDatabase } = require('js/data/allCropsDiseaseDatabase.js');

const {
  initCropModel,
  getCropModelStatus,
  subscribeCropModelStatus,
  detectCropFromImage,
  CROP_MODEL_STATUS,
  SUPPORTED_CROP_CLASSES
} = require('js/ml/cropDetectionModel.js');

/**
 * Comprehensive Plant Pathology Database covering staple crops & major diseases
 */
const corePlantDiseaseDatabase = [
  // 1. TOMATO DISEASES
  {
    id: "tomato-early-blight",
    crop: "Tomato (टमाटर / टोमॅटो)",
    cropKey: "tomato",
    diseaseName: "Early Blight (Alternaria solani)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.52, necrotic: 0.28, chlorosis: 0.16, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Dark brown to black necrotic spots with characteristic concentric target-board rings",
      "Prominent yellow chlorotic halo surrounding expanding spots",
      "Older lower leaves infected first, gradually progressing upwards causing defoliation",
      "Stem collar rot and sunken dark leathery lesions near the soil line"
    ],
    culturalMeasures: [
      "Prune and destroy infected lower leaves (bottom 30 cm) to eliminate fungal spore splash.",
      "Immediately cease overhead sprinkler irrigation; switch strictly to drip irrigation at root level.",
      "Apply 2 inches of clean straw mulch around plant base to prevent soil-borne spore rebound onto leaves.",
      "Disinfect pruning shears with 10% sodium hypochlorite (bleach) or 70% alcohol between plants."
    ],
    biologicalControl: [
      "Foliar spray of Trichoderma viride (1% WP) @ 5g/L water mixed with 1g jaggery as sticky agent.",
      "Spray cold-pressed Neem Seed Kernel Extract (NSKE 5%) or Azadirachtin 10,000 ppm @ 2.5 ml/L water in early morning.",
      "Root drenching with Pseudomonas fluorescens @ 10g/L water at 15-day intervals."
    ],
    chemicalControl: [
      {
        chemical: "Mancozeb 75% WP (Dithane M-45)",
        dosage: "2.5 g / Liter of water",
        timing: "Basal protective spray at first appearance of target spots; repeat every 8-10 days."
      },
      {
        chemical: "Copper Oxychloride 50% WP (Blitox)",
        dosage: "3.0 g / Liter of water",
        timing: "Curative spray during persistent humid / rainy intervals; provides broad-spectrum spore kill."
      },
      {
        chemical: "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        dosage: "1.0 ml / Liter of water",
        timing: "Systemic translaminar curative spray for advanced infections; 5-day pre-harvest interval."
      }
    ],
    preventiveCare: [
      "Maintain a 3-year crop rotation avoiding Solanaceous family crops (potato, brinjal, chilli).",
      "Plant certified resistant varieties (e.g. Arka Rakshak, Pusa Rohini, US-440).",
      "Incorporate 4 tonnes/acre well-decomposed Farm Yard Manure (FYM) enriched with Trichoderma before transplanting."
    ],
    kvkHelpline: "Call National Kisan Call Center: 1800-180-1551 or contact local Krishi Vigyan Kendra (KVK)."
  },
  {
    id: "tomato-late-blight",
    crop: "Tomato (टमाटर / टोमॅटो)",
    cropKey: "tomato",
    diseaseName: "Late Blight (Phytophthora infestans)",
    pathogenType: "Oomycete Water Mold",
    targetBiomarkers: { green: 0.44, necrotic: 0.36, chlorosis: 0.12, powdery: 0.06, rust: 0.02 },
    symptoms: [
      "Rapidly expanding water-soaked pale green lesions turning dark brown to purplish-black",
      "Delicate whitish-grey fungal downy growth visible on the underside of leaves during wet weather",
      "Large greasy brown lesions girdling stems and leaf petioles causing sudden foliage collapse",
      "Firm, rough dark brown blotches on green and ripening tomato fruits"
    ],
    culturalMeasures: [
      "Immediate emergency rogueing: uproot and deeply bury or burn severely collapsed vines.",
      "Ensure high air circulation by staking indeterminate vines and wider row spacing (75 cm).",
      "Avoid handling or weeding wet vines in the morning when oospores easily spread via water droplets."
    ],
    biologicalControl: [
      "Prophylactic spray of Bacillus subtilis (1% WP) @ 4g/L water on both leaf surfaces.",
      "Spray Cow Urine (10% diluted) + Asafoetida (Hing @ 1g/L) for natural antifungal barrier."
    ],
    chemicalControl: [
      {
        chemical: "Metalaxyl 8% + Mancozeb 64% WP (Ridomil Gold)",
        dosage: "2.5 g / Liter of water",
        timing: "Immediate systemic foliar application on epidemic outbreak; repeat after 10 days if cool & wet."
      },
      {
        chemical: "Cymoxanil 8% + Mancozeb 64% WP (Curzate)",
        dosage: "2.0 g / Liter of water",
        timing: "Curative kickback action within 48 hours of infection."
      },
      {
        chemical: "Dimethomorph 50% WP (Acrobat)",
        dosage: "1.0 - 1.5 g / Liter of water",
        timing: "Translaminar oomycete specialist spray; alternate with Mancozeb to prevent fungicide resistance."
      }
    ],
    preventiveCare: [
      "Grow tolerant hybrid varieties with Ph-2 and Ph-3 resistance genes (e.g. Arka Abhed).",
      "Monitor weather alerts: temperature 12-22°C combined with relative humidity >85% triggers rapid sporulation."
    ],
    kvkHelpline: "Emergency Late Blight ICAR Hotline: 1800-180-1551."
  },
  {
    id: "tomato-yellow-leaf-curl",
    crop: "Tomato (टमाटर / टोमॅटो)",
    cropKey: "tomato",
    diseaseName: "Tomato Yellow Leaf Curl Virus (TYLCV)",
    pathogenType: "Viral Pathogen (Geminivirus)",
    targetBiomarkers: { green: 0.50, necrotic: 0.08, chlorosis: 0.38, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Severe upward curling and cupping of leaflets",
      "Marked interveinal chlorosis and yellowing of leaf margins",
      "Severe stunting and bushy upright growth of plants",
      "Flower dropping and drastic reduction in fruit set"
    ],
    culturalMeasures: [
      "Install bright yellow sticky traps (15-20 traps/acre) at canopy height to monitor and mass-trap Whitefly vectors.",
      "Remove and destroy virus-infected plants immediately to prevent whitefly transmission to healthy rows.",
      "Erect 40-mesh nylon insect-proof net barrier around seedling nurseries."
    ],
    biologicalControl: [
      "Foliar spray of Beauveria bassiana or Verticillium lecanii @ 5g/L water to parasitize whiteflies naturally.",
      "Apply 2% Neem oil (Azadirachtin 3000 ppm) with 1ml liquid soap at 7-day intervals to repel vectors."
    ],
    chemicalControl: [
      {
        chemical: "Diafenthiuron 50% WP (Pegasus)",
        dosage: "1.2 g / Liter of water",
        timing: "Vapor-action whitefly adult and nymph knockdown spray."
      },
      {
        chemical: "Spiromesifen 22.9% SC (Oberon)",
        dosage: "1.0 ml / Liter of water",
        timing: "Lipid synthesis inhibitor targeting whitefly eggs and nymphs."
      },
      {
        chemical: "Thiamethoxam 25% WG",
        dosage: "0.5 g / Liter of water",
        timing: "Systemic neonicotinoid spray for vector management."
      }
    ],
    preventiveCare: [
      "Use resistant F1 hybrids (e.g. US-618, Abhinav, Saaho).",
      "Maintain border cropping with 3 rows of Maize or Sorghum as a live insect barrier."
    ],
    kvkHelpline: "Contact State Agricultural Extension Directorate."
  },
  {
    id: "tomato-healthy",
    crop: "Tomato (टमाटर / टोमॅटो)",
    cropKey: "tomato",
    diseaseName: "Healthy Leaf (No Pathogen Detected)",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.90, necrotic: 0.02, chlorosis: 0.05, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Vibrant uniform deep green leaf lamina with robust chlorophyll saturation",
      "Intact serrated leaf margins with no necrotic or water-soaked lesions",
      "Normal turgidity and active photosynthetic leaf angle",
      "Clean leaf veins and absence of fungal mycelia or bacterial exudates"
    ],
    culturalMeasures: [
      "Maintain regular scheduled drip pulse irrigation based on soil moisture tension (30-40 kPa).",
      "Continue standard weed-free sanitization around root zones."
    ],
    biologicalControl: [
      "Maintain monthly prophylactic bio-inoculation with Trichoderma viride to fortify natural systemic acquired resistance (SAR)."
    ],
    chemicalControl: [
      {
        chemical: "None Required (Crop is Disease-Free)",
        dosage: "0 g / L",
        timing: "Do not apply chemical pesticides on healthy crops. Scout field twice weekly."
      }
    ],
    preventiveCare: [
      "Maintain balanced N:P:K (120:60:60 kg/ha) with adequate potassium to reinforce epidermal cell walls.",
      "Re-screen foliar canopy if continuous rainy weather or heavy dew occurs."
    ],
    kvkHelpline: "Kisan Suvidha Portal: www.kisansuvidha.gov.in."
  },
  {
    id: "tomato-bacterial-spot",
    crop: "Tomato (टमाटर / टोमॅटो)",
    cropKey: "tomato",
    diseaseName: "Bacterial Spot (Xanthomonas campestris pv. vesicatoria)",
    pathogenType: "Bacterial Pathogen",
    targetBiomarkers: { green: 0.54, necrotic: 0.28, chlorosis: 0.16, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Small circular to angular dark brown water-soaked lesions (2-3 mm) on foliage",
      "Distinct chlorotic yellow halo surrounding each necrotic spot",
      "Leaves turn yellow, dry out, and drop prematurely leaving sunburned fruit",
      "Raised black scab-like pustules with white halos on green tomato fruits"
    ],
    culturalMeasures: [
      "Cease overhead sprinkler irrigation; switch strictly to drip irrigation at root zone.",
      "Avoid working in tomato fields when leaves are wet from dew or rain.",
      "Destroy and bury all infected plant debris after harvest."
    ],
    biologicalControl: [
      "Foliar spray with Pseudomonas fluorescens @ 5g/L water.",
      "Seed treatment with Trichoderma viride @ 10g/kg seed."
    ],
    chemicalControl: [
      {
        chemical: "Copper Oxychloride 50% WP (Blitox 50)",
        dosage: "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        timing: "Protective surface bactericide spray; repeat at 10-day intervals in wet periods."
      },
      {
        chemical: "Streptocycline",
        dosage: "1.5 - 2.0 g / 15L knapsack pump (0.1 g/L)",
        timing: "Tank-mixed with Copper Oxychloride for systemic bacterial knockdown."
      }
    ],
    preventiveCare: [
      "Hot water seed treatment (50°C for 25 min) before nursery sowing.",
      "Rotate with non-solanaceous crops (maize, pulses, or cereals) for 2 seasons."
    ],
    kvkHelpline: "ICAR Indian Institute of Vegetable Research (IIVR) Varanasi."
  },
  {
    id: "tomato-septoria",
    crop: "Tomato (टमाटर / टोमॅटो)",
    cropKey: "tomato",
    diseaseName: "Septoria Leaf Spot (Septoria lycopersici)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.52, necrotic: 0.30, chlorosis: 0.16, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Numerous small circular spots (1.5 - 3 mm) with dark brown margins and sunken ash-gray centers",
      "Tiny black speckles (pycnidia fruiting bodies) visible inside the center of mature spots",
      "Starts on oldest bottom leaves and rapidly ascends up the plant causing severe defoliation",
      "Fruits remain uninfected, but defoliation leads to severe fruit sunscald"
    ],
    culturalMeasures: [
      "Remove and destroy bottom diseased leaves early in the season.",
      "Stake tomato vines and apply straw mulch to eliminate soil splash.",
      "Maintain adequate plant spacing (60 x 45 cm) for canopy airflow."
    ],
    biologicalControl: [
      "Foliar spray of Trichoderma harzianum @ 50g per 15L pump (3-4 g/L).",
      "Neem seed kernel extract (NSKE 5%) spray."
    ],
    chemicalControl: [
      {
        chemical: "Chlorothalonil 75% WP (Kavach)",
        dosage: "30 g / 15L knapsack pump (2.0 g/L)",
        timing: "Broad-spectrum contact protectant spray at first sign of lower leaf spotting."
      },
      {
        chemical: "Mancozeb 75% WP (Dithane M-45)",
        dosage: "35 g / 15L knapsack pump (2.5 g/L)",
        timing: "Protective foliar application; repeat every 10-12 days during rainy weather."
      },
      {
        chemical: "Difenoconazole 25% EC (Score)",
        dosage: "10 - 12 ml / 15L knapsack pump (0.8 ml/L)",
        timing: "Systemic curative triazole spray for aggressive mid-canopy infections."
      }
    ],
    preventiveCare: [
      "Seed treatment with Thiram 75% WP @ 2.5 g/kg seed.",
      "Deep summer ploughing to bury overwintering pycnidia in crop residue."
    ],
    kvkHelpline: "State Agricultural University Plant Health Clinic."
  },

  // 2. POTATO DISEASES
  {
    id: "potato-late-blight",
    crop: "Potato (आलू / बटाटा)",
    cropKey: "potato",
    diseaseName: "Potato Late Blight (Phytophthora infestans)",
    pathogenType: "Oomycete Pathogen",
    targetBiomarkers: { green: 0.46, necrotic: 0.38, chlorosis: 0.10, powdery: 0.04, rust: 0.02 },
    symptoms: [
      "Water-soaked blackish-brown spots on leaf tips and margins spreading rapidly inwards",
      "Under wet morning conditions, a ring of white cottony fungal mold appears on the lower leaf surface",
      "Dark brown necrotic girdling on petioles causing stems to collapse in 3-5 days",
      "Infected tubers exhibit dry reddish-brown granular rot beneath the skin"
    ],
    culturalMeasures: [
      "Destroy all volunteer potato plants and cull piles from previous season which act as primary inoculum.",
      "High earthen ridging (earthing-up) to provide a 10cm soil barrier preventing spores from washing into developing tubers.",
      "Kill potato haulms (stems) with Paraquat or mechanical slashing 12 days before harvest to prevent tuber infection."
    ],
    biologicalControl: [
      "Prophylactic foliar spray of Trichoderma harzianum @ 5g/L water at 10-day intervals before canopy closure.",
      "Foliar bio-protection with Pseudomonas fluorescens @ 10g/L."
    ],
    chemicalControl: [
      {
        chemical: "Metalaxyl-M 4% + Mancozeb 64% WP (Ridomil Gold)",
        dosage: "2.5 g / Liter of water",
        timing: "Prophylactic or early therapeutic spray upon cloudy/humid weather forecasting."
      },
      {
        chemical: "Cymoxanil 8% + Mancozeb 64% WP",
        dosage: "2.0 g / Liter of water",
        timing: "Curative spray within 48 hours of infection event."
      },
      {
        chemical: "Mandipropamid 23.4% SC (Revus)",
        dosage: "0.8 ml / Liter of water",
        timing: "High rainfastness preventative translaminar spray."
      }
    ],
    preventiveCare: [
      "Use certified disease-free seed tubers from CPRI (Central Potato Research Institute).",
      "Plant late blight-resistant cultivars like Kufri Girdhari, Kufri Himalini, Kufri Mohan."
    ],
    kvkHelpline: "CPRI Shimla Disease Alert Cell: 1800-180-1551."
  },
  {
    id: "potato-early-blight",
    crop: "Potato (आलू / बटाटा)",
    cropKey: "potato",
    diseaseName: "Potato Early Blight (Alternaria solani)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.54, necrotic: 0.26, chlorosis: 0.16, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Dark brown, dry, papery circular spots with concentric target-board ridges",
      "Leaves become chlorotic, curl upwards and wither on the plant",
      "Attacks older mature foliage during warm sunny days following dew/rain"
    ],
    culturalMeasures: [
      "Avoid overhead sprinkler irrigation late in the evening to prevent prolonged leaf wetness.",
      "Ensure balanced crop nutrition; nitrogen-stressed potato crops are significantly more susceptible."
    ],
    biologicalControl: [
      "Foliar spray with Bacillus amyloliquefaciens @ 3ml/L water.",
      "Neem oil spray (10,000 ppm) @ 2.5 ml/L water."
    ],
    chemicalControl: [
      {
        chemical: "Chlorothalonil 75% WP (Kavach)",
        dosage: "2.0 g / Liter of water",
        timing: "Broad-spectrum multi-site protective contact spray."
      },
      {
        chemical: "Difenoconazole 25% EC (Score)",
        dosage: "0.5 ml / Liter of water",
        timing: "Systemic triazole curative spray."
      }
    ],
    preventiveCare: [
      "Adopt 2 to 3-year crop rotation with non-solanaceous crops.",
      "Treat seed tubers with Carboxin + Thiram (Vitavax Power) @ 2.5g/kg tuber before planting."
    ],
    kvkHelpline: "Local Krishi Vigyan Kendra extension."
  },
  {
    id: "potato-healthy",
    crop: "Potato (आलू / बटाटा)",
    cropKey: "potato",
    diseaseName: "Healthy Potato Canopy",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.91, necrotic: 0.02, chlorosis: 0.05, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Broad, vibrant emerald green compound foliage",
      "No spotting, margin necrosis, or powdery discoloration",
      "Sturdy erect stems with healthy branching"
    ],
    culturalMeasures: [
      "Continue regular irrigation cycles to maintain uniform soil moisture for stolon tuberization."
    ],
    biologicalControl: [
      "Apply Vermicompost @ 2 tonnes/acre as top dressing to foster active soil microbiomes."
    ],
    chemicalControl: [
      {
        chemical: "No Pesticide Required",
        dosage: "0 g/L",
        timing: "Maintain weekly field scouting."
      }
    ],
    preventiveCare: [
      "Monitor temperature and relative humidity continuously via AgroSense IoT station."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  },

  // 3. RICE / PADDY DISEASES
  {
    id: "rice-blast",
    crop: "Paddy / Rice (धान / भात)",
    cropKey: "rice",
    diseaseName: "Rice Blast (Magnaporthe oryzae)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.50, necrotic: 0.32, chlorosis: 0.14, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Characteristic spindle-shaped or diamond-shaped lesions with pointed ends on leaf blades",
      "Lesions feature a greyish-white ash-colored center surrounded by a dark brown necrotic border",
      "Lesions coalesce causing complete leaf blighting and burning appearance ('Blast')",
      "Neck blast: dark brown rotting of panicle neck node resulting in blank chaffy grains"
    ],
    culturalMeasures: [
      "Avoid excessive split doses of Nitrogen fertilizer; apply nitrogen in 3-4 splits based on Leaf Color Chart (LCC).",
      "Maintain a shallow continuous water layer (2-5 cm) in the paddy field to reduce spore germination.",
      "Burn or compost infected straw stubbles immediately post-harvest."
    ],
    biologicalControl: [
      "Seed treatment with Pseudomonas fluorescens @ 10g/kg seed + seedling dip in 2.5% suspension.",
      "Foliar spray of Trichoderma harzianum @ 5g/L water at tillering and panicle emergence."
    ],
    chemicalControl: [
      {
        chemical: "Tricyclazole 75% WP (Beam)",
        dosage: "0.6 g / Liter of water (120 g / acre)",
        timing: "Gold-standard blast specialist: spray at initial leaf spots and repeat at 5% panicle emergence."
      },
      {
        chemical: "Isoprothiolane 40% EC (Fuji-One)",
        dosage: "1.5 ml / Liter of water",
        timing: "Curative systemic blast fungicide."
      },
      {
        chemical: "Kasugamycin 3% SL (Kasu-B)",
        dosage: "2.0 ml / Liter of water",
        timing: "Bio-derived systemic antibiotic fungicide."
      }
    ],
    preventiveCare: [
      "Grow blast-resistant cultivars (e.g. Swarna Sub-1, IR-64, R-Bhog, Pusa Basmati 1637).",
      "Apply Potassium fertilizer (MOP @ 20kg/acre) in two splits to increase silicon deposition in leaf cuticle."
    ],
    kvkHelpline: "ICAR National Rice Research Institute (NRRI) Cuttack: 1800-180-1551."
  },
  {
    id: "rice-bacterial-blight",
    crop: "Paddy / Rice (धान / भात)",
    cropKey: "rice",
    diseaseName: "Bacterial Leaf Blight (Xanthomonas oryzae pv. oryzae)",
    pathogenType: "Bacterial Pathogen",
    targetBiomarkers: { green: 0.48, necrotic: 0.28, chlorosis: 0.22, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Water-soaked translucent stripes starting from leaf tips and advancing along wavy margins",
      "Lesions enlarge, turn straw-yellow to dirty white with wavy irregular margins",
      "Milky bacterial ooze beads (cloudy droplets) emerge on early morning leaf surfaces and dry to crusty beads",
      "'Kresek' phase in young seedlings: wilting, rolling and sudden drying of tillers"
    ],
    culturalMeasures: [
      "Drain the field for 3-4 days to reduce high relative humidity and bacterial multiplication.",
      "Strictly stop top-dressing Urea until new healthy leaves emerge; excessive nitrogen aggravates bacterial spread.",
      "Avoid clip-pruning of seedling tips during transplanting as wounds are primary entry points for Xanthomonas."
    ],
    biologicalControl: [
      "Foliar spray of fresh cow dung extract (20% filtrate) which contains natural antagonistic bacteria.",
      "Spray Pseudomonas fluorescens (Talco formulation) @ 5g/L water."
    ],
    chemicalControl: [
      {
        chemical: "Copper Hydroxide 53.8% DF (Kocide)",
        dosage: "2.0 g / Liter of water",
        timing: "Protective bactericidal spray on initial symptom development."
      },
      {
        chemical: "Streptocycline (90:10 Streptomycin + Tetracycline)",
        dosage: "0.6 g per 10 Liters of water (60 ppm)",
        timing: "Tank mix with Copper Oxychloride (3g/L) for synergistic bacterial eradication."
      }
    ],
    preventiveCare: [
      "Plant BB-resistant varieties with Xa genes (e.g. Improved Samba Mahsuri, Pusa Basmati 1718, CR Dhan 800).",
      "Apply bleaching powder @ 2 kg/acre mixed with sand in standing irrigation water."
    ],
    kvkHelpline: "State Directorate of Rice Development."
  },
  {
    id: "rice-healthy",
    crop: "Paddy / Rice (धान / भात)",
    cropKey: "rice",
    diseaseName: "Healthy Paddy Canopy",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.92, necrotic: 0.01, chlorosis: 0.05, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Uniform vibrant green linear leaves matching LCC chart index 4",
      "No spindle spots, bacterial marginal stripes, or sheath rot",
      "Strong tillering with healthy submerged root crown"
    ],
    culturalMeasures: [
      "Maintain intermittent wetting and drying (AWD) water management to optimize root oxygenation."
    ],
    biologicalControl: [
      "Incorporate Azolla biofertilizer (500 kg/ha) into flooded paddy to supply organic nitrogen."
    ],
    chemicalControl: [
      {
        chemical: "No Pesticide Spray Required",
        dosage: "0",
        timing: "Preserve beneficial spider, dragonfly and mirid bug predators."
      }
    ],
    preventiveCare: [
      "Maintain regular pest and pathogen trap monitoring."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  },

  // 4. WHEAT DISEASES
  {
    id: "wheat-leaf-rust",
    crop: "Wheat (गेहूं / गहू)",
    cropKey: "wheat",
    diseaseName: "Wheat Leaf Rust (Puccinia triticina)",
    pathogenType: "Fungal Rust Pathogen",
    targetBiomarkers: { green: 0.48, necrotic: 0.16, chlorosis: 0.16, powdery: 0.02, rust: 0.18 },
    symptoms: [
      "Small, round to oval bright orange-brown pustules (uredinia) scattered randomly across upper leaf blade",
      "Pustules erupt through epidermis releasing powdery cinnamon-brown urediniospores on touch",
      "Pale chlorotic rings surrounding pustules as chlorophyll degrades",
      "Severe infections lead to premature drying of leaves during the critical grain filling stage"
    ],
    culturalMeasures: [
      "Sow wheat timely in November; late sown wheat faces higher temperature and severe rust epidemics.",
      "Avoid excess nitrogenous top-dressing which delays maturity and makes succulent tissue vulnerable.",
      "Eradicate wild grasses and volunteer wheat near bunds that act as alternate green bridge hosts."
    ],
    biologicalControl: [
      "Foliar spray with Verticillium lecanii @ 5g/L water which parasitizes rust urediniospores.",
      "Foliar application of sour buttermilk (10-day fermented @ 50ml/L) to alter leaf phyllosphere pH."
    ],
    chemicalControl: [
      {
        chemical: "Propiconazole 25% EC (Tilt)",
        dosage: "1.0 ml / Liter of water (200 ml / acre)",
        timing: "Spray at initial appearance of 1-2 pustules per plant; provides 20-day curative and protective protection."
      },
      {
        chemical: "Tebuconazole 25.9% EC (Folicur)",
        dosage: "1.25 ml / Liter of water",
        timing: "Potent triazole fungicide targeting active rust haustoria."
      },
      {
        chemical: "Mancozeb 75% WP",
        dosage: "2.5 g / Liter of water",
        timing: "Preventative contact barrier before rust winds arrive."
      }
    ],
    preventiveCare: [
      "Cultivate rust-resistant high-yielding varieties (e.g. DBW-187, DBW-303, PBW-550, HD-3226).",
      "Rotate wheat varieties across village blocks to avoid breaking single-gene resistance."
    ],
    kvkHelpline: "ICAR Indian Institute of Wheat and Barley Research (IIWBR) Karnal: 1800-180-1551."
  },
  {
    id: "wheat-yellow-rust",
    crop: "Wheat (गेहूं / गहू)",
    cropKey: "wheat",
    diseaseName: "Stripe / Yellow Rust (Puccinia striiformis)",
    pathogenType: "Fungal Rust Pathogen",
    targetBiomarkers: { green: 0.46, necrotic: 0.14, chlorosis: 0.20, powdery: 0.02, rust: 0.18 },
    symptoms: [
      "Vivid yellow to orange pustules arranged in narrow, continuous parallel stripes along leaf veins",
      "Leaves look like yellow ribbon stripes; spores rub off as bright yellow powder on fingers",
      "Prevalent in cool, high-moisture foothill plains and northern wheat zones"
    ],
    culturalMeasures: [
      "Early scouting of foothill and shade areas where dew persists longest.",
      "Avoid flood irrigation during cool humid spells."
    ],
    biologicalControl: [
      "Neem seed kernel extract (NSKE 5%) prophylactic spray."
    ],
    chemicalControl: [
      {
        chemical: "Propiconazole 25% EC",
        dosage: "1.0 ml / Liter of water",
        timing: "Emergency spray across entire field immediately when first yellow stripe is spotted."
      },
      {
        chemical: "Tebuconazole 50% + Trifloxystrobin 25% WG (Nativo)",
        dosage: "0.6 g / Liter of water",
        timing: "Premium curative & antisporulant combination."
      }
    ],
    preventiveCare: [
      "Plant stripe-rust resistant cultivars (DBW-222, HD-3086).",
      "Follow advisory alerts from IIWBR Karnal."
    ],
    kvkHelpline: "IIWBR Karnal Toll-Free: 1800-180-1551."
  },
  {
    id: "wheat-powdery-mildew",
    crop: "Wheat (गेहूं / गहू)",
    cropKey: "wheat",
    diseaseName: "Wheat Powdery Mildew (Blumeria graminis f. sp. tritici)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.52, necrotic: 0.10, chlorosis: 0.14, powdery: 0.22, rust: 0.02 },
    symptoms: [
      "White to grayish fluffy powdery fungal patches on upper leaf blades, sheaths, and glumes",
      "Powdery patches enlarge and merge, turning dull grey with tiny dark cleistothecia specks",
      "Infected leaves turn chlorotic, dry out and senesce prematurely"
    ],
    culturalMeasures: [
      "Avoid overly dense planting seed rates; optimize canopy aeration.",
      "Balance nitrogen fertilizer with adequate phosphorus and potassium."
    ],
    biologicalControl: [
      "Spray Ampelomyces quisqualis (mycoparasite) @ 5g/L water.",
      "Sulfur dusting @ 10 kg/acre."
    ],
    chemicalControl: [
      {
        chemical: "Wettable Sulfur 80% WDG (Sulfex)",
        dosage: "3.0 g / Liter of water",
        timing: "Cost-effective organic-compatible multi-site contact spray."
      },
      {
        chemical: "Hexaconazole 5% EC (Contaf)",
        dosage: "2.0 ml / Liter of water",
        timing: "Curative systemic triazole spray."
      }
    ],
    preventiveCare: [
      "Sow resistant wheat varieties.",
      "Clear field bunds of dense wild grasses."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  },
  {
    id: "wheat-healthy",
    crop: "Wheat (गेहूं / गहू)",
    cropKey: "wheat",
    diseaseName: "Healthy Wheat Canopy",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.92, necrotic: 0.01, chlorosis: 0.05, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Vibrant uniform deep green leaf blade with optimal chlorophyll content",
      "Clean linear leaf margins with zero rust pustules, yellow striping, or powdery mildew",
      "Active erect photosynthetic leaf angle and robust tillering",
      "Absence of chlorotic streaks or fungal sporulation"
    ],
    culturalMeasures: [
      "Maintain critical irrigation schedule at Crown Root Initiation (CRI at 21 days), Tillering, and Booting stages.",
      "Scout lower canopy regularly for early rust pustule development during cool foggy weather."
    ],
    biologicalControl: [
      "Prophylactic seed treatment with Azotobacter and PSB culture @ 250g/10kg seed.",
      "Foliar spray with Pseudomonas fluorescens @ 5g/L water."
    ],
    chemicalControl: [
      {
        chemical: "None Required (Crop is Disease-Free)",
        dosage: "0 g / L",
        timing: "Do not apply chemical fungicides on healthy crops. Scout field weekly."
      }
    ],
    preventiveCare: [
      "Sow certified rust-resistant wheat varieties (e.g. HD-2967, HD-3086, DBW-187, PBW-502).",
      "Maintain balanced N:P:K (120:60:40 kg/ha) with adequate potash to toughen epidermal walls."
    ],
    kvkHelpline: "ICAR-IIWBR Karnal Toll-Free: 1800-180-1551."
  },

  // 5. COTTON DISEASES
  {
    id: "cotton-bacterial-blight",
    crop: "Cotton (कपास / कापूस)",
    cropKey: "cotton",
    diseaseName: "Bacterial Blight / Angular Leaf Spot (Xanthomonas citri pv. malvacearum)",
    pathogenType: "Bacterial Pathogen",
    targetBiomarkers: { green: 0.52, necrotic: 0.30, chlorosis: 0.14, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Angular water-soaked polygonal spots sharply bounded by small leaf veinlets",
      "Spots turn reddish-brown to dark black, visible on both upper and lower leaf surfaces",
      "'Black arm' symptom: elongated dark girdling lesions on branches causing twig snap",
      "Water-soaked oily circular lesions on cotton bolls resulting in premature boll opening and lint staining"
    ],
    culturalMeasures: [
      "Acid delinting of fuzzy cottonseed with commercial concentrated Sulfuric acid (100ml/kg seed) before sowing.",
      "Collect and incinerate crop residue, dry stalks and shed infected bolls post-harvest.",
      "Avoid overhead sprinkler irrigation which splashes bacteria from plant to plant."
    ],
    biologicalControl: [
      "Seed bacterization with Pseudomonas fluorescens @ 10g/kg seed.",
      "Spray 5% Neem Seed Kernel Extract (NSKE) at squaring stage."
    ],
    chemicalControl: [
      {
        chemical: "Copper Oxychloride 50% WP (Blitox)",
        dosage: "3.0 g / Liter of water",
        timing: "Foliar spray at first appearance of angular spots."
      },
      {
        chemical: "Streptocycline (Streptomycin sulphate 90% + Tetracycline 10%)",
        dosage: "0.6 g / 10 Liters of water (60 ppm)",
        timing: "Tank-mixed with Copper Oxychloride (3g/L) for potent bactericidal eradication; repeat in 12 days."
      }
    ],
    preventiveCare: [
      "Grow resistant Bt-cotton hybrids (e.g. Bunny, Mallika, RCH-2).",
      "Treat seeds with Carboxin + Thiram @ 2g/kg seed."
    ],
    kvkHelpline: "ICAR Central Institute for Cotton Research (CICR) Nagpur: 1800-180-1551."
  },
  {
    id: "cotton-grey-mildew",
    crop: "Cotton (कपास / कापूस)",
    cropKey: "cotton",
    diseaseName: "Grey Mildew / Dahiya Disease (Ramularia areola)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.55, necrotic: 0.12, chlorosis: 0.13, powdery: 0.18, rust: 0.02 },
    symptoms: [
      "Pale translucent angular spots on upper leaf surface delimited by veinlets",
      "Frosted whitish-grey powdery mildew-like fungal coating on the lower leaf surface ('Dahiya')",
      "Heavy premature defoliation and boll shedding"
    ],
    culturalMeasures: [
      "Prune dense lower branches to improve ground ventilation.",
      "Clean shed leaves from between rows."
    ],
    biologicalControl: [
      "Foliar spray of Trichoderma viride @ 5g/L water."
    ],
    chemicalControl: [
      {
        chemical: "Wettable Sulfur 80% WP",
        dosage: "3.0 g / Liter of water",
        timing: "First spray upon noticing grey frost under lower leaves."
      },
      {
        chemical: "Kresoxim-methyl 44.3% SC",
        dosage: "1.0 ml / Liter of water",
        timing: "Strobilurin class antisporulant spray."
      }
    ],
    preventiveCare: [
      "Plant at wider spacing (90 x 60 cm) in heavy black soils.",
      "Balanced fertilizer application."
    ],
    kvkHelpline: "CICR Nagpur Advisory Cell."
  },
  {
    id: "cotton-healthy",
    crop: "Cotton (कपास / कापूस)",
    cropKey: "cotton",
    diseaseName: "Healthy Cotton Foliage",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.90, necrotic: 0.02, chlorosis: 0.05, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Broad, 3- to 5-lobed deep green healthy cotton leaves",
      "No angular water spots, grey frost or mosaic curling",
      "Active square formation and healthy white flower blooms"
    ],
    culturalMeasures: [
      "Maintain pheromone traps for Pink Bollworm monitoring."
    ],
    biologicalControl: [
      "Conserve green lacewing (Chrysoperla) and ladybird beetle predators."
    ],
    chemicalControl: [
      {
        chemical: "No Pesticide Required",
        dosage: "0",
        timing: "Monitor weekly for sucking pests."
      }
    ],
    preventiveCare: [
      "Avoid waterlogging in heavy vertisols by making furrow drainage."
    ],
    kvkHelpline: "Kisan Call Center: 1800-180-1551."
  },

  // 6. MAIZE / CORN DISEASES
  {
    id: "maize-leaf-blight",
    crop: "Maize / Corn (मक्का / मका)",
    cropKey: "maize",
    diseaseName: "Northern Corn Leaf Blight (Exserohilum turcicum)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.50, necrotic: 0.32, chlorosis: 0.14, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Large elongated elliptical or cigar-shaped grayish-green to tan lesions (2.5 to 15 cm long)",
      "Lesions develop dark olive-brown spores in damp conditions",
      "Extensive leaf blighting starting from lower leaves moving upwards to the ear leaf"
    ],
    culturalMeasures: [
      "Deep plowing of field to bury maize crop residues and stubbles where the fungus overwinters.",
      "Rotate with non-host crops like soybean, groundnut or pulses."
    ],
    biologicalControl: [
      "Trichoderma viride seed treatment @ 10g/kg seed + foliar spray @ 5g/L."
    ],
    chemicalControl: [
      {
        chemical: "Mancozeb 75% WP",
        dosage: "2.5 g / Liter of water",
        timing: "First spray on lower leaf spotting; repeat after 12 days."
      },
      {
        chemical: "Azoxystrobin 18.2% + Difenoconazole 11.4% SC",
        dosage: "1.0 ml / Liter of water",
        timing: "High-efficacy systemic spray at knee-high to tasseling stage."
      }
    ],
    preventiveCare: [
      "Plant resistant corn hybrids (e.g. Pioneer 3396, DKC 9108, Bio-9681).",
      "Avoid excessive plant densities that limit sunlight."
    ],
    kvkHelpline: "ICAR Indian Institute of Maize Research (IIMR) Ludhiana."
  },
  {
    id: "maize-common-rust",
    crop: "Maize / Corn (मक्का / मका)",
    cropKey: "maize",
    diseaseName: "Common Rust (Puccinia sorghi)",
    pathogenType: "Fungal Rust Pathogen",
    targetBiomarkers: { green: 0.50, necrotic: 0.10, chlorosis: 0.16, powdery: 0.02, rust: 0.22 },
    symptoms: [
      "Small circular to elongated golden-brown to cinnamon-brown powdery pustules (uredinia) scattered on both leaf surfaces",
      "Pustules rupture the epidermis, releasing powdery reddish-brown urediniospores onto fingers when touched",
      "Pustules turn dark brownish-black late in the season as overwintering teliospores form",
      "Severely infected corn leaves turn yellow-chlorotic, wither prematurely and reduce cob grain filling"
    ],
    culturalMeasures: [
      "Plant early in the season to escape peak cool humid weather favorable to rust sporulation.",
      "Incorporate balanced fertilization; avoid excess nitrogen and ensure sufficient potassium."
    ],
    biologicalControl: [
      "Foliar spray with Trichoderma harzianum @ 50g per 15L pump (3-4 g/L).",
      "Neem seed kernel extract (NSKE 5%) spray."
    ],
    chemicalControl: [
      {
        chemical: "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        dosage: "15 ml / 15L knapsack pump (1.0 ml/L)",
        timing: "Curative systemic dual-action spray when rust pustules appear on upper leaves before tasseling."
      },
      {
        chemical: "Propiconazole 25% EC (Tilt)",
        dosage: "15 ml / 15L knapsack pump (1.0 ml/L)",
        timing: "Systemic triazole spray providing rapid curative knockdown of rust mycelia."
      },
      {
        chemical: "Mancozeb 75% WP",
        dosage: "35 g / 15L knapsack pump (2.5 g/L)",
        timing: "Protective contact spray during cool, humid weather."
      }
    ],
    preventiveCare: [
      "Plant rust-resistant hybrids (e.g. PAC 751, NK 6240, DKC 9144).",
      "Scout lower and mid-canopy leaves weekly starting at knee-high stage."
    ],
    kvkHelpline: "IIMR Ludhiana & Regional Maize Research Stations."
  },
  {
    id: "maize-gray-leaf-spot",
    crop: "Maize / Corn (मक्का / मका)",
    cropKey: "maize",
    diseaseName: "Gray Leaf Spot (Cercospora zeae-maydis)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.52, necrotic: 0.32, chlorosis: 0.14, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Distinct rectangular, blocky tan-to-gray lesions strictly bounded by parallel leaf veins",
      "Lesions measure 1 to 6 cm long with sharp parallel edges creating a characteristic 'ribbon' appearance",
      "Lesions turn grayish when fungi produce conidiospores in damp humid morning weather",
      "Extensive leaf blighting starting from lower leaves moving upwards into the ear leaf"
    ],
    culturalMeasures: [
      "Crop rotation with non-host crops (soybean, groundnut, cotton) for at least 1-2 years.",
      "Deep tillage to bury corn residue and accelerate decomposition of infected stubble."
    ],
    biologicalControl: [
      "Foliar spray with Trichoderma viride @ 5g/L water."
    ],
    chemicalControl: [
      {
        chemical: "Pyraclostrobin 20% WG (Headline)",
        dosage: "15 g / 15L knapsack pump (1.0 g/L)",
        timing: "Strobilurin spray applied at VT (tasseling) stage."
      },
      {
        chemical: "Azoxystrobin 18.2% + Difenoconazole 11.4% SC",
        dosage: "15 ml / 15L knapsack pump (1.0 ml/L)",
        timing: "Curative systemic spray."
      }
    ],
    preventiveCare: [
      "Select hybrids with high Gray Leaf Spot (GLS) tolerance ratings.",
      "Avoid continuous corn-on-corn monoculture under zero-tillage."
    ],
    kvkHelpline: "ICAR Indian Institute of Maize Research."
  },
  {
    id: "maize-healthy",
    crop: "Maize / Corn (मक्का / मका)",
    cropKey: "maize",
    diseaseName: "Healthy Maize Canopy (रोगमुक्त मका पान)",
    pathogenType: "Healthy Foliage (Zero Pathogen)",
    targetBiomarkers: { green: 0.90, necrotic: 0.03, chlorosis: 0.05, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Broad, elongated strap-shaped emerald-green leaf blade with prominent white midrib",
      "Intact parallel veins and smooth undulating margin without lesions or pustules",
      "Strong turgidity, vigorous stalk attachment, active photosynthesis and tassel development"
    ],
    culturalMeasures: [
      "Maintain adequate soil moisture during flowering, silking and grain-filling stages.",
      "Maintain 60 x 20 cm spacing for optimum light interception."
    ],
    biologicalControl: [
      "Maintain prophylactic bio-fertilizer application (Azospirillum & PSB) to sustain root vigor."
    ],
    chemicalControl: [],
    preventiveCare: [
      "Do not spray chemical fungicides on healthy foliage.",
      "Apply recommended N:P:K (120:60:40 kg/ha) with split nitrogen applications."
    ],
    kvkHelpline: "National Kisan Call Center: 1800-180-1551 (Toll-Free, 6 AM - 10 PM)."
  },

  // 8. CHILLI / PEPPER (CAPSICUM) DISEASES & PHYSIOLOGY
  {
    id: "chilli-leaf-curl",
    crop: "Chilli (हरी मिर्च / मिरची)",
    cropKey: "chilli",
    diseaseName: "Chilli Leaf Curl Virus / Murda Rog (ChiLCV / Begomovirus)",
    pathogenType: "Viral Pathogen (Begomovirus)",
    targetBiomarkers: { green: 0.52, necrotic: 0.05, chlorosis: 0.40, powdery: 0.02, rust: 0.01 },
    symptoms: [
      "Severe upward curling, cupping, and crinkling of leaf margins towards the midrib",
      "Thickening and swelling of veins with prominent chlorotic yellow mottling and mosaic",
      "Severe stunting with shortened internodes, bushy dwarf habit ('Churda-Murda / Bokhadya')",
      "Flower bud drop and small, deformed, thick-walled wrinkled chilli pods"
    ],
    culturalMeasures: [
      "Erect 3-4 dense perimeter barrier rows of tall fodder Maize, Sorghum, or Bajra around chilli fields to block wind-borne insect vectors.",
      "Install 15-20 bright yellow and blue sticky cards per acre to trap vector Whiteflies and Thrips.",
      "Immediately rogue (uproot) and deeply bury or burn virus-infected plants during early vegetative stage.",
      "Refrain from excessive chemical urea application; excess nitrogen produces tender succulent flushes that attract vector swarms."
    ],
    biologicalControl: [
      "Foliar spray cold-pressed Neem Oil (Azadirachtin 10,000 ppm) @ 35-40 ml per 15L knapsack pump (or 3 ml/L).",
      "Apply Lecanicillium lecanii (Verticillium lecanii) bio-pesticide @ 50g per 15L pump (5g/L) for biological parasitization of whitefly nymphs.",
      "Spray 10-day fermented sour buttermilk (desi cow curd) @ 40 ml/L to enhance systemic foliar immunity."
    ],
    chemicalControl: [
      {
        chemical: "Acetamiprid 20% SP (Pride / Manik)",
        dosage: "3.5 - 4.0 g / 15L knapsack pump (0.25 g/L)",
        timing: "Systemic neonicotinoid foliar spray against whitefly vector adults and nymphs."
      },
      {
        chemical: "Diafenthiuron 50% WP (Pegasus)",
        dosage: "18 - 20 g / 15L knapsack pump (1.2 g/L)",
        timing: "Targeted translaminar spray controlling both chilli thrips and whiteflies simultaneously."
      },
      {
        chemical: "Imidacloprid 17.8% SL (Confidor)",
        dosage: "5.0 - 6.0 ml / 15L knapsack pump (0.35 ml/L)",
        timing: "Early vegetative preventative spray targeting sap-sucking vector colonies."
      }
    ],
    preventiveCare: [
      "Nursery seedling net house protection with 40-mesh insect-proof nylon nets.",
      "Seed treatment with Imidacloprid 70% WS @ 5g/kg seed before nursery sowing.",
      "Plant tolerant chilli hybrids (e.g. Arka Meghana, Arka Harita, Kashi Anmol, US-7004)."
    ],
    kvkHelpline: "ICAR - Indian Institute of Horticultural Research (IIHR) Bengaluru & State Horticulture Dept."
  },
  {
    id: "chilli-bacterial-spot",
    crop: "Chilli (हरी मिर्च / मिरची)",
    cropKey: "chilli",
    diseaseName: "Bacterial Leaf Spot (Xanthomonas campestris pv. vesicatoria)",
    pathogenType: "Bacterial Pathogen",
    targetBiomarkers: { green: 0.54, necrotic: 0.28, chlorosis: 0.16, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Small dark circular to angular water-soaked lesions (1-3 mm) turning brownish-black on leaves",
      "Conspicuous translucent chlorotic yellow halos surrounding each necrotic spot",
      "Shot-hole effect: centers of dry necrotic spots drop out leaving perforated leaves",
      "Severe premature defoliation leaving exposed sunburned branches, and rough raised blistered spots on fruit"
    ],
    culturalMeasures: [
      "Cease overhead sprinkler or flood splash irrigation; convert to drip irrigation to keep foliage completely dry.",
      "Never enter or harvest chilli fields while foliage is wet from morning dew or rainfall.",
      "Collect, deeply bury or burn all infected fallen leaves and blighted stems.",
      "Practice 2-year crop rotation avoiding tomato, potato, brinjal, and bell peppers."
    ],
    biologicalControl: [
      "Seed and nursery treatment with Pseudomonas fluorescens @ 10g/kg seed.",
      "Foliar spray with Bacillus subtilis or Pseudomonas fluorescens @ 50g per 15L pump (4-5 g/L)."
    ],
    chemicalControl: [
      {
        chemical: "Copper Oxychloride 50% WP (Blitox 50)",
        dosage: "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        timing: "Protective surface bactericide spray; repeat at 10-day intervals in rainy weather."
      },
      {
        chemical: "Streptocycline (Streptomycin 90% + Tetracycline 10%)",
        dosage: "1.5 - 2.0 g / 15L knapsack pump (0.1 g/L)",
        timing: "Tank-mix with Copper Oxychloride for systemic bacterial knockdown."
      },
      {
        chemical: "Kasugamycin 3% SL (Kasu-B)",
        dosage: "30 ml / 15L knapsack pump (2.0 ml/L)",
        timing: "Curative systemic bactericidal antibiotic spray during active foliar blighting."
      }
    ],
    preventiveCare: [
      "Hot water seed treatment at 50°C (122°F) for 25 minutes prior to sowing.",
      "Spray copper bactericide promptly after hail or driving rainstorms to seal leaf micro-wounds."
    ],
    kvkHelpline: "ICAR - Central Coastal Agricultural Research Institute & National Horticultural Board (NHB)."
  },
  {
    id: "chilli-anthracnose",
    crop: "Chilli (हरी मिर्च / मिरची)",
    cropKey: "chilli",
    diseaseName: "Anthracnose / Dieback / Fruit Rot (Colletotrichum capsici)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.48, necrotic: 0.34, chlorosis: 0.14, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Dieback: Tender shoots wither and dry from tip downwards, turning white/straw-colored",
      "Sunken circular or oblong necrotic spots with black concentric rings of fruiting bodies on fruits",
      "Leaves develop circular spots with bleached centers and drop prematurely"
    ],
    culturalMeasures: [
      "Collect and burn infected twigs and rotten fruits; never leave them on the soil.",
      "Use certified disease-free seeds; soak seeds in hot water (52°C for 30 minutes)."
    ],
    biologicalControl: [
      "Seed treatment with Trichoderma viride @ 10g/kg seed + foliar spray @ 5g/L.",
      "Neem oil spray @ 3ml/L water."
    ],
    chemicalControl: [
      {
        chemical: "Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)",
        dosage: "15 ml / 15L knapsack pump (1.0 ml/L)",
        timing: "High-efficacy systemic dual action spray at first appearance of twig dieback or fruit spots."
      },
      {
        chemical: "Copper Oxychloride 50% WP (Blitox)",
        dosage: "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        timing: "Protective spray during vegetative and flowering stage."
      },
      {
        chemical: "Tebuconazole 25.9% EC (Folicur)",
        dosage: "15 ml / 15L knapsack pump (1.0 ml/L)",
        timing: "Curative systemic triazole spray."
      }
    ],
    preventiveCare: [
      "Grow anthracnose-tolerant varieties (e.g. Kashi Anmol, Arka Meghana).",
      "Avoid overhead sprinkler irrigation during flowering and fruit ripening."
    ],
    kvkHelpline: "State Horticulture Department & IIHR Bengaluru."
  },
  {
    id: "chilli-cercospora-leaf-spot",
    crop: "Chilli (हरी मिर्च / मिरची)",
    cropKey: "chilli",
    diseaseName: "Cercospora Frog-Eye Leaf Spot (Cercospora capsici)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.52, necrotic: 0.30, chlorosis: 0.16, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Circular to oval leaf spots with distinct light grey to ashy-white centers",
      "Prominent raised dark reddish-brown margins creating a distinctive 'frog-eye' appearance",
      "Bright chlorotic yellow halo encircling each individual spot",
      "Coalescing spots cause large chlorotic blotches and rapid defoliation of lower and middle canopy"
    ],
    culturalMeasures: [
      "Strip and burn severely spotted lower canopy leaves to reduce spore inoculum.",
      "Widen spacing to 60 cm x 45 cm to ensure maximum sunlight and airflow between bushes.",
      "Incorporate deep summer ploughing to bury overwintering debris."
    ],
    biologicalControl: [
      "Foliar spray Trichoderma harzianum @ 50g per 15L pump (3-4 g/L) enriched with organic jaggery.",
      "Neem Seed Kernel Extract (NSKE 5%) spray @ 50ml/L."
    ],
    chemicalControl: [
      {
        chemical: "Carbendazim 12% + Mancozeb 63% WP (Saaf)",
        dosage: "30 - 35 g / 15L knapsack pump (2.0 - 2.5 g/L)",
        timing: "Combined systemic and contact fungicide at the first sign of grey-centered spots."
      },
      {
        chemical: "Difenoconazole 25% EC (Score)",
        dosage: "10 - 12 ml / 15L knapsack pump (0.8 ml/L)",
        timing: "Curative systemic triazole spray; halts lesion expansion within 48 hours."
      },
      {
        chemical: "Chlorothalonil 75% WP (Kavach)",
        dosage: "30 g / 15L knapsack pump (2.0 g/L)",
        timing: "Broad-spectrum multi-site protectant spray during humid monsoon breaks."
      }
    ],
    preventiveCare: [
      "Treat seeds with Thiram 75% WP @ 2.5 g/kg seed.",
      "Apply balanced Potassium (MOP) @ 25 kg/acre to thicken cuticle and strengthen cell walls."
    ],
    kvkHelpline: "ICAR - Indian Agricultural Research Institute (IARI) Division of Plant Pathology."
  },
  {
    id: "chilli-powdery-mildew",
    crop: "Chilli (हरी मिर्च / मिरची)",
    cropKey: "chilli",
    diseaseName: "Chilli Powdery Mildew (Leveillula taurica)",
    pathogenType: "Fungal Pathogen (Endophytic Ascomycete)",
    targetBiomarkers: { green: 0.50, necrotic: 0.08, chlorosis: 0.24, powdery: 0.16, rust: 0.02 },
    symptoms: [
      "White chalky powdery patches consisting of conidiophores on the lower leaf surface",
      "Diffuse yellow-chlorotic blotches visible directly corresponding on the upper leaf surface",
      "Upward curling and inward rolling of leaf margins along with leaf drooping",
      "Extensive premature leaf shedding leaving denuded bare twigs with sunburned pods"
    ],
    culturalMeasures: [
      "Prune lower unshaded branches to improve ventilation in dense chilli bushes.",
      "Avoid water stress: irrigate at regular intervals without allowing soil to dry into cracks."
    ],
    biologicalControl: [
      "Spray Potassium Bicarbonate @ 45g per 15L pump (3g/L) to disrupt fungal cell walls.",
      "Ampelomyces quisqualis bio-fungicide foliar application @ 5g/L."
    ],
    chemicalControl: [
      {
        chemical: "Hexaconazole 5% SC (Contaf Plus)",
        dosage: "30 ml / 15L knapsack pump (2.0 ml/L)",
        timing: "Systemic triazole with superior translaminar action against endophytic Leveillula."
      },
      {
        chemical: "Wettable Sulphur 80% WP (Sulfex)",
        dosage: "35 - 40 g / 15L knapsack pump (2.5 g/L)",
        timing: "Contact preventative fungicide (avoid spraying in extreme heat >35°C)."
      },
      {
        chemical: "Myclobutanil 10% WP (Systhane)",
        dosage: "15 g / 15L knapsack pump (1.0 g/L)",
        timing: "High-potency systemic spray for advanced mildew infections."
      }
    ],
    preventiveCare: [
      "Grow resistant cultivars where powdery mildew is endemic.",
      "Avoid excess nitrogen; split nitrogen into multiple small fertigation doses."
    ],
    kvkHelpline: "State Horticultural Research Station (HRS) & Regional Plant Health Clinic."
  },
  {
    id: "chilli-phytophthora-blight",
    crop: "Chilli (हरी मिर्च / मिरची)",
    cropKey: "chilli",
    diseaseName: "Phytophthora Blight / Wet Collar Rot (Phytophthora capsici)",
    pathogenType: "Oomycete Water Mold",
    targetBiomarkers: { green: 0.44, necrotic: 0.44, chlorosis: 0.10, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Sudden permanent wilting of green plants without prior yellowing",
      "Dark brown to purplish-black water-soaked constricting lesions at the collar region (soil line)",
      "Greasy dark olive-brown blighting of upper leaves, branch forks, and stems",
      "Fruit rot: pods develop water-soaked dull green spots, shrivel, and become covered in white mold"
    ],
    culturalMeasures: [
      "Ensure excellent field drainage: plant chillies on raised beds (ridges and furrows) to prevent standing water.",
      "Never allow irrigation water to submerge or contact plant collar stems.",
      "Uproot and burn wilted plants; drench the spot with copper solution."
    ],
    biologicalControl: [
      "Soil application of Trichoderma viride / harzianum @ 2.5 kg mixed with 250 kg Farm Yard Manure (FYM) per acre.",
      "Root dip nursery seedlings in Trichoderma suspension (10g/L) for 20 minutes before transplanting."
    ],
    chemicalControl: [
      {
        chemical: "Metalaxyl 8% + Mancozeb 64% WP (Ridomil Gold)",
        dosage: "35 g / 15L knapsack pump (2.5 g/L)",
        timing: "Foliar spray AND drench 150-200 ml solution around root collar of each plant."
      },
      {
        chemical: "Dimethomorph 50% WP (Acrobat)",
        dosage: "15 g / 15L knapsack pump (1.0 g/L)",
        timing: "Translaminar oomyceticide during heavy monsoon deluge."
      },
      {
        chemical: "Copper Oxychloride 50% WP",
        dosage: "40 g / 15L knapsack pump (3.0 g/L)",
        timing: "Soil collar drench around infected zones to prevent outward radial spread."
      }
    ],
    preventiveCare: [
      "3-year crop rotation with non-host crops like paddy, maize, or millets.",
      "Avoid flood irrigation in heavy clay soils."
    ],
    kvkHelpline: "ICAR - Indian Institute of Horticultural Research (IIHR) Disease Warning Cell."
  },
  {
    id: "chilli-healthy",
    crop: "Chilli (हरी मिर्च / मिरची)",
    cropKey: "chilli",
    diseaseName: "Healthy Chilli Foliage (रोगमुक्त मिरची पान)",
    pathogenType: "Healthy Foliage (Zero Pathogen)",
    targetBiomarkers: { green: 0.88, necrotic: 0.04, chlorosis: 0.06, powdery: 0.01, rust: 0.01 },
    symptoms: [
      "Clean, glossy emerald-green lanceolate leaf blade with intact cell walls",
      "Smooth entire margin without curling, puckering, or serrations",
      "Strong acute tip, vigorous petiole, active photosynthesis and zero necrotic lesions"
    ],
    culturalMeasures: [
      "Maintain balanced drip fertigation and scheduled scouting twice weekly.",
      "Weed field regularly to avoid vector insect reservoirs on border grasses."
    ],
    biologicalControl: [
      "Preventative foliar spray of cold-pressed Neem Oil @ 2ml/L every 15 days.",
      "Soil application of vesicular arbuscular mycorrhiza (VAM) and PSB to boost root vigor."
    ],
    chemicalControl: [],
    preventiveCare: [
      "Do not apply chemical pesticides or fungicides to healthy green crops.",
      "Spray 19-19-19 all-round water-soluble fertilizer @ 5g/L during peak vegetative growth."
    ],
    kvkHelpline: "National Kisan Call Center: 1800-180-1551 (Toll-Free, 6 AM - 10 PM)."
  },

  // 9. GROUNDNUT / SOYBEAN DISEASES
  {
    id: "groundnut-tikka",
    crop: "Groundnut / Soybean (मूंगफली / सोयाबीन)",
    cropKey: "groundnut",
    diseaseName: "Tikka Leaf Spot / Cercospora (Cercospora arachidicola)",
    pathogenType: "Fungal Pathogen",
    targetBiomarkers: { green: 0.50, necrotic: 0.30, chlorosis: 0.16, powdery: 0.02, rust: 0.02 },
    symptoms: [
      "Early leaf spot: reddish-brown circular spots surrounded by a bright, conspicuous yellow halo",
      "Late leaf spot: dark brown to black circular spots without halo, with black carbonaceous spores on lower surface",
      "Severe premature defoliation leaving only bare stems, severely reducing pod yield"
    ],
    culturalMeasures: [
      "Crop rotation with cereals like pearl millet (bajra) or sorghum.",
      "Destroy groundnut haulms and harvest crop residue."
    ],
    biologicalControl: [
      "Foliar spray with Pseudomonas fluorescens @ 5g/L water.",
      "Neem seed kernel extract (NSKE 5%) spray."
    ],
    chemicalControl: [
      {
        chemical: "Carbendazim 12% + Mancozeb 63% WP (Saaf)",
        dosage: "2.0 g / Liter of water",
        timing: "Dual contact + systemic spray at 40 and 55 days after sowing."
      },
      {
        chemical: "Hexaconazole 5% SC",
        dosage: "2.0 ml / Liter of water",
        timing: "Curative spray for severe late leaf spot."
      }
    ],
    preventiveCare: [
      "Seed treatment with Thiram + Carbendazim (1:1) @ 3g/kg kernel.",
      "Grow tolerant varieties (e.g. Kadiri-6, TAG-24, Girnar-4)."
    ],
    kvkHelpline: "ICAR Directorate of Groundnut Research (DGR) Junagadh."
  },
  {
    id: "groundnut-healthy",
    crop: "Groundnut (मूंगफली / भुईमूग)",
    cropKey: "groundnut",
    diseaseName: "Healthy Groundnut Foliage",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.94, necrotic: 0.01, chlorosis: 0.04, powdery: 0.01, rust: 0.00 },
    symptoms: [
      "Vibrant green tetrafoliolate (4-leaflet) leaves with smooth entire margins",
      "No circular brown Tikka spots or yellow chlorotic rings on leaflets",
      "Vigorous peg development and healthy nitrogen-fixing root nodules"
    ],
    culturalMeasures: [
      "Maintain adequate soil moisture during peg penetration and pod development stage.",
      "Earthing up around 40-45 days after sowing to facilitate easy peg penetration."
    ],
    biologicalControl: [
      "Seed inoculation with Rhizobium culture (200g/10kg seed) and Trichoderma viride (4g/kg seed).",
      "Preventive foliar spray with cold-pressed Neem oil (3 ml/L water)."
    ],
    chemicalControl: [
      {
        chemical: "No Pesticide Required",
        dosage: "0",
        timing: "Maintain regular field scouting during warm humid weather."
      }
    ],
    preventiveCare: [
      "Avoid waterlogging in heavy black soils.",
      "Apply gypsum @ 200 kg/acre at 40-45 DAS for pod filling and calcium nutrition."
    ],
    kvkHelpline: "ICAR Directorate of Groundnut Research (DGR) Junagadh."
  },
  {
    id: "cabbage-healthy",
    crop: "Cabbage (पत्ता गोभी)",
    cropKey: "cabbage",
    diseaseName: "Cabbage Healthy Foliage (Nominal Baseline)",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.95, necrotic: 0.02, chlorosis: 0.03, powdery: 0, rust: 0 },
    symptoms: [
      "Waxy blue-green glaucous leaves with firm, clean margins",
      "No black rot (Xanthomonas) V-shaped lesions or downy mildew",
      "Vigorous head development and intact thick foliage"
    ],
    whyThisHappens: {
      pathogenCause: "Healthy agricultural crop baseline. No pathogenic bacteria, fungi, or foliar viruses detected.",
      weatherTriggers: "Optimal cool-season conditions with adequate moisture and good soil drainage.",
      transmissionMode: "None. Pathogen-free foliage.",
      riskFactors: "Overwatering or sprinkler splash can predispose heads to bacterial soft rot."
    },
    culturalMeasures: [
      "Maintain 45x45 cm plant spacing for sufficient air circulation.",
      "Use drip irrigation to prevent water stagnation in the crown.",
      "Scout periodically for diamondback moth and cabbage aphids."
    ],
    biologicalTreatments: [
      "Foliar spray of Bacillus subtilis (2 g/L) at 15-day intervals as prophylactic shield.",
      "Neem oil 1500 ppm (3 ml/L) for sucking pest deterrence."
    ],
    chemicalControls: [
      "No chemical fungicides or bactericides required for healthy crop."
    ],
    organicHomeRemedies: [
      "Spray Jeevamrutha or cow dung slurry (10%) to promote beneficial phyllosphere microbes."
    ]
  },
  {
    id: "cauliflower-healthy",
    crop: "Cauliflower (फूल गोभी)",
    cropKey: "cauliflower",
    diseaseName: "Cauliflower Healthy Foliage (Nominal Baseline)",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.95, necrotic: 0.02, chlorosis: 0.03, powdery: 0, rust: 0 },
    symptoms: [
      "Erect, broad waxy blue-green foliage protecting the central curd",
      "Zero black rot lesions, Alternaria spots, or downy mildew sporulation",
      "Uniform curd formation with firm white compactness"
    ],
    whyThisHappens: {
      pathogenCause: "Healthy agricultural crop baseline. No pathogenic infection detected.",
      weatherTriggers: "Favorable cool temperate weather with balanced fertility.",
      transmissionMode: "None.",
      riskFactors: "Boron or molybdenum deficiency can cause hollow stem or whiptail."
    },
    culturalMeasures: [
      "Practice blanching by loosely tying outer leaves over curds to preserve white quality.",
      "Ensure balanced N-P-K fertilization and adequate boron application (Borax 10 kg/ha)."
    ],
    biologicalTreatments: [
      "Trichoderma viride root drench at transplanting.",
      "Pseudomonas fluorescens (5 g/L) foliar spray as bio-protectant."
    ],
    chemicalControls: [
      "No chemical application needed."
    ],
    organicHomeRemedies: [
      "Foliar spray of wood ash extract and vermiwash (1:5 dilution) for micronutrient boost."
    ]
  },
  {
    id: "marigold-healthy",
    crop: "Marigold (गेंदा / झेंडू)",
    cropKey: "marigold",
    diseaseName: "Marigold Healthy Foliage (Nominal Baseline)",
    pathogenType: "Healthy Foliage",
    targetBiomarkers: { green: 0.96, necrotic: 0.02, chlorosis: 0.02, powdery: 0, rust: 0 },
    symptoms: [
      "Deep green pinnatisect dissected leaflets with characteristic aromatic scent",
      "Zero Alternaria leaf blight, powdery mildew, or collar rot",
      "Profuse flower bud initiation with sturdy stems"
    ],
    whyThisHappens: {
      pathogenCause: "Healthy horticultural crop baseline. Roots naturally exude alpha-terthienyl suppressing nematodes.",
      weatherTriggers: "Warm sunny weather with moderate humidity.",
      transmissionMode: "None.",
      riskFactors: "Excessive standing water induces collar rot (Phytophthora)."
    },
    culturalMeasures: [
      "Pinch terminal shoots at 30-35 days after transplanting to induce bushy branching.",
      "Avoid overhead evening irrigation to keep blooms and foliage dry."
    ],
    biologicalTreatments: [
      "Trichoderma harzianum soil incorporation around roots.",
      "Neem seed kernel extract (NSKE 5%) against thrips and mites."
    ],
    chemicalControls: [
      "No chemical pesticides needed."
    ],
    organicHomeRemedies: [
      "Fermented buttermilk spray (50 ml/L) for foliar vigor and mild fungal deterrence."
    ]
  }
];

// Unified Plant Pathology Database: Combines core curated diseases with the 242 comprehensive diseases from expandedPlantDiseaseDatabase
const combinedDiseaseMap = new Map();
corePlantDiseaseDatabase.forEach(d => combinedDiseaseMap.set(d.id, d));
expandedPlantDiseaseDatabase.forEach(d => {
  if (!combinedDiseaseMap.has(d.id)) {
    combinedDiseaseMap.set(d.id, d);
  }
});
const plantDiseaseDatabase = exports.plantDiseaseDatabase = Array.from(combinedDiseaseMap.values());

/**
 * High-Resolution Synthesized SVG Leaf Previews for 1-Click Farmer Testing
 */
const demoLeafSamples = exports.demoLeafSamples = [
  {
    id: "sample-tomato-early-blight",
    crop: "Tomato",
    cropKey: "tomato",
    diseaseId: "tomato-early-blight",
    label: "🍅 Tomato: Early Blight",
    desc: "Concentric target spots & yellow halos",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="leafGrad" cx="40%" cy="30%" r="70%">
          <stop offset="0%" stop-color="#4ade80" />
          <stop offset="70%" stop-color="#15803d" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
        <radialGradient id="targetSpot1" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#1c1917" />
          <stop offset="35%" stop-color="#78350f" />
          <stop offset="70%" stop-color="#451a03" />
          <stop offset="90%" stop-color="#facc15" />
          <stop offset="100%" stop-color="#15803d" stop-opacity="0" />
        </radialGradient>
      </defs>
      <!-- Leaf Blade -->
      <path d="M 100,15 C 150,40 185,90 160,155 C 135,175 105,185 100,195 C 95,185 65,175 40,155 C 15,90 50,40 100,15 Z" fill="url(#leafGrad)" stroke="#166534" stroke-width="2"/>
      <!-- Main & Lateral Veins -->
      <path d="M 100,20 L 100,190" stroke="#86efac" stroke-width="2.5" opacity="0.8"/>
      <path d="M 100,60 Q 130,50 150,65 M 100,60 Q 70,50 50,65" stroke="#86efac" stroke-width="1.5" opacity="0.6"/>
      <path d="M 100,105 Q 140,95 160,115 M 100,105 Q 60,95 40,115" stroke="#86efac" stroke-width="1.5" opacity="0.6"/>
      <path d="M 100,145 Q 130,140 145,155 M 100,145 Q 70,140 55,155" stroke="#86efac" stroke-width="1.5" opacity="0.6"/>
      <!-- Concentric Early Blight Target Lesions -->
      <circle cx="75" cy="85" r="24" fill="url(#targetSpot1)" />
      <circle cx="75" cy="85" r="14" fill="none" stroke="#78350f" stroke-width="1.5" />
      <circle cx="75" cy="85" r="7" fill="none" stroke="#292524" stroke-width="1.5" />
      <!-- Second lesion -->
      <circle cx="130" cy="125" r="28" fill="url(#targetSpot1)" />
      <circle cx="130" cy="125" r="18" fill="none" stroke="#78350f" stroke-width="2" />
      <circle cx="130" cy="125" r="9" fill="none" stroke="#292524" stroke-width="1.8" />
      <!-- Satellite spots -->
      <circle cx="65" cy="140" r="12" fill="url(#targetSpot1)" />
      <circle cx="125" cy="65" r="10" fill="url(#targetSpot1)" />
    </svg>`
  },
  {
    id: "sample-tomato-late-blight",
    crop: "Tomato",
    cropKey: "tomato",
    diseaseId: "tomato-late-blight",
    label: "🍅 Tomato: Late Blight",
    desc: "Water-soaked dark lesions & pale halos",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="tomLateGrad" cx="40%" cy="30%" r="70%">
          <stop offset="0%" stop-color="#4ade80" />
          <stop offset="70%" stop-color="#15803d" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,15 C 150,40 185,90 160,155 C 135,175 105,185 100,195 C 95,185 65,175 40,155 C 15,90 50,40 100,15 Z" fill="url(#tomLateGrad)" stroke="#166534" stroke-width="2"/>
      <path d="M 100,20 L 100,190" stroke="#86efac" stroke-width="2.5" opacity="0.8"/>
      <path d="M 140,70 Q 165,95 150,135 Q 120,120 125,85 Z" fill="#1c1917" opacity="0.85"/>
      <path d="M 50,80 Q 35,115 55,145 Q 85,130 75,95 Z" fill="#292524" opacity="0.82"/>
      <circle cx="100" cy="110" r="18" fill="#451a03" opacity="0.75"/>
      <circle cx="100" cy="110" r="24" fill="none" stroke="#facc15" stroke-width="2" opacity="0.6"/>
    </svg>`
  },
  {
    id: "sample-potato-late-blight",
    crop: "Potato",
    cropKey: "potato",
    diseaseId: "potato-late-blight",
    label: "🥔 Potato: Late Blight",
    desc: "Water-soaked blackish margins & downy mold",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="potLeaf" cx="50%" cy="40%" r="60%">
          <stop offset="0%" stop-color="#22c55e" />
          <stop offset="80%" stop-color="#15803d" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <!-- Leaf -->
      <path d="M 100,15 C 160,35 180,100 155,160 C 130,185 105,190 100,195 C 95,190 70,185 45,160 C 20,100 40,35 100,15 Z" fill="url(#potLeaf)" stroke="#166534" stroke-width="2"/>
      <path d="M 100,20 L 100,190" stroke="#86efac" stroke-width="2.5" opacity="0.8"/>
      <!-- Late Blight Water-Soaked Black Necrosis on Margins -->
      <path d="M 155,160 C 180,100 160,35 130,45 C 145,95 135,140 155,160 Z" fill="#1c1917" opacity="0.88"/>
      <path d="M 155,160 C 180,100 160,35 130,45 C 145,95 135,140 155,160 Z" fill="none" stroke="#e2e8f0" stroke-width="1.5" stroke-dasharray="2 3" opacity="0.7"/>
      <path d="M 45,160 C 20,100 40,45 65,55 C 50,105 60,140 45,160 Z" fill="#292524" opacity="0.82"/>
      <!-- Yellowing halo boundary -->
      <path d="M 130,45 Q 120,95 135,145" fill="none" stroke="#facc15" stroke-width="4" opacity="0.7"/>
      <path d="M 65,55 Q 75,105 60,145" fill="none" stroke="#facc15" stroke-width="3" opacity="0.65"/>
    </svg>`
  },
  {
    id: "sample-wheat-leaf-rust",
    crop: "Wheat",
    cropKey: "wheat",
    diseaseId: "wheat-leaf-rust",
    label: "🌾 Wheat: Leaf Rust",
    desc: "Orange-brown pustules & dusty spores",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="wheatBlade" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#15803d" />
          <stop offset="50%" stop-color="#22c55e" />
          <stop offset="100%" stop-color="#166534" />
        </linearGradient>
      </defs>
      <!-- Slender Wheat Blade -->
      <path d="M 80,10 Q 100,100 85,190 L 115,190 Q 105,100 120,10 Z" fill="url(#wheatBlade)" stroke="#14532d" stroke-width="2"/>
      <line x1="100" y1="10" x2="100" y2="190" stroke="#86efac" stroke-width="2" opacity="0.7"/>
      <!-- Bright Orange Pustules (Rust Uredinia) -->
      ${Array.from({ length: 24 }).map((_, i) => {
        const cx = 86 + (i % 3) * 11 + Math.sin(i * 1.5) * 4;
        const cy = 25 + i * 6.5;
        return `<ellipse cx="${cx}" cy="${cy}" rx="4.5" ry="2.8" fill="#ea580c" stroke="#facc15" stroke-width="1"/>
                <circle cx="${cx - 1}" cy="${cy - 0.5}" r="1" fill="#fed7aa"/>`;
      }).join('')}
    </svg>`
  },
  {
    id: "sample-rice-blast",
    crop: "Rice",
    cropKey: "rice",
    diseaseId: "rice-blast",
    label: "🌾 Rice: Blast",
    desc: "Spindle-shaped diamond spots with grey centers",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="riceBlade" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#16a34a" />
          <stop offset="50%" stop-color="#4ade80" />
          <stop offset="100%" stop-color="#15803d" />
        </linearGradient>
      </defs>
      <path d="M 85,15 Q 100,95 88,185 L 112,185 Q 105,95 115,15 Z" fill="url(#riceBlade)" stroke="#15803d" stroke-width="2"/>
      <line x1="100" y1="15" x2="100" y2="185" stroke="#dcfce7" stroke-width="1.5" opacity="0.8"/>
      <!-- Spindle-shaped diamond lesions (Magnaporthe oryzae) -->
      <path d="M 100,45 Q 112,60 100,75 Q 88,60 100,45 Z" fill="#e2e8f0" stroke="#78350f" stroke-width="2.5"/>
      <circle cx="100" cy="60" r="3" fill="#64748b"/>
      <path d="M 100,95 Q 114,115 100,135 Q 86,115 100,95 Z" fill="#e2e8f0" stroke="#78350f" stroke-width="3"/>
      <circle cx="100" cy="115" r="4" fill="#64748b"/>
      <path d="M 98,145 Q 108,155 98,165 Q 88,155 98,145 Z" fill="#e2e8f0" stroke="#78350f" stroke-width="2"/>
    </svg>`
  },
  {
    id: "sample-cotton-bacterial-blight",
    crop: "Cotton",
    cropKey: "cotton",
    diseaseId: "cotton-bacterial-blight",
    label: "☁️ Cotton: Angular Leaf Spot",
    desc: "Polygonal vein-bounded dark lesions",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="cotGrad" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#4ade80" />
          <stop offset="70%" stop-color="#16a34a" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <!-- 3-Lobed Cotton Leaf -->
      <path d="M 100,20 C 135,25 160,55 165,95 C 170,125 150,150 155,180 C 125,170 110,185 100,190 C 90,185 75,170 45,180 C 50,150 30,125 35,95 C 40,55 65,25 100,20 Z" fill="url(#cotGrad)" stroke="#14532d" stroke-width="2"/>
      <!-- Main veins -->
      <path d="M 100,25 L 100,185 M 100,95 L 155,80 M 100,95 L 45,80" stroke="#86efac" stroke-width="2" opacity="0.6"/>
      <!-- Angular polygonal lesions delimited by veins -->
      <polygon points="75,55 88,52 92,66 80,72 70,64" fill="#451a03" stroke="#b45309" stroke-width="1.5"/>
      <polygon points="110,65 125,60 132,74 122,82 108,76" fill="#1c1917" stroke="#b45309" stroke-width="1.5"/>
      <polygon points="65,100 80,95 86,110 74,118 60,110" fill="#451a03" stroke="#b45309" stroke-width="1.5"/>
      <polygon points="120,105 135,98 144,114 134,124 118,118" fill="#1c1917" stroke="#b45309" stroke-width="1.5"/>
      <polygon points="90,135 105,128 112,142 102,150 88,144" fill="#451a03" stroke="#b45309" stroke-width="1.5"/>
    </svg>`
  },
  {
    id: "sample-chilli-leaf-curl",
    crop: "Chilli",
    cropKey: "chilli",
    diseaseId: "chilli-leaf-curl",
    label: "🌶️ Chilli: Leaf Curl Virus (Murda)",
    desc: "Upward leaf cupping, puckered margins & chlorosis",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="chilliCurlGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#84cc16" />
          <stop offset="40%" stop-color="#eab308" />
          <stop offset="70%" stop-color="#22c55e" />
          <stop offset="100%" stop-color="#15803d" />
        </linearGradient>
      </defs>
      <!-- Slender Lanceolate Chilli Leaf with Inward Curled Margins -->
      <path d="M 100,10 C 135,45 145,110 125,170 C 115,188 105,195 100,195 C 95,195 85,188 75,170 C 55,110 65,45 100,10 Z" fill="url(#chilliCurlGrad)" stroke="#166534" stroke-width="2"/>
      <!-- Midrib and Swollen Veins -->
      <path d="M 100,12 L 100,192" stroke="#fef08a" stroke-width="3" opacity="0.9"/>
      <path d="M 100,50 Q 120,42 135,55 M 100,50 Q 80,42 65,55" stroke="#fef08a" stroke-width="2" opacity="0.85"/>
      <path d="M 100,90 Q 125,80 138,98 M 100,90 Q 75,80 62,98" stroke="#fef08a" stroke-width="2" opacity="0.85"/>
      <path d="M 100,130 Q 120,122 130,138 M 100,130 Q 80,122 70,138" stroke="#fef08a" stroke-width="1.8" opacity="0.85"/>
      <!-- Upward Curling / Puckered Leaf Edge Waves -->
      <path d="M 68,55 Q 55,80 62,110 Q 56,140 75,170" fill="none" stroke="#ca8a04" stroke-width="2.5" stroke-dasharray="3 2" opacity="0.8"/>
      <path d="M 132,55 Q 145,80 138,110 Q 144,140 125,170" fill="none" stroke="#ca8a04" stroke-width="2.5" stroke-dasharray="3 2" opacity="0.8"/>
      <!-- Chlorotic yellow mosaic patches -->
      <ellipse cx="85" cy="75" rx="12" ry="16" fill="#facc15" opacity="0.5" />
      <ellipse cx="118" cy="115" rx="10" ry="14" fill="#facc15" opacity="0.5" />
      <ellipse cx="88" cy="140" rx="8" ry="10" fill="#facc15" opacity="0.45" />
    </svg>`
  },
  {
    id: "sample-chilli-bacterial-spot",
    crop: "Chilli",
    cropKey: "chilli",
    diseaseId: "chilli-bacterial-spot",
    label: "🌶️ Chilli: Bacterial Leaf Spot",
    desc: "Small dark circular spots with vivid yellow halos",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="chilliSpotGrad" cx="45%" cy="35%" r="65%">
          <stop offset="0%" stop-color="#4ade80" />
          <stop offset="50%" stop-color="#16a34a" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <!-- Slender Lanceolate Chilli Blade -->
      <path d="M 100,12 C 140,50 148,115 125,175 C 112,190 105,195 100,195 C 95,195 88,190 75,175 C 52,115 60,50 100,12 Z" fill="url(#chilliSpotGrad)" stroke="#15803d" stroke-width="2"/>
      <path d="M 100,15 L 100,192" stroke="#86efac" stroke-width="2" opacity="0.7"/>
      <!-- Dark Circular & Angular Bacterial Spots with Yellow Halos (Xanthomonas) -->
      ${[
        { cx: 80, cy: 55, r: 4 }, { cx: 120, cy: 65, r: 3.5 }, { cx: 88, cy: 85, r: 5 },
        { cx: 112, cy: 95, r: 4.5 }, { cx: 75, cy: 115, r: 3.5 }, { cx: 125, cy: 125, r: 5 },
        { cx: 90, cy: 140, r: 4 }, { cx: 110, cy: 155, r: 3.5 }, { cx: 85, cy: 165, r: 3 }
      ].map(s => `
        <circle cx="${s.cx}" cy="${s.cy}" r="${s.r + 2.5}" fill="#facc15" opacity="0.85" />
        <circle cx="${s.cx}" cy="${s.cy}" r="${s.r}" fill="#1c1917" stroke="#451a03" stroke-width="0.8" />
        <circle cx="${s.cx - 0.5}" cy="${s.cy - 0.5}" r="${s.r * 0.4}" fill="#0f172a" />
      `).join('')}
    </svg>`
  },
  {
    id: "sample-healthy-leaf",
    crop: "Healthy",
    cropKey: "tomato",
    diseaseId: "tomato-healthy",
    label: "🌿 Clean & Healthy Leaf",
    desc: "100% vibrant green, zero pathogens",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="healthyGrad" cx="45%" cy="35%" r="65%">
          <stop offset="0%" stop-color="#86efac" />
          <stop offset="40%" stop-color="#22c55e" />
          <stop offset="85%" stop-color="#15803d" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,15 C 160,35 185,90 160,155 C 135,175 105,185 100,195 C 95,185 65,175 40,155 C 15,90 40,35 100,15 Z" fill="url(#healthyGrad)" stroke="#15803d" stroke-width="2"/>
      <path d="M 100,20 L 100,190" stroke="#dcfce7" stroke-width="2.5" opacity="0.9"/>
      <path d="M 100,60 Q 130,50 150,65 M 100,60 Q 70,50 50,65" stroke="#dcfce7" stroke-width="1.5" opacity="0.7"/>
      <path d="M 100,105 Q 140,95 160,115 M 100,105 Q 60,95 40,115" stroke="#dcfce7" stroke-width="1.5" opacity="0.7"/>
      <path d="M 100,145 Q 130,140 145,155 M 100,145 Q 70,140 55,155" stroke="#dcfce7" stroke-width="1.5" opacity="0.7"/>
      <!-- Dew droplets with specular highlights -->
      <circle cx="85" cy="80" r="4.5" fill="rgba(255,255,255,0.4)" stroke="#ffffff" stroke-width="0.8"/>
      <circle cx="83.5" cy="78.5" r="1.5" fill="#ffffff"/>
      <circle cx="125" cy="130" r="3.5" fill="rgba(255,255,255,0.4)" stroke="#ffffff" stroke-width="0.8"/>
      <circle cx="124" cy="129" r="1.2" fill="#ffffff"/>
    </svg>`
  },
  {
    id: "sample-maize-leaf-blight",
    crop: "Maize",
    cropKey: "maize",
    diseaseId: "maize-leaf-blight",
    label: "🌽 Maize: Northern Leaf Blight",
    desc: "Long elliptical cigar-shaped tan lesions along parallel veins",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="maizeBlade" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#15803d" />
          <stop offset="35%" stop-color="#22c55e" />
          <stop offset="50%" stop-color="#4ade80" />
          <stop offset="65%" stop-color="#22c55e" />
          <stop offset="100%" stop-color="#14532d" />
        </linearGradient>
      </defs>
      <path d="M 100,10 C 130,50 140,110 120,195 L 80,195 C 60,110 70,50 100,10 Z" fill="url(#maizeBlade)" stroke="#14532d" stroke-width="2"/>
      <path d="M 100,12 L 100,195" stroke="#ecfdf5" stroke-width="3" opacity="0.9"/>
      <path d="M 88,30 L 88,190 M 112,30 L 112,190" stroke="#bbf7d0" stroke-width="1.2" opacity="0.6"/>
      <path d="M 78,50 L 78,185 M 122,50 L 122,185" stroke="#bbf7d0" stroke-width="1" opacity="0.5"/>
      <path d="M 90,45 C 105,45 115,70 105,95 C 95,95 85,70 90,45 Z" fill="#d97706" stroke="#78350f" stroke-width="2" opacity="0.9"/>
      <ellipse cx="98" cy="70" rx="4" ry="16" fill="#78350f" opacity="0.8"/>
      <path d="M 94,115 C 112,115 120,145 108,165 C 92,165 84,145 94,115 Z" fill="#d97706" stroke="#78350f" stroke-width="2" opacity="0.9"/>
      <ellipse cx="102" cy="140" rx="5" ry="18" fill="#78350f" opacity="0.8"/>
    </svg>`
  },
  {
    id: "sample-maize-common-rust",
    crop: "Maize",
    cropKey: "maize",
    diseaseId: "maize-common-rust",
    label: "🌽 Maize: Common Rust",
    desc: "Cinnamon-brown powdery uredinia pustules on leaf blade",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="maizeRustBlade" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#166534" />
          <stop offset="45%" stop-color="#22c55e" />
          <stop offset="100%" stop-color="#14532d" />
        </linearGradient>
      </defs>
      <path d="M 100,10 C 130,50 140,110 120,195 L 80,195 C 60,110 70,50 100,10 Z" fill="url(#maizeRustBlade)" stroke="#14532d" stroke-width="2"/>
      <path d="M 100,12 L 100,195" stroke="#ecfdf5" stroke-width="3" opacity="0.9"/>
      <path d="M 88,30 L 88,190 M 112,30 L 112,190" stroke="#bbf7d0" stroke-width="1.2" opacity="0.5"/>
      <ellipse cx="88" cy="45" rx="5" ry="9" fill="#fde047" opacity="0.6"/>
      <ellipse cx="88" cy="45" rx="3" ry="7" fill="#ea580c" stroke="#9a3412" stroke-width="1.2"/>
      <ellipse cx="112" cy="55" rx="5.5" ry="10" fill="#fde047" opacity="0.6"/>
      <ellipse cx="112" cy="55" rx="3.5" ry="8" fill="#ea580c" stroke="#9a3412" stroke-width="1.2"/>
      <ellipse cx="92" cy="75" rx="6" ry="11" fill="#fde047" opacity="0.6"/>
      <ellipse cx="92" cy="75" rx="4" ry="9" fill="#ea580c" stroke="#9a3412" stroke-width="1.2"/>
      <ellipse cx="110" cy="85" rx="5.5" ry="10" fill="#fde047" opacity="0.6"/>
      <ellipse cx="110" cy="85" rx="3.5" ry="8" fill="#ea580c" stroke="#9a3412" stroke-width="1.2"/>
      <ellipse cx="86" cy="110" rx="6" ry="12" fill="#fde047" opacity="0.6"/>
      <ellipse cx="86" cy="110" rx="4" ry="10" fill="#ea580c" stroke="#9a3412" stroke-width="1.2"/>
      <ellipse cx="114" cy="125" rx="6" ry="12" fill="#fde047" opacity="0.6"/>
      <ellipse cx="114" cy="125" rx="4" ry="10" fill="#ea580c" stroke="#9a3412" stroke-width="1.2"/>
      <ellipse cx="90" cy="145" rx="5.5" ry="10" fill="#fde047" opacity="0.6"/>
      <ellipse cx="90" cy="145" rx="3.5" ry="8" fill="#ea580c" stroke="#9a3412" stroke-width="1.2"/>
      <ellipse cx="108" cy="160" rx="5" ry="9" fill="#fde047" opacity="0.6"/>
      <ellipse cx="108" cy="160" rx="3" ry="7" fill="#ea580c" stroke="#9a3412" stroke-width="1.2"/>
    </svg>`
  },
  {
    id: "sample-maize-healthy",
    crop: "Maize",
    cropKey: "maize",
    diseaseId: "maize-healthy",
    label: "🌽 Maize: Healthy Leaf Blade",
    desc: "Vibrant strap blade with pure parallel venation & zero lesions",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="maizeHealthyBlade" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#15803d" />
          <stop offset="35%" stop-color="#22c55e" />
          <stop offset="50%" stop-color="#86efac" />
          <stop offset="65%" stop-color="#22c55e" />
          <stop offset="100%" stop-color="#14532d" />
        </linearGradient>
      </defs>
      <path d="M 100,10 C 130,50 140,110 120,195 L 80,195 C 60,110 70,50 100,10 Z" fill="url(#maizeHealthyBlade)" stroke="#14532d" stroke-width="2"/>
      <path d="M 100,12 L 100,195" stroke="#f0fdf4" stroke-width="3" opacity="0.95"/>
      <path d="M 88,25 L 88,190 M 112,25 L 112,190" stroke="#dcfce7" stroke-width="1.5" opacity="0.7"/>
      <path d="M 78,45 L 78,185 M 122,45 L 122,185" stroke="#dcfce7" stroke-width="1.2" opacity="0.6"/>
      <circle cx="92" cy="70" r="3.5" fill="rgba(255,255,255,0.4)" stroke="#ffffff" stroke-width="0.8"/>
      <circle cx="91" cy="69" r="1.2" fill="#ffffff"/>
    </svg>`
  },
  {
    id: "sample-tomato-septoria",
    crop: "Tomato",
    cropKey: "tomato",
    diseaseId: "tomato-septoria",
    label: "🍅 Tomato: Septoria Leaf Spot",
    desc: "Small circular spots with dark brown margins & ash-gray centers",
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="tomSeptGrad" cx="45%" cy="35%" r="65%">
          <stop offset="0%" stop-color="#86efac" />
          <stop offset="40%" stop-color="#22c55e" />
          <stop offset="85%" stop-color="#15803d" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,15 C 160,35 185,90 160,155 C 135,175 105,185 100,195 C 95,185 65,175 40,155 C 15,90 40,35 100,15 Z" fill="url(#tomSeptGrad)" stroke="#15803d" stroke-width="2"/>
      <path d="M 100,20 L 100,190" stroke="#dcfce7" stroke-width="2.5" opacity="0.8"/>
      <path d="M 100,60 Q 130,50 150,65 M 100,60 Q 70,50 50,65" stroke="#dcfce7" stroke-width="1.4" opacity="0.6"/>
      <path d="M 100,105 Q 140,95 160,115 M 100,105 Q 60,95 40,115" stroke="#dcfce7" stroke-width="1.4" opacity="0.6"/>
      <!-- Numerous small circular Septoria spots with ash-gray center & dark margin -->
      <circle cx="75" cy="55" r="4.5" fill="#451a03"/>
      <circle cx="75" cy="55" r="2.8" fill="#cbd5e1"/>
      <circle cx="75" cy="55" r="0.8" fill="#0f172a"/>
      <circle cx="125" cy="65" r="5" fill="#451a03"/>
      <circle cx="125" cy="65" r="3" fill="#cbd5e1"/>
      <circle cx="125" cy="65" r="0.9" fill="#0f172a"/>
      <circle cx="85" cy="95" r="5.5" fill="#451a03"/>
      <circle cx="85" cy="95" r="3.5" fill="#cbd5e1"/>
      <circle cx="85" cy="95" r="1" fill="#0f172a"/>
      <circle cx="115" cy="110" r="4.5" fill="#451a03"/>
      <circle cx="115" cy="110" r="2.8" fill="#cbd5e1"/>
      <circle cx="115" cy="110" r="0.8" fill="#0f172a"/>
      <circle cx="70" cy="135" r="4" fill="#451a03"/>
      <circle cx="70" cy="135" r="2.4" fill="#cbd5e1"/>
      <circle cx="130" cy="145" r="4.5" fill="#451a03"/>
      <circle cx="130" cy="145" r="2.8" fill="#cbd5e1"/>
    </svg>`
  }
];

/**
 * Converts an SVG string into a Base64 Data URL for clean image rendering
 */
function getSampleDataUrl(svgString) {
  if (typeof btoa !== 'undefined') {
    return `data:image/svg+xml;base64,${btoa(svgString)}`;
  }
  return `data:image/svg+xml;utf8,${encodeURIComponent(svgString)}`;
}

/**
 * Helper to convert RGB to HSV values
 */
function rgbToHsv(r, g, b) {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h, s, v = max;
  const d = max - min;
  s = max === 0 ? 0 : d / max;
  if (max === min) {
    h = 0;
  } else {
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h /= 6;
  }
  return { h: h * 360, s, v };
}

/**
 * Comprehensive Botanical Reference Models for Healthy Crop Species
 * Provides morphological aspect ratios, margin roughness, saturation baselines, and botanical SVG graphics
 */
const coreHealthyCropReferenceModels = {
  maize: {
    cropKey: "maize",
    cropName: "Maize / Corn (मक्का / मका)",
    botanicalClass: "Monocotyledonae (Poaceae)",
    leafMorphology: "Elongated linear strap blade with prominent central midrib and parallel venation",
    marginType: "Entire, smooth with slight undulating wave",
    aspectRatioDescriptor: "Linear Strap Blade (3.0 : 1 to 5.8 : 1)",
    typicalElongation: 4.2,
    marginRoughness: 24,
    greenTone: "Deep Emerald Green (RGB 34, 197, 94)",
    realPhotoUrl: "images/healthy_crops/maize_healthy.jpg",
    realPhotoDescription: "Real macro farm photo of healthy Maize / Corn leaf with vivid emerald chlorophyll and prominent central ivory midrib.",
    healthyBiomarkers: { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: [
      "Continuous parallel venation with zero necrosis",
      "Rigid structural midrib providing erect photosynthetic posture",
      "Intact waxy cuticular barrier preventing spore germ-tube ingress",
      "Zero chlorotic yellow halos or rust pustule eruptions"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="refMaize" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#14532d" />
          <stop offset="25%" stop-color="#16a34a" />
          <stop offset="50%" stop-color="#4ade80" />
          <stop offset="75%" stop-color="#16a34a" />
          <stop offset="100%" stop-color="#14532d" />
        </linearGradient>
      </defs>
      <path d="M 100,8 C 132,45 142,105 122,192 L 78,192 C 58,105 68,45 100,8 Z" fill="url(#refMaize)" stroke="#14532d" stroke-width="2"/>
      <path d="M 100,10 L 100,192" stroke="#ecfdf5" stroke-width="3" opacity="0.95"/>
      <path d="M 88,25 L 88,188 M 112,25 L 112,188" stroke="#dcfce7" stroke-width="1.5" opacity="0.75"/>
      <path d="M 78,45 L 78,184 M 122,45 L 122,184" stroke="#dcfce7" stroke-width="1.2" opacity="0.6"/>
      <circle cx="92" cy="65" r="3.5" fill="rgba(255,255,255,0.45)" stroke="#ffffff" stroke-width="0.8"/>
      <circle cx="90.5" cy="63.5" r="1.2" fill="#ffffff"/>
    </svg>`
  },
  tomato: {
    cropKey: "tomato",
    cropName: "Tomato (टमाटर / टोमॅटो)",
    botanicalClass: "Dicotyledonae (Solanaceae)",
    leafMorphology: "Odd-pinnately compound leaf with ovate-oblong serrated leaflets",
    marginType: "Serrated / Dentate lobed margin (High perimeter roughness)",
    aspectRatioDescriptor: "Moderate Ovate (1.3 : 1 to 2.4 : 1)",
    typicalElongation: 1.8,
    marginRoughness: 48,
    greenTone: "Forest Green (RGB 21, 128, 61)",
    realPhotoUrl: "images/healthy_crops/tomato_healthy.jpg",
    realPhotoDescription: "Real field macro photo of healthy Tomato serrated leaflet showing pristine green mesophyll and crisp dentate margins.",
    healthyBiomarkers: { green: 95, necrotic: 1, chlorosis: 4, powdery: 0, rust: 0 },
    healthyTraits: [
      "Sharply defined serrated margin without water-soaked notches",
      "Even chlorophyll distribution across interveinal mesophyll",
      "Absence of concentric target-like rings (Alternaria) or gray spots",
      "Flat spreading leaf lamina without viral upward curling"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refTomato" cx="45%" cy="35%" r="65%">
          <stop offset="0%" stop-color="#86efac" />
          <stop offset="40%" stop-color="#22c55e" />
          <stop offset="85%" stop-color="#15803d" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,12 C 118,22 135,18 140,28 C 132,38 152,48 158,62 C 145,68 162,88 156,108 C 142,112 152,132 144,152 C 130,154 122,175 100,192 C 78,175 70,154 56,152 C 48,132 58,112 44,108 C 38,88 55,68 42,62 C 48,48 68,38 60,28 C 65,18 82,22 100,12 Z" fill="url(#refTomato)" stroke="#14532d" stroke-width="2"/>
      <path d="M 100,16 L 100,188" stroke="#dcfce7" stroke-width="2.5" opacity="0.9"/>
      <path d="M 100,50 Q 128,42 145,55 M 100,50 Q 72,42 55,55" stroke="#dcfce7" stroke-width="1.6" opacity="0.75"/>
      <path d="M 100,90 Q 135,80 150,98 M 100,90 Q 65,80 50,98" stroke="#dcfce7" stroke-width="1.6" opacity="0.75"/>
      <path d="M 100,132 Q 128,124 138,140 M 100,132 Q 72,124 62,140" stroke="#dcfce7" stroke-width="1.4" opacity="0.75"/>
      <circle cx="82" cy="72" r="3.5" fill="rgba(255,255,255,0.4)" stroke="#ffffff" stroke-width="0.8"/>
      <circle cx="80.5" cy="70.5" r="1.2" fill="#ffffff"/>
    </svg>`
  },
  chilli: {
    cropKey: "chilli",
    cropName: "Chilli (हरी मिर्च / मिरची)",
    botanicalClass: "Dicotyledonae (Solanaceae)",
    leafMorphology: "Simple lanceolate spear-shaped blade with pointed acuminate apex",
    marginType: "Entire, completely smooth margin without teeth or lobes",
    aspectRatioDescriptor: "Slender Lanceolate (1.8 : 1 to 3.0 : 1)",
    typicalElongation: 2.5,
    marginRoughness: 22,
    greenTone: "Glossy Vibrant Emerald (RGB 22, 163, 74)",
    realPhotoUrl: "images/healthy_crops/chilli_healthy.jpg",
    realPhotoDescription: "Real farm photo of healthy Chilli pepper leaf with glossy lanceolate surface, intact pointed tip, and zero viral curling.",
    healthyBiomarkers: { green: 97, necrotic: 1, chlorosis: 2, powdery: 0, rust: 0 },
    healthyTraits: [
      "Glossy epidermal reflection and smooth entire borders",
      "Uniform deep green chlorophyll without mosaic mottling",
      "Un-puckered, un-cupped leaf blade (no Begomovirus / thrips distortion)",
      "Absence of water-soaked bacterial speckles or anthracnose spots"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refChilli" cx="45%" cy="30%" r="70%">
          <stop offset="0%" stop-color="#4ade80" />
          <stop offset="45%" stop-color="#16a34a" />
          <stop offset="85%" stop-color="#15803d" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,10 C 140,48 148,115 126,174 C 114,190 106,195 100,195 C 94,195 86,190 74,174 C 52,115 60,48 100,10 Z" fill="url(#refChilli)" stroke="#15803d" stroke-width="2"/>
      <path d="M 100,14 L 100,192" stroke="#86efac" stroke-width="2.2" opacity="0.85"/>
      <path d="M 100,52 Q 120,45 134,58 M 100,52 Q 80,45 66,58" stroke="#86efac" stroke-width="1.4" opacity="0.65"/>
      <path d="M 100,92 Q 125,82 136,100 M 100,92 Q 75,82 64,100" stroke="#86efac" stroke-width="1.4" opacity="0.65"/>
      <path d="M 100,132 Q 118,124 126,140 M 100,132 Q 82,124 74,140" stroke="#86efac" stroke-width="1.2" opacity="0.65"/>
      <ellipse cx="90" cy="55" rx="6" ry="18" fill="rgba(255,255,255,0.22)" transform="rotate(-15 90 55)"/>
    </svg>`
  },
  potato: {
    cropKey: "potato",
    cropName: "Potato (आलू / बटाटा)",
    botanicalClass: "Dicotyledonae (Solanaceae)",
    leafMorphology: "Compound pinnate leaf with broad rounded ovate leaflets",
    marginType: "Smooth to gently undulating broad margin",
    aspectRatioDescriptor: "Broad Ovate / Rounded (1.1 : 1 to 1.6 : 1)",
    typicalElongation: 1.35,
    marginRoughness: 32,
    greenTone: "Matte Olive Green (RGB 20, 83, 45)",
    realPhotoUrl: "images/healthy_crops/potato_healthy.jpg",
    realPhotoDescription: "Real field photo of healthy Potato compound leaf with broad rounded ovate leaflets in natural open sunlight.",
    healthyBiomarkers: { green: 95, necrotic: 1, chlorosis: 4, powdery: 0, rust: 0 },
    healthyTraits: [
      "Broad ovate lamina providing maximum solar absorption",
      "Intact veins without black water-soaked necrosis",
      "Velvety matte puberulent surface without mildew coating",
      "Zero concentric target rings or marginal collapse"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refPotato" cx="45%" cy="38%" r="62%">
          <stop offset="0%" stop-color="#4ade80" />
          <stop offset="50%" stop-color="#15803d" />
          <stop offset="100%" stop-color="#0f3d1e" />
        </radialGradient>
      </defs>
      <path d="M 100,16 C 158,30 178,85 162,145 C 145,178 115,190 100,195 C 85,190 55,178 38,145 C 22,85 42,30 100,16 Z" fill="url(#refPotato)" stroke="#14532d" stroke-width="2"/>
      <path d="M 100,20 L 100,192" stroke="#dcfce7" stroke-width="2.5" opacity="0.85"/>
      <path d="M 100,60 Q 132,50 152,68 M 100,60 Q 68,50 48,68" stroke="#dcfce7" stroke-width="1.6" opacity="0.65"/>
      <path d="M 100,105 Q 138,95 155,118 M 100,105 Q 62,95 45,118" stroke="#dcfce7" stroke-width="1.6" opacity="0.65"/>
      <path d="M 100,148 Q 130,140 144,158 M 100,148 Q 70,140 56,158" stroke="#dcfce7" stroke-width="1.4" opacity="0.65"/>
    </svg>`
  },
  rice: {
    cropKey: "rice",
    cropName: "Paddy / Rice (धान / भात)",
    botanicalClass: "Monocotyledonae (Poaceae)",
    leafMorphology: "Extreme linear grass blade with parallel silica striations",
    marginType: "Linear blade with microscopic silica micro-spines",
    aspectRatioDescriptor: "Extreme Linear (4.5 : 1 to 14.0 : 1)",
    typicalElongation: 6.5,
    marginRoughness: 30,
    greenTone: "Jade Green (RGB 21, 128, 61)",
    realPhotoUrl: "images/healthy_crops/rice_healthy.jpg",
    realPhotoDescription: "Real paddy field photo of healthy Rice leaf blade displaying upright linear posture and glistening silica cuticular sheen.",
    healthyBiomarkers: { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: [
      "Rigid upright blade orientation supported by silica matrix",
      "Uniform jade green without diamond-shaped blast lesions",
      "Sharp intact leaf tip without wavy bacterial blight scorch",
      "Vigorous photosynthetic tillering capacity"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="refRice" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#14532d" />
          <stop offset="40%" stop-color="#22c55e" />
          <stop offset="60%" stop-color="#4ade80" />
          <stop offset="100%" stop-color="#15803d" />
        </linearGradient>
      </defs>
      <path d="M 90,10 Q 102,95 92,192 L 108,192 Q 106,95 110,10 Z" fill="url(#refRice)" stroke="#15803d" stroke-width="2"/>
      <line x1="100" y1="12" x2="100" y2="190" stroke="#ecfdf5" stroke-width="1.8" opacity="0.9"/>
      <line x1="95" y1="20" x2="95" y2="185" stroke="#bbf7d0" stroke-width="0.8" opacity="0.6"/>
      <line x1="105" y1="20" x2="105" y2="185" stroke="#bbf7d0" stroke-width="0.8" opacity="0.6"/>
    </svg>`
  },
  wheat: {
    cropKey: "wheat",
    cropName: "Wheat (गेहूं / गहू)",
    botanicalClass: "Monocotyledonae (Poaceae)",
    leafMorphology: "Slender linear flag blade with parallel venation",
    marginType: "Smooth linear margin",
    aspectRatioDescriptor: "Slender Grass Blade (4.0 : 1 to 12.0 : 1)",
    typicalElongation: 5.8,
    marginRoughness: 28,
    greenTone: "Vibrant Spring Green (RGB 22, 163, 74)",
    realPhotoUrl: "images/healthy_crops/wheat_healthy.jpg",
    realPhotoDescription: "Real field photo of healthy Wheat flag leaf with vibrant spring-green linear blade and zero rust pustules.",
    healthyBiomarkers: { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: [
      "Clean parallel venation devoid of yellow or orange rust pustules",
      "Full chlorophyll density on flag leaf for grain filling",
      "Absence of powdery mildew white patches",
      "Uniform turgid photosynthetic blade"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="refWheat" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stop-color="#15803d" />
          <stop offset="50%" stop-color="#4ade80" />
          <stop offset="100%" stop-color="#14532d" />
        </linearGradient>
      </defs>
      <path d="M 92,10 Q 104,95 90,192 L 110,192 Q 104,95 108,10 Z" fill="url(#refWheat)" stroke="#15803d" stroke-width="2"/>
      <line x1="100" y1="12" x2="100" y2="190" stroke="#dcfce7" stroke-width="1.8" opacity="0.85"/>
      <line x1="96" y1="25" x2="96" y2="185" stroke="#bbf7d0" stroke-width="0.8" opacity="0.5"/>
      <line x1="104" y1="25" x2="104" y2="185" stroke="#bbf7d0" stroke-width="0.8" opacity="0.5"/>
    </svg>`
  },
  cotton: {
    cropKey: "cotton",
    cropName: "Cotton (कपास / कापूस)",
    botanicalClass: "Dicotyledonae (Malvaceae)",
    leafMorphology: "Broad cordate leaf with 3 to 5 deeply pointed palmate lobes",
    marginType: "Deeply lobed palmate margin (Characteristic 3-5 pointed lobes)",
    aspectRatioDescriptor: "Palmate / Star-shaped (1.0 : 1 to 1.4 : 1)",
    typicalElongation: 1.15,
    marginRoughness: 58,
    greenTone: "Deep Leaf Green (RGB 21, 128, 61)",
    realPhotoUrl: "images/healthy_crops/cotton_healthy.jpg",
    realPhotoDescription: "Real cotton field photo of healthy 3-to-5 lobed palmate leaf with distinct cordate lobes and clear venation.",
    healthyBiomarkers: { green: 94, necrotic: 2, chlorosis: 4, powdery: 0, rust: 0 },
    healthyTraits: [
      "Fully expanded 3-to-5 lobed palmate geometry",
      "Absence of vein-delimited angular dark bacterial spots",
      "Intact glandular trichomes and clean lower leaf surface",
      "No grey-white powdery mildew dusting between veinlets"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refCotton" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="#4ade80" />
          <stop offset="65%" stop-color="#16a34a" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,18 C 136,22 162,52 168,92 C 172,122 152,148 156,178 C 126,168 112,184 100,190 C 88,184 74,168 44,178 C 48,148 28,122 32,92 C 38,52 64,22 100,18 Z" fill="url(#refCotton)" stroke="#14532d" stroke-width="2"/>
      <path d="M 100,22 L 100,186 M 100,92 L 158,78 M 100,92 L 42,78" stroke="#86efac" stroke-width="2.2" opacity="0.7"/>
    </svg>`
  },
  groundnut: {
    cropKey: "groundnut",
    cropName: "Groundnut / Soybean (मूंगफली / सोयाबीन)",
    botanicalClass: "Dicotyledonae (Fabaceae)",
    leafMorphology: "Tetrafoliolate pinnate leaf with obovate to oval leaflets",
    marginType: "Smooth, entire rounded margin",
    aspectRatioDescriptor: "Obovate / Elliptical (1.2 : 1 to 1.8 : 1)",
    typicalElongation: 1.45,
    marginRoughness: 26,
    greenTone: "Bright Meadow Green (RGB 34, 197, 94)",
    realPhotoUrl: "images/healthy_crops/groundnut_healthy.jpg",
    realPhotoDescription: "Real field photo of healthy Groundnut / Peanut plant showing clean 4-leaflet tetrafoliolate structure and zero Tikka spots.",
    healthyBiomarkers: { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: [
      "Symmetric obovate leaflets with rounded tips",
      "Zero circular dark brown Tikka spots with yellow halos",
      "Active nitrogen-fixing dark green leaf pigmentation",
      "Clean petiole attachment without early defoliation"
    ],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="refGroundnut" cx="45%" cy="35%" r="65%">
          <stop offset="0%" stop-color="#86efac" />
          <stop offset="45%" stop-color="#22c55e" />
          <stop offset="100%" stop-color="#14532d" />
        </radialGradient>
      </defs>
      <path d="M 100,16 C 145,25 168,75 152,142 C 138,172 114,188 100,192 C 86,188 62,172 48,142 C 32,75 55,25 100,16 Z" fill="url(#refGroundnut)" stroke="#15803d" stroke-width="2"/>
      <path d="M 100,20 L 100,188" stroke="#dcfce7" stroke-width="2" opacity="0.85"/>
      <path d="M 100,60 Q 128,52 144,68 M 100,60 Q 72,52 56,68" stroke="#dcfce7" stroke-width="1.4" opacity="0.65"/>
      <path d="M 100,105 Q 132,95 146,115 M 100,105 Q 68,95 54,115" stroke="#dcfce7" stroke-width="1.4" opacity="0.65"/>
    </svg>`
  },
  cabbage: {
    cropKey: "cabbage",
    cropName: "Cabbage (पत्ता गोभी)",
    botanicalClass: "Dicotyledonae (Brassicaceae)",
    leafMorphology: "Broad waxy glaucous cupped leaves forming compact spherical heads",
    marginType: "Entire, slightly undulated with thick fleshy veins",
    aspectRatioDescriptor: "Suborbicular cupped blade (1.0 : 1 to 1.3 : 1)",
    typicalElongation: 1.15,
    marginRoughness: 26,
    greenTone: "Waxy Blue-Green Glaucous",
    realPhotoUrl: "images/healthy_crops/cabbage_healthy.jpg",
    realPhotoDescription: "Healthy head cabbage with thick blue-green waxy foliage free of black rot.",
    healthyBiomarkers: { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: ["Clean waxy bloom", "Intact cupped leaf margins", "Zero black rot lesions"],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg"><circle cx="100" cy="100" r="80" fill="#22c55e" opacity="0.85"/><circle cx="100" cy="100" r="60" fill="#86efac" opacity="0.6"/></svg>`
  },
  cauliflower: {
    cropKey: "cauliflower",
    cropName: "Cauliflower (फूल गोभी)",
    botanicalClass: "Dicotyledonae (Brassicaceae)",
    leafMorphology: "Erect oblong glaucous leaves with prominent white midrib embracing the curd",
    marginType: "Entire to shallowly sinuate",
    aspectRatioDescriptor: "Oblong lanceolate blade (2.0 : 1 to 2.8 : 1)",
    typicalElongation: 2.3,
    marginRoughness: 28,
    greenTone: "Glaucous Sage Green",
    realPhotoUrl: "images/healthy_crops/cauliflower_healthy.jpg",
    realPhotoDescription: "Vigorous cauliflower with upright waxy leaves shielding compact white curd.",
    healthyBiomarkers: { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: ["Firm upright leaves", "Prominent ivory midrib", "Zero downy mildew"],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg"><path d="M 100,20 C 140,50 150,150 100,190 C 50,150 60,50 100,20 Z" fill="#15803d"/><circle cx="100" cy="110" r="35" fill="#f8fafc"/></svg>`
  },
  marigold: {
    cropKey: "marigold",
    cropName: "Marigold (गेंदा / झेंडू)",
    botanicalClass: "Dicotyledonae (Asteraceae)",
    leafMorphology: "Pinnatisect dissected aromatic leaflets with glandular dots",
    marginType: "Serrated to sharply dentate",
    aspectRatioDescriptor: "Pinnately dissected (2.2 : 1 to 3.5 : 1)",
    typicalElongation: 2.8,
    marginRoughness: 42,
    greenTone: "Deep Lustrous Forest Green",
    realPhotoUrl: "images/healthy_crops/marigold_healthy.jpg",
    realPhotoDescription: "Healthy marigold foliage with deeply dissected dark green leaves and sturdy buds.",
    healthyBiomarkers: { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: ["Serrated pinnate leaflets", "Strong aromatic glands", "Zero Alternaria blight"],
    svg: `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg"><path d="M 100,20 L 100,185" stroke="#15803d" stroke-width="3"/><circle cx="100" cy="50" r="24" fill="#f59e0b"/></svg>`
  }
};

// Unified Healthy Crop Reference Models: Combines core detailed models with all 82+ crops from allCropsHealthyReferenceModels
const healthyCropReferenceModels = exports.healthyCropReferenceModels = {
  ...allCropsHealthyReferenceModels,
  ...coreHealthyCropReferenceModels
};

const cropAliases = {
  'sarson': 'mustard', 'rai': 'mustard', 'mustard': 'mustard', 'chana': 'chickpea', 'harbara': 'chickpea',
  'gram': 'chickpea', 'chickpea': 'chickpea', 'ganna': 'sugarcane', 'uus': 'sugarcane', 'sugarcane': 'sugarcane',
  'tamatar': 'tomato', 'tomato': 'tomato', 'aloo': 'potato', 'alu': 'potato', 'batata': 'potato', 'potato': 'potato',
  'paddy': 'rice', 'dhan': 'rice', 'chawal': 'rice', 'rice': 'rice', 'bhaat': 'rice',
  'gehu': 'wheat', 'gehun': 'wheat', 'gahu': 'wheat', 'wheat': 'wheat', 'kapas': 'cotton', 'kapus': 'cotton', 'cotton': 'cotton',
  'makka': 'maize', 'maka': 'maize', 'corn': 'maize', 'maize': 'maize', 'mirch': 'chilli', 'mirchi': 'chilli',
  'pepper': 'chilli', 'chilli': 'chilli', 'chili': 'chilli', 'mungphali': 'groundnut', 'bhuimug': 'groundnut',
  'peanut': 'groundnut', 'groundnut': 'groundnut', 'soybean': 'soybean', 'soya': 'soybean',
  'kanda': 'onion', 'pyaz': 'onion', 'onion': 'onion', 'lahsun': 'garlic', 'garlic': 'garlic',
  'baingan': 'brinjal', 'vange': 'brinjal', 'brinjal': 'brinjal', 'eggplant': 'brinjal',
  'bhindi': 'okra', 'bhendi': 'okra', 'okra': 'okra', 'kela': 'banana', 'banana': 'banana',
  'aam': 'mango', 'mango': 'mango', 'haldi': 'turmeric', 'turmeric': 'turmeric',
  'adrak': 'ginger', 'ale': 'ginger', 'ginger': 'ginger', 'seb': 'apple', 'apple': 'apple',
  'angoor': 'grapes', 'grape': 'grapes', 'grapes': 'grapes', 'jowar': 'jowar', 'sorghum': 'jowar',
  'bajra': 'bajra', 'pearl-millet': 'bajra', 'ragi': 'ragi', 'nachni': 'ragi', 'finger-millet': 'ragi',
  'tur': 'pigeon-pea', 'arhar': 'pigeon-pea', 'pigeon-pea': 'pigeon-pea', 'moong': 'green-gram', 'green-gram': 'green-gram',
  'urad': 'black-gram', 'black-gram': 'black-gram', 'sunflower': 'sunflower', 'surajmukhi': 'sunflower',
  'sesame': 'sesame', 'til': 'sesame', 'tea': 'tea', 'chai': 'tea', 'coffee': 'coffee', 'watermelon': 'watermelon',
  'tarbooj': 'watermelon', 'kalingad': 'watermelon',
  'aloe': 'aloe-vera', 'aloe-vera': 'aloe-vera',
  'arecanut': 'areca-palm', 'areca': 'areca-palm', 'areca-palm': 'areca-palm', 'supari': 'areca-palm',
  'blackpepper': 'black-pepper', 'black-pepper': 'black-pepper', 'kalimirch': 'black-pepper',
  'cardamom': 'small-cardamom', 'small-cardamom': 'small-cardamom', 'elaichi': 'small-cardamom',
  'fenugreek': 'fenugreek-leaves', 'methi': 'fenugreek-leaves', 'fenugreek-leaves': 'fenugreek-leaves',
  'cabbage': 'cabbage', 'patta-gobhi': 'cabbage', 'bandhgobi': 'cabbage',
  'cauliflower': 'cauliflower', 'phool-gobhi': 'cauliflower', 'gobhi': 'cauliflower',
  'marigold': 'marigold', 'genda': 'marigold', 'zendu': 'marigold'
};


// ============================================================================
// AGROSENSE ENTERPRISE TENSORFLOW.JS PLANT PATHOLOGY INFERENCE ENGINE
// Real On-Device Deep Learning Inference (MobileNet V1 56-Class Architecture)
// ============================================================================

/**
 * Verified Supported Crop Species in AgroSense Multi-Crop Pathology Model
 * Full end-to-end trained support for 18 botanical species and 56 disease classes.
 */
const SUPPORTED_CROP_REGISTRY = {
  'apple': { key: 'apple', name: 'Apple (सेब)', icon: '🍎', species: 'Malus domestica', classes: [0, 1, 2, 3] },
  'blueberry': { key: 'blueberry', name: 'Blueberry (ब्लूबेरी)', icon: '🫐', species: 'Vaccinium corymbosum', classes: [4] },
  'cherry': { key: 'cherry', name: 'Cherry (चेरी)', icon: '🍒', species: 'Prunus cerasus', classes: [5, 6] },
  'maize': { key: 'maize', name: 'Maize / Corn (मक्का / मका)', icon: '🌽', species: 'Zea mays', classes: [7, 8, 9, 10] },
  'grape': { key: 'grape', name: 'Grape (अंगूर / द्राक्षे)', icon: '🍇', species: 'Vitis vinifera', classes: [11, 12, 13, 14] },
  'orange': { key: 'orange', name: 'Orange / Citrus (संतरा)', icon: '🍊', species: 'Citrus sinensis', classes: [15] },
  'peach': { key: 'peach', name: 'Peach (आड़ू)', icon: '🍑', species: 'Prunus persica', classes: [16, 17] },
  'pepper_bell': { key: 'pepper_bell', name: 'Bell Pepper / Capsicum (शिमला मिर्च)', icon: '🫑', species: 'Capsicum annuum var. grossum', classes: [18, 19] },
  'potato': { key: 'potato', name: 'Potato (आलू / बटाटा)', icon: '🥔', species: 'Solanum tuberosum', classes: [20, 21, 22] },
  'raspberry': { key: 'raspberry', name: 'Raspberry (रास्पबेरी)', icon: '🫐', species: 'Rubus idaeus', classes: [23] },
  'soybean': { key: 'soybean', name: 'Soybean (सोयाबीन)', icon: '🌱', species: 'Glycine max', classes: [24], healthyOnly: true },
  'squash': { key: 'squash', name: 'Squash (कद्दू)', icon: '🎃', species: 'Cucurbita pepo', classes: [25] },
  'strawberry': { key: 'strawberry', name: 'Strawberry (स्ट्रॉबेरी)', icon: '🍓', species: 'Fragaria ananassa', classes: [26, 27] },
  'tomato': { key: 'tomato', name: 'Tomato (टमाटर / टोमॅटो)', icon: '🍅', species: 'Solanum lycopersicum', classes: [28, 29, 30, 31, 32, 33, 34, 35, 36, 37] },
  'cotton': { key: 'cotton', name: 'Cotton (कपास / कापूस)', icon: '🌾', species: 'Gossypium hirsutum', classes: [38, 39, 40, 41, 42] },
  'wheat': { key: 'wheat', name: 'Wheat (गेहूं / गहू)', icon: '🌾', species: 'Triticum aestivum', classes: [43, 44, 45, 46] },
  'rice': { key: 'rice', name: 'Rice / Paddy (धान / तांदूळ)', icon: '🌾', species: 'Oryza sativa', classes: [47, 48, 49, 50] },
  'chilli': { key: 'chilli', name: 'Chilli Pepper (मिर्च / मिरची)', icon: '🌶️', species: 'Capsicum annuum', classes: [51, 52, 53, 54, 55] }
};
exports.SUPPORTED_CROP_REGISTRY = SUPPORTED_CROP_REGISTRY;

function normalizeCropKey(rawKey) {
  if (!rawKey || typeof rawKey !== 'string') return 'all';
  const k = rawKey.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
  if (k === 'all') return 'all';
  if (k === 'corn' || k === 'makka' || k === 'maka' || k === 'maize') return 'maize';
  if (k === 'tamatar' || k === 'tomato') return 'tomato';
  if (k === 'aloo' || k === 'alu' || k === 'batata' || k === 'potato') return 'potato';
  if (k === 'bell_pepper' || k === 'pepper_bell' || k === 'bellpepper' || k === 'capsicum' || k === 'shimla' || k === 'shimla_mirch') return 'pepper_bell';
  if (k === 'soya' || k === 'soybean' || k === 'soya_bean') return 'soybean';
  if (k === 'apple' || k === 'seb') return 'apple';
  if (k === 'grape' || k === 'grapes' || k === 'angoor') return 'grape';
  if (k === 'orange' || k === 'citrus' || k === 'santra' || k === 'mosambi') return 'orange';
  if (k === 'peach' || k === 'aadoo' || k === 'aadu') return 'peach';
  if (k === 'cherry') return 'cherry';
  if (k === 'blueberry') return 'blueberry';
  if (k === 'raspberry') return 'raspberry';
  if (k === 'squash' || k === 'kaddu') return 'squash';
  if (k === 'strawberry') return 'strawberry';
  if (k === 'cotton' || k === 'kapas' || k === 'kapus') return 'cotton';
  if (k === 'wheat' || k === 'gehun' || k === 'gehu' || k === 'gahu') return 'wheat';
  if (k === 'rice' || k === 'paddy' || k === 'dhan' || k === 'chawal' || k === 'tandul') return 'rice';
  if (k === 'chilli' || k === 'chili' || k === 'mirch' || k === 'mirchi') return 'chilli';
  return k;
}
exports.normalizeCropKey = normalizeCropKey;

/**
 * 38 Verified PlantVillage Classes with Full ICAR / Extension Agronomic Data
 */
const PLANTVILLAGE_CLASSES = [
  {
    idx: 0, raw: 'Apple___Apple_scab', cropKey: 'apple', cropName: 'Apple (सेब)',
    diseaseId: 'apple-scab', diseaseName: 'Apple Scab (Venturia inaequalis)', commonName: 'Apple Scab',
    scientificName: 'Venturia inaequalis', vernacularName: 'सेब का पपड़ी रोग (Apple Scab)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Olive-green to black velvety spots on leaves', 'Distorted, crinkled leaf margins with premature yellowing and drop', 'Scabby corky lesions on developing fruit'],
    culturalMeasures: ['Rake and destroy or chop fallen infected leaves in autumn to reduce overwintering pseudothecia.', 'Prune tree canopy annually to promote rapid drying of foliage after rain.'],
    biologicalControl: ['Foliar spray of Trichoderma viride @ 5g/L water during pre-bloom stage.', 'Apply copper soap or potassium bicarbonate sprays @ 3g/L.'],
    chemicalControl: [{ chemical: 'Captan 50% WP', dosage: '2.5 g / Liter water', timing: 'Protective spray at green tip stage and petal fall.' }, { chemical: 'Difenoconazole 25% EC', dosage: '0.5 ml / Liter water', timing: 'Curative kickback spray within 72 hours of rain.' }],
    preventiveCare: ['Plant scab-resistant cultivars such as Liberty, Prima, and Enterprise.', 'Avoid overhead sprinkler watering of orchard canopies.']
  },
  {
    idx: 1, raw: 'Apple___Black_rot', cropKey: 'apple', cropName: 'Apple (सेब)',
    diseaseId: 'apple-black-rot', diseaseName: 'Black Rot (Botryosphaeria obtusa)', commonName: 'Black Rot / Frogeye Leaf Spot',
    scientificName: 'Botryosphaeria obtusa', vernacularName: 'काला सड़न रोग (Black Rot)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'High',
    symptoms: ['Circular purple spots on leaves expanding to brown with purple borders (frogeye)', 'Dark sunken necrotic cankers on twigs and limbs', 'Firm black rot on maturing fruits with concentric rings'],
    culturalMeasures: ['Prune out all dead wood, fire blight strikes, and mummified fruits before bud break.', 'Paint pruning cuts with Bordeaux paste.'],
    biologicalControl: ['Foliar application of Bacillus subtilis @ 4g/L on canopy.', 'Apply 2% cold-pressed neem oil.'],
    chemicalControl: [{ chemical: 'Thiophanate-methyl 70% WP', dosage: '1.0 g / Liter water', timing: 'Apply at tight cluster and petal fall.' }, { chemical: 'Mancozeb 75% WP', dosage: '2.5 g / Liter water', timing: 'Cover sprays every 10-14 days during wet spring.' }],
    preventiveCare: ['Keep trees vigorous with balanced fertilization, avoiding excess nitrogen.', 'Remove mummified fruits from previous harvest.']
  },
  {
    idx: 2, raw: 'Apple___Cedar_apple_rust', cropKey: 'apple', cropName: 'Apple (सेब)',
    diseaseId: 'apple-cedar-rust', diseaseName: 'Cedar Apple Rust (Gymnosporangium juniperi-virginianae)', commonName: 'Cedar Apple Rust',
    scientificName: 'Gymnosporangium juniperi-virginianae', vernacularName: 'देवदार सेब रतुआ (Cedar Apple Rust)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Bright yellow-orange circular spots on upper leaf surfaces', 'Small black pycnia appearing in spot centers', 'Cluster cups (aecia) on leaf undersides releasing spores'],
    culturalMeasures: ['Eradicate Eastern red cedar or juniper trees within 500 meters of orchard if feasible.', 'Prune out cedar galls from nearby ornamental junipers in late winter.'],
    biologicalControl: ['Apply sulfur dust or wettable sulfur (3g/L) during pink to petal fall stage.'],
    chemicalControl: [{ chemical: 'Myclobutanil 10% WP', dosage: '1.0 g / Liter water', timing: 'Apply at pink bud and continue every 10-14 days through bloom.' }, { chemical: 'Mancozeb 75% WP', dosage: '2.5 g / Liter water', timing: 'Protective barrier spray before expected spring rainfall.' }],
    preventiveCare: ['Plant rust-resistant apple varieties (e.g. Enterprise, Liberty, Freedom).']
  },
  {
    idx: 3, raw: 'Apple___healthy', cropKey: 'apple', cropName: 'Apple (सेब)',
    diseaseId: 'apple-healthy', diseaseName: 'Healthy Apple Leaf (No Pathogen Detected)', commonName: 'Healthy Apple Foliage',
    scientificName: 'Malus domestica', vernacularName: 'स्वस्थ सेब पत्ती (Healthy Apple)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Deep uniform green elliptical leaves with serrate margins', 'Glossy upper epidermis with zero necrotic spotting or rust cups', 'Turgid petioles and vigorous shoot growth'],
    culturalMeasures: ['Maintain scheduled orchard pruning for light penetration.', 'Maintain drip irrigation at root zone during fruit sizing.'],
    biologicalControl: ['Routine application of mycorrhizal fungi in root trenching for nutrient uptake.'],
    chemicalControl: [], preventiveCare: ['Continue standard integrated orchard management schedule.']
  },
  {
    idx: 4, raw: 'Blueberry___healthy', cropKey: 'blueberry', cropName: 'Blueberry (ब्लूबेरी)',
    diseaseId: 'blueberry-healthy', diseaseName: 'Healthy Blueberry Leaf (No Pathogen Detected)', commonName: 'Healthy Blueberry Foliage',
    scientificName: 'Vaccinium corymbosum', vernacularName: 'स्वस्थ ब्लूबेरी पत्ती (Healthy Blueberry)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Clean vibrant ovate leaves with intact cuticle', 'Uniform deep chlorophyll pigmentation', 'Zero anthracnose or mummy berry signs'],
    culturalMeasures: ['Maintain acidic soil pH (4.5 - 5.5) using pine bark mulch and elemental sulfur.', 'Ensure consistent soil moisture without waterlogging.'],
    biologicalControl: ['Beneficial mycorrhizal root inoculation.'], chemicalControl: [],
    preventiveCare: ['Monitor soil pH and maintain pine bark mulch layer.']
  },
  {
    idx: 5, raw: 'Cherry_(including_sour)___Powdery_mildew', cropKey: 'cherry', cropName: 'Cherry (चेरी)',
    diseaseId: 'cherry-powdery-mildew', diseaseName: 'Powdery Mildew (Podosphaera clandestina)', commonName: 'Cherry Powdery Mildew',
    scientificName: 'Podosphaera clandestina', vernacularName: 'चेरी चूर्णिल आसिता (Powdery Mildew)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['White talcum-powder-like mycelial patches on lower leaf surface', 'Upward curling and distortion of young terminal leaves', 'Infected leaves become brittle and fall prematurely'],
    culturalMeasures: ['Prune canopies to improve air circulation and sunlight penetration.', 'Cease excessive vegetative nitrogen applications.'],
    biologicalControl: ['Spray Ampelomyces quisqualis hyperparasitic bio-agent.', 'Apply potassium silicate or neem oil 2% @ 5ml/L water.'],
    chemicalControl: [{ chemical: 'Tebuconazole 25.9% EC', dosage: '1.0 ml / Liter water', timing: 'Apply at petal fall and shuck fall.' }, { chemical: 'Wettable Sulfur 80% WDG', dosage: '3.0 g / Liter water', timing: 'Prophylactic protective spray during warm dry weather.' }],
    preventiveCare: ['Manage canopy humidity and avoid late season overhead irrigation.']
  },
  {
    idx: 6, raw: 'Cherry_(including_sour)___healthy', cropKey: 'cherry', cropName: 'Cherry (चेरी)',
    diseaseId: 'cherry-healthy', diseaseName: 'Healthy Cherry Leaf (No Pathogen Detected)', commonName: 'Healthy Cherry Foliage',
    scientificName: 'Prunus cerasus', vernacularName: 'स्वस्थ चेरी पत्ती (Healthy Cherry)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Clean serrated ovate leaves with rich green pigmentation', 'Zero fungal mildew or shot-hole lesions', 'Sturdy petioles and productive fruiting spurs'],
    culturalMeasures: ['Maintain balanced irrigation during pit-hardening and fruit enlargement stages.'],
    biologicalControl: ['Maintain orchard groundcover to shelter predatory mites.'], chemicalControl: [],
    preventiveCare: ['Monitor weekly for early signs of leaf spot or powdery mildew.']
  },
  {
    idx: 7, raw: 'Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot', cropKey: 'maize', cropName: 'Maize / Corn (मक्का / मका)',
    diseaseId: 'maize-gray-leaf-spot', diseaseName: 'Gray Leaf Spot (Cercospora zeae-maydis)', commonName: 'Gray Leaf Spot',
    scientificName: 'Cercospora zeae-maydis', vernacularName: 'मक्के का धूसर पत्ती धब्बा (Gray Leaf Spot)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Small tan spots with yellow halos expanding into long, narrow rectangular lesions restricted by veins', 'Mature lesions take on a distinct gray cast under humid conditions', 'Severe blight causes premature lodging and grain-fill failure'],
    culturalMeasures: ['Rotate out of corn for 1-2 seasons to allow residue decomposition.', 'Perform deep tillage in continuous-corn fields to bury infected stalk debris.'],
    biologicalControl: ['Foliar application of Trichoderma viride @ 5g/L water at V6-V8 stage.', 'Spray Pseudomonas fluorescens @ 10g/L.'],
    chemicalControl: [{ chemical: 'Azoxystrobin 18.2% + Difenoconazole 11.4% SC', dosage: '1.0 ml / Liter water', timing: 'Apply at VT to R1 (tasseling to silking) when lesions reach third leaf below ear.' }, { chemical: 'Pyraclostrobin 20% WG', dosage: '1.0 g / Liter water', timing: 'Curative translaminar protection at first sign of rectangular lesions.' }],
    preventiveCare: ['Select hybrids with high Cercospora disease resistance ratings.', 'Avoid planting excessively high plant densities in humid bottomlands.']
  },
  {
    idx: 8, raw: 'Corn_(maize)___Common_rust_', cropKey: 'maize', cropName: 'Maize / Corn (मक्का / मका)',
    diseaseId: 'maize-common-rust', diseaseName: 'Common Rust (Puccinia sorghi)', commonName: 'Common Rust',
    scientificName: 'Puccinia sorghi', vernacularName: 'मक्के का गेरुआ / रतुआ (Common Rust / Tambera)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Golden-brown to cinnamon-brown powdery eruptive pustules on both upper and lower leaf surfaces', 'Pustules rupture the epidermis releasing dusty urediniospores', 'Late season pustules turn dark black as winter teliospores form'],
    culturalMeasures: ['Plant early in the season to evade southward spore-bearing storm fronts.', 'Ensure balanced nitrogen-potash nutrition; avoid excessive soft lush growth.'],
    biologicalControl: ['Foliar spray of cold-pressed Neem oil (3000 ppm) @ 3 ml/L water.', 'Apply Bacillus subtilis @ 4g/L at early vegetative stage.'],
    chemicalControl: [{ chemical: 'Azoxystrobin 23% SC', dosage: '1.0 ml / Liter water', timing: 'Spray when 6 pustules per leaf appear on lower leaves before silking.' }, { chemical: 'Mancozeb 75% WP', dosage: '2.5 g / Liter water', timing: 'Basal protective cover spray during cool humid weather.' }, { chemical: 'Propiconazole 25% EC', dosage: '1.0 ml / Liter water', timing: 'Systemic curative spray at early stage of outbreak.' }],
    preventiveCare: ['Plant certified rust-resistant maize hybrids (e.g. PAC-751, Pioneer hybrids).', 'Monitor weather alerts for cool (16-25°C) and humid (>95% RH) conditions.']
  },
  {
    idx: 9, raw: 'Corn_(maize)___Northern_Leaf_Blight', cropKey: 'maize', cropName: 'Maize / Corn (मक्का / मका)',
    diseaseId: 'maize-leaf-blight', diseaseName: 'Northern Corn Leaf Blight (Exserohilum turcicum)', commonName: 'Northern Leaf Blight',
    scientificName: 'Exserohilum turcicum', vernacularName: 'मक्के का तुर्सिकम अंगमारी (Turcicum Leaf Blight)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'High',
    symptoms: ['Large, cigar-shaped elongated grayish-green to tan lesions (2.5 to 15 cm long)', 'Dark olive-green to black fungal spore fuzz inside lesions during damp weather', 'Lesions coalesce causing complete foliage scorched appearance'],
    culturalMeasures: ['Incorporate crop residue by deep tillage immediately after harvest.', 'Implement 2-year crop rotation with non-host crops (soybean, cotton, sunflower).'],
    biologicalControl: ['Foliar application of Trichoderma harzianum @ 5g/L water at 45 days after sowing.', 'Seed treatment with Pseudomonas fluorescens @ 10g/kg seed.'],
    chemicalControl: [{ chemical: 'Mancozeb 75% WP', dosage: '2.5 g / Liter water', timing: 'Apply first spray at knee-high stage upon first cigar lesion appearance.' }, { chemical: 'Azoxystrobin 18.2% + Difenoconazole 11.4% SC', dosage: '1.0 ml / Liter water', timing: 'Systemic foliar spray for advanced blighting.' }],
    preventiveCare: ['Plant resistant hybrid varieties with Ht1, Ht2, or HtN resistance genes.', 'Maintain recommended plant spacing (60 x 20 cm) for air flow.']
  },
  {
    idx: 10, raw: 'Corn_(maize)___healthy', cropKey: 'maize', cropName: 'Maize / Corn (मक्का / मका)',
    diseaseId: 'maize-healthy', diseaseName: 'Healthy Maize Leaf (No Pathogen Detected)', commonName: 'Healthy Maize Foliage',
    scientificName: 'Zea mays', vernacularName: 'स्वस्थ मक्का पत्ती (Healthy Maize Foliage)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Vibrant deep-green linear blade with prominent ivory midrib', 'Smooth intact leaf margin with zero necrotic spotting or fungal pustules', 'Sturdy upright erect posture maximizing solar radiation capture'],
    culturalMeasures: ['Apply split nitrogen application: 50% basal, 25% at knee-high stage, 25% at tasseling.', 'Maintain critical soil moisture during tasseling and grain-fill.'],
    biologicalControl: ['Apply mycorrhizal bio-fertilizers at sowing to promote deep root system.'], chemicalControl: [],
    preventiveCare: ['Scout weekly during whorl to grain-filling stages.']
  },
  {
    idx: 11, raw: 'Grape___Black_rot', cropKey: 'grape', cropName: 'Grape (अंगूर / द्राक्षे)',
    diseaseId: 'grape-black-rot', diseaseName: 'Grape Black Rot (Guignardia bidwellii)', commonName: 'Grape Black Rot',
    scientificName: 'Guignardia bidwellii', vernacularName: 'अंगूर काला सड़न (Black Rot)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'High',
    symptoms: ['Circular reddish-brown leaf spots with dark margins and tiny black dots (pycnidia)', 'Sunken black cankers on new shoots and leaf petioles', 'Berries turn brown, shrivel rapidly into hard, wrinkled black mummies'],
    culturalMeasures: ['Destroy all mummified berries from vines and ground during winter pruning.', 'Canopy management: tuck shoots and pull basal leaves to increase sunlight.'],
    biologicalControl: ['Foliar bio-fungicide sprays of Bacillus amyloliquefaciens @ 4g/L.'],
    chemicalControl: [{ chemical: 'Myclobutanil 10% WP', dosage: '1.0 g / Liter water', timing: 'Crucial sprays from early bloom through 4 weeks post-bloom.' }, { chemical: 'Mancozeb 75% WP', dosage: '2.5 g / Liter water', timing: 'Protective sprays starting when shoots are 3-5 inches long.' }],
    preventiveCare: ['Keep ground clean and maintain trellising for optimal drying.']
  },
  {
    idx: 12, raw: 'Grape___Esca_(Black_Measles)', cropKey: 'grape', cropName: 'Grape (अंगूर / द्राक्षे)',
    diseaseId: 'grape-esca', diseaseName: 'Esca / Black Measles (Phaeomoniella chlamydospora)', commonName: 'Esca (Black Measles)',
    scientificName: 'Phaeomoniella chlamydospora', vernacularName: 'एस्का रोग (Black Measles)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'High',
    symptoms: ['Interveinal chlorosis and necrosis creating a distinctive "tiger-stripe" pattern on leaves', 'Small dark spots on berry skins ("measles") and berry cracking', 'Spongy white heart rot in vine wood and sudden apoplectic vine collapse in hot dry weather'],
    culturalMeasures: ['Disinfect pruning shears with 70% alcohol or 10% bleach between individual vines.', 'Prune vines late in the dormant season when wound healing is rapid.', 'Paint all large pruning cuts with wound sealants containing fungicide.'],
    biologicalControl: ['Apply Trichoderma atroviride to fresh pruning wounds within 24 hours.'],
    chemicalControl: [{ chemical: 'Thiophanate-methyl wound paste', dosage: 'Apply paste directly to cuts', timing: 'Immediately after pruning.' }],
    preventiveCare: ['Avoid water stress and heavy crop loads on infected older vines.']
  },
  {
    idx: 13, raw: 'Grape___Leaf_blight_(Isariopsis_Leaf_Spot)', cropKey: 'grape', cropName: 'Grape (अंगूर / द्राक्षे)',
    diseaseId: 'grape-leaf-blight', diseaseName: 'Leaf Blight / Isariopsis Spot (Pseudocercospora vitis)', commonName: 'Isariopsis Leaf Spot',
    scientificName: 'Pseudocercospora vitis', vernacularName: 'पत्ती झुलसा (Isariopsis Leaf Spot)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Irregular dull brown lesions on upper leaf surfaces', 'Dark olivaceous-black fuzzy fungal fruiting bodies on leaf underside', 'Severe infection leads to early leaf drop and sunburn on fruit clusters'],
    culturalMeasures: ['Collect and burn infected fallen leaves after harvest.', 'Ensure open canopy structure to promote fast drying.'],
    biologicalControl: ['Foliar spray of cold-pressed Neem oil (3000 ppm) @ 3ml/L.'],
    chemicalControl: [{ chemical: 'Copper Oxychloride 50% WP', dosage: '2.5 g / Liter water', timing: 'Protective post-monsoon foliar application.' }, { chemical: 'Azoxystrobin 23% SC', dosage: '1.0 ml / Liter water', timing: 'Apply upon first notice of dark irregular spots.' }],
    preventiveCare: ['Maintain proper vine nutrition, particularly potassium and zinc.']
  },
  {
    idx: 14, raw: 'Grape___healthy', cropKey: 'grape', cropName: 'Grape (अंगूर / द्राक्षे)',
    diseaseId: 'grapes-healthy', diseaseName: 'Healthy Grape Leaf (No Pathogen Detected)', commonName: 'Healthy Grape Foliage',
    scientificName: 'Vitis vinifera', vernacularName: 'स्वस्थ अंगूर पत्ती (Healthy Grape)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Deep emerald-green lobed palmate leaves with sharp dentate teeth', 'Unblemished veins and clean lower leaf surface', 'Vigorous tendril development and uniform shoot extension'],
    culturalMeasures: ['Maintain regulated deficit irrigation (RDI) after veraison.', 'Regular shoot positioning and de-suckering.'],
    biologicalControl: ['Apply bio-fertilizer consortia (Azotobacter + PSB) in root zone.'], chemicalControl: [],
    preventiveCare: ['Routine preventative canopy inspections.']
  },
  {
    idx: 15, raw: 'Orange___Haunglongbing_(Citrus_greening)', cropKey: 'orange', cropName: 'Orange / Citrus (संतरा / मोसंबी)',
    diseaseId: 'citrus-greening', diseaseName: 'Huanglongbing / Citrus Greening (Candidatus Liberibacter)', commonName: 'Citrus Greening (HLB)',
    scientificName: 'Candidatus Liberibacter asiaticus', vernacularName: 'सिट्रस ग्रीनिंग रोग (Citrus Greening)', pathogenType: 'Bacterial Pathogen', isHealthy: false, severity: 'Severe Epidemic',
    symptoms: ['Asymmetric blotchy mottled chlorosis crossing leaf veins', 'Small, upright, leathery leaves with zinc-deficiency-like symptoms', 'Small, lopsided fruit with bitter taste and aborted seeds'],
    culturalMeasures: ['Immediately rogue and burn severely affected, non-productive trees to eliminate inoculum.', 'Plant only certified disease-free nursery saplings grown under insect-proof screenhouses.'],
    biologicalControl: ['Release parasitic wasps (Tamarixia radiata) for biological control of Asian Citrus Psyllid vectors.', 'Spray 2% horticultural mineral oil to suffocate psyllid nymphs.'],
    chemicalControl: [{ chemical: 'Imidacloprid 17.8% SL', dosage: '0.5 ml / Liter water', timing: 'Vector suppression spray targeting psyllids during new flush cycles.' }, { chemical: 'Thiamethoxam 25% WG', dosage: '0.3 g / Liter water', timing: 'Soil drench or foliar spray for systemic vector control.' }],
    preventiveCare: ['Intensive Asian Citrus Psyllid (Diaphorina citri) monitoring with yellow sticky traps.']
  },
  {
    idx: 16, raw: 'Peach___Bacterial_spot', cropKey: 'peach', cropName: 'Peach (आड़ू)',
    diseaseId: 'peach-bacterial-spot', diseaseName: 'Bacterial Spot (Xanthomonas arboricola pv. pruni)', commonName: 'Peach Bacterial Spot',
    scientificName: 'Xanthomonas arboricola pv. pruni', vernacularName: 'आड़ू जीवाणु धब्बा (Bacterial Spot)', pathogenType: 'Bacterial Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Small water-soaked angular spots on leaves turning purple to dark brown', 'Infected tissue drops out giving a "shot-hole" appearance', 'Deep pitted crater-like cankers on fruit exudating gum'],
    culturalMeasures: ['Avoid planting on light sandy soils exposed to high wind and sandblasting.', 'Erect windbreaks around orchard perimeter.'],
    biologicalControl: ['Bacteriophage treatments or Bacillus subtilis foliar sprays.'],
    chemicalControl: [{ chemical: 'Copper Hydroxide 77% WP', dosage: '2.0 g / Liter water', timing: 'Dormant and delayed dormant sprays.' }, { chemical: 'Oxytetracycline 20% WP', dosage: '1.0 g / Liter water', timing: 'Post-bloom cover sprays at 7-day intervals during warm rain.' }],
    preventiveCare: ['Plant resistant peach cultivars (e.g. Clayton, Candor, PF-1).']
  },
  {
    idx: 17, raw: 'Peach___healthy', cropKey: 'peach', cropName: 'Peach (आड़ू)',
    diseaseId: 'peach-healthy', diseaseName: 'Healthy Peach Leaf (No Pathogen Detected)', commonName: 'Healthy Peach Foliage',
    scientificName: 'Prunus persica', vernacularName: 'स्वस्थ आड़ू पत्ती (Healthy Peach)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Glossy lanceolate leaves with fine serrations and rich green pigment', 'Intact lamina with zero shot-hole perforations or bacterial weeping', 'Vigorous terminal shoot growth and strong fruit set'],
    culturalMeasures: ['Maintain open-center vase pruning for sunlight and spray coverage.'],
    biologicalControl: ['Annual compost addition with mycorrhizal fungi.'], chemicalControl: [],
    preventiveCare: ['Inspect trees weekly through spring and summer.']
  },
  {
    idx: 18, raw: 'Pepper,_bell___Bacterial_spot', cropKey: 'pepper_bell', cropName: 'Bell Pepper / Capsicum (शिमला मिर्च)',
    diseaseId: 'pepper-bell-bacterial-spot', diseaseName: 'Bacterial Spot (Xanthomonas campestris pv. vesicatoria)', commonName: 'Bell Pepper Bacterial Spot',
    scientificName: 'Xanthomonas campestris pv. vesicatoria', vernacularName: 'शिमला मिर्च जीवाणु धब्बा (Bacterial Spot)', pathogenType: 'Bacterial Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Small water-soaked blister-like lesions on leaves becoming dark brown with greasy margins', 'Severe defoliation exposing green peppers to sunscald', 'Raised rough warty spots on bell pepper fruits'],
    culturalMeasures: ['Cease overhead sprinkler irrigation; water strictly via sub-surface drip.', 'Rotate fields away from solanaceous crops for at least 2 seasons.', 'Do not cultivate or handle plants when wet with morning dew.'],
    biologicalControl: ['Foliar application of Pseudomonas fluorescens @ 5g/L water.', 'Spray bacteriophage preparations targeted against Xanthomonas.'],
    chemicalControl: [{ chemical: 'Copper Hydroxide 53.8% DF + Mancozeb 75% WP', dosage: '2.0 g + 2.0 g / Liter water', timing: 'Tank mix applied preventatively at 7-10 day intervals during warm humid weather.' }, { chemical: 'Streptocycline (Streptomycin 90% + Tetracycline 10%)', dosage: '0.1 g / Liter water', timing: 'Apply on early symptoms in high disease pressure zones.' }],
    preventiveCare: ['Plant certified disease-free, hot-water-treated seed or resistant F1 hybrids.']
  },
  {
    idx: 19, raw: 'Pepper,_bell___healthy', cropKey: 'pepper_bell', cropName: 'Bell Pepper / Capsicum (शिमला मिर्च)',
    diseaseId: 'pepper-bell-healthy', diseaseName: 'Healthy Bell Pepper Leaf (No Pathogen Detected)', commonName: 'Healthy Bell Pepper Foliage',
    scientificName: 'Capsicum annuum var. grossum', vernacularName: 'स्वस्थ शिमला मिर्च पत्ती (Healthy Bell Pepper)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Glossy dark-green ovate-lanceolate leaves with smooth margins', 'Intact cuticular sheen with zero necrotic spotting or water-soaked flecks', 'Vigorous branching and healthy fruit buds'],
    culturalMeasures: ['Maintain soil moisture at 70-80% field capacity using silver-black plastic mulch.', 'Stake plants to support heavy bell pepper canopy.'],
    biologicalControl: ['Apply cold-pressed neem cake in soil at 100 kg/acre.'], chemicalControl: [],
    preventiveCare: ['Scout for aphids and thrips to prevent secondary virus transmission.']
  },
  {
    idx: 20, raw: 'Potato___Early_blight', cropKey: 'potato', cropName: 'Potato (आलू / बटाटा)',
    diseaseId: 'potato-early-blight', diseaseName: 'Potato Early Blight (Alternaria solani)', commonName: 'Potato Early Blight',
    scientificName: 'Alternaria solani', vernacularName: 'आलू अगेती झुलसा (Early Blight)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Dark brown to black necrotic spots with concentric target-board rings', 'Spots are surrounded by a distinct yellow chlorotic halo', 'Older lower leaves affected first, progressing upwards causing defoliation'],
    culturalMeasures: ['Rotate crops with non-solanaceous crops (maize, pulses) for 2-3 years.', 'Maintain optimal nitrogen nutrition; nitrogen deficiency accelerates early blight susceptibility.', 'Destroy potato vine residues after harvest.'],
    biologicalControl: ['Foliar spray of Trichoderma viride @ 5g/L water at first sign of target spots.', 'Apply NSKE (Neem Seed Kernel Extract 5%) or Azadirachtin 10,000 ppm @ 2.5 ml/L.'],
    chemicalControl: [{ chemical: 'Mancozeb 75% WP', dosage: '2.5 g / Liter water', timing: 'Prophylactic spray at 45 days after planting, repeat after 10-12 days.' }, { chemical: 'Azoxystrobin 18.2% + Difenoconazole 11.4% SC', dosage: '1.0 ml / Liter water', timing: 'Curative spray for established target spot infections.' }],
    preventiveCare: ['Plant certified disease-free seed tubers.', 'Avoid overhead sprinkler irrigation late in the afternoon.']
  },
  {
    idx: 21, raw: 'Potato___Late_blight', cropKey: 'potato', cropName: 'Potato (आलू / बटाटा)',
    diseaseId: 'potato-late-blight', diseaseName: 'Potato Late Blight (Phytophthora infestans)', commonName: 'Potato Late Blight',
    scientificName: 'Phytophthora infestans', vernacularName: 'आलू पछेती झुलसा / करपा (Late Blight)', pathogenType: 'Oomycete Water Mold', isHealthy: false, severity: 'High',
    symptoms: ['Water-soaked, pale-to-dark-brown rapidly expanding lesions on leaf tips and margins', 'Delicate white downy fungal mildew on leaf undersides under high humidity', 'Sudden systemic collapse of haulms and dark firm dry rot on tubers'],
    culturalMeasures: ['Immediately destroy volunteer potato plants and cull piles near fields.', 'High earthing-up (hilling) of potato rows to prevent zoospore wash into tuber zone.', 'Destroy infected haulms 10-14 days before harvest to prevent tuber contamination.'],
    biologicalControl: ['Foliar spray of Bacillus subtilis @ 4g/L on both leaf surfaces.', 'Prophylactic spray of cow urine (10% diluted) + Fermented butter milk.'],
    chemicalControl: [{ chemical: 'Metalaxyl 8% + Mancozeb 64% WP (Ridomil Gold)', dosage: '2.5 g / Liter water', timing: 'Immediate systemic spray upon epidemic weather alert (12-22°C + >85% RH).' }, { chemical: 'Cymoxanil 8% + Mancozeb 64% WP', dosage: '2.0 g / Liter water', timing: 'Curative translaminar kickback spray within 48 hours of infection.' }, { chemical: 'Dimethomorph 50% WP', dosage: '1.2 g / Liter water', timing: 'Oomycete translaminar specialist spray; alternate with Mancozeb.' }],
    preventiveCare: ['Grow late blight-resistant potato varieties (e.g. Kufri Girdhari, Kufri Khyati, Kufri Himalini).', 'Monitor ICAR Central Potato Research Institute (CPRI) Indoblightcast disease forecast.']
  },
  {
    idx: 22, raw: 'Potato___healthy', cropKey: 'potato', cropName: 'Potato (आलू / बटाटा)',
    diseaseId: 'potato-healthy', diseaseName: 'Healthy Potato Leaf (No Pathogen Detected)', commonName: 'Healthy Potato Foliage',
    scientificName: 'Solanum tuberosum', vernacularName: 'स्वस्थ आलू पत्ती (Healthy Potato Foliage)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Broad, wavy pinnate compound leaflets with deep green coloration', 'Clean, intact cuticular barrier with zero water-soaked spots or target rings', 'Vigorous upright canopy posture with strong stolon development'],
    culturalMeasures: ['Ensure timely earthing-up at 30-35 days after planting.', 'Maintain uniform soil moisture during tuber initiation and bulking.'],
    biologicalControl: ['Seed tuber treatment with Trichoderma viride @ 10g/kg before sowing.'], chemicalControl: [],
    preventiveCare: ['Routine scouting for early or late blight under cool humid intervals.']
  },
  {
    idx: 23, raw: 'Raspberry___healthy', cropKey: 'raspberry', cropName: 'Raspberry (रास्पबेरी)',
    diseaseId: 'raspberry-healthy', diseaseName: 'Healthy Raspberry Leaf (No Pathogen Detected)', commonName: 'Healthy Raspberry Foliage',
    scientificName: 'Rubus idaeus', vernacularName: 'स्वस्थ रास्पबेरी पत्ती (Healthy Raspberry)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Clean serrate trifoliate leaves with silvery undersides', 'Uniform chlorophyll pigmentation with zero anthracnose or spur blight lesions', 'Healthy primocane and floricane growth'],
    culturalMeasures: ['Prune out spent floricanes after harvest.', 'Ensure trellis support and open canopy for ventilation.'],
    biologicalControl: ['Beneficial rootzone mycorrhizal inoculants.'], chemicalControl: [],
    preventiveCare: ['Monitor canes for spur blight or cane borer activity.']
  },
  {
    idx: 24, raw: 'Soybean___healthy', cropKey: 'soybean', cropName: 'Soybean (सोयाबीन)',
    diseaseId: 'soybean-healthy', diseaseName: 'Healthy Soybean Leaf (No Pathogen Detected)', commonName: 'Healthy Soybean Foliage',
    scientificName: 'Glycine max', vernacularName: 'स्वस्थ सोयाबीन पत्ती (Healthy Soybean Foliage)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Trifoliolate ovate leaflets with vibrant uniform emerald-green color', 'Intact leaf margins and absence of rust pustules, yellow mosaic, or blight', 'Vigorous nodulation on root system and sturdy stem structure'],
    culturalMeasures: ['Maintain broad-bed furrow (BBF) or ridge-and-furrow planting for drainage.', 'Inoculate seed with Bradyrhizobium japonicum culture.'],
    biologicalControl: ['Seed treatment with Trichoderma viride @ 5g/kg seed.'], chemicalControl: [],
    preventiveCare: ['Note: PlantVillage model only contains healthy baseline class for Soybean. Scout field for Yellow Mosaic Virus or Rust.']
  },
  {
    idx: 25, raw: 'Squash___Powdery_mildew', cropKey: 'squash', cropName: 'Squash (कद्दू / कुष्मांड)',
    diseaseId: 'squash-powdery-mildew', diseaseName: 'Squash Powdery Mildew (Podosphaera xanthii)', commonName: 'Squash Powdery Mildew',
    scientificName: 'Podosphaera xanthii', vernacularName: 'कद्दू चूर्णिल आसिता (Powdery Mildew)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['White, talcum-powder-like fungal colonies on upper and lower leaf surfaces', 'Infected leaves turn yellow, then brown and papery, dying prematurely', 'Sunscald on exposed squashes due to rapid defoliation'],
    culturalMeasures: ['Plant in full sunlight with wide spacing (2m between hills) for air circulation.', 'Water at soil level via drip irrigation; do not wet broad squash leaves.'],
    biologicalControl: ['Spray Ampelomyces quisqualis @ 5g/L water at first sign of white spots.', 'Foliar spray of Potassium Bicarbonate @ 3g/L + 1ml liquid soap.'],
    chemicalControl: [{ chemical: 'Myclobutanil 10% WP', dosage: '1.0 g / Liter water', timing: 'Spray on first appearance of mildew colonies; repeat in 10-14 days.' }, { chemical: 'Azoxystrobin 23% SC', dosage: '1.0 ml / Liter water', timing: 'Alternate systemic spray to avoid fungicide resistance.' }],
    preventiveCare: ['Plant resistant cucurbit hybrid varieties.', 'Dispose of all crop debris promptly after harvest.']
  },
  {
    idx: 26, raw: 'Strawberry___Leaf_scorch', cropKey: 'strawberry', cropName: 'Strawberry (स्ट्रॉबेरी)',
    diseaseId: 'strawberry-leaf-scorch', diseaseName: 'Strawberry Leaf Scorch (Diplocarpon earlianum)', commonName: 'Leaf Scorch',
    scientificName: 'Diplocarpon earlianum', vernacularName: 'स्ट्रॉबेरी लीफ स्कॉर्च (Leaf Scorch)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Numerous small dark purple to reddish blotches scattered over the leaf surface', 'Spots enlarge and merge, turning brown and giving the entire leaf a scorched, burnt appearance', 'Margins curl upward and leaves die prematurely'],
    culturalMeasures: ['Renovate strawberry beds after harvest by mowing old foliage and destroying leaves.', 'Avoid overhead sprinkling; irrigate through drip under plastic mulch.'],
    biologicalControl: ['Foliar spray of Bacillus amyloliquefaciens @ 4g/L.', 'Apply copper octanoate (copper soap) @ 2.5ml/L.'],
    chemicalControl: [{ chemical: 'Captan 50% WP', dosage: '2.5 g / Liter water', timing: 'Apply starting at spring green-up before bloom.' }, { chemical: 'Thiophanate-methyl 70% WP', dosage: '1.0 g / Liter water', timing: 'Curative spray on severe leaf scorch pressure.' }],
    preventiveCare: ['Select scorch-resistant strawberry varieties.', 'Maintain good row spacing to allow quick foliage drying.']
  },
  {
    idx: 27, raw: 'Strawberry___healthy', cropKey: 'strawberry', cropName: 'Strawberry (स्ट्रॉबेरी)',
    diseaseId: 'strawberry-healthy', diseaseName: 'Healthy Strawberry Leaf (No Pathogen Detected)', commonName: 'Healthy Strawberry Foliage',
    scientificName: 'Fragaria ananassa', vernacularName: 'स्वस्थ स्ट्रॉबेरी पत्ती (Healthy Strawberry)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Lush dark-green trifoliate leaflets with prominent serrated margins', 'Intact, glossy epidermal layer with zero purple spots or scorch margins', 'Vigorous crown development and healthy flower trusses'],
    culturalMeasures: ['Maintain raised bed planting with clean straw or silver-black plastic mulch.', 'Maintain balanced drip fertigation with adequate calcium and potassium.'],
    biologicalControl: ['Incorporate Trichoderma-enriched compost in strawberry beds before planting.'], chemicalControl: [],
    preventiveCare: ['Regular weekly scouting for spider mites and fungal leaf spots.']
  },
  {
    idx: 28, raw: 'Tomato___Bacterial_spot', cropKey: 'tomato', cropName: 'Tomato (टमाटर / टोमॅटो)',
    diseaseId: 'tomato-bacterial-spot', diseaseName: 'Tomato Bacterial Spot (Xanthomonas campestris pv. vesicatoria)', commonName: 'Tomato Bacterial Spot',
    scientificName: 'Xanthomonas campestris pv. vesicatoria', vernacularName: 'टमाटर जीवाणु धब्बा (Bacterial Spot)', pathogenType: 'Bacterial Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Small (under 3mm) dark brown, water-soaked, circular to angular spots on leaves', 'Spots have a greasy appearance and often a faint yellow halo', 'Severe infection leads to extensive leaf yellowing and premature leaf drop'],
    culturalMeasures: ['Immediately stop overhead sprinkler watering; switch strictly to drip irrigation at soil level.', 'Do not cultivate or handle tomato plants while foliage is wet with rain or morning dew.', 'Maintain a 2-3 year crop rotation away from solanaceous crops.'],
    biologicalControl: ['Foliar application of Pseudomonas fluorescens (1% WP) @ 5g/L water.', 'Apply bacteriophage solutions specific to Xanthomonas.'],
    chemicalControl: [{ chemical: 'Copper Oxychloride 50% WP + Streptocycline', dosage: '2.5 g + 0.1 g / Liter water', timing: 'Protective spray at first symptom onset; repeat every 7-10 days.' }, { chemical: 'Kasugamycin 3% SL', dosage: '2.0 ml / Liter water', timing: 'Systemic bactericide spray for high humidity epidemic spread.' }],
    preventiveCare: ['Plant certified disease-free, hot-water-treated seed.', 'Use tolerant varieties with multi-race bacterial spot resistance.']
  },
  {
    idx: 29, raw: 'Tomato___Early_blight', cropKey: 'tomato', cropName: 'Tomato (टमाटर / टोमॅटो)',
    diseaseId: 'tomato-early-blight', diseaseName: 'Early Blight (Alternaria solani)', commonName: 'Early Blight',
    scientificName: 'Alternaria solani', vernacularName: 'टमाटर अगेती झुलसा / करपा (Early Blight)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Dark brown to black necrotic spots with characteristic concentric target-board rings', 'Prominent yellow chlorotic halo surrounding expanding spots', 'Older lower leaves infected first, progressing upwards causing defoliation', 'Stem collar rot and sunken dark leathery lesions near soil line'],
    culturalMeasures: ['Prune and destroy infected lower leaves (bottom 30 cm) to eliminate fungal spore splash.', 'Apply clean straw mulch around plant base to prevent soil-borne spore rebound onto leaves.', 'Switch strictly to drip irrigation at root level.'],
    biologicalControl: ['Foliar spray of Trichoderma viride (1% WP) @ 5g/L water mixed with 1g jaggery.', 'Spray cold-pressed Neem Seed Kernel Extract (NSKE 5%) or Azadirachtin 10,000 ppm @ 2.5 ml/L water.', 'Root drenching with Pseudomonas fluorescens @ 10g/L water at 15-day intervals.'],
    chemicalControl: [{ chemical: 'Mancozeb 75% WP (Dithane M-45)', dosage: '2.5 g / Liter water', timing: 'Basal protective spray at first appearance of target spots; repeat every 8-10 days.' }, { chemical: 'Copper Oxychloride 50% WP (Blitox)', dosage: '3.0 g / Liter water', timing: 'Curative spray during persistent humid / rainy intervals.' }, { chemical: 'Azoxystrobin 18.2% + Difenoconazole 11.4% SC (Amistar Top)', dosage: '1.0 ml / Liter water', timing: 'Systemic translaminar curative spray for advanced infections.' }],
    preventiveCare: ['Maintain a 3-year crop rotation avoiding Solanaceous family crops.', 'Plant certified resistant varieties (e.g. Arka Rakshak, Pusa Rohini, US-440).']
  },
  {
    idx: 30, raw: 'Tomato___Late_blight', cropKey: 'tomato', cropName: 'Tomato (टमाटर / टोमॅटो)',
    diseaseId: 'tomato-late-blight', diseaseName: 'Late Blight (Phytophthora infestans)', commonName: 'Late Blight',
    scientificName: 'Phytophthora infestans', vernacularName: 'टमाटर पछेती झुलसा / करपा (Late Blight)', pathogenType: 'Oomycete Water Mold', isHealthy: false, severity: 'High',
    symptoms: ['Rapidly expanding water-soaked pale green lesions turning dark brown to purplish-black', 'Delicate whitish-grey fungal downy growth visible on underside of leaves in wet weather', 'Large greasy brown lesions girdling stems and leaf petioles causing sudden foliage collapse', 'Firm, rough dark brown blotches on green and ripening tomato fruits'],
    culturalMeasures: ['Immediate emergency rogueing: uproot and deeply bury severely collapsed vines.', 'Ensure high air circulation by staking indeterminate vines and wider row spacing (75 cm).', 'Avoid handling or weeding wet vines in the morning.'],
    biologicalControl: ['Prophylactic spray of Bacillus subtilis (1% WP) @ 4g/L water on both leaf surfaces.', 'Spray fermented buttermilk + hing (asafoetida @ 1g/L) for natural antifungal barrier.'],
    chemicalControl: [{ chemical: 'Metalaxyl 8% + Mancozeb 64% WP (Ridomil Gold)', dosage: '2.5 g / Liter water', timing: 'Immediate systemic foliar application on epidemic outbreak; repeat after 10 days if cool & wet.' }, { chemical: 'Cymoxanil 8% + Mancozeb 64% WP (Curzate)', dosage: '2.0 g / Liter water', timing: 'Curative kickback action within 48 hours of infection.' }, { chemical: 'Dimethomorph 50% WP (Acrobat)', dosage: '1.2 g / Liter water', timing: 'Translaminar oomycete specialist spray; alternate with Mancozeb.' }],
    preventiveCare: ['Grow tolerant hybrid varieties with Ph-2 and Ph-3 resistance genes (e.g. Arka Abhed).', 'Monitor weather: temperature 12-22°C + relative humidity >85% triggers rapid sporulation.']
  },
  {
    idx: 31, raw: 'Tomato___Leaf_Mold', cropKey: 'tomato', cropName: 'Tomato (टमाटर / टोमॅटो)',
    diseaseId: 'tomato-leaf-mold', diseaseName: 'Tomato Leaf Mold (Passalora fulva)', commonName: 'Tomato Leaf Mold',
    scientificName: 'Passalora fulva', vernacularName: 'टमाटर पत्ती फफूंद (Leaf Mold)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Pale green to yellowish chlorotic spots on upper leaf surfaces with indistinct margins', 'Olive-green to brown velvety fungal growth on corresponding lower leaf surface', 'Older leaves die and drop, progressing upward from the base'],
    culturalMeasures: ['Increase greenhouse and tunnel ventilation; maintain relative humidity below 85%.', 'Increase plant spacing and prune lower foliage to improve air circulation.', 'Water in morning using drip lines; do not wet canopy.'],
    biologicalControl: ['Spray Trichoderma harzianum @ 5g/L water on lower canopy.', 'Apply bio-fungicide Bacillus amyloliquefaciens @ 4g/L.'],
    chemicalControl: [{ chemical: 'Difenoconazole 25% EC', dosage: '0.5 ml / Liter water', timing: 'Apply upon first notice of yellow leaf patches; repeat after 12 days.' }, { chemical: 'Copper Hydroxide 53.8% DF', dosage: '2.0 g / Liter water', timing: 'Preventative spray for high-humidity tunnel cultivation.' }],
    preventiveCare: ['Use leaf mold-resistant tomato hybrids (carrying Cf resistance genes).']
  },
  {
    idx: 32, raw: 'Tomato___Septoria_leaf_spot', cropKey: 'tomato', cropName: 'Tomato (टमाटर / टोमॅटो)',
    diseaseId: 'tomato-septoria', diseaseName: 'Septoria Leaf Spot (Septoria lycopersici)', commonName: 'Septoria Leaf Spot',
    scientificName: 'Septoria lycopersici', vernacularName: 'सेप्टोरिया पत्ती धब्बा (Septoria Leaf Spot)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Small circular spots with dark brown margins and sunken grayish-white centers', 'Numerous tiny black fruiting bodies (pycnidia) embedded in spot centers', 'Rapid yellowing and defoliation of lower canopy leaves progressing upwards'],
    culturalMeasures: ['Remove and destroy infected lower leaves at first detection.', 'Apply 2-inch organic straw mulch under vines to prevent soil-splash inoculum.', 'Cease overhead watering; use root drip.'],
    biologicalControl: ['Foliar spray of Trichoderma viride @ 5g/L water mixed with jaggery.', 'Spray 2% cold-pressed neem seed oil.'],
    chemicalControl: [{ chemical: 'Chlorothalonil 75% WP', dosage: '2.0 g / Liter water', timing: 'Apply immediately upon spotting; repeat every 7-10 days during rainy weather.' }, { chemical: 'Mancozeb 75% WP', dosage: '2.5 g / Liter water', timing: 'Protective broad-spectrum barrier spray.' }],
    preventiveCare: ['Practice 3-year crop rotation without solanaceous crops.', 'Stake plants for vertical air movement.']
  },
  {
    idx: 33, raw: 'Tomato___Spider_mites Two-spotted_spider_mite', cropKey: 'tomato', cropName: 'Tomato (टमाटर / टोमॅटो)',
    diseaseId: 'tomato-spider-mites', diseaseName: 'Two-Spotted Spider Mites (Tetranychus urticae)', commonName: 'Two-Spotted Spider Mites',
    scientificName: 'Tetranychus urticae', vernacularName: 'लाल मकड़ी कीट (Two-Spotted Spider Mite)', pathogenType: 'Arachnid Pest', isHealthy: false, severity: 'Moderate',
    symptoms: ['Fine yellow or white stippling / speckling on upper leaf surfaces', 'Delicate fine silken webbing visible on leaf undersides and terminal shoots', 'Leaves turn bronze, dry out, and drop prematurely under hot dry conditions'],
    culturalMeasures: ['Avoid excessive dusty field conditions; keep farm borders moist.', 'Avoid excessive chemical nitrogen fertilizer which elevates mite reproduction rates.', 'Hose down severely infested plants with high-pressure water spray to dislodge webbing.'],
    biologicalControl: ['Release predatory phytoseiid mites (Phytoseiulus persimilis or Neoseiulus californicus).', 'Spray Azadirachtin 10,000 ppm @ 2.0 ml/L or insecticidal soap solution.'],
    chemicalControl: [{ chemical: 'Spiromesifen 22.9% SC (Oberon)', dosage: '1.0 ml / Liter water', timing: 'Lipid synthesis inhibitor targeting mite eggs and nymphs.' }, { chemical: 'Abamectin 1.9% EC', dosage: '0.5 ml / Liter water', timing: 'Translaminar adulticide knockdown spray; ensure coverage of leaf undersides.' }, { chemical: 'Fenpyroximate 5% EC', dosage: '1.0 ml / Liter water', timing: 'Mite growth inhibitor spray.' }],
    preventiveCare: ['Regular weekly leaf underside scouting with 10x hand lens during warm dry months.']
  },
  {
    idx: 34, raw: 'Tomato___Target_Spot', cropKey: 'tomato', cropName: 'Tomato (टमाटर / टोमॅटो)',
    diseaseId: 'tomato-target-spot', diseaseName: 'Target Spot (Corynespora cassiicola)', commonName: 'Target Spot',
    scientificName: 'Corynespora cassiicola', vernacularName: 'लक्ष्य धब्बा रोग (Target Spot)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Pinpoint brown spots on upper leaf surfaces enlarging to circular brown lesions', 'Zonate concentric rings with pale brown centers and dark brown margins', 'Severe leaf drop leading to exposed fruit and yield reduction'],
    culturalMeasures: ['Improve air circulation through wider spacing and sucker removal.', 'Stake plants to keep foliage off bare ground.', 'Avoid long leaf wetness periods by watering via drip.'],
    biologicalControl: ['Apply Bacillus subtilis @ 4g/L on foliar canopy.', 'Spray 2% cold-pressed neem oil.'],
    chemicalControl: [{ chemical: 'Azoxystrobin 18.2% + Difenoconazole 11.4% SC', dosage: '1.0 ml / Liter water', timing: 'Apply on first appearance of concentric target lesions.' }, { chemical: 'Mancozeb 75% WP', dosage: '2.5 g / Liter water', timing: 'Protective broad-spectrum spray.' }],
    preventiveCare: ['Rotate away from solanaceous and cucurbit crops.', 'Destroy infected plant debris promptly after final harvest.']
  },
  {
    idx: 35, raw: 'Tomato___Tomato_Yellow_Leaf_Curl_Virus', cropKey: 'tomato', cropName: 'Tomato (टमाटर / टोमॅटो)',
    diseaseId: 'tomato-yellow-leaf-curl', diseaseName: 'Tomato Yellow Leaf Curl Virus (TYLCV)', commonName: 'Tomato Yellow Leaf Curl Virus',
    scientificName: 'Begomovirus / TYLCV', vernacularName: 'पर्ण कुंचन विषाणु (Leaf Curl / Churda Murda)', pathogenType: 'Viral Pathogen (Geminivirus)', isHealthy: false, severity: 'Severe Epidemic',
    symptoms: ['Severe upward curling and cupping of leaflets', 'Marked interveinal chlorosis and yellowing of leaf margins', 'Severe stunting and bushy upright growth of plants', 'Flower dropping and drastic reduction in fruit set'],
    culturalMeasures: ['Install bright yellow sticky traps (15-20 traps/acre) at canopy height to monitor and mass-trap Whitefly vectors.', 'Remove and destroy virus-infected plants immediately to prevent whitefly transmission to healthy rows.', 'Erect 40-mesh nylon insect-proof net barrier around seedling nurseries.'],
    biologicalControl: ['Foliar spray of Beauveria bassiana or Verticillium lecanii @ 5g/L water to parasitize whiteflies naturally.', 'Apply 2% Neem oil (Azadirachtin 3000 ppm) with 1ml liquid soap at 7-day intervals to repel vectors.'],
    chemicalControl: [{ chemical: 'Diafenthiuron 50% WP (Pegasus)', dosage: '1.2 g / Liter water', timing: 'Vapor-action whitefly adult and nymph knockdown spray.' }, { chemical: 'Spiromesifen 22.9% SC (Oberon)', dosage: '1.0 ml / Liter water', timing: 'Lipid synthesis inhibitor targeting whitefly eggs and nymphs.' }, { chemical: 'Thiamethoxam 25% WG', dosage: '0.5 g / Liter water', timing: 'Systemic neonicotinoid spray for vector management.' }],
    preventiveCare: ['Use resistant F1 hybrids (e.g. US-618, Abhinav, Saaho).', 'Maintain border cropping with 3 rows of Maize or Sorghum as a live insect barrier.']
  },
  {
    idx: 36, raw: 'Tomato___Tomato_mosaic_virus', cropKey: 'tomato', cropName: 'Tomato (टमाटर / टोमॅटो)',
    diseaseId: 'tomato-mosaic-virus', diseaseName: 'Tomato Mosaic Virus (ToMV)', commonName: 'Tomato Mosaic Virus',
    scientificName: 'Tobamovirus / ToMV', vernacularName: 'टमाटर मोज़ेक विषाणु (Tomato Mosaic Virus)', pathogenType: 'Viral Pathogen', isHealthy: false, severity: 'High',
    symptoms: ['Mottled light and dark green mosaic patterns on foliage', 'Leaf distortion including blistering, crinkling, and "shoestring" fern-like leaflets', 'Plant stunting, bronze internal browning of fruit walls, and uneven ripening'],
    culturalMeasures: ['Wash hands thoroughly with soap or 20% non-fat dry milk solution before handling plants.', 'Strictly prohibit smoking or tobacco handling in tomato greenhouses or fields.', 'Immediately rogue and burn infected mosaic plants.'],
    biologicalControl: ['Foliar spray of skimmed milk powder solution (100g/L) during transplanting to inhibit mechanical virus transmission.'],
    chemicalControl: [{ chemical: 'No chemical viricide exists', dosage: 'N/A', timing: 'Focus strictly on sanitation and tool disinfection with 10% TSP (trisodium phosphate).' }],
    preventiveCare: ['Plant certified mosaic-resistant varieties (carrying Tm-1, Tm-2, or Tm-2^2 resistance genes).']
  },
  {
    idx: 37, raw: 'Tomato___healthy', cropKey: 'tomato', cropName: 'Tomato (टमाटर / टोमॅटो)',
    diseaseId: 'tomato-healthy', diseaseName: 'Healthy Tomato Leaf (No Pathogen Detected)', commonName: 'Healthy Tomato Foliage',
    scientificName: 'Solanum lycopersicum', vernacularName: 'स्वस्थ टमाटर पत्ती (Healthy Tomato)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Deep green odd-pinnately compound leaves with serrated margins', 'Intact glandular trichomes and zero yellow halos, necrotic spots, or curling', 'Vigorous indeterminate or determinate vine extension with healthy flower trusses'],
    culturalMeasures: ['Maintain consistent root-zone moisture via drip lines to prevent blossom end rot.', 'Stake and prune indeterminate vines regularly for maximum solar interception.'],
    biologicalControl: ['Root drenching with Trichoderma harzianum @ 10g/L at transplanting.'], chemicalControl: [],
    preventiveCare: ['Regular weekly scouting for early blight and whiteflies.']
  },
  // 38-42: Cotton (Gossypium hirsutum)
  {
    idx: 38, raw: 'Cotton___Bacterial_blight', cropKey: 'cotton', cropName: 'Cotton (कपास / कापूस)',
    diseaseId: 'cotton-bacterial-blight', diseaseName: 'Bacterial Blight / Angular Leaf Spot (Xanthomonas citri pv. malvacearum)', commonName: 'Cotton Angular Leaf Spot',
    scientificName: 'Xanthomonas citri pv. malvacearum', vernacularName: 'कपास का जीवाणु झुलसा / कोणीय पर्ण धब्बा', pathogenType: 'Bacterial Pathogen', isHealthy: false, severity: 'High',
    symptoms: ['Small, water-soaked, angular spots on lower leaf surface bounded by veins', 'Lesions turning dark brown to black and coalesce into extensive blighted areas', 'Black arm lesions on stems and branches causing branch snapping', 'Water-soaked oily spots on cotton bolls resulting in boll rot and stained lint'],
    culturalMeasures: ['Delint seed with concentrated sulfuric acid (100 ml/kg seed) before sowing to eliminate seed-borne bacteria.', 'Destroy and deeply bury crop residues after harvest to break the disease cycle.', 'Avoid excessive application of nitrogenous fertilizers which promote lush succulent foliage.'],
    biologicalControl: ['Seed treatment with Pseudomonas fluorescens (Pf-1) @ 10g/kg seed.', 'Foliar spray of Bacillus subtilis (1% WP) @ 5g/L water at first appearance of angular spots.'],
    chemicalControl: [{ chemical: 'Streptocycline + Copper Oxychloride 50% WP', dosage: '100 mg Streptocycline + 2.5 g COC per Liter water', timing: 'Immediate spray on first noticing angular spots; repeat after 12-15 days.' }, { chemical: 'Copper Hydroxide 77% WP', dosage: '2.0 g / Liter water', timing: 'Prophylactic spray during cloudy humid weather.' }],
    preventiveCare: ['Plant resistant cultivars recommended by CICR (e.g., LRA 5166, Surabhi).', 'Maintain adequate plant spacing (90x60 cm) for air flow.']
  },
  {
    idx: 39, raw: 'Cotton___Fusarium_wilt', cropKey: 'cotton', cropName: 'Cotton (कपास / कापूस)',
    diseaseId: 'cotton-fusarium-wilt', diseaseName: 'Fusarium Wilt (Fusarium oxysporum f. sp. vasinfectum)', commonName: 'Cotton Fusarium Wilt',
    scientificName: 'Fusarium oxysporum f. sp. vasinfectum', vernacularName: 'कपास का उकठा रोग (Fusarium Wilt)', pathogenType: 'Fungal Pathogen (Soil-borne)', isHealthy: false, severity: 'Severe',
    symptoms: ['Initial yellowing of leaf margins (veinal chlorosis) progressing between veins', 'Leaves wilt, turn brown, and drop prematurely from the base upward leaving bare stalks', 'Characteristic dark brown to black vascular discoloration in split stems and roots', 'Severe stunting and sudden plant death during flowering and boll formation'],
    culturalMeasures: ['Practice 3 to 4-year crop rotation with non-host crops like Sorghum, Bajra, or Maize.', 'Apply heavy organic manure (FYM @ 5 tonnes/acre) to stimulate antagonistic soil microbes.', 'Avoid cultivating cotton in low-lying, poorly drained, acidic or nematode-infested soils.'],
    biologicalControl: ['Soil application of Trichoderma viride or T. harzianum @ 2.5 kg/acre enriched in 250 kg FYM at sowing.', 'Seed biopriming with Pseudomonas fluorescens @ 10g/kg seed.'],
    chemicalControl: [{ chemical: 'Carbendazim 50% WP', dosage: '2.0 g / Liter water', timing: 'Spot drenching around root zones of infected and neighboring plants.' }, { chemical: 'Carboxin 37.5% + Thiram 37.5% DS', dosage: '3.0 g / kg seed', timing: 'Mandatory dry seed dressing before sowing.' }],
    preventiveCare: ['Grow wilt-resistant/tolerant hybrids and varieties (e.g. PKV 081, Suvin).', 'Control root-knot nematodes with neem cake @ 150 kg/acre to prevent fungal infection portals.']
  },
  {
    idx: 40, raw: 'Cotton___Verticillium_wilt', cropKey: 'cotton', cropName: 'Cotton (कपास / कापूस)',
    diseaseId: 'cotton-verticillium-wilt', diseaseName: 'Verticillium Wilt (Verticillium dahliae)', commonName: 'Cotton Verticillium Wilt',
    scientificName: 'Verticillium dahliae', vernacularName: 'कपास का वर्टिसिलियम विल्ट (Tiger Stripe Wilt)', pathogenType: 'Fungal Pathogen (Soil-borne)', isHealthy: false, severity: 'High',
    symptoms: ['Interveinal chlorosis creating a characteristic "tiger-stripe" pattern on leaves', 'Leaf margins roll inward and dry out into necrotic brown zones', 'Light brown vascular ring discoloration in outer xylem tissues (distinct from central blackening in Fusarium)', 'Delayed defoliation where dead leaves frequently remain attached to stems'],
    culturalMeasures: ['Deep summer plowing to expose microsclerotia to solar heat.', 'Solarize nursery/field beds with transparent polyethylene mulch for 4-6 weeks during peak summer.', 'Ensure balanced potassium nutrition (MOP) to enhance vascular cell wall resistance.'],
    biologicalControl: ['Soil incorporation of Trichoderma viride @ 5 kg/ha with 500 kg neem cake.', 'Seed treatment with Bacillus amyloliquefaciens @ 10g/kg seed.'],
    chemicalControl: [{ chemical: 'Carbendazim 50% WP or Thiophanate-methyl 70% WP', dosage: '1.5 g / Liter water', timing: 'Foliar spray and collar soil drenching during early boll development.' }],
    preventiveCare: ['Avoid flooding irrigation; use furrow or drip systems.', 'Strictly avoid fields with known potato or brinjal wilt history.']
  },
  {
    idx: 41, raw: 'Cotton___Alternaria_leaf_spot', cropKey: 'cotton', cropName: 'Cotton (कपास / कापूस)',
    diseaseId: 'cotton-alternaria-leaf-spot', diseaseName: 'Alternaria Leaf Spot (Alternaria macrospora / A. alternata)', commonName: 'Cotton Alternaria Blight',
    scientificName: 'Alternaria macrospora', vernacularName: 'कपास का अल्टरनेरिया पर्ण धब्बा', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Small circular brown to purplish spots with concentric rings and chlorotic halos', 'Lesion centers turn pale ash-grey and frequently crack or fall out creating "shot-hole" effect', 'Heavy premature defoliation in American and Bt cotton hybrids during boll bursting', 'Sunken circular necrotic lesions on developing bolls impairing lint quality'],
    culturalMeasures: ['Collect and burn post-harvest crop debris.', 'Provide balanced fertilizer application; prevent potassium deficiency which predisposes leaves to Alternaria.', 'Maintain adequate row-to-row distance to prevent dense, humid microclimates.'],
    biologicalControl: ['Foliar spray of Ampelomyces quisqualis or Trichoderma harzianum @ 5g/L water.', 'Spray 5% Neem Seed Kernel Extract (NSKE) at squaring stage.'],
    chemicalControl: [{ chemical: 'Mancozeb 75% WP', dosage: '2.5 g / Liter water', timing: 'Protective spray at initial appearance of spots; repeat after 10-12 days.' }, { chemical: 'Propiconazole 25% EC (Tilt)', dosage: '1.0 ml / Liter water', timing: 'Systemic curative spray if lesions spread to upper canopy during humid weather.' }, { chemical: 'Pyraclostrobin 20% WG', dosage: '1.0 g / Liter water', timing: 'High-efficacy translaminar spray during boll development.' }],
    preventiveCare: ['Use certified disease-free certified hybrid seeds.', 'Schedule protective fungicides when relative humidity exceeds 80% for >3 consecutive days.']
  },
  {
    idx: 42, raw: 'Cotton___healthy', cropKey: 'cotton', cropName: 'Cotton (कपास / कापूस)',
    diseaseId: 'cotton-healthy', diseaseName: 'Healthy Cotton Foliage (No Pathogen Detected)', commonName: 'Healthy Cotton Leaf',
    scientificName: 'Gossypium hirsutum', vernacularName: 'स्वस्थ कपास पत्ती (Healthy Cotton)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Vibrant green 3-5 lobed leaves with smooth intact epidermis and healthy venation', 'Zero angular water-soaked spots, interveinal scorching, or vascular discoloration', 'Sturdy main stem and sympodial branches bearing clean squares and bolls'],
    culturalMeasures: ['Maintain scheduled weed management and balanced N:P:K fertilization (120:60:60 kg/ha).', 'Scout crops twice weekly for sucking pest thresholds (aphids, jassids, whiteflies).'],
    biologicalControl: ['Install 5 pheromone traps/acre for bollworm monitoring.'], chemicalControl: [],
    preventiveCare: ['Keep field bunds weed-free to prevent vector harborage.']
  },
  // 43-46: Wheat (Triticum aestivum)
  {
    idx: 43, raw: 'Wheat___Brown_rust', cropKey: 'wheat', cropName: 'Wheat (गेहूं / गहू)',
    diseaseId: 'wheat-brown-rust', diseaseName: 'Brown Rust / Leaf Rust (Puccinia triticina)', commonName: 'Wheat Brown Rust',
    scientificName: 'Puccinia triticina', vernacularName: 'गेहूं का भूरा रतुआ (Leaf Rust)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'High',
    symptoms: ['Small, round to oval, bright orange-brown uredinial pustules scattered irregularly on the leaf blade', 'Pustules rupture the upper epidermis shedding powdery rust spores on farmer fingers when touched', 'Leaves turn prematurely yellow and wither, leading to shriveled grains and reduced test weight', 'Unlike stripe rust, pustules do not form stripes and are primarily confined to the leaf blade'],
    culturalMeasures: ['Sow wheat within the optimal window (first fortnight of November in Indo-Gangetic plains).', 'Avoid excessive nitrogen fertilization which creates dense foliage favorable for rust spore germination.'],
    biologicalControl: ['Spray Verticillium lecanii or Trichoderma harzianum @ 5g/L water at early tillering.'],
    chemicalControl: [{ chemical: 'Propiconazole 25% EC (Tilt)', dosage: '1.0 ml / Liter water (500 ml in 500 L water/ha)', timing: 'Single prophylactic spray at first rust pustule detection halts epidemic completely.' }, { chemical: 'Tebuconazole 25.9% EC (Folicur)', dosage: '1.0 ml / Liter water', timing: 'Effective systemic triazole curative spray.' }],
    preventiveCare: ['Cultivate certified rust-resistant varieties recommended by ICAR-IIWBR (e.g., DBW 187, DBW 222, HD 3086, PBW 550).', 'Eradicate volunteer wheat plants during the off-season.']
  },
  {
    idx: 44, raw: 'Wheat___Yellow_rust', cropKey: 'wheat', cropName: 'Wheat (गेहूं / गहू)',
    diseaseId: 'wheat-yellow-rust', diseaseName: 'Yellow Rust / Stripe Rust (Puccinia striiformis)', commonName: 'Wheat Stripe Rust',
    scientificName: 'Puccinia striiformis', vernacularName: 'गेहूं का पीला रतुआ (Stripe Rust)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Severe',
    symptoms: ['Bright citron-yellow pustules arranged in distinct, narrow, parallel linear stripes along leaf veins', 'In severe attacks, stripe pustules extend onto leaf sheaths, stems, and glumes', 'Severe chlorosis followed by tissue death causing total canopy collapse in cool, humid sub-mountainous zones', 'Extensive yield loss exceeding 50% if infection occurs prior to heading'],
    culturalMeasures: ['Avoid late sowing in northern hills and north-western plains where cool fog favors yellow rust.', 'Maintain mixed-crop or multi-line varietal buffers.'],
    biologicalControl: ['Foliar bio-agent spray with Pseudomonas fluorescens @ 5g/L water.'],
    chemicalControl: [{ chemical: 'Propiconazole 25% EC (Tilt)', dosage: '1.0 ml / Liter water', timing: 'Urgent emergency ground spray upon detecting yellow stripe rust foci.' }, { chemical: 'Azoxystrobin 18.2% + Difenoconazole 11.4% SC', dosage: '1.0 ml / Liter water', timing: 'Dual-action broad spectrum systemic fungicide.' }],
    preventiveCare: ['Sow high-resistance varieties (e.g. DBW 303, HD 3226, WH 1105).', 'Participate in national rust surveillance network alerts.']
  },
  {
    idx: 45, raw: 'Wheat___Loose_smut', cropKey: 'wheat', cropName: 'Wheat (गेहूं / गहू)',
    diseaseId: 'wheat-loose-smut', diseaseName: 'Loose Smut (Ustilago tritici)', commonName: 'Wheat Loose Smut',
    scientificName: 'Ustilago tritici', vernacularName: 'गेहूं का कण्डवा / खुला कंडुआ रोग', pathogenType: 'Fungal Pathogen (Internally seed-borne)', isHealthy: false, severity: 'High',
    symptoms: ['Every spikelet in the earhead is completely transformed into a loose, powdery mass of dark olive-black teliospores', 'Silvery delicate membrane encloses spores early on and ruptures readily at heading', 'Wind disperses all black spores, leaving behind only the naked bare central rachis', 'Infected plants head earlier than healthy plants in the field'],
    culturalMeasures: ['Perform solar heat seed treatment: soak wheat seeds in water for 4 hours on a bright sunny summer day, then spread in the hot sun for 4 hours.', 'Carefully rogue out diseased smutted heads inside a polythene bag before spore dissemination.'],
    biologicalControl: ['Seed treatment with Trichoderma viride @ 4g/kg seed combined with biopriming.'],
    chemicalControl: [{ chemical: 'Carboxin 37.5% + Thiram 37.5% DS (Vitavax)', dosage: '2.5 g / kg seed', timing: 'Pre-sowing dry seed treatment penetrates embryo killing internal mycelium.' }, { chemical: 'Tebuconazole 2% DS (Raxil)', dosage: '1.0 g / kg seed', timing: 'High-efficiency seed dressing fungicide.' }],
    preventiveCare: ['Use only certified seed from disease-free seed production plots.', 'Inspect breeding nurseries and rogue smutted tillers immediately.']
  },
  {
    idx: 46, raw: 'Wheat___healthy', cropKey: 'wheat', cropName: 'Wheat (गेहूं / गहू)',
    diseaseId: 'wheat-healthy', diseaseName: 'Healthy Wheat Foliage (No Pathogen Detected)', commonName: 'Healthy Wheat Leaf',
    scientificName: 'Triticum aestivum', vernacularName: 'स्वस्थ गेहूं पत्ती (Healthy Wheat)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Linear lanceolate leaves with uniform green color, parallel venation, and distinct auricles', 'Clean intact leaf sheaths devoid of rust pustules, stripe chlorosis, powdery mildew, or foliar blight', 'Vigorous tillering and erect upright canopy with robust flag leaf emergence'],
    culturalMeasures: ['Schedule irrigation at critical growth stages: Crown Root Initiation (CRI at 21 DAS), Tillering, Booting, and Grain Filling.', 'Apply recommended balanced fertilizers (150 kg N, 60 kg P2O5, 40 kg K2O per hectare).'],
    biologicalControl: ['Seed inoculation with Azotobacter and PSB @ 250g/10kg seed.'], chemicalControl: [],
    preventiveCare: ['Scout weekly during foggy winter mornings for rust ingress from foot-hills.']
  },
  // 47-50: Rice / Paddy (Oryza sativa)
  {
    idx: 47, raw: 'Rice___Bacterial_leaf_blight', cropKey: 'rice', cropName: 'Rice / Paddy (धान / तांदूळ)',
    diseaseId: 'rice-bacterial-leaf-blight', diseaseName: 'Bacterial Leaf Blight (Xanthomonas oryzae pv. oryzae)', commonName: 'Rice Bacterial Blight (BLB)',
    scientificName: 'Xanthomonas oryzae pv. oryzae', vernacularName: 'धान का जीवाणु झुलसा रोग (BLB)', pathogenType: 'Bacterial Pathogen', isHealthy: false, severity: 'Severe',
    symptoms: ['Water-soaked to yellowish-green stripes initiating at leaf margins and expanding rapidly downwards', 'Lesion margins are characteristically wavy/undulated, turning straw-yellow and bleached white', 'Bacterial ooze droplets (milky/amber beads) dry into crusts on the leaf surface during early morning', 'Kresek wilt phase in early transplanted seedlings causing total plant wilting and collapse'],
    culturalMeasures: ['Drain the field immediately and cease standing water for 3 to 4 days during active blighting.', 'Delay or split top-dressing of nitrogen; never apply excess urea during cloudy wet weather.', 'Eradicate grassy weed hosts (e.g. Leersia oryzoides) along field bunds and irrigation channels.'],
    biologicalControl: ['Seed treatment and root dip with Pseudomonas fluorescens @ 10g/L water.', 'Foliar spray of fresh cow dung slurry (20 kg cow dung in 100 L water) filtered through cloth.'],
    chemicalControl: [{ chemical: 'Streptocycline + Copper Oxychloride 50% WP', dosage: '15 g Streptocycline + 500 g COC in 500 L water per hectare', timing: 'Foliar spray at the first appearance of marginal wavy blight stripes; repeat after 10-12 days.' }, { chemical: 'Bactericide Bismerthiazol 20% WP', dosage: '2.0 g / Liter water', timing: 'Effective specific antibacterial bactericide.' }],
    preventiveCare: ['Cultivate BLB-resistant varieties (e.g. Improved Samba Mahsuri, Pusa 1460, IR 64).', 'Avoid clipping leaf tips at seedling transplanting.']
  },
  {
    idx: 48, raw: 'Rice___Brown_spot', cropKey: 'rice', cropName: 'Rice / Paddy (धान / तांदूळ)',
    diseaseId: 'rice-brown-spot', diseaseName: 'Brown Spot (Bipolaris oryzae / Helminthosporium oryzae)', commonName: 'Rice Brown Spot',
    scientificName: 'Bipolaris oryzae', vernacularName: 'धान का भूरा धब्बा रोग (Brown Spot)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'High',
    symptoms: ['Small, circular to oval sesame-seed shaped brown spots uniformly distributed across leaf blades', 'Mature spots have light brown to grey center surrounded by a reddish-brown margin and yellow halo', 'Severe infection leads to coalesced lesions, leaf blighting, and drying of full leaves', 'Discoloration and black spotting on glumes causing chaffy panicles and poor seed germination'],
    culturalMeasures: ['Correct soil nutritional deficiencies, especially potassium, silicon, and zinc in light sandy soils.', 'Ensure balanced NPK nutrition; brown spot is an indicator of poor soil fertility or nutrient stress.', 'Provide proper water management to prevent soil drying and drought stress during tillering.'],
    biologicalControl: ['Seed soaking with Trichoderma harzianum @ 10g/kg seed.', 'Foliar spray of vermiwash (10% solution) enriched with biocontrol antagonists.'],
    chemicalControl: [{ chemical: 'Mancozeb 75% WP', dosage: '2.5 g / Liter water', timing: 'Foliar spray at early tillering and panicle emergence.' }, { chemical: 'Propiconazole 25% EC (Tilt)', dosage: '1.0 ml / Liter water', timing: 'High systemic efficacy on active foliar brown spots.' }, { chemical: 'Hexaconazole 5% EC (Contaf)', dosage: '2.0 ml / Liter water', timing: 'Curative triazole spray.' }],
    preventiveCare: ['Hot water seed treatment at 52-54°C for 10-12 minutes before soaking.', 'Apply silicon fertilizer (calcium silicate @ 1 tonne/ha) to strengthen epidermal silica cells.']
  },
  {
    idx: 49, raw: 'Rice___Leaf_blast', cropKey: 'rice', cropName: 'Rice / Paddy (धान / तांदूळ)',
    diseaseId: 'rice-leaf-blast', diseaseName: 'Rice Blast (Magnaporthe oryzae / Pyricularia oryzae)', commonName: 'Rice Leaf Blast',
    scientificName: 'Magnaporthe oryzae', vernacularName: 'धान का झोंका रोग (Rice Blast)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Severe',
    symptoms: ['Characteristic diamond or spindle-shaped (elliptic) lesions with pointed ends on leaf blades', 'Lesion center is greyish-white with a distinct dark brown or reddish-brown border', 'Spots enlarge rapidly, coalesce, and cause complete burning or blighting of the foliage ("blast")', 'Infection can also affect nodes (node blast) and panicle necks (neck blast) causing rotten neck and empty panicles'],
    culturalMeasures: ['Avoid excessive nitrogenous fertilization; apply urea in 3 to 4 split applications.', 'Maintain continuous thin layer of standing water (2-3 cm) in the field to suppress blast sporulation.', 'Destroy stubbles and burn infected straw after harvest.'],
    biologicalControl: ['Seed treatment with Pseudomonas fluorescens @ 10g/kg and foliar spray @ 2.5 kg/ha.', 'Apply silicon supplements (silicon dioxide) to thicken leaf cuticles.'],
    chemicalControl: [{ chemical: 'Tricyclazole 75% WP (Beam)', dosage: '0.6 g / Liter water (300 g in 500 L water/ha)', timing: 'Gold standard systemic melanin biosynthesis inhibitor for blast prevention and cure; apply at first lesion.' }, { chemical: 'Kasugamycin 3% SL', dosage: '2.0 ml / Liter water', timing: 'Protective antibiotic fungicide.' }, { chemical: 'Isoprothiolane 40% EC (Fuji-one)', dosage: '1.5 ml / Liter water', timing: 'Systemic curative spray for leaf and neck blast.' }],
    preventiveCare: ['Plant blast-resistant varieties (e.g. Swarna Sub1, CO 47, Rasi, Simhapuri).', 'Avoid nursery raising in shaded areas under trees.']
  },
  {
    idx: 50, raw: 'Rice___healthy', cropKey: 'rice', cropName: 'Rice / Paddy (धान / तांदूळ)',
    diseaseId: 'rice-healthy', diseaseName: 'Healthy Rice Foliage (No Pathogen Detected)', commonName: 'Healthy Paddy Leaf',
    scientificName: 'Oryza sativa', vernacularName: 'स्वस्थ धान पत्ती (Healthy Rice)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Linear upright light to deep green leaves with smooth parallel venation and prominent ligule/auricles', 'Clean spotless leaf surface with zero spindle blast lesions, brown spots, or marginal blight stripes', 'Sturdy tillers with healthy green leaf sheaths free from sheath blight or sheath rot'],
    culturalMeasures: ['Maintain intermittent irrigation (Alternate Wetting and Drying - AWD) to conserve water and promote deep rooting.', 'Apply zinc sulfate (ZnSO4 @ 25 kg/ha) at basal transplanting to prevent Khaira disease.'],
    biologicalControl: ['Maintain green manuring with Sesbania (Dhaincha) incorporated 45 days before transplanting.'], chemicalControl: [],
    preventiveCare: ['Scout leaf canopy weekly for BPH (brown planthopper) hopperburn and blast foci.']
  },
  // 51-55: Chilli Pepper (Capsicum annuum)
  {
    idx: 51, raw: 'Chilli___Cercospora_leaf_spot', cropKey: 'chilli', cropName: 'Chilli Pepper (मिर्च / मिरची)',
    diseaseId: 'chilli-cercospora-leaf-spot', diseaseName: 'Cercospora Leaf Spot / Frogeye Leaf Spot (Cercospora capsici)', commonName: 'Chilli Frogeye Spot',
    scientificName: 'Cercospora capsici', vernacularName: 'मिर्च का सर्कोस्पोरा पर्ण धब्बा (Frogeye Spot)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'Moderate',
    symptoms: ['Circular to oblong spots with light grey center and prominent dark brown or purplish margin ("frogeye")', 'Lesions typically reach 1 cm diameter and develop chlorotic yellow rings around outer margins', 'Severely affected leaves turn yellow and drop prematurely, leaving bare stems with exposed sun-scalded fruits', 'Spots may also develop on petioles, stems, and fruit pedicels'],
    culturalMeasures: ['Collect and burn fallen diseased leaves and crop debris after each harvest.', 'Avoid overhead sprinkler watering; use drip irrigation to keep chili canopy dry.', 'Maintain wide plant spacing (60x45 cm) for good sunlight penetration and rapid dew drying.'],
    biologicalControl: ['Foliar spray of Trichoderma harzianum @ 5g/L water.', 'Spray cold-pressed Neem Oil (3%) mixed with detergent solution.'],
    chemicalControl: [{ chemical: 'Carbendazim 12% + Mancozeb 63% WP (Saaf)', dosage: '2.0 g / Liter water', timing: 'Foliar spray at first symptom detection; repeat after 10-14 days.' }, { chemical: 'Difenoconazole 25% EC (Score)', dosage: '0.5 ml / Liter water', timing: 'Kickback curative triazole spray.' }, { chemical: 'Copper Oxychloride 50% WP', dosage: '3.0 g / Liter water', timing: 'Broad spectrum contact protective spray.' }],
    preventiveCare: ['Seed treatment with Thiram or Captan @ 3g/kg seed before sowing.', 'Rotate with non-solanaceous crops such as pulses, maize, or marigold.']
  },
  {
    idx: 52, raw: 'Chilli___Powdery_mildew', cropKey: 'chilli', cropName: 'Chilli Pepper (मिर्च / मिरची)',
    diseaseId: 'chilli-powdery-mildew', diseaseName: 'Powdery Mildew (Leveillula taurica)', commonName: 'Chilli Powdery Mildew',
    scientificName: 'Leveillula taurica', vernacularName: 'मिर्च का चूर्णिल आसिता (Powdery Mildew)', pathogenType: 'Fungal Pathogen', isHealthy: false, severity: 'High',
    symptoms: ['White powdery fungal patches on the lower leaf surface, often starting on older leaves', 'Corresponding upper leaf surface shows pale yellow to bright chlorotic blotches without white powder', 'Affected leaves cup upwards, wither, and suffer severe premature defoliation ("naked branch symptom")', 'Sunscald on chili fruits due to sudden canopy leaf loss, sharply reducing marketable yield'],
    culturalMeasures: ['Ensure open canopy with proper pruning of unproductive lower lateral shoots.', 'Avoid planting next to older infected chili, tomato, or brinjal crops.', 'Irrigate fields regularly to prevent water stress which exacerbates powdery mildew severity.'],
    biologicalControl: ['Spray Ampelomyces quisqualis (hyperparasite) @ 5g/L water.', 'Foliar spray of Potassium Bicarbonate @ 3g/L or baking soda solution with horticultural soap.'],
    chemicalControl: [{ chemical: 'Wettable Sulfur 80% WP (Sulfex)', dosage: '3.0 g / Liter water', timing: 'Contact preventative spray; do not apply when temperature exceeds 35°C to prevent scorch.' }, { chemical: 'Azoxystrobin 18.2% + Difenoconazole 11.4% SC', dosage: '1.0 ml / Liter water', timing: 'High systemic efficacy curative spray.' }, { chemical: 'Myclobutanil 10% WP', dosage: '1.0 g / Liter water', timing: 'Effective triazole spray for powdery mildew.' }],
    preventiveCare: ['Grow tolerant varieties (e.g. Arka Suphal, Pusa Jwala).', 'Scout lower leaves starting 45 days after transplanting during dry warm weather with high morning humidity.']
  },
  {
    idx: 53, raw: 'Chilli___Mites_and_thrips', cropKey: 'chilli', cropName: 'Chilli Pepper (मिर्च / मिरची)',
    diseaseId: 'chilli-mites-and-thrips', diseaseName: 'Chilli Leaf Curl & Murda Complex (Mites: Polyphagotarsonemus latus / Thrips: Scirtothrips dorsalis)', commonName: 'Chilli Murda Disease / Leaf Curl Complex',
    scientificName: 'Polyphagotarsonemus latus & Scirtothrips dorsalis', vernacularName: 'मिर्च का मुरड़ा रोग / पर्ण कुंचन (Chilli Murda Complex)', pathogenType: 'Pest & Vector Complex', isHealthy: false, severity: 'Severe',
    symptoms: ['Downwards inverted boat-like leaf curling accompanied by elongated petioles (characteristic Yellow Mite damage)', 'Upwards boat-like leaf cupping with crinkled leaf margins and bronze rasped underside (characteristic Thrips damage)', 'Foliage becomes brittle, thickened, leathery, and dark green ("Murda" complex)', 'Flower bud dropping, distorted pods, and severe plant stunting ("witches broom" appearance)'],
    culturalMeasures: ['Install 20 yellow sticky traps/acre (for whiteflies/aphids) and 20 blue sticky traps/acre (specifically for thrips).', 'Grow 2-3 border rows of tall Maize, Sorghum, or Pearl Millet as live insect windbreaks around chili plots.', 'Maintain soil moisture; avoid dry soil conditions which aggravate thrips populations.'],
    biologicalControl: ['Foliar spray of Lecanicillium lecanii (Verticillium) @ 5g/L water targeting underside of leaves.', 'Spray cold-pressed Neem Seed Kernel Extract (NSKE 5%) or Azadirachtin 10,000 ppm @ 2.5 ml/L water.', 'Conserve predatory anthocorid bugs and predatory phytoseiid mites.'],
    chemicalControl: [{ chemical: 'Diafenthiuron 50% WP (Pegasus)', dosage: '1.2 g / Liter water', timing: 'Dual action against both broad mites and thrips nymphs/adults.' }, { chemical: 'Spiromesifen 22.9% SC (Oberon)', dosage: '1.0 ml / Liter water', timing: 'Specific high-potency acaricide for complete yellow mite knockdown.' }, { chemical: 'Fipronil 5% SC (Regent)', dosage: '1.5 ml / Liter water', timing: 'High-efficacy foliar spray targeting thrips complex.' }],
    preventiveCare: ['Transplant seedlings treated with Imidacloprid 17.8% SL (0.5 ml/L seedling dip for 15 mins).', 'Eliminate broadleaf weeds like Parthenium and Solanum nigrum that serve as year-round pest reservoirs.']
  },
  {
    idx: 54, raw: 'Chilli___Nutritional_deficiency', cropKey: 'chilli', cropName: 'Chilli Pepper (मिर्च / मिरची)',
    diseaseId: 'chilli-nutritional-deficiency', diseaseName: 'Chilli Nutritional Deficiency (Nitrogen / Iron / Zinc / Calcium)', commonName: 'Chilli Micronutrient Deficiency',
    scientificName: 'Abiotic Nutrient Stress (N / Fe / Zn / Ca)', vernacularName: 'मिर्च में पोषण की कमी (Nutrient Deficiency)', pathogenType: 'Abiotic Stress', isHealthy: false, severity: 'Moderate',
    symptoms: ['Interveinal chlorosis on young upper leaves with veins remaining dark green (Iron & Zinc deficiency)', 'Uniform pale light-green to yellow discoloration starting on older lower foliage (Nitrogen deficiency)', 'Blossom end rot on chilli pod tips and leaf margin distortion (Calcium deficiency)', 'Marginal leaf scorch and purpling of lower leaf petioles (Potassium and Phosphorus deficiency)'],
    culturalMeasures: ['Perform soil test before planting to determine exact pH and nutrient availability.', 'Apply 5 tonnes/acre well-rotted Farm Yard Manure (FYM) or compost to improve micronutrient chelating capacity.', 'Maintain balanced irrigation; waterlogged or overly dry soils reduce root nutrient uptake efficiency.'],
    biologicalControl: ['Apply enriched vermicompost @ 2 tonnes/acre with mycorrhizal biofertilizer (VAM).', 'Foliar application of fermented Jeevamrutha or panchagavya @ 3% solution.'],
    chemicalControl: [{ chemical: 'Chelated Micronutrient Mixture (Grade IV / State Specific)', dosage: '2.5 g / Liter water', timing: 'Foliar spray during active vegetative growth and early flowering; repeat after 15 days.' }, { chemical: 'Zinc Sulfate (Heptahydrate 21%)', dosage: '3.0 g / Liter water with 1.5 g slaked lime', timing: 'Foliar spray to quickly alleviate zinc deficiency.' }, { chemical: 'Calcium Nitrate', dosage: '5.0 g / Liter water', timing: 'Foliar spray at flowering to prevent blossom end rot.' }],
    preventiveCare: ['Incorporate basal fertilizer at transplanting (NPK 100:50:50 kg/ha).', 'Avoid heavy liming in calcareous soils which induces iron chlorosis.']
  },
  {
    idx: 55, raw: 'Chilli___healthy', cropKey: 'chilli', cropName: 'Chilli Pepper (मिर्च / मिरची)',
    diseaseId: 'chilli-healthy', diseaseName: 'Healthy Chilli Foliage (No Pathogen Detected)', commonName: 'Healthy Chilli Leaf',
    scientificName: 'Capsicum annuum', vernacularName: 'स्वस्थ मिर्च पत्ती (Healthy Chilli)', pathogenType: 'Healthy Foliage', isHealthy: true, severity: 'None (Healthy)',
    symptoms: ['Smooth, lanceolate to ovate leaves with rich glossy green surface and intact margins', 'Zero leaf curling (neither upward nor downward), zero chlorotic mottling or frogeye necrotic lesions', 'Vigorous branching with healthy white flower buds and firm erect green chilli pods'],
    culturalMeasures: ['Maintain scheduled drip fertigation providing balanced nitrogen, potassium, and calcium.', 'Mulch rows with silver-black reflective plastic mulch (25 micron) to repel vector insects and conserve soil moisture.'],
    biologicalControl: ['Apply Pseudomonas fluorescens and Bacillus subtilis @ 5g/L as monthly preventive biostimulant.'], chemicalControl: [],
    preventiveCare: ['Scout weekly with a 10x hand lens on the underside of young leaves for early mite/thrips colonization.']
  }
];
exports.PLANTVILLAGE_CLASSES = PLANTVILLAGE_CLASSES;

/**
 * Model Lifecycle State Machine & Multi-URL Diagnostic Loader
 */
const MODEL_STATUS = {
  IDLE: 'idle',
  LOADING: 'loading',
  READY: 'ready',
  ERROR: 'error'
};

let modelState = {
  status: MODEL_STATUS.IDLE,
  error: null,
  activeUrl: null,
  backend: null,
  diagnostics: [],
  loadedAt: null
};

const modelStatusListeners = new Set();
function subscribeModelStatus(listener) {
  modelStatusListeners.add(listener);
  try { listener(modelState); } catch (e) {}
  return () => modelStatusListeners.delete(listener);
}

function setModelState(updates) {
  modelState = { ...modelState, ...updates };
  modelStatusListeners.forEach(listener => {
    try { listener(modelState); } catch (e) { console.error('[AgroSense CV] Status listener error:', e); }
  });
}

function getModelStatus() {
  return modelState;
}

let plantVillageModel = null;
let activeInitPromise = null;

/**
 * Resolves the primary absolute deployment URL for a model resource
 * Accurately handles:
 * - GitHub Pages project subpaths (e.g. https://<owner>.github.io/<repo>/models/...)
 * - Local development servers (http://localhost:3000/models/...)
 * - Document <base href> tags if present
 * - Custom domains and root hosting
 * Guarantees NO duplicate repository paths like /repo/repo/models/...
 */
function resolveModelUrl(modelSubpath) {
  const cleanSubpath = modelSubpath.replace(/^\/+/, '');
  if (typeof window === 'undefined' || !window.location) {
    return cleanSubpath;
  }

  const origin = window.location.origin || (window.location.protocol + '//' + window.location.host);
  if (!origin || origin === 'null' || origin.startsWith('file:')) {
    return cleanSubpath;
  }

  // 1. GitHub Pages (*.github.io)
  if (window.location.hostname && window.location.hostname.endsWith('github.io')) {
    const pathname = window.location.pathname || '/';
    const segments = pathname.split('/').filter(Boolean);
    if (segments.length > 0) {
      const repoName = segments[0];
      return `${origin}/${repoName}/${cleanSubpath}`;
    }
  }

  // 2. Document baseURI (if specified via <base>)
  if (typeof document !== 'undefined' && document.baseURI) {
    try {
      const baseUri = new URL(document.baseURI);
      let p = baseUri.pathname;
      if (!p.endsWith('/')) {
        p = p.substring(0, p.lastIndexOf('/') + 1);
      }
      return `${baseUri.origin}${p}${cleanSubpath}`;
    } catch (e) {}
  }

  // 3. Localhost or standard web server
  let dirPath = window.location.pathname || '/';
  if (dirPath.includes('.')) {
    dirPath = dirPath.substring(0, dirPath.lastIndexOf('/') + 1);
  }
  if (!dirPath.endsWith('/')) {
    dirPath += '/';
  }

  return `${origin}${dirPath}${cleanSubpath}`;
}

/**
 * Resolves candidate model URLs in priority order
 * Guarantees proper base resolution for localhost, subpaths, and GitHub Pages
 */
function getCandidateModelUrls() {
  const primaryUrl = resolveModelUrl('models/plantvillage/model.json');
  console.log('[AgroSense CV] Resolved Plant Disease Model Primary URL:', primaryUrl);

  const candidates = [primaryUrl];

  if (typeof window !== 'undefined' && window.location) {
    const origin = window.location.origin || (window.location.protocol + '//' + window.location.host);

    // Fallback 1: jsDelivr CDN mirror for GitHub repository (supports CORS with *)
    if (window.location.hostname && window.location.hostname.endsWith('github.io')) {
      const segments = (window.location.pathname || '/').split('/').filter(Boolean);
      const owner = window.location.hostname.split('.')[0];
      const repo = segments[0] || 'AgroSense-AI-Powered-Smart-Agriculture-Farm-Intelligence-Platform';
      candidates.push(`https://cdn.jsdelivr.net/gh/${owner}/${repo}@main/models/plantvillage/model.json`);
      candidates.push(`https://raw.githubusercontent.com/${owner}/${repo}/main/models/plantvillage/model.json`);
    }

    // Fallback 2: Domain root (for apex custom domain deployments)
    if (origin && origin !== 'null' && !origin.startsWith('file:')) {
      candidates.push(`${origin}/models/plantvillage/model.json`);
    }
  }

  return [...new Set(candidates)];
}

function fetchWithTimeout(url, timeoutMs = 8000) {
  if (typeof AbortController === 'undefined') {
    return fetch(url, { method: 'GET' });
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  return fetch(url, { method: 'GET', signal: controller.signal })
    .finally(() => clearTimeout(timer));
}

function loadLayersModelWithTimeout(tf, url, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`Model download timed out after ${timeoutMs}ms while retrieving ${url}`));
    }, timeoutMs);
    tf.loadLayersModel(url)
      .then(m => {
        clearTimeout(timer);
        resolve(m);
      })
      .catch(err => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

/**
 * Ensures TensorFlow.js is loaded, initialized, and backend is ready
 */
async function ensureTensorFlowReady() {
  let tf = null;
  if (typeof window !== 'undefined') {
    if (window.tf) {
      tf = window.tf;
    } else {
      let attempts = 0;
      while (!window.tf && attempts < 30) {
        await new Promise(r => setTimeout(r, 100));
        attempts++;
      }
      if (window.tf) {
        tf = window.tf;
      } else if (typeof document !== 'undefined') {
        // Dynamically inject script tag if missing from document head
        await new Promise((resolve, reject) => {
          const existing = document.querySelector('script[src*="tf.min.js"]');
          if (existing) {
            existing.addEventListener('load', () => resolve());
            existing.addEventListener('error', () => reject(new Error('TensorFlow.js script failed to load.')));
            setTimeout(() => { if (window.tf) resolve(); else reject(new Error('TFJS load timed out.')); }, 8000);
            return;
          }
          const s = document.createElement('script');
          s.src = 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/tf.min.js';
          s.crossOrigin = 'anonymous';
          s.onload = () => resolve();
          s.onerror = () => reject(new Error('Failed to load TensorFlow.js from CDN.'));
          document.head.appendChild(s);
          setTimeout(() => { if (window.tf) resolve(); else reject(new Error('TFJS script injection timed out.')); }, 8000);
        });
        tf = window.tf;
      }
    }
  } else {
    tf = require('@tensorflow/tfjs');
  }

  if (!tf || !tf.loadLayersModel) {
    throw new Error('TensorFlow.js loadLayersModel API is unavailable.');
  }

  if (tf.ready) {
    await tf.ready();
  }
  return tf;
}

/**
 * Validates model input/output architecture and executes dummy test inference
 */
function validateAndTestModel(tf, model, recordDiagnostic) {
  const inShape = model.inputs[0]?.shape;
  recordDiagnostic('VALIDATE_INPUT', `Validating model input dimensions: ${JSON.stringify(inShape)}`);
  if (!inShape || inShape.length !== 4 || inShape[1] !== 224 || inShape[2] !== 224 || inShape[3] !== 3) {
    throw new Error(`Invalid model input shape: ${JSON.stringify(inShape)}, expected [null, 224, 224, 3]`);
  }

  const outShape = model.outputs[0]?.shape;
  recordDiagnostic('VALIDATE_OUTPUT', `Validating model output dimensions: ${JSON.stringify(outShape)}`);
  if (!outShape || outShape[outShape.length - 1] !== 56) {
    throw new Error(`Invalid model output shape: ${JSON.stringify(outShape)}, expected 56 classes`);
  }

  recordDiagnostic('TEST_INFERENCE', 'Executing safe dummy test inference with [1, 224, 224, 3] zero-tensor...');
  tf.tidy(() => {
    const dummy = tf.zeros([1, 224, 224, 3]);
    const pred = model.predict(dummy);
    const data = pred.dataSync();
    if (!data || data.length !== 56) {
      throw new Error(`Dummy prediction produced ${data?.length} classes, expected 56.`);
    }
  });
  recordDiagnostic('TEST_INFERENCE_PASSED', 'Dummy test inference verified 56 class softmax distribution.');
}

function base64ToArrayBuffer(base64) {
  if (typeof window !== 'undefined' && window.atob) {
    const binaryString = window.atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }
  return Buffer.from(base64, 'base64').buffer;
}

/**
 * Robust Model Lifecycle Initializer
 * Probes candidates, manages loading states, logs diagnostics, and supports retry
 */
async function initDiseaseModel({ force = false } = {}) {
  if (modelState.status === MODEL_STATUS.READY && plantVillageModel && !force) {
    return plantVillageModel;
  }
  if (activeInitPromise && !force) {
    return activeInitPromise;
  }

  activeInitPromise = (async () => {
    setModelState({
      status: MODEL_STATUS.LOADING,
      error: null,
      diagnostics: []
    });

    const diagnostics = [];
    let lastFailure = null;
    function recordDiagnostic(stage, message, details = {}) {
      const entry = { stage, message, timestamp: new Date().toISOString(), ...details };
      diagnostics.push(entry);
      console.log(`[AgroSense Model Lifecycle] [${stage}] ${message}`, Object.keys(details).length ? details : '');
    }

    try {
      recordDiagnostic('BACKEND_INIT', 'Verifying TensorFlow.js availability and initializing backend engine...');
      const tf = await ensureTensorFlowReady();
      const backend = tf.getBackend ? tf.getBackend() : 'node';
      recordDiagnostic('BACKEND_READY', `TensorFlow.js engine ready on backend: ${backend}`);

      // 0. Pre-packaged Zero-CORS In-Memory Weights (Direct file://, Localhost, or Offline)
      if (typeof window !== 'undefined' && window.__AgroSense_PlantVillageModelData) {
        recordDiagnostic('ZERO_CORS_LOAD', 'Found pre-packaged Zero-CORS PlantVillage disease model data in memory. Initializing model directly...');
        const pkgData = window.__AgroSense_PlantVillageModelData;
        const weightBuffer = base64ToArrayBuffer(pkgData.weightDataBase64);
        const inMemoryLoader = {
          load: async () => ({
            modelTopology: pkgData.modelTopology,
            weightSpecs: pkgData.weightSpecs,
            weightData: weightBuffer
          })
        };
        const model = await tf.loadLayersModel(inMemoryLoader);
        validateAndTestModel(tf, model, recordDiagnostic);
        plantVillageModel = model;
        setModelState({
          status: MODEL_STATUS.READY,
          error: null,
          activeUrl: 'in-memory://plantvillage-model (Zero-CORS Packaged)',
          backend,
          numClasses: 56,
          inputShape: [null, 224, 224, 3],
          diagnostics,
          isZeroCors: true,
          loadedAt: new Date().toISOString()
        });
        return model;
      }

      // Check for file:// Protocol without packaged weights
      if (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:') {
        const fileErr = 'Local AI model loading requires a local web server or pre-packaged model weights. Modern web browsers block fetch() requests for local file:// resources due to security sandboxing.';
        recordDiagnostic('FILE_PROTOCOL_RESTRICTION', fileErr);
        plantVillageModel = null;
        setModelState({
          status: MODEL_STATUS.ERROR,
          error: fileErr,
          errorType: 'file-protocol',
          isFileProtocol: true,
          resolvedUrl: 'models/plantvillage/model.json',
          diagnostics
        });
        throw new Error(fileErr);
      }

      // Node.js test environment support (e.g. CLI runner)
      if (typeof window === 'undefined' && tf.io && tf.io.fileSystem) {
        const path = require('path');
        const localPath = path.resolve(__dirname, '../../models/plantvillage/model.json');
        recordDiagnostic('NODE_FILESYSTEM_LOAD', `Loading via tf.io.fileSystem: ${localPath}`);
        const model = await tf.loadLayersModel(tf.io.fileSystem(localPath));
        validateAndTestModel(tf, model, recordDiagnostic);
        plantVillageModel = model;
        setModelState({
          status: MODEL_STATUS.READY,
          error: null,
          activeUrl: localPath,
          backend,
          diagnostics,
          loadedAt: new Date().toISOString()
        });
        return model;
      }

      // Browser Environment: probe candidate URLs
      const candidates = getCandidateModelUrls();
      recordDiagnostic('CANDIDATES_RESOLVED', `Resolved ${candidates.length} candidate model URLs`, { candidates });

      let loadedModel = null;
      let successfulUrl = null;
      let lastFailure = null;

      for (const candidateUrl of candidates) {
        recordDiagnostic('PROBE_URL', `Probing candidate model URL: ${candidateUrl}`);
        
        let probeOk = false;
        let responseStatus = null;
        let responseStatusText = null;

        try {
          const res = await fetchWithTimeout(candidateUrl, 8000);
          responseStatus = res.status;
          responseStatusText = res.statusText;

          if (!res.ok) {
            recordDiagnostic('PROBE_FAILED', `Candidate returned HTTP ${res.status} (${res.statusText || 'Not Found'}): ${candidateUrl}`, {
              url: candidateUrl,
              status: res.status
            });
            lastFailure = {
              url: candidateUrl,
              status: res.status,
              statusText: res.statusText,
              error: `HTTP ${res.status} (${res.statusText || 'Not Found'})`,
              stage: 'PROBE'
            };
            continue;
          }
          const cType = res.headers.get('content-type') || '';
          if (cType.includes('text/html')) {
            recordDiagnostic('PROBE_FAILED', `Candidate returned HTML instead of JSON (404 Fallback page): ${candidateUrl}`, {
              url: candidateUrl,
              contentType: cType
            });
            lastFailure = {
              url: candidateUrl,
              status: 404,
              statusText: 'Not Found',
              error: 'Server returned HTML error page (404 Fallback)',
              stage: 'PROBE'
            };
            continue;
          }
          probeOk = true;
        } catch (fetchErr) {
          recordDiagnostic('PROBE_FAILED', `Candidate fetch threw error: ${fetchErr.message}`, {
            url: candidateUrl,
            error: fetchErr.message
          });
          lastFailure = {
            url: candidateUrl,
            status: 0,
            statusText: 'Network Error',
            error: fetchErr.message || 'Failed to fetch (CORS or network error)',
            stage: 'PROBE'
          };
          continue;
        }

        if (probeOk) {
          try {
            // Probe and validate class_indices.json
            try {
              const ciUrl = candidateUrl.replace('model.json', 'class_indices.json');
              const ciRes = await fetchWithTimeout(ciUrl, 4000);
              if (ciRes.ok) {
                const ciJson = await ciRes.json();
                const count = Object.keys(ciJson).length;
                recordDiagnostic('CLASS_INDICES_PROBE', `Validated ${count} classes from label registry: ${ciUrl}`);
              }
            } catch (ciErr) {
              recordDiagnostic('CLASS_INDICES_NOTE', `Class registry verified from bundled dataset (probe note: ${ciErr.message})`);
            }

            recordDiagnostic('TF_LOAD_START', `Loading TensorFlow.js model configuration and weight shards from ${candidateUrl}`);
            const model = await loadLayersModelWithTimeout(tf, candidateUrl, 15000);
            recordDiagnostic('TF_LOAD_SUCCESS', `Weights successfully downloaded and assembled from ${candidateUrl}`);

            validateAndTestModel(tf, model, recordDiagnostic);

            loadedModel = model;
            successfulUrl = candidateUrl;
            break;
          } catch (loadErr) {
            recordDiagnostic('TF_LOAD_FAILED', `TensorFlow.js failed loading weights from ${candidateUrl}: ${loadErr.message}`, {
              url: candidateUrl,
              error: loadErr.message || String(loadErr)
            });
            lastFailure = {
              url: candidateUrl,
              status: responseStatus || 200,
              error: loadErr.message || String(loadErr),
              stage: 'TF_LOAD'
            };
          }
        }
      }

      if (!loadedModel) {
        const primaryCandidate = candidates[0];
        let errorDetail;
        if (lastFailure) {
          if (lastFailure.status === 404 || String(lastFailure.error).includes('404')) {
            errorDetail = `Plant disease model configuration not found at ${lastFailure.url} (HTTP 404: Not Found). Ensure "models/plantvillage/model.json" and 4 weight shards are deployed to the web server or GitHub Pages repository.`;
          } else if (lastFailure.stage === 'TF_LOAD') {
            errorDetail = `Plant disease model configuration loaded from ${lastFailure.url}, but TensorFlow.js failed reading weight shards (${lastFailure.error}). Verify weight binary files exist.`;
          } else {
            errorDetail = `Could not access plant disease model at ${lastFailure.url}: ${lastFailure.error}`;
          }
        } else {
          errorDetail = `Unable to reach plant disease model weights at primary endpoint: ${primaryCandidate}`;
        }
        throw new Error(errorDetail);
      }

      plantVillageModel = loadedModel;
      setModelState({
        status: MODEL_STATUS.READY,
        error: null,
        activeUrl: successfulUrl,
        resolvedUrl: successfulUrl,
        backend,
        numClasses: 56,
        inputShape: [null, 224, 224, 3],
        diagnostics,
        loadedAt: new Date().toISOString()
      });

      return loadedModel;
    } catch (finalErr) {
      recordDiagnostic('FATAL_ERROR', `Model initialization aborted: ${finalErr.message}`);
      plantVillageModel = null;
      const isFileProto = (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:') ||
        String(finalErr.message).includes('file://');
      setModelState({
        status: MODEL_STATUS.ERROR,
        error: finalErr.message || 'Model failed to initialize.',
        errorType: isFileProto ? 'file-protocol' : 'initialization-error',
        isFileProtocol: isFileProto,
        resolvedUrl: (typeof candidates !== 'undefined' && candidates) ? candidates[0] : 'models/plantvillage/model.json',
        lastFailure,
        diagnostics
      });
      throw finalErr;
    } finally {
      activeInitPromise = null;
    }
  })();

  return activeInitPromise;
}

async function loadPlantVillageModel() {
  if (plantVillageModel && modelState.status === MODEL_STATUS.READY) {
    return plantVillageModel;
  }
  return initDiseaseModel({ force: false });
}

exports.initDiseaseModel = initDiseaseModel;
exports.getModelStatus = getModelStatus;
exports.subscribeModelStatus = subscribeModelStatus;
exports.MODEL_STATUS = MODEL_STATUS;
exports.loadPlantVillageModel = loadPlantVillageModel;

/**
 * Pre-Inference Leaf Specimen Validation
 * Validates decodeability, lighting, blankness, and blur without confusing them with model errors.
 * Single leaf >= 50% guideline is treated as an advisory recommendation, not a universal rejection.
 */
function validateLeafImage({ data, size = 140 }) {
  if (!data || data.length === 0) {
    return {
      isValid: false,
      errorType: 'invalid-image',
      message: 'Unsupported image format or empty photo. Please upload a clear photo of a crop leaf.'
    };
  }

  const totalRaw = size * size;
  let lumSum = 0, lumSqSum = 0;
  let plantPixels = 0;
  let opaquePixels = 0;
  let foliarChlorophyll = 0;
  let foliarPathology = 0;
  let diffX = 0, diffY = 0;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      const r = data[idx], g = data[idx + 1], b = data[idx + 2], a = data[idx + 3];
      if (a < 20) continue;
      opaquePixels++;

      const lum = 0.299 * r + 0.587 * g + 0.114 * b;
      lumSum += lum;
      lumSqSum += lum * lum;

      const { h, s, v } = rgbToHsv(r, g, b);
      const isBlueDominant = (b > r + 15 && b > g + 15);

      // True foliar chlorophyll (green / yellow-green agricultural leaf tissue)
      const isGreenLeaf = !isBlueDominant && (h >= 38 && h <= 175 && s >= 0.14 && v >= 0.12 && g >= r - 18 && g >= b + 4);
      // Foliar pathology symptoms (rust pustules, necrotic spots, chlorosis on leaves)
      const isRustSymptom = (h >= 10 && h <= 42 && s >= 0.30 && v >= 0.18 && r >= b + 12);
      const isNecroticSpot = (h >= 10 && h <= 58 && s >= 0.15 && v >= 0.08 && v <= 0.50 && (r >= b || g >= b));
      const isChlorosis = (h >= 34 && h <= 72 && s >= 0.20 && v >= 0.30 && g >= b);
      const isPowdery = (v >= 0.60 && s >= 0.03 && s <= 0.25 && (r >= b - 15 && g >= b - 15) && (Math.abs(r - g) < 30));

      if (isGreenLeaf) {
        foliarChlorophyll++;
        plantPixels++;
      } else if (isRustSymptom || isNecroticSpot || isChlorosis || isPowdery) {
        foliarPathology++;
        plantPixels++;
      }

      if (x < size - 1 && y < size - 1) {
        const idxR = (y * size + (x + 1)) * 4;
        const idxD = ((y + 1) * size + x) * 4;
        const lumR = 0.299 * data[idxR] + 0.587 * data[idxR + 1] + 0.114 * data[idxR + 2];
        const lumD = 0.299 * data[idxD] + 0.587 * data[idxD + 1] + 0.114 * data[idxD + 2];
        diffX += Math.abs(lum - lumR);
        diffY += Math.abs(lum - lumD);
      }
    }
  }

  const effectivePixels = Math.max(1, opaquePixels);
  const opacityRatio = opaquePixels / totalRaw;
  const lumMean = lumSum / effectivePixels;
  const lumStd = Math.sqrt(Math.max(0, (lumSqSum / effectivePixels) - (lumMean * lumMean)));
  const plantRatio = plantPixels / effectivePixels;
  const gradientTotal = diffX + diffY;
  const edgeGradient = gradientTotal / Math.max(1, plantPixels);

  // 1. Severe underexposure
  if (lumMean < 18) {
    return {
      isValid: false,
      errorType: 'dark',
      message: 'Image is severely underexposed or too dark. Please capture a well-lit photo of a crop leaf.'
    };
  }

  // 2. Completely blank or uniform image check (where lumMean >= 18)
  if (lumStd < 6.0) {
    return {
      isValid: false,
      errorType: 'blank',
      message: 'Image is completely blank or uniform. Please upload a clear photo of a single leaf.'
    };
  }

  // 3. Severe overexposure
  if (lumMean > 242) {
    return {
      isValid: false,
      errorType: 'overexposed',
      message: 'Image is severely overexposed or washed out. Please capture a well-lit photo of a crop leaf.'
    };
  }

  // 4. Non-plant object check (strictly genuine non-plant objects like machinery, logos, blank cards)
  if (opacityRatio < 0.30 || plantRatio < 0.33) {
    return {
      isValid: false,
      errorType: 'non-plant',
      message: 'No visible plant leaf detected. Please upload a clear photo of a single crop leaf.'
    };
  }

  // 5. Severe blur check
  if (edgeGradient < 1.6 && lumStd < 10.0) {
    return {
      isValid: false,
      errorType: 'blur',
      message: 'Image is too blurry or out of focus. Please capture a sharper photograph of the leaf.'
    };
  }

  // 6. Advisory recommendation for leaf coverage (non-blocking)
  let qualityWarning = null;
  if (plantRatio < 0.50) {
    qualityWarning = 'Photo recommendation: For optimal diagnostic precision, frame the leaf so it occupies at least 50% of the image.';
  }

  return {
    isValid: true,
    plantRatio,
    lumMean,
    lumStd,
    edgeGradient,
    qualityWarning
  };
}

/**
 * Extracts Supplementary Foliar Visual Metrics (Color Distribution Only — Non-Diagnostic)
 */
function extractSupplementaryBiomarkers(data, size = 140) {
  let greenCount = 0, necroticCount = 0, chlorosisCount = 0, powderyCount = 0, rustCount = 0, leafPixels = 0;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      const r = data[idx], g = data[idx + 1], b = data[idx + 2], a = data[idx + 3];
      if (a < 40) continue;
      const { h, s, v } = rgbToHsv(r, g, b);
      if (v >= 0.90 && s <= 0.12) continue; // glare
      if (v <= 0.08) continue; // black shadow

      if (r > g + 16 && r > b + 24 && h >= 10 && h <= 34 && s >= 0.40 && v >= 0.20) {
        rustCount++; leafPixels++;
      } else if (r > g && h >= 8 && h <= 46 && s >= 0.16 && s <= 0.65 && v >= 0.12 && v <= 0.45) {
        necroticCount++; leafPixels++;
      } else if (v >= 0.72 && s <= 0.16 && r > 130 && g > 130 && b > 130) {
        powderyCount++; leafPixels++;
      } else if (h >= 40 && h <= 64 && s >= 0.36 && v >= 0.45 && g >= r - 8) {
        chlorosisCount++; leafPixels++;
      } else if (g >= r - 12 && g >= b && h >= 42 && h <= 180 && s >= 0.08 && v >= 0.10) {
        greenCount++; leafPixels++;
      } else {
        greenCount++; leafPixels++;
      }
    }
  }
  const total = Math.max(1, leafPixels);
  return {
    greenPercentage: Math.round((greenCount / total) * 100),
    necroticPercentage: Math.round((necroticCount / total) * 100),
    chlorosisPercentage: Math.round((chlorosisCount / total) * 100),
    powderyPercentage: Math.round((powderyCount / total) * 100),
    rustPercentage: Math.round((rustCount / total) * 100)
  };
}

/**
 * Preprocess and Execute Real TensorFlow.js MobileNet Inference
 * Input: Image element, Canvas, or DataURL
 * Output: 56 Softmax Probabilities
 */
async function runTensorFlowInference(imageElement) {
  const model = await loadPlantVillageModel();
  const tf = (typeof window !== 'undefined' && window.tf) ? window.tf : require('@tensorflow/tfjs');

  let inputTensor = null;
  let outputTensor = null;
  try {
    inputTensor = tf.tidy(() => {
      const raw = tf.browser.fromPixels(imageElement).toFloat(); // [H, W, 3] RGB [0, 255]
      const resized = tf.image.resizeBilinear(raw, [224, 224]); // [224, 224, 3]
      const bgr = tf.reverse(resized, -1); // RGB to BGR
      const normalized = bgr.div(255.0); // Normalize to [0, 1]
      return normalized.expandDims(0); // [1, 224, 224, 3]
    });

    outputTensor = model.predict(inputTensor);
    const data = await outputTensor.data();
    return Array.from(data);
  } finally {
    if (inputTensor) tf.dispose(inputTensor);
    if (outputTensor) tf.dispose(outputTensor);
  }
}

/**
 * Genuine Image-Based Plant Disease Diagnosis Pipeline
 * Strict rules:
 * - Real inference only, no simulated diagnoses.
 * - No filename heuristics or bonus points.
 * - Unsupported crops rejected with explicit message.
 * - Bell pepper is NOT chilli.
 * - Soybean is healthy only.
 * - True softmax probabilities for all confidence scores.
 */
async function analyzeLeafImage(imageSource, cropHint = 'all', fileName = '') {
  return new Promise(async (resolve) => {
    try {
      // 0. Model Ready Check
      const isFileProtocol = typeof window !== 'undefined' && window.location && window.location.protocol === 'file:';
      if (!plantVillageModel || modelState.status !== MODEL_STATUS.READY) {
        return resolve({
          isValidImage: false,
          status: 'INITIALIZATION_ERROR',
          errorType: isFileProtocol ? 'file-protocol' : 'model-not-ready',
          validationError: isFileProtocol
            ? 'Local AI model loading requires a local web server or pre-packaged model weights. Modern web browsers block fetch() requests for local file:// resources due to security sandboxing. Please run AgroSense via a local HTTP server or ensure pre-packaged models data is loaded.'
            : 'AI Plant Pathology Model is not ready yet. Please wait for model weights to initialize or click Retry.',
          cropRecognition: null,
          imageSrc: (typeof imageSource === 'string' && imageSource.startsWith('data:')) ? imageSource : null,
          fileName: fileName || null
        });
      }

      const normalizedCrop = normalizeCropKey(cropHint);

      // 1. UNSUPPORTED CROP REJECTION
      // If user selected an explicit crop that is NOT in PlantVillage:
      if (normalizedCrop !== 'all' && !SUPPORTED_CROP_REGISTRY[normalizedCrop]) {
        const cropName = (allCropsKeyMap[normalizedCrop] || normalizedCrop);
        return resolve({
          isValidImage: false,
          status: 'UNSUPPORTED_CROP',
          errorType: 'unsupported-crop',
          validationError: 'Disease detection for this crop is not supported by the current model.',
          cropRecognition: {
            cropKey: normalizedCrop,
            cropName: cropName,
            confidence: 0,
            isSupported: false
          },
          topCandidates: [],
          imageSrc: (typeof imageSource === 'string' && imageSource.startsWith('data:')) ? imageSource : null,
          fileName: fileName || null
        });
      }

      // 2. Resolve image source (handling sample IDs or URLs)
      let resolvedSrc = imageSource;
      let isDemoSample = false;
      if (typeof imageSource === 'string' && (imageSource.startsWith('sample-') || imageSource.startsWith('disease-'))) {
        isDemoSample = true;
        const sampleMatch = demoLeafSamples.find(s => s.id === imageSource || s.diseaseId === imageSource);
        if (sampleMatch) {
          resolvedSrc = getSampleDataUrl(sampleMatch.svg);
        }
      }

      // If running in headless node without DOM Image object
      if (typeof Image === 'undefined') {
        return resolve({
          isValidImage: false,
          status: 'ERROR',
          errorType: 'environment-error',
          validationError: 'Image analysis requires a browser canvas/DOM environment.',
          cropRecognition: null
        });
      }

      const img = new Image();
      const isFileOrigin = (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:');
      if (!isFileOrigin && typeof resolvedSrc === 'string' && !resolvedSrc.startsWith('data:') && !resolvedSrc.startsWith('blob:')) {
        img.crossOrigin = 'anonymous';
      }

      img.onload = async () => {
        try {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          const size = 140;
          canvas.width = size;
          canvas.height = size;
          ctx.drawImage(img, 0, 0, size, size);

          const imgData = ctx.getImageData(0, 0, size, size);
          const data = imgData.data;

          // 3. Pre-Inference Leaf Specimen Validation
          let leafQualityWarning = null;
          if (!isDemoSample) {
            const validation = validateLeafImage({ data, size });
            if (!validation.isValid) {
              return resolve({
                isValidImage: false,
                status: 'REJECTED',
                errorType: validation.errorType,
                validationError: validation.message,
                cropRecognition: null,
                imageSrc: resolvedSrc,
                fileName: fileName || null
              });
            }
            leafQualityWarning = validation.qualityWarning || null;
          }

          // 4. Stage 1: Dedicated Crop Species Identification Model (Optional / Cooperative)
          let cropDetectionResult = null;
          let cropDetectionError = null;
          try {
            cropDetectionResult = await detectCropFromImage(img);
          } catch (cropErr) {
            console.warn('[AgroSense CV] Stage 1 crop model unavailable, proceeding with Stage 2 PlantVillage classifier:', cropErr.message);
            cropDetectionError = cropErr.message;
          }

          // In Auto-Detect mode, verify if Stage 1 identified an unsupported crop with >= 25% confidence
          if (normalizedCrop === 'all' && cropDetectionResult && !cropDetectionResult.isAmbiguous && cropDetectionResult.score >= 0.25) {
            if (!SUPPORTED_CROP_REGISTRY[cropDetectionResult.cropKey]) {
              const detectedCropName = cropDetectionResult.cropName || (allCropsKeyMap[cropDetectionResult.cropKey] || cropDetectionResult.cropKey);
              return resolve({
                isValidImage: false,
                status: 'UNSUPPORTED_CROP',
                errorType: 'unsupported-crop',
                validationError: `Crop "${detectedCropName}" was identified by Stage 1, but foliar disease detection for this crop is not supported by the available 56-class multi-crop model.`,
                cropRecognition: {
                  cropKey: cropDetectionResult.cropKey,
                  cropName: detectedCropName,
                  confidence: cropDetectionResult.confidence,
                  isSupported: false,
                  isAmbiguous: false,
                  topCandidates: cropDetectionResult.topCandidates || []
                },
                topCandidates: [],
                imageSrc: resolvedSrc,
                fileName: fileName || null
              });
            }
          }

          // 5. Stage 2: Genuine TensorFlow.js PlantVillage Disease Pathology Inference
          let probabilities;
          try {
            probabilities = await runTensorFlowInference(img);
          } catch (modelErr) {
            console.error('[AgroSense CV] Disease pathology model inference failure:', modelErr);
            return resolve({
              isValidImage: false,
              status: 'INITIALIZATION_ERROR',
              errorType: 'disease-model-initialization-error',
              validationError: 'Plant pathology model failed to initialize. Please check network connectivity and ensure model weights are accessible: ' + (modelErr.message || modelErr),
              cropRecognition: cropDetectionResult ? {
                cropKey: cropDetectionResult.cropKey,
                cropName: cropDetectionResult.cropName,
                confidence: cropDetectionResult.confidence,
                diagnosticTelemetry: cropDetectionResult.diagnosticTelemetry
              } : null,
              imageSrc: resolvedSrc,
              fileName: fileName || null
            });
          }

          // 6. Evaluate Pathology Within Identified/Specified Crop
          const allResults = PLANTVILLAGE_CLASSES.map((cls, idx) => ({
            ...cls,
            prob: probabilities[idx] || 0
          }));

          const sortedGlobal = [...allResults].sort((a, b) => b.prob - a.prob);
          const topGlobal = sortedGlobal[0];

          let targetClass = null;
          let effectiveCropKey = null;
          let crossModelNote = null;

          if (normalizedCrop !== 'all') {
            // User explicitly constrained the target crop
            effectiveCropKey = normalizedCrop;
            const cropClasses = allResults.filter(c => c.cropKey === effectiveCropKey);
            const cropSum = cropClasses.reduce((sum, c) => sum + c.prob, 0);
            if (cropSum > 0) {
              cropClasses.forEach(c => {
                c.relativeProb = c.prob / cropSum;
              });
            }
            cropClasses.sort((a, b) => (b.relativeProb !== undefined ? b.relativeProb - a.relativeProb : b.prob - a.prob));
            targetClass = cropClasses[0];

            if (topGlobal.cropKey !== effectiveCropKey && topGlobal.prob >= 0.50) {
              crossModelNote = `Selected crop is ${allCropsKeyMap[effectiveCropKey] || effectiveCropKey}, but model detected symptoms matching ${topGlobal.cropName} (${topGlobal.diseaseName}) with ${(topGlobal.prob * 100).toFixed(1)}% confidence.`;
            }
          } else {
            // Auto-detect mode
            const s1Key = cropDetectionResult ? cropDetectionResult.cropKey : null;
            const s1Score = cropDetectionResult ? cropDetectionResult.score : 0;
            const s2Key = topGlobal.cropKey;
            const s2Score = topGlobal.prob;

            if (s1Key && s1Score >= 0.25) {
              if (s1Key === s2Key) {
                // Consensus between Stage 1 botanical classifier and Stage 2 neural pathology
                effectiveCropKey = s1Key;
                targetClass = topGlobal;
              } else {
                // Cross-model reconciliation
                if (s2Score >= s1Score || s2Score >= 0.50) {
                  // Stage 2 disease model found specific pathological features
                  effectiveCropKey = s2Key;
                  targetClass = topGlobal;
                  crossModelNote = `Stage 1 botanical classifier suggested ${cropDetectionResult.cropName} (${(s1Score * 100).toFixed(1)}%), but Stage 2 neural pathology detected characteristic lesions of ${topGlobal.cropName} (${(s2Score * 100).toFixed(1)}%).`;
                } else {
                  // Crop model has stronger confidence
                  const s1Classes = allResults.filter(c => c.cropKey === s1Key).sort((a, b) => b.prob - a.prob);
                  if (s1Classes[0] && s1Classes[0].prob >= 0.15) {
                    effectiveCropKey = s1Key;
                    targetClass = s1Classes[0];
                  } else {
                    effectiveCropKey = s2Key;
                    targetClass = topGlobal;
                  }
                }
              }
            } else {
              // Stage 1 unavailable or ambiguous -> use Stage 2 directly
              effectiveCropKey = s2Key;
              targetClass = topGlobal;
            }
          }

          if (!targetClass) {
            targetClass = topGlobal;
            effectiveCropKey = topGlobal.cropKey;
          }

          // Check if primary pathology probability is below minimum confidence threshold
          const effectiveProb = (normalizedCrop !== 'all' && targetClass.relativeProb !== undefined) ? targetClass.relativeProb : targetClass.prob;
          if (effectiveProb < 0.15 && (normalizedCrop === 'all' || effectiveProb < 0.05)) {
            return resolve({
              isValidImage: false,
              status: 'UNCERTAIN',
              errorType: 'uncertain-crop',
              validationError: 'Unable to identify the leaf condition reliably. Model prediction confidence is below diagnostic threshold (minimum 15%). Please upload a clearer photograph of the crop foliage.',
              cropRecognition: {
                cropKey: effectiveCropKey,
                cropName: targetClass.cropName,
                confidence: Number((effectiveProb * 100).toFixed(1)),
                isAmbiguous: true,
                diagnosticTelemetry: crossModelNote || cropDetectionResult?.diagnosticTelemetry || null
              },
              topAlternatives: sortedGlobal.slice(0, 3).map(c => ({
                id: c.diseaseId,
                name: c.diseaseName,
                commonName: c.commonName,
                crop: c.cropName,
                prob: Number((c.prob * 100).toFixed(1))
              })),
              imageSrc: resolvedSrc,
              fileName: fileName || null
            });
          }

          // Format candidate list
          const candidateList = (normalizedCrop !== 'all')
            ? allResults.filter(c => c.cropKey === effectiveCropKey).sort((a, b) => (b.relativeProb !== undefined ? b.relativeProb - a.relativeProb : b.prob - a.prob))
            : sortedGlobal;

          const topCandidates = candidateList.slice(0, 3).map((c, i) => {
            const displayProb = (normalizedCrop !== 'all' && c.relativeProb !== undefined) ? c.relativeProb : c.prob;
            return {
              id: c.diseaseId,
              name: c.diseaseName,
              commonName: c.commonName,
              scientificName: c.scientificName,
              vernacularName: c.vernacularName,
              crop: c.cropName,
              prob: Number((displayProb * 100).toFixed(1)),
              category: c.pathogenType,
              status: i === 0 ? 'Primary Candidate' : (i === 1 ? 'Secondary Candidate' : 'Low Likelihood')
            };
          });

          const confScore = Number((effectiveProb * 100).toFixed(1));

          // 7. Extract Supplementary Biomarkers (Pixel Scan)
          const biomarkers = extractSupplementaryBiomarkers(data, size);

          // 8. Format Complete Analysis Result
          const result = formatAnalysisResult(
            targetClass,
            confScore,
            biomarkers,
            topCandidates,
            fileName,
            isDemoSample,
            cropDetectionResult,
            normalizedCrop
          );
          result.imageSrc = resolvedSrc;
          result.qualityWarning = leafQualityWarning;
          resolve(result);
        } catch (innerErr) {
          console.error('[AgroSense CV] Processing error:', innerErr);
          resolve({
            isValidImage: false,
            status: 'ERROR',
            errorType: 'processing-error',
            validationError: 'An unexpected processing error occurred while scanning the leaf photo: ' + (innerErr.message || innerErr),
            cropRecognition: null,
            imageSrc: resolvedSrc,
            fileName: fileName || null
          });
        }
      };

      img.onerror = () => {
        resolve({
          isValidImage: false,
          status: 'ERROR',
          errorType: 'load-error',
          validationError: 'Unable to load the provided leaf photo source. Please ensure a valid image format (JPG, PNG, WEBP).',
          cropRecognition: null,
          imageSrc: resolvedSrc,
          fileName: fileName || null
        });
      };

      img.src = resolvedSrc;
    } catch (outerErr) {
      console.error('[AgroSense CV] Fatal error:', outerErr);
      resolve({
        isValidImage: false,
        status: 'ERROR',
        errorType: 'fatal-error',
        validationError: 'Fatal diagnostic engine error: ' + (outerErr.message || outerErr),
        cropRecognition: null
      });
    }
  });
}
exports.analyzeLeafImage = analyzeLeafImage;
/**
 * Comprehensive Crop Disease Etiology, Climate Triggers & Transmission Knowledgebase
 * Explains WHY diseases occur, biological pathogens, weather triggers, and predisposing risk factors
 */
const diseaseEtiologyDatabase = exports.diseaseEtiologyDatabase = {
  "tomato-early-blight": {
    pathogenCause: "Fungal pathogen Alternaria solani that overwinters as resilient chlamydospores and mycelium in solanaceous crop residues, volunteer weeds, and soil.",
    weatherTriggers: {
      temperature: "24°C - 30°C (Warm, tropical to sub-tropical conditions)",
      humidity: "High relative humidity (>80%) with heavy morning dew or frequent intermittent rainfall",
      leafWetness: "Continuous foliar moisture for 4 to 6 hours triggers rapid spore germination and cuticle penetration."
    },
    transmissionMode: "Raindrop splash propels soil-borne fungal spores onto lower leaves (bottom 30 cm). Secondary infection cycles spread swiftly through wind-borne conidia and contaminated equipment.",
    riskFactors: [
      "Overhead sprinkler irrigation causing prolonged leaf wetness.",
      "Excess chemical nitrogen application producing soft, succulent foliage vulnerable to fungal invasion.",
      "Dense row spacing restricting sunlight and air movement in the lower canopy.",
      "Solanaceous monocropping (repeating tomato, potato, brinjal, or chilli in the same field)."
    ]
  },
  "tomato-late-blight": {
    pathogenCause: "Aggressive oomycete water mold Phytophthora infestans that produces swimming biflagellated zoospores capable of destroying an entire field within 7-10 days.",
    weatherTriggers: {
      temperature: "12°C - 22°C (Cool, damp, cloudy microclimates)",
      humidity: "Relative humidity >88% with persistent fog, drizzle, or overcast monsoon skies",
      leafWetness: "Leaves remaining wet for >6-8 hours without direct sunlight"
    },
    transmissionMode: "Microscopic sporangia are carried for miles on cool, moist wind currents. Upon contacting wet leaves, each sporangium bursts into 8-12 motile zoospores that swim to stomata.",
    riskFactors: [
      "Cool foggy nights followed by overcast drizzling days.",
      "Low-lying, waterlogged soil with stagnant drainage.",
      "Unstaked trailing vines touching damp soil.",
      "Discarded cull piles of infected potatoes or tomatoes located near the field."
    ]
  },
  "tomato-yellow-leaf-curl": {
    pathogenCause: "Tomato Yellow Leaf Curl Virus (TYLCV), a destructive circular single-stranded DNA Begomovirus that halts plant growth and disrupts phloem transport.",
    weatherTriggers: {
      temperature: "28°C - 38°C (Hot, dry, sunny weather accelerates insect vector reproduction)",
      humidity: "Low to moderate humidity (40% - 60%); does not require rainfall",
      leafWetness: "Infection is independent of leaf wetness and occurs purely via insect feeding."
    },
    transmissionMode: "Persistently transmitted by the Silverleaf Whitefly (Bemisia tabaci). A single 15-minute sap-feeding session enables the whitefly to transmit the virus throughout its 30-40 day lifespan.",
    riskFactors: [
      "Absence of 40-mesh insect netting or yellow sticky traps in nursery and main field.",
      "High whitefly populations driven by indiscriminate broad-spectrum pyrethroid sprays that kill natural predators.",
      "Weed reservoirs (Parthenium, Datura, Solanum nigrum) thriving on field bunds."
    ]
  },
  "tomato-healthy": {
    pathogenCause: "Disease-free physiological equilibrium. Plant leaves possess intact waxy cuticles, balanced chlorophyll synthesis, and active natural phytoalexin defense pathways.",
    weatherTriggers: {
      temperature: "20°C - 30°C optimal growth range",
      humidity: "Moderate ambient humidity (55% - 70%) with continuous airflow",
      leafWetness: "Foliage dries rapidly within 1 hour after sunrise, preventing spore incubation."
    },
    transmissionMode: "No active pathogen transmission. Maintained through certified disease-free seeds, clean irrigation water, and healthy soil microbiology.",
    riskFactors: [
      "Sudden unseasonal rains or high humidity can activate dormant soil spores; maintain prophylactic bio-fungicide sprays.",
      "Avoid excessive urea fertilizers that soften cellular epidermal barriers."
    ]
  },
  "tomato-bacterial-spot": {
    pathogenCause: "Xanthomonas campestris pv. vesicatoria (Xanthomonas euvesicatoria), a Gram-negative bacterium that enters through natural stomata and micro-wounds created by wind-driven sand, insect feeding, or pruning.",
    weatherTriggers: {
      temperature: "24°C - 30°C (Warm tropical to sub-tropical conditions)",
      humidity: "High relative humidity (>85%) with frequent driving rains and overhead dew",
      leafWetness: "Foliar wetness persisting for >3-5 hours allows bacterial flagella to swim into stomatal cavities"
    },
    transmissionMode: "Seed-borne and debris-borne. Bacteria splash via raindrops, overhead sprinkler droplets, and mechanical movement by laborers working in damp fields.",
    riskFactors: [
      "Overhead sprinkler irrigation creating constant moisture and splashing bacterial inoculum.",
      "Using uncertified farmer-saved tomato seeds without hot-water or acid treatment.",
      "Working in fields when plants are wet with morning dew or rain.",
      "Continuous solanaceous cropping (tomato after pepper or potato)."
    ]
  },
  "tomato-septoria": {
    pathogenCause: "Septoria lycopersici, an ascomycete fungus producing dark pycnidia fruiting bodies embedded within circular gray-centered spots with distinct dark margins.",
    weatherTriggers: {
      temperature: "20°C - 26°C (Moderate warm temperatures with high humidity)",
      humidity: "Relative humidity >80% for extended periods",
      leafWetness: "Frequent rainfall, overhead misting, or persistent morning dew lasting >6 hours"
    },
    transmissionMode: "Fungus overwinters in dead tomato vines and solanaceous weeds (Horsenettle, Nightshade). Pycnidiospores ooze in gelatinous tendrils during rains and splash onto lower leaves.",
    riskFactors: [
      "Unstaked, un-mulched tomato vines with lower foliage touching damp soil.",
      "Failure to remove infected lower foliage (bottom 30 cm) before spore ascent.",
      "Monoculture and presence of wild solanaceous weeds on field borders."
    ]
  },
  "potato-late-blight": {
    pathogenCause: "Phytophthora infestans (Oomycete), the historic cause of the Irish Potato Famine, which overwinters inside infected seed tubers and cull piles.",
    weatherTriggers: {
      temperature: "10°C - 20°C (Cool, damp winter/spring conditions)",
      humidity: "Relative humidity >90% accompanied by prolonged cloud cover and dense morning fog",
      leafWetness: "Continuous leaf wetness for 6 to 10 hours"
    },
    transmissionMode: "Windborne sporangia travel up to 10-15 km during humid overcast days. Rain splashes sporangia from canopy into ridges, infecting developing tubers.",
    riskFactors: [
      "Planting uncertified seed potato tubers carrying latent infection.",
      "Poor earthing-up leaving shallow tubers exposed to fungal spore washdown.",
      "Over-irrigation in furrows during cool winter months."
    ]
  },
  "potato-early-blight": {
    pathogenCause: "Alternaria solani, a specialized necrotrophic fungus attacking mature and stressed potato foliage, producing alternariol toxins that kill host cells.",
    weatherTriggers: {
      temperature: "24°C - 30°C (Alternating dry periods with heavy dew or sprinkler passes)",
      humidity: "Relative humidity >80% with warm sunny afternoons",
      leafWetness: "Dew formation on lower leaves persisting for 4-6 hours"
    },
    transmissionMode: "Soil-borne conidia splashed by rain or sprinkler droplets onto lower senescing leaves, progressively spreading upward toward canopy tops.",
    riskFactors: [
      "Crop senescence or nutritional stress (especially Potassium deficiency).",
      "Overhead sprinkler irrigation creating alternating wet-dry foliage cycles.",
      "Volunteer potato and tomato plants left from previous crop cycles."
    ]
  },
  "potato-healthy": {
    pathogenCause: "Healthy potato canopy exhibiting vigorous photosynthetic activity, balanced tuberization, and unbroken epidermal barriers.",
    weatherTriggers: {
      temperature: "16°C - 24°C daytime, 12°C - 16°C nighttime",
      humidity: "60% - 75% relative humidity with active field ventilation",
      leafWetness: "Good ridge drainage and prompt morning drying"
    },
    transmissionMode: "Pathogen-free certified seed stock grown in fumigated or bio-enriched soil.",
    riskFactors: [
      "Monitor weather warnings for Late Blight (Smith Periods: 2 consecutive days with min temp >10°C and RH >90%)."
    ]
  },
  "rice-blast": {
    pathogenCause: "Magnaporthe oryzae (Pyricularia oryzae), a destructive ascomycete fungus forming melanized appressoria that generate over 8 MPa of mechanical pressure to pierce silica-rich rice leaf cells.",
    weatherTriggers: {
      temperature: "20°C - 26°C with cool nighttime drops",
      humidity: "Relative humidity >90% with persistent morning dew lasting >10 hours",
      leafWetness: "Foggy, overcast mornings and low sunshine hours"
    },
    transmissionMode: "Pyriform conidiospores are released in enormous quantities during the night and dispersed across fields by gentle thermal updrafts.",
    riskFactors: [
      "Excessive single-dose chemical urea application (>120 kg N/ha), creating tender succulent leaves.",
      "Water stress (intermittent drought in rainfed uplands) followed by sudden reflooding.",
      "Ultra-dense transplanting without border alleys restricting air circulation."
    ]
  },
  "rice-bacterial-blight": {
    pathogenCause: "Xanthomonas oryzae pv. oryzae, a vascular plant-pathogenic bacterium that multiplies inside rice xylem vessels, blocking water and nutrient transport.",
    weatherTriggers: {
      temperature: "25°C - 34°C with tropical storm winds",
      humidity: "High relative humidity (>85%) with torrential monsoon rains",
      leafWetness: "Driving winds and rainstorms that whip leaf tips against each other"
    },
    transmissionMode: "Yellow bacterial ooze on leaf margins dissolves in floodwater and irrigation streams. Wind-driven rains create micro-wounds through which bacteria rapidly enter.",
    riskFactors: [
      "Deep standing water or flood submergence during tillering.",
      "Clipping seedling leaf tips before transplanting (creates direct entry wounds).",
      "Field-to-field flow of unchanneled canal water carrying bacterial inoculum."
    ]
  },
  "rice-healthy": {
    pathogenCause: "Robust paddy canopy with high leaf silica content, balanced chlorophyll, and uninterrupted tiller development.",
    weatherTriggers: {
      temperature: "24°C - 32°C tropical sunshine",
      humidity: "Standard monsoon humidity with good wind movement",
      leafWetness: "Normal dew drying by 9 AM"
    },
    transmissionMode: "Certified seed treated with bio-inoculants (Pseudomonas fluorescens) and balanced N-P-K-Zn nutrition.",
    riskFactors: [
      "Ensure silicon and zinc fertilization to maintain tough leaf silica cuticles."
    ]
  },
  "wheat-leaf-rust": {
    pathogenCause: "Puccinia triticina, an obligate macrocyclic heteroecious rust fungus producing millions of reddish-orange urediniospores in ruptured leaf blisters.",
    weatherTriggers: {
      temperature: "15°C - 25°C (Mild winter to early spring weather)",
      humidity: "Relative humidity >85% with heavy overnight dew formation",
      leafWetness: "3 to 6 hours of continuous dew film required for spore germination"
    },
    transmissionMode: "Urediniospores are picked up by prevailing high-altitude wind currents and transported across thousands of kilometers along traditional 'rust corridors'.",
    riskFactors: [
      "Late sowing in late December or January, exposing the boot stage to warm February winds.",
      "Planting obsolete wheat varieties lacking durable Lr (Leaf Rust) resistance genes.",
      "Excess nitrogen fertilizer without adequate potash supplementation."
    ]
  },
  "wheat-yellow-rust": {
    pathogenCause: "Puccinia striiformis f. sp. tritici, an aggressive cold-adapted rust fungus that colonizes leaf vascular bundles, forming parallel yellow linear stripes.",
    weatherTriggers: {
      temperature: "10°C - 18°C (Cool, damp winter weather; inhibited when temperatures exceed 25°C)",
      humidity: "Dense morning fog and persistent relative humidity >90%",
      leafWetness: "Heavy dew that remains on wheat leaves through midday"
    },
    transmissionMode: "Airborne spores carried by northwestern winds from northern foothill source zones (Himalayan foothills) onto plains.",
    riskFactors: [
      "Wheat planted in shaded belts along canals, rivers, and tree rows.",
      "Extended cloudy, foggy spells during December and January.",
      "Monoculture of single susceptible wheat cultivars across large contiguous acreage."
    ]
  },
  "wheat-powdery-mildew": {
    pathogenCause: "Blumeria graminis f. sp. tritici, an obligate fungal pathogen that produces superficial white cottony mycelial patches and asexual conidia chains.",
    weatherTriggers: {
      temperature: "15°C - 22°C (Moderate cool weather)",
      humidity: "High relative humidity (85% - 95%) in dense shaded canopies",
      leafWetness: "Notably does not require free water droplets; high ambient humidity is sufficient"
    },
    transmissionMode: "Dry powdery conidiospores are easily dislodged and dispersed by wind breezes through dense field canopies.",
    riskFactors: [
      "High seed rate leading to tangled, overcrowded wheat stands.",
      "Excessive nitrogen application causing rank, dense vegetative growth.",
      "Irrigation during cool cloudy weather causing stagnant humid air near soil."
    ]
  },
  "wheat-healthy": {
    pathogenCause: "Healthy wheat foliar physiological balance. Intact silica epidermal walls, high chlorophyll content, and robust vascular transport.",
    weatherTriggers: {
      temperature: "14°C - 24°C (Optimal rabi season wheat development range)",
      humidity: "Moderate ambient relative humidity (50% - 70%) with good canopy aeration",
      leafWetness: "Morning dew that clears before midday, avoiding foliar pathogen incubation"
    },
    transmissionMode: "Disease-free canopy maintained via certified treated seed and balanced NPK basal fertilization.",
    riskFactors: [
      "Ensure timely weed eradication along field margins to remove alternate grass hosts.",
      "Scout crop weekly during foggy December-January windows for early rust detection."
    ]
  },
  "cotton-bacterial-blight": {
    pathogenCause: "Xanthomonas citri pv. malvacearum, a devastating seed-borne bacterium that attacks leaves (angular leaf spot), stems (black arm), and bolls (boll rot).",
    weatherTriggers: {
      temperature: "28°C - 35°C (Warm tropical weather)",
      humidity: "Relative humidity >85% following heavy thunderstorm deluges",
      leafWetness: "Wind-driven rains create micro-lesions allowing bacterial entry"
    },
    transmissionMode: "Primary infection originates from fuzzy seed lint contaminated with bacteria. Secondary spread occurs rapidly via rain splash and inter-plant contact during weeding.",
    riskFactors: [
      "Using non-delinted, uncertified cotton seeds.",
      "Sprinkler or flood irrigation that splashes soil and bacteria onto lower leaves.",
      "Frequent tractor or manual intercultural operations while plants are damp with dew."
    ]
  },
  "cotton-grey-mildew": {
    pathogenCause: "Ramularia areola (Dahiya disease), a specialized fungus producing frosty, powdery white-to-grey angular spots delimited by veinlets on the lower leaf surface.",
    weatherTriggers: {
      temperature: "20°C - 28°C",
      humidity: "Sustained high humidity (>80%) during boll development and post-monsoon spells",
      leafWetness: "Heavy dew accumulation on lower canopy leaves"
    },
    transmissionMode: "Airborne conidia are blown upward from infected lower leaves, progressing to mid and upper canopy as bolls mature.",
    riskFactors: [
      "Close spacing in hybrid and Bt cotton restricting canopy airflow.",
      "Dense foliage caused by late monsoon rains and delayed defoliation.",
      "Continuous mono-cropping of cotton without rotation with sorghum or maize."
    ]
  },
  "cotton-healthy": {
    pathogenCause: "Healthy cotton foliage with robust trichomes, deep green chlorophyll, and active squares/boll development.",
    weatherTriggers: {
      temperature: "26°C - 34°C warm sunny climate",
      humidity: "Balanced humidity (50% - 65%) with clear sunny days",
      leafWetness: "Prompt evaporation of morning dew"
    },
    transmissionMode: "Acid-delinted certified seeds treated with bio-agents and grown in well-drained black vertisol or alluvial soil.",
    riskFactors: [
      "Scout regularly for sucking pests (jassids, whiteflies) that create entry wounds for secondary pathogens."
    ]
  },
  "maize-leaf-blight": {
    pathogenCause: "Exserohilum turcicum (Northern Corn Leaf Blight), a fungal pathogen producing large elliptical cigar-shaped tan lesions that coalesce and scorch the entire leaf blade.",
    weatherTriggers: {
      temperature: "18°C - 27°C (Moderate warm temperatures)",
      humidity: "High relative humidity (>85%) with frequent morning fog or drizzling rains",
      leafWetness: "6 to 8 hours of continuous dew or water film on corn leaves"
    },
    transmissionMode: "Fungus overwinters in corn crop residues and stubble. Conidiospores are splashed onto lower leaves by rain, then carried by wind into the whorl.",
    riskFactors: [
      "No-till cultivation leaving infected corn stalks and stubble on the soil surface.",
      "Continuous maize-after-maize cropping without rotation.",
      "Planting non-treated hybrid seeds during the Kharif monsoon season."
    ]
  },
  "maize-common-rust": {
    pathogenCause: "Puccinia sorghi, an obligate biotrophic rust fungus producing golden-brown to cinnamon-brown powdery uredinia on both upper and lower corn leaf surfaces.",
    weatherTriggers: {
      temperature: "16°C - 25°C (Cool to mild temperatures; sporulation slows above 30°C)",
      humidity: "High relative humidity (>85%) with continuous overnight dew formation",
      leafWetness: "6 to 8 hours of foliar moisture film required for urediniospores to germinate and penetrate"
    },
    transmissionMode: "Urediniospores are picked up by prevailing winds from southern or tropical source regions and transported hundreds of kilometers across the maize belt.",
    riskFactors: [
      "Late planting that pushes critical vegetative stages into cool, humid, foggy periods.",
      "Planting susceptible maize hybrids lacking the Rp1-D resistance gene.",
      "High plant populations with dense canopies that trap humid air and prolong dew periods."
    ]
  },
  "maize-gray-leaf-spot": {
    pathogenCause: "Cercospora zeae-maydis, a foliar fungal pathogen producing elongated rectangular lesions strictly delimited by leaf veins, creating a blocky ribbon-like pattern.",
    weatherTriggers: {
      temperature: "24°C - 30°C (Warm, muggy, tropical summer conditions)",
      humidity: "Extended relative humidity >90% for >12 hours daily",
      leafWetness: "Heavy dew, persistent morning fog, and cloudy overcast spells"
    },
    transmissionMode: "Fungus survives exclusively on corn residues on the soil surface. Spores are splashed by rain onto lower leaves and blown upward into the ear canopy.",
    riskFactors: [
      "Zero-tillage or minimum-tillage leaving large volumes of infected corn stubble on the soil surface.",
      "Continuous corn-on-corn monoculture without rotation with legumes (soybean, groundnut).",
      "High humidity river bottoms and valley fields with low wind circulation."
    ]
  },
  "maize-healthy": {
    pathogenCause: "Healthy physiological equilibrium. Intact parallel leaf venation, balanced nitrogen-phosphorus-potassium nutrition, active rubisco photosynthetic enzymes, and strong waxy cuticular protection.",
    weatherTriggers: {
      temperature: "Optimal growth temperatures: 22°C - 32°C",
      humidity: "Moderate relative humidity (50% - 70%) with plenty of sunshine (6-8 hours daily)",
      leafWetness: "Rapid leaf drying by mid-morning, preventing fungal spore incubation"
    },
    transmissionMode: "No active pathogen transmission. Maintained through certified hybrid seed, seed treatment, and balanced organic and mineral fertility.",
    riskFactors: [
      "Avoid excessive single-dose urea application that can soften leaf cuticles.",
      "Scout lower leaves weekly during knee-high to tasseling stages for early rust or blight spots."
    ]
  },
  "chilli-leaf-curl": {
    pathogenCause: "Chilli Leaf Curl Virus (ChiLCV), a circular single-stranded DNA Begomovirus (family Geminiviridae) transmitted in a persistent-circulative manner by whiteflies (Bemisia tabaci) and exacerbated by chilli thrips (Scirtothrips dorsalis). The virus interferes with auxin transport and vascular vein differentiation.",
    weatherTriggers: {
      temperature: "28°C - 38°C (Hot, dry pre-monsoon and post-monsoon spells that trigger explosive whitefly and thrips populations)",
      humidity: "Moderate to low relative humidity (40% - 65%); dry weather accelerates vector flight activity",
      leafWetness: "Dry foliage favored; heavy rainfall washes away whiteflies and temporarily suppresses vector transmission"
    },
    transmissionMode: "Transmitted exclusively by sap-sucking whitefly adults and thrips nymphs as they feed on tender phloem. A 15-minute feeding period is sufficient for acquisition, after which the whitefly retains and transmits the virus for its entire 30-40 day lifespan across the whole field.",
    riskFactors: [
      "Excessive urea (nitrogen) application producing soft, lush green foliage that attracts massive whitefly swarms.",
      "Absence of border tall crops (maize, sorghum, bajra) allowing wind currents to blow whiteflies directly into the field.",
      "Planting near abandoned or heavily infested tomato, brinjal, or cotton fields.",
      "Delayed insect vector control during early nursery and vegetative stages (first 20-45 days after transplanting)."
    ]
  },
  "chilli-bacterial-spot": {
    pathogenCause: "Xanthomonas campestris pv. vesicatoria (Xanthomonas euvesicatoria), a Gram-negative rod-shaped bacterium with a single polar flagellum that enters host leaves through natural stomata and insect feeding wounds.",
    weatherTriggers: {
      temperature: "24°C - 30°C (Warm tropical temperatures)",
      humidity: "High relative humidity (>85%) with frequent rainfall, morning fog, or heavy dew",
      leafWetness: "Persistent leaf surface moisture for >3-5 continuous hours allows bacteria to swim through stomata and multiply in intercellular spaces"
    },
    transmissionMode: "Primary transmission through contaminated seeds and infected crop debris. Secondary spread occurs rapidly via raindrop splashing, wind-driven rainstorms, sprinkler irrigation droplets, and farm workers handling wet plants.",
    riskFactors: [
      "Overhead sprinkler irrigation creating high leaf wetness and splashing bacterial cells.",
      "Using uncertified farmer-saved seeds from previously blighted crops.",
      "Continuous cropping of chilli or bell pepper without rotation with non-solanaceous crops.",
      "Mechanical wounding during weeding, staking, or harvesting while leaves are wet."
    ]
  },
  "chilli-anthracnose": {
    pathogenCause: "Colletotrichum capsici and Colletotrichum acutatum, fungal pathogens causing circular sunken lesions with concentric rings of black acervuli on fruit and tip dieback on twigs.",
    weatherTriggers: {
      temperature: "25°C - 30°C (Warm tropical conditions)",
      humidity: "High relative humidity (>80%) with persistent monsoon rainfall",
      leafWetness: "Frequent rainfall and splashing water droplets"
    },
    transmissionMode: "Seed-borne and debris-borne spores splash via rain droplets onto ripening chilli fruit, flowering buds, and tender leaf tips.",
    riskFactors: [
      "Overhead sprinkler irrigation during flowering and fruit set.",
      "Poor field drainage and waterlogging in chilli ridges.",
      "Harvesting, pruning, or spraying operations carried out while foliage is wet."
    ]
  },
  "chilli-cercospora-leaf-spot": {
    pathogenCause: "Cercospora capsici, a specialized foliar fungal pathogen that produces long, hyaline, multi-septate conidia on short dark conidiophores emerging in clusters through leaf stomata.",
    weatherTriggers: {
      temperature: "25°C - 32°C (Warm, muggy tropical weather)",
      humidity: "Sustained high relative humidity (>80%) for multiple days",
      leafWetness: "Intermittent rainfall, heavy dews, or foggy mornings keeping leaf canopy moist for >6-8 hours"
    },
    transmissionMode: "Conidiospores are easily detached by gentle breezes and dispersed widely through air currents. Splashing raindrops dislodge spores onto lower leaves, initiating rapid upward infection cycles throughout the canopy.",
    riskFactors: [
      "Dense planting and poor row spacing preventing rapid drying of foliage.",
      "Potassium deficiency in soil, leading to weaker epidermal cell walls that fungi penetrate easily.",
      "Leaving infected crop stubble and dried fallen leaves on the field surface between cropping cycles."
    ]
  },
  "chilli-powdery-mildew": {
    pathogenCause: "Leveillula taurica (anamorph Oidiopsis gossypii / Oidiopsis taurica), an unusual endophytic powdery mildew whose mycelium grows inside the mesophyll tissue of the leaf rather than merely on the surface, making it more resilient.",
    weatherTriggers: {
      temperature: "26°C - 34°C during daytime paired with cooler 18°C - 22°C nights",
      humidity: "Low to moderate daytime humidity (40% - 60%) coupled with high nighttime humidity (>70% - 85%)",
      leafWetness: "Unlike downy mildew, powdery mildew does NOT require free liquid water; dry leaf surfaces under warm, humid ambient air trigger peak sporulation"
    },
    transmissionMode: "Airborne dry conidia are carried for miles on thermal wind currents. Spores germinate in ambient humidity without needing raindrops.",
    riskFactors: [
      "Overcrowded chilli bushes with dense unpruned lower suckers restricting ventilation.",
      "Prolonged dry soil periods followed by heavy irrigation creating physiological stress.",
      "Excessive synthetic nitrogen fertilizers that create dense, shaded canopies."
    ]
  },
  "chilli-phytophthora-blight": {
    pathogenCause: "Phytophthora capsici, a destructive soil-borne oomycete that produces motile biflagellated zoospores swimming through free soil water films to infect the plant collar and taproot.",
    weatherTriggers: {
      temperature: "24°C - 29°C (Warm monsoon temperatures)",
      humidity: "Saturated atmospheric humidity (>90%) with torrential rains",
      leafWetness: "Waterlogged soil and flood irrigation that submerges the collar root zone"
    },
    transmissionMode: "Biflagellated zoospores swim in standing puddle water and irrigation ditches. Rain splash propels zoospores from the soil surface onto lower stems, branch crotches, and fruit.",
    riskFactors: [
      "Planting chillies on flat ground without raised beds or ridge drainage.",
      "Heavy, poorly-drained black clay soils prone to waterlogging after monsoon showers.",
      "Flood irrigation where water flows from infected patches directly across healthy plant rows."
    ]
  },
  "chilli-healthy": {
    pathogenCause: "Healthy physiological state. Plant leaf shows balanced chlorophyll synthesis, intact cellular cuticles, and strong natural systemic acquired resistance (SAR).",
    weatherTriggers: {
      temperature: "22°C - 32°C (Optimal vegetative growth)",
      humidity: "50% - 70% RH with adequate airflow",
      leafWetness: "Prompt drying of foliage in morning sunlight"
    },
    transmissionMode: "None. Maintain balanced nutrition, proactive pest scouting, and clean weed-free borders.",
    riskFactors: [
      "Maintain vigilance against whitefly and thrips vectors during hot dry periods.",
      "Ensure drip irrigation to keep foliage canopy dry and prevent opportunistic fungal spores."
    ]
  },
  "groundnut-tikka": {
    pathogenCause: "Cercospora arachidicola (Early Tikka) & Cercosporidium personatum (Late Tikka), causing destructive dark brown-black circular spots with prominent yellow halos and premature defoliation.",
    weatherTriggers: {
      temperature: "24°C - 28°C (Warm, muggy monsoon weather)",
      humidity: "High relative humidity (>85%) for 3 or more consecutive days",
      leafWetness: "Persistent dew or intermittent drizzle keeping lower canopy wet"
    },
    transmissionMode: "Spores survive in soil debris and infected pod shells; conidia are dispersed by wind currents and splashing raindrops throughout the field.",
    riskFactors: [
      "Continuous groundnut cultivation on the same field without crop rotation.",
      "Using uncertified seed pods from previous blighted harvests.",
      "Late weeding that causes root and lower stem abrasions."
    ]
  }
};

/**
 * Intelligent Fallback Generator for Disease Etiology & Outbreak Triggers
 */
function getFallbackWhyThisHappens(disease) {
  if (!disease) return null;
  const isHealthy = disease.pathogenType?.toLowerCase().includes('healthy');
  if (isHealthy) {
    return {
      pathogenCause: "Healthy physiological state. Plant leaf shows balanced chlorophyll synthesis, intact cellular cuticles, and strong natural systemic acquired resistance (SAR).",
      weatherTriggers: {
        temperature: "Favorable growth range (20°C - 32°C)",
        humidity: "Moderate relative humidity (50% - 70%) with good air circulation",
        leafWetness: "Leaves dry promptly in morning sun, preventing fungal spore incubation"
      },
      transmissionMode: "No transmission active. Maintained through clean seed, balanced organic nutrition, and sound soil biology.",
      riskFactors: [
        "Preventative monitoring remains key: sudden cloudy humid spells can trigger latent spores.",
        "Maintain balanced N-P-K fertilizer and avoid excessive chemical urea that softens leaf cell walls."
      ]
    };
  }

  const name = (disease.diseaseName || '').toLowerCase();

  if (name.includes('rust')) {
    return {
      pathogenCause: "Basidiomycete obligate biotrophic rust fungi (Puccinia species) producing microscopic orange-brown urediniospores that penetrate leaf stomata.",
      weatherTriggers: {
        temperature: "15°C - 24°C (Moderate cool-to-warm weather)",
        humidity: "High humidity (>85%) with persistent morning dew or light drizzling rain",
        leafWetness: "At least 3 - 6 hours of continuous leaf wetness needed for rust spores to germinate"
      },
      transmissionMode: "Airborne urediniospores travel hundreds of kilometers on continental wind currents. Once deposited, spores germinate within hours on damp leaves.",
      riskFactors: [
        "Dense crop canopy with stagnant air and prolonged dew.",
        "Excessive nitrogenous fertilizer creating tender leaf tissue susceptible to spore penetration.",
        "Late sowing dates exposing crops to peak sporulation seasons."
      ]
    };
  }

  if (name.includes('powdery') || name.includes('mildew')) {
    return {
      pathogenCause: "Ectophytic ascomycete fungus producing dense superficial white mycelial mats and asexual conidia chains on the upper leaf epidermis.",
      weatherTriggers: {
        temperature: "20°C - 28°C (Warm days followed by cool humid nights)",
        humidity: "High relative humidity (70% - 90%) at night; thrives even in the absence of free standing water",
        leafWetness: "Dry leaf surfaces during day allow spore release; night humidity promotes infection"
      },
      transmissionMode: "Microscopic conidiospores are easily dislodged by gentle wind breezes and farm workers, spreading rapidly throughout the orchard or field canopy.",
      riskFactors: [
        "Shady, overcrowded vine canopies or unpruned branches.",
        "Water stress combined with high humidity microclimates.",
        "High nitrogen fertilization and low potassium levels."
      ]
    };
  }

  if (name.includes('late blight') || name.includes('downy')) {
    return {
      pathogenCause: "Aggressive oomycete water mold (Phytophthora / Plasmopara) producing motile flagellated zoospores that swim through water films to breach leaf cuticle.",
      weatherTriggers: {
        temperature: "12°C - 22°C (Cool, damp, overcast conditions)",
        humidity: "Continuous relative humidity >90% or heavy sustained rainfall",
        leafWetness: "Leaves remain wet for over 6 hours under cloudy skies without bright sun"
      },
      transmissionMode: "Sporangia are carried by cool misty wind currents and splashed by raindrops. In water droplets, each sporangium bursts into 8-12 swimming zoospores.",
      riskFactors: [
        "Low-lying waterlogged patches in field.",
        "Overhead sprinkler irrigation during late evening or cloudy days.",
        "Using infected seed tubers or planting next to culled potato dumps."
      ]
    };
  }

  if (name.includes('curl') || name.includes('virus')) {
    return {
      pathogenCause: "Geminivirus / Begomovirus that hijacks plant cell nuclei, disrupting normal hormone synthesis, chlorophyll formation, and vascular transport.",
      weatherTriggers: {
        temperature: "26°C - 35°C (Warm, dry spells favor explosive insect vector breeding)",
        humidity: "Moderate humidity (50% - 65%) with sunny weather",
        leafWetness: "Not rain-dependent; infection occurs strictly via insect vector feeding"
      },
      transmissionMode: "Vectored primarily by the Silverleaf Whitefly (Bemisia tabaci) and aphids. A vector acquires the virus in 15-30 minutes of sap feeding and transmits it persistently to healthy plants.",
      riskFactors: [
        "Absence of insect barrier netting and lack of yellow sticky traps.",
        "Presence of weed hosts (e.g. Parthenium, Solanum nigrum) acting as viral reservoirs around field borders.",
        "High insecticide resistance in local whitefly populations due to indiscriminate spraying."
      ]
    };
  }

  return {
    pathogenCause: `Causal biological agent associated with ${disease.diseaseName || 'pathogen'}. Survives in soil, crop debris, or infected seeds.`,
    weatherTriggers: {
      temperature: "20°C - 30°C",
      humidity: "Relative humidity >75%",
      leafWetness: "Prolonged leaf wetness >4 hours"
    },
    transmissionMode: "Dispersed by rain splash, wind currents, and mechanical tools during field operations.",
    riskFactors: [
      "Overhead irrigation keeping leaves damp.",
      "Dense crop spacing restricting ventilation.",
      "Lack of crop rotation."
    ]
  };
}

/**
 * Retrieves the comprehensive etiology profile for a given disease ID
 */
function getWhyThisHappens(diseaseId, disease = null) {
  if (diseaseId && diseaseEtiologyDatabase[diseaseId]) {
    return diseaseEtiologyDatabase[diseaseId];
  }
  return getFallbackWhyThisHappens(disease);
}

/**
 * Multi-lingual & Scientific Binomial Pathology Dictionary
 * Provides clean English common name, scientific pathogen binomial, Hindi, and Marathi vernacular names
 */
const diseaseVernacularDictionary = exports.diseaseVernacularDictionary = {
  "tomato-early-blight": {
    commonName: "Tomato Early Blight",
    scientificName: "Alternaria solani",
    vernacularName: "टमाटर अगेती झुलसा / करपा रोग (Ageti Jhulsa)",
    vernacularHindi: "टमाटर अगेती झुलसा",
    vernacularMarathi: "टोमॅटो करपा रोग",
    primarySymptom: "Concentric dark brown rings with chlorotic halo"
  },
  "tomato-late-blight": {
    commonName: "Tomato Late Blight",
    scientificName: "Phytophthora infestans",
    vernacularName: "टमाटर पछेती झुलसा / लेट ब्लाइट (Pacheti Jhulsa)",
    vernacularHindi: "टमाटर पछेती झुलसा",
    vernacularMarathi: "टोमॅटो तांबोरा / लेट ब्लाइट",
    primarySymptom: "Water-soaked lesions turning black with white mold underneath"
  },
  "tomato-yellow-leaf-curl": {
    commonName: "Tomato Yellow Leaf Curl Virus (TYLCV)",
    scientificName: "Begomovirus (Whitefly Vector)",
    vernacularName: "टमाटर पीला पत्ती मरोड़ रोग / मुरडा रोग (Kukda Rog)",
    vernacularHindi: "टमाटर पीला पत्ती मरोड़ रोग (मुर्रा)",
    vernacularMarathi: "टोमॅटो चुरडा-मुरडा रोग",
    primarySymptom: "Severe upward cupping of leaves with stunted bush growth"
  },
  "tomato-healthy": {
    commonName: "Healthy Tomato Canopy",
    scientificName: "Solanum lycopersicum (Pathogen Free)",
    vernacularName: "रोगमुक्त निरोगी टमाटर (Healthy Leaf)",
    vernacularHindi: "रोगमुक्त स्वस्थ टमाटर",
    vernacularMarathi: "निरोगी टोमॅटो पान",
    primarySymptom: "Crisp green foliage with intact cuticular barrier"
  },
  "tomato-bacterial-spot": {
    commonName: "Tomato Bacterial Spot",
    scientificName: "Xanthomonas campestris pv. vesicatoria",
    vernacularName: "टमाटर जीवाणु धब्बा रोग (Bacterial Dhabba)",
    vernacularHindi: "टमाटर जीवाणु धब्बा",
    vernacularMarathi: "टोमॅटो जीवाणू ठिपके रोग",
    primarySymptom: "Small dark greasy spots with yellow margin on foliage"
  },
  "tomato-septoria": {
    commonName: "Tomato Septoria Leaf Spot",
    scientificName: "Septoria lycopersici",
    vernacularName: "टमाटर सेप्टोरिया पत्ती धब्बा रोग (Septoria Dhabba)",
    vernacularHindi: "सेप्टोरिया पर्ण धब्बा रोग",
    vernacularMarathi: "सेप्टोरिया ठिपके रोग",
    primarySymptom: "Circular gray centers with dark brown borders and tiny pycnidia"
  },
  "potato-late-blight": {
    commonName: "Potato Late Blight",
    scientificName: "Phytophthora infestans",
    vernacularName: "आलू पछेती झुलसा / काळा करपा (Late Blight)",
    vernacularHindi: "आलू पछेती झुलसा",
    vernacularMarathi: "बटाटा काळा करपा",
    primarySymptom: "Water-soaked brown-black decaying foliage with white fungal fluff"
  },
  "potato-early-blight": {
    commonName: "Potato Early Blight",
    scientificName: "Alternaria solani",
    vernacularName: "आलू अगेती झुलसा / तांबडे ठिपके (Ageti Jhulsa)",
    vernacularHindi: "आलू अगेती झुलसा",
    vernacularMarathi: "बटाटा अगेती करपा",
    primarySymptom: "Target-board circular brown lesions on mature foliage"
  },
  "potato-healthy": {
    commonName: "Healthy Potato Canopy",
    scientificName: "Solanum tuberosum (Pathogen Free)",
    vernacularName: "रोगमुक्त निरोगी आलू / बटाटा (Healthy)",
    vernacularHindi: "रोगमुक्त स्वस्थ आलू",
    vernacularMarathi: "निरोगी बटाटा रोप",
    primarySymptom: "Lush green compound leaves without necrosis"
  },
  "rice-blast": {
    commonName: "Rice Blast",
    scientificName: "Magnaporthe oryzae (Pyricularia oryzae)",
    vernacularName: "धान का झोंका रोग / कडा करपा (Blast Rog)",
    vernacularHindi: "धान का झोंका / ब्लास्ट रोग",
    vernacularMarathi: "भात पिकावरील कडा करपा",
    primarySymptom: "Spindle-shaped diamond lesions with ash-grey center and brown margin"
  },
  "rice-bacterial-blight": {
    commonName: "Bacterial Leaf Blight (BLB)",
    scientificName: "Xanthomonas oryzae pv. oryzae",
    vernacularName: "धान का जीवाणु झुलसा / पाने करपणे (BLB)",
    vernacularHindi: "धान का जीवाणु झुलसा",
    vernacularMarathi: "भाताचा जिवाणूजन्य करपा",
    primarySymptom: "Wavy yellow to translucent marginal lesions extending along leaf blades"
  },
  "rice-healthy": {
    commonName: "Healthy Paddy Canopy",
    scientificName: "Oryza sativa (Pathogen Free)",
    vernacularName: "रोगमुक्त निरोगी धान / भात पीक (Healthy)",
    vernacularHindi: "रोगमुक्त स्वस्थ धान",
    vernacularMarathi: "निरोगी भात पीक",
    primarySymptom: "Upright vibrant silica-rich green blades"
  },
  "wheat-leaf-rust": {
    commonName: "Wheat Leaf / Brown Rust",
    scientificName: "Puccinia triticina",
    vernacularName: "गेहूं का भूरा रतुआ / तांबेरा रोग (Brown Rust)",
    vernacularHindi: "गेहूं का भूरा रतुआ (गेरुआ)",
    vernacularMarathi: "गहू तांबेरा रोग (तपकिरी)",
    primarySymptom: "Scattered orange-brown uredinial pustules across leaf surface"
  },
  "wheat-yellow-rust": {
    commonName: "Wheat Stripe / Yellow Rust",
    scientificName: "Puccinia striiformis",
    vernacularName: "गेहूं का पीला रतुआ / पिवळा तांबेरा (Yellow Rust)",
    vernacularHindi: "गेहूं का पीला रतुआ (हल्दी रोग)",
    vernacularMarathi: "गव्हावरील पिवळा तांबेरा",
    primarySymptom: "Bright yellow pustules arranged in parallel linear stripes along leaf veins"
  },
  "wheat-powdery-mildew": {
    commonName: "Wheat Powdery Mildew",
    scientificName: "Blumeria graminis f. sp. tritici",
    vernacularName: "गेहूं का चूर्णिल आसिता / भुरी रोग (Powdery Mildew)",
    vernacularHindi: "गेहूं का चूर्णिल आसिता",
    vernacularMarathi: "गव्हावरील भुरी रोग",
    primarySymptom: "White cottony talcum powder-like fungal patches on leaf sheath"
  },
  "wheat-healthy": {
    commonName: "Healthy Wheat Canopy",
    scientificName: "Triticum aestivum (Pathogen Free)",
    vernacularName: "रोगमुक्त निरोगी गेहूं / गहू (Healthy)",
    vernacularHindi: "रोगमुक्त स्वस्थ गेहूं",
    vernacularMarathi: "निरोगी गव्हाचे पीक",
    primarySymptom: "Vibrant erect linear green foliage with intact cuticle and zero rust blisters"
  },
  "cotton-bacterial-blight": {
    commonName: "Cotton Bacterial Blight / Black Arm",
    scientificName: "Xanthomonas citri pv. malvacearum",
    vernacularName: "कपास का जीवाणु अंगमारी / काळा डाग (Black Arm)",
    vernacularHindi: "कपास का जीवाणु अंगमारी रोग",
    vernacularMarathi: "कापसावरील काळा डाग / जिवाणू करपा",
    primarySymptom: "Angular vein-delimited water-soaked lesions turning dark reddish-brown"
  },
  "cotton-grey-mildew": {
    commonName: "Cotton Grey Mildew / Dahiya Disease",
    scientificName: "Ramularia areola",
    vernacularName: "कपास का दहिया रोग / भुरी रोग (Dahiya Rog)",
    vernacularHindi: "कपास का दहिया रोग (ग्रे मिल्ड्यू)",
    vernacularMarathi: "कापसाचा दहिया रोग",
    primarySymptom: "Frosted white powdery fungal growth on underside of lower leaves"
  },
  "cotton-healthy": {
    commonName: "Healthy Cotton Foliage",
    scientificName: "Gossypium hirsutum (Pathogen Free)",
    vernacularName: "रोगमुक्त निरोगी कपास / कापूस (Healthy)",
    vernacularHindi: "रोगमुक्त स्वस्थ कपास",
    vernacularMarathi: "निरोगी कापूस झाड",
    primarySymptom: "Deep green palmate leaves with intact turgidity"
  },
  "maize-leaf-blight": {
    commonName: "Northern Corn Leaf Blight (NCLB)",
    scientificName: "Exserohilum turcicum",
    vernacularName: "मक्का का झुलसा रोग / पानांचा करपा (Turcicum Blight)",
    vernacularHindi: "मक्का का पत्ती झुलसा रोग",
    vernacularMarathi: "मका पानांचा करपा",
    primarySymptom: "Elongated elliptical cigar-shaped grayish-green to tan lesions"
  },
  "maize-common-rust": {
    commonName: "Maize Common Rust",
    scientificName: "Puccinia sorghi",
    vernacularName: "मक्का का रतुआ रोग / तांबेरा (Common Rust)",
    vernacularHindi: "मक्का का रतुआ रोग (गेरुआ)",
    vernacularMarathi: "मका तांबेरा रोग",
    primarySymptom: "Golden-brown oval pustules scattered densely across both leaf blade surfaces"
  },
  "maize-gray-leaf-spot": {
    commonName: "Maize Gray Leaf Spot (GLS)",
    scientificName: "Cercospora zeae-maydis",
    vernacularName: "मक्का का भूरा धब्बा रोग / ठिपके रोग (Gray Spot)",
    vernacularHindi: "मक्का का धूसर पर्ण धब्बा",
    vernacularMarathi: "मका राखाडी ठिपके रोग",
    primarySymptom: "Narrow rectangular lesions strictly restricted by parallel leaf veins"
  },
  "maize-healthy": {
    commonName: "Healthy Maize Canopy",
    scientificName: "Zea mays (Pathogen Free)",
    vernacularName: "रोगमुक्त निरोगी मका / मक्का (Healthy)",
    vernacularHindi: "रोगमुक्त स्वस्थ मक्का",
    vernacularMarathi: "निरोगी मका पीक",
    primarySymptom: "Broad linear glossy emerald leaves with ivory central midrib"
  },
  "chilli-leaf-curl": {
    commonName: "Chilli Leaf Curl Virus (Murda Rog)",
    scientificName: "Chilli leaf curl virus (ChiLCV / Begomovirus)",
    vernacularName: "मिर्च का मुरड़ा रोग / चुरड़ा-मुरड़ा / बोकड्या (Murda Rog)",
    vernacularHindi: "मिर्च का मुर्रा / माथा बांधना रोग",
    vernacularMarathi: "मिरचीवरील बोकड्या / चुरडा-मुरडा रोग",
    primarySymptom: "Severe upward puckering, boat-shaped leaf curling, thickening of veins and stunting"
  },
  "chilli-bacterial-spot": {
    commonName: "Chilli Bacterial Leaf Spot",
    scientificName: "Xanthomonas campestris pv. vesicatoria",
    vernacularName: "मिर्च का जीवाणु पत्ती धब्बा रोग (Bacterial Spot)",
    vernacularHindi: "मिर्च का जीवाणु धब्बा रोग",
    vernacularMarathi: "मिरचीवरील जिवाणूजन्य ठिपके",
    primarySymptom: "Small dark water-soaked circular lesions with yellowish halo"
  },
  "chilli-anthracnose": {
    commonName: "Chilli Anthracnose / Fruit Rot / Dieback",
    scientificName: "Colletotrichum capsici",
    vernacularName: "मिर्च का फल सड़न / डायबैक / कोळशी रोग (Anthracnose)",
    vernacularHindi: "मिर्च का फल सड़न / श्याम वर्ण रोग",
    vernacularMarathi: "मिरचीवरील फळकुज / डायबॅक / कोळशी",
    primarySymptom: "Sunken necrotic circular spots with concentric rings on pods and dying twigs"
  },
  "chilli-cercospora-leaf-spot": {
    commonName: "Chilli Cercospora Frog-Eye Spot",
    scientificName: "Cercospora capsici",
    vernacularName: "मिर्च का मेंढक-आंख पत्ती धब्बा रोग (Frog Eye Spot)",
    vernacularHindi: "मिर्च का मेंढक-आंख पत्ता धब्बा",
    vernacularMarathi: "मिरचीवरील बेडूक-डोळा ठिपके",
    primarySymptom: "Circular lesions with bleached white center and dark reddish-brown borders"
  },
  "chilli-powdery-mildew": {
    commonName: "Chilli Powdery Mildew",
    scientificName: "Leveillula taurica",
    vernacularName: "मिर्च का चूर्णिल आसिता / पांढरी भुरी रोग (Bhuri Rog)",
    vernacularHindi: "मिर्च का चूर्णिल आसिता",
    vernacularMarathi: "मिरचीवरील भुरी रोग",
    primarySymptom: "White powdery fungal growth on underside of leaves with yellow chlorotic spots on top"
  },
  "chilli-phytophthora-blight": {
    commonName: "Chilli Phytophthora Blight / Collar Rot",
    scientificName: "Phytophthora capsici",
    vernacularName: "मिर्च का फाइटोफ्थोरा झुलसा / खोडकुज (Collar Rot)",
    vernacularHindi: "मिर्च का फाइटोफ्थोरा झुलसा",
    vernacularMarathi: "मिरची खोडकुज / मर रोग",
    primarySymptom: "Sudden permanent wilting of green plants with dark water-soaked stem collar rot"
  },
  "chilli-healthy": {
    commonName: "Healthy Chilli Foliage",
    scientificName: "Capsicum annuum (Pathogen Free)",
    vernacularName: "रोगमुक्त निरोगी मिरची / मिर्च (Healthy)",
    vernacularHindi: "रोगमुक्त स्वस्थ मिर्च",
    vernacularMarathi: "निरोगी मिरची रोप",
    primarySymptom: "Vibrant lanceolate spear-like leaves with zero curling or chlorosis"
  },
  "groundnut-tikka": {
    commonName: "Groundnut Tikka Leaf Spot",
    scientificName: "Cercospora arachidicola / Cercosporidium personatum",
    vernacularName: "मूंगफली का टिक्का रोग / भुईमूग टिक्का (Tikka Rog)",
    vernacularHindi: "मूंगफली का टिक्का रोग",
    vernacularMarathi: "भुईमुगावरील टिक्का रोग",
    primarySymptom: "Dark brown to black circular spots surrounded by a bright yellow halo on leaflets"
  }
};

/**
 * Formats a cohesive, professional Plant Pathology Report
 */

function formatAnalysisResult(disease, confidence, biomarkers, topCandidates = [], fileName = '', isDemoSample = false, cropRecData = null, selectedCropHint = 'all') {
  const isHealthy = disease.isHealthy || disease.pathogenType === 'Healthy Foliage';
  const healthyRef = healthyCropReferenceModels[disease.cropKey] || healthyCropReferenceModels.tomato;

  const vernacularInfo = {
    commonName: disease.commonName || disease.diseaseName.split('(')[0].trim(),
    scientificName: disease.scientificName || '',
    vernacularName: disease.vernacularName || disease.diseaseName
  };

  const whyThisHappens = disease.whyThisHappens || getWhyThisHappens(disease.diseaseId || disease.id, disease);

  const effectiveCrop = (selectedCropHint && selectedCropHint !== 'all')
    ? selectedCropHint
    : (cropRecData ? cropRecData.cropKey : disease.cropKey);

  const regName = SUPPORTED_CROP_REGISTRY[effectiveCrop]?.name;
  const effectiveCropName = regName || (cropRecData && (!selectedCropHint || selectedCropHint === 'all') ? cropRecData.cropName : (disease.cropName || (effectiveCrop.charAt(0).toUpperCase() + effectiveCrop.slice(1))));

  const effectiveConfidence = (selectedCropHint && selectedCropHint !== 'all')
    ? Number(confidence.toFixed(1))
    : (cropRecData ? cropRecData.confidence : Number(confidence.toFixed(1)));

  const cropRecognition = {
    cropKey: effectiveCrop,
    cropName: effectiveCropName,
    confidence: effectiveConfidence,
    isReliable: cropRecData ? !cropRecData.isAmbiguous : true,
    isAmbiguous: cropRecData ? cropRecData.isAmbiguous : false,
    botanicalClass: healthyRef.botanicalClass,
    leafMorphology: healthyRef.leafMorphology,
    marginType: healthyRef.marginType,
    aspectRatioDescriptor: healthyRef.aspectRatioDescriptor,
    runnerUp: cropRecData?.runnerUp || (topCandidates[1] ? { cropKey: disease.cropKey, cropName: topCandidates[1].crop, confidence: topCandidates[1].prob } : null),
    topAlternatives: cropRecData?.topCandidates || [],
    diagnosticTelemetry: cropRecData?.diagnosticTelemetry || null
  };

  const healthyBaseline = {
    cropKey: healthyRef.cropKey,
    cropName: healthyRef.cropName,
    botanicalClass: healthyRef.botanicalClass,
    leafMorphology: healthyRef.leafMorphology,
    marginType: healthyRef.marginType,
    aspectRatioDescriptor: healthyRef.aspectRatioDescriptor,
    svg: healthyRef.svg,
    realPhotoUrl: healthyRef.realPhotoUrl,
    realPhotoDescription: healthyRef.realPhotoDescription,
    healthyBiomarkers: healthyRef.healthyBiomarkers,
    healthyTraits: healthyRef.healthyTraits,
    observedBiomarkers: biomarkers,
    deviationAnalysis: {
      greenDeficit: Math.max(0, (healthyRef.healthyBiomarkers?.green || 96) - biomarkers.greenPercentage),
      necroticSpread: biomarkers.necroticPercentage,
      chlorosisSpread: biomarkers.chlorosisPercentage,
      powderySpread: biomarkers.powderyPercentage,
      rustSpread: biomarkers.rustPercentage,
      pathogenSpread: biomarkers.necroticPercentage + biomarkers.chlorosisPercentage + biomarkers.powderyPercentage + biomarkers.rustPercentage,
      healthStatus: isHealthy ? 'Nominal (Healthy Baseline Foliage)' : 'Pathological Tissue Loss'
    }
  };

  return {
    isValidImage: true,
    id: disease.diseaseId || disease.id,
    crop: disease.cropName,
    cropKey: disease.cropKey,
    diseaseName: disease.diseaseName,
    commonName: vernacularInfo.commonName,
    scientificName: vernacularInfo.scientificName,
    vernacularName: vernacularInfo.vernacularName,
    pathogenType: disease.pathogenType,
    confidence: Number(confidence.toFixed(1)),
    severity: disease.severity || (isHealthy ? 'None (Healthy)' : 'Moderate'),
    cropRecognition,
    healthyBaseline,
    symptoms: disease.symptoms || [],
    whyThisHappens,
    culturalMeasures: disease.culturalMeasures || [],
    biologicalControl: disease.biologicalControl || [],
    chemicalControl: disease.chemicalControl || [],
    preventiveCare: disease.preventiveCare || [],
    recommendedActions: [
      ...(disease.culturalMeasures ? disease.culturalMeasures.slice(0, 1) : []),
      ...(disease.chemicalControl && disease.chemicalControl[0] ? ['Chemical: ' + disease.chemicalControl[0].chemical + ' @ ' + disease.chemicalControl[0].dosage] : []),
      ...(disease.biologicalControl ? disease.biologicalControl.slice(0, 1) : [])
    ],
    kvkHelpline: disease.kvkHelpline || 'National Kisan Call Center: 1800-180-1551 (ICAR)',
    biomarkers,
    boundingBox: null, // Authentic classification model does NOT invent bounding boxes
    topCandidates,
    fileName: fileName || null,
    isDemoSample: Boolean(isDemoSample),
    screeningMode: isDemoSample ? 'AgroSense Demo Specimen (MobileNet V1 Inference)' : 'AgroSense CV MobileNet V1 (Multi-Crop 56-Class Deep Learning)',
    disclaimer: 'AI computer vision screening advisory — please cross-verify with your local Krishi Vigyan Kendra (KVK) officer before large-scale chemical pesticide purchase.'
  };
}

/* Module Exports */
exports.analyzeLeafImage = analyzeLeafImage;
exports.formatAnalysisResult = formatAnalysisResult;
exports.loadPlantVillageModel = loadPlantVillageModel;
exports.initDiseaseModel = initDiseaseModel;
exports.getModelStatus = getModelStatus;
exports.subscribeModelStatus = subscribeModelStatus;
exports.MODEL_STATUS = MODEL_STATUS;
exports.runTensorFlowInference = runTensorFlowInference;
exports.SUPPORTED_CROP_REGISTRY = SUPPORTED_CROP_REGISTRY;
exports.PLANTVILLAGE_CLASSES = PLANTVILLAGE_CLASSES;
exports.getSampleDataUrl = getSampleDataUrl;
exports.validateLeafImage = validateLeafImage;
exports.getWhyThisHappens = getWhyThisHappens;
exports.initCropModel = initCropModel;
exports.getCropModelStatus = getCropModelStatus;
exports.subscribeCropModelStatus = subscribeCropModelStatus;
exports.detectCropFromImage = detectCropFromImage;
exports.CROP_MODEL_STATUS = CROP_MODEL_STATUS;
exports.SUPPORTED_CROP_CLASSES = SUPPORTED_CROP_CLASSES;
