// AGROSENSE INTERACTIVE FARM WHAT-IF SIMULATOR PAGE (/#/what-if)

const { predictSmartCrop } = require('js/ml/fodsMLEngine.js');

function renderWhatIfSimulatorPage(state) {
  const input = state.whatIfInput || {
    N: 90, P: 42, K: 43, temp: 24, humidity: 80, ph: 6.5, rainfall: 220, moisture: 45
  };

  const prediction = predictSmartCrop(input);

  return `
    <div class="space-y-8 max-w-7xl mx-auto py-2">
      <!-- Page Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-extrabold text-white tracking-tight">Interactive What-If Farm Simulator</h1>
            <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">REAL-TIME INFERENCE SLIDERS</span>
          </div>
          <p class="text-xs text-gray-400 mt-1">Manipulate environmental parameters in real time and observe live ML prediction shifts & confidence score deltas</p>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <!-- Environmental Sliders Column (7 cols) -->
        <div class="lg:col-span-7 space-y-4">
          <div class="glass-card p-6 space-y-6">
            <h3 class="text-sm font-bold text-white flex items-center gap-2 border-b border-emerald-950/60 pb-3">
              <i data-lucide="sliders-horizontal" class="w-4 h-4 text-emerald-400"></i>
              Agronomic & Environmental Parameter Controls
            </h3>

            <div class="space-y-4 font-mono text-xs">
              <!-- Nitrogen Slider -->
              <div class="space-y-1">
                <div class="flex justify-between text-gray-300"><span>Nitrogen (N):</span><span class="text-emerald-400 font-bold" id="val-N">${input.N} kg/ha</span></div>
                <input type="range" id="slider-N" min="0" max="140" value="${input.N}" class="w-full accent-emerald-500 cursor-pointer" />
              </div>

              <!-- Phosphorus Slider -->
              <div class="space-y-1">
                <div class="flex justify-between text-gray-300"><span>Phosphorus (P):</span><span class="text-teal-300 font-bold" id="val-P">${input.P} kg/ha</span></div>
                <input type="range" id="slider-P" min="0" max="145" value="${input.P}" class="w-full accent-teal-500 cursor-pointer" />
              </div>

              <!-- Potassium Slider -->
              <div class="space-y-1">
                <div class="flex justify-between text-gray-300"><span>Potassium (K):</span><span class="text-blue-300 font-bold" id="val-K">${input.K} kg/ha</span></div>
                <input type="range" id="slider-K" min="0" max="205" value="${input.K}" class="w-full accent-blue-500 cursor-pointer" />
              </div>

              <!-- Temperature Slider -->
              <div class="space-y-1">
                <div class="flex justify-between text-gray-300"><span>Temperature:</span><span class="text-amber-300 font-bold" id="val-temp">${input.temp} °C</span></div>
                <input type="range" id="slider-temp" min="8" max="45" value="${input.temp}" class="w-full accent-amber-500 cursor-pointer" />
              </div>

              <!-- Humidity Slider -->
              <div class="space-y-1">
                <div class="flex justify-between text-gray-300"><span>Humidity:</span><span class="text-blue-400 font-bold" id="val-humidity">${input.humidity} %</span></div>
                <input type="range" id="slider-humidity" min="14" max="100" value="${input.humidity}" class="w-full accent-blue-400 cursor-pointer" />
              </div>

              <!-- Soil pH Slider -->
              <div class="space-y-1">
                <div class="flex justify-between text-gray-300"><span>Soil pH:</span><span class="text-purple-300 font-bold" id="val-ph">${input.ph}</span></div>
                <input type="range" id="slider-ph" min="3.5" max="10.0" step="0.1" value="${input.ph}" class="w-full accent-purple-500 cursor-pointer" />
              </div>

              <!-- Rainfall Slider -->
              <div class="space-y-1">
                <div class="flex justify-between text-gray-300"><span>Rainfall:</span><span class="text-teal-400 font-bold" id="val-rainfall">${input.rainfall} mm</span></div>
                <input type="range" id="slider-rainfall" min="20" max="300" value="${input.rainfall}" class="w-full accent-teal-400 cursor-pointer" />
              </div>
            </div>
          </div>
        </div>

        <!-- Real-Time Prediction Column (5 cols) -->
        <div class="lg:col-span-5 space-y-4">
          <!-- Primary Prediction Card -->
          <div class="glass-card p-6 space-y-4 border-l-4 border-l-emerald-500">
            <span class="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-wider">Top Recommended Crop</span>
            <div class="flex items-center justify-between">
              <h2 class="text-2xl font-extrabold text-white" id="pred-primary-crop">${prediction.primaryCrop}</h2>
              <span class="px-3 py-1 rounded font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-lg" id="pred-confidence">
                ${prediction.confidence}% Confidence
              </span>
            </div>

            <!-- Alternative Crops -->
            <div class="space-y-2 border-t border-emerald-950/60 pt-3">
              <div class="text-[11px] font-bold text-gray-400">Alternative Crop Options:</div>
              <div class="space-y-1.5 text-xs font-mono">
                ${prediction.alternatives.map(alt => `
                  <div class="flex justify-between p-2 rounded bg-gray-900 border border-gray-800">
                    <span class="text-gray-300 font-bold">${alt.name}</span>
                    <span class="text-teal-300">${alt.confidence}%</span>
                  </div>
                `).join('')}
              </div>
            </div>

            <!-- XAI Reason Cards -->
            <div class="space-y-2 border-t border-emerald-950/60 pt-3">
              <div class="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">WHY THIS CROP? (XAI Attribution)</div>
              <div class="space-y-1 text-xs text-gray-300">
                ${prediction.reasons.map(r => `<div class="flex items-center gap-1.5"><i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-emerald-400 shrink-0"></i><span>${r}</span></div>`).join('')}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;
}

function initWhatIfHooks(state, setState) {
  ['N', 'P', 'K', 'temp', 'humidity', 'ph', 'rainfall'].forEach(param => {
    const slider = document.getElementById(`slider-${param}`);
    const valLabel = document.getElementById(`val-${param}`);
    if (slider && valLabel) {
      slider.addEventListener('input', (e) => {
        const val = Number(e.target.value);
        valLabel.textContent = `${val}${param === 'temp' ? ' °C' : param === 'humidity' ? ' %' : param === 'rainfall' ? ' mm' : param === 'ph' ? '' : ' kg/ha'}`;

        const curInput = state.whatIfInput || { N: 90, P: 42, K: 43, temp: 24, humidity: 80, ph: 6.5, rainfall: 220 };
        curInput[param] = val;

        const pred = predictSmartCrop(curInput);
        const primaryEl = document.getElementById('pred-primary-crop');
        const confEl = document.getElementById('pred-confidence');
        if (primaryEl) primaryEl.textContent = pred.primaryCrop;
        if (confEl) confEl.textContent = `${pred.confidence}% Confidence`;
      });
    }
  });
}

/* Module Exports */
exports.renderWhatIfSimulatorPage = renderWhatIfSimulatorPage; exports.initWhatIfHooks = initWhatIfHooks;
