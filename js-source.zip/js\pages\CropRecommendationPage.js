// AgroSense AI Crop Recommendation & Farmer Crop Selection Prediction Model Page
// Real-time interactive multi-variable machine learning prediction based on:
// 1. Farm profile (Acres, Season, Irrigation, Previous Crop)
// 2. Soil fertility & contains (Soil Type, Fertility Index, N, P, K, pH, Organic Carbon)
// 3. Rainfall & climate (Rainfall mm, Temperature, Humidity)

import { predictFarmerCropSelection, farmerPresets } from '../ml/cropPredictionModel.js';
import { calculateCropSuitability } from '../services/aiEngine.js';
import { cropCategories } from '../data/expandedCropDatabase.js';
import { renderXAIExplanationCard } from '../components/XAIExplanationCard.js';
import { renderEmbedded3DFarmCard, initEmbedded3DFarmTwin } from '../components/ThreeDFarmCanvas.js';
import { translations } from '../data/translations.js';

/**
 * Renders the Right Column Prediction Results HTML
 */
export function renderPredictionResults(prediction, input) {
  const primary = prediction.primaryCrop;

  return `
    <!-- Hero Recommended Crop Banner -->
    <div id="hero-prediction-card" class="glass-card p-6 rounded-2xl border border-emerald-700/60 bg-[#0d1e17] relative overflow-hidden shadow-lg transition-all duration-300">
      
      <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-900/60 pb-3">
        <div class="flex items-center gap-2">
          <span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
          <span class="text-xs font-bold uppercase tracking-wider text-emerald-300 font-mono">
            Primary Suitability Recommendation
          </span>
        </div>
        <span class="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-800/80 text-emerald-100 border border-emerald-600/50">
          ${primary.suitabilityScore}% Match Score
        </span>
      </div>

      <!-- Title & Category -->
      <div class="mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 class="text-2xl sm:text-3xl font-black text-white font-['Outfit'] tracking-tight">
            ${primary.name}
          </h2>
          <p class="text-xs text-emerald-300/90 font-medium mt-0.5">
            ${primary.category} • Duration: ${primary.growthDuration} • Season: ${primary.season}
          </p>
        </div>

        <div class="text-left sm:text-right">
          <span class="text-[10px] text-gray-400 block uppercase font-mono">Projected Net Margin</span>
          <span class="text-xl font-black text-emerald-400 font-mono">
            ₹${primary.totalFarmNetProfit.toLocaleString('en-IN')}
          </span>
          <span class="text-[10px] text-gray-400 block font-mono">(across ${input.farm.acres} acres)</span>
        </div>
      </div>

      <!-- Key Production Metric Cards -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5 font-mono text-xs">
        
        <div class="p-3 rounded-xl bg-black/40 border border-emerald-900/60">
          <span class="text-gray-400 block text-[10px]">Predicted Yield</span>
          <span class="text-sm font-bold text-white">${primary.estimatedYieldPerAcre} Qtl/Acre</span>
          <span class="text-[10px] text-emerald-400 block">(${primary.estimatedYieldPerHa} Qtl/Ha)</span>
        </div>

        <div class="p-3 rounded-xl bg-black/40 border border-emerald-900/60">
          <span class="text-gray-400 block text-[10px]">Total Production</span>
          <span class="text-sm font-bold text-amber-300">${primary.totalFarmProductionQtl} Quintals</span>
          <span class="text-[10px] text-gray-400 block">for ${input.farm.acres} Acres</span>
        </div>

        <div class="p-3 rounded-xl bg-black/40 border border-emerald-900/60">
          <span class="text-gray-400 block text-[10px]">Water Balance</span>
          <span class="text-sm font-bold text-sky-300">${primary.waterScore}/30 pts</span>
          <span class="text-[10px] text-sky-400 truncate block">${primary.waterStatus}</span>
        </div>

        <div class="p-3 rounded-xl bg-black/40 border border-emerald-900/60">
          <span class="text-gray-400 block text-[10px]">Market Value</span>
          <span class="text-sm font-bold text-teal-300">${primary.marketPriceAvg}</span>
          <span class="text-[10px] text-gray-400 block">APMC mandi avg</span>
        </div>

      </div>

      <!-- Why Reasons -->
      <div class="mt-5 space-y-2 border-t border-emerald-900/60 pt-3 text-xs">
        <span class="text-[10px] font-black uppercase tracking-wider text-emerald-400 font-mono block">
          Why This Crop Fits Your Farm & Soil:
        </span>
        <div class="space-y-1.5 text-gray-200">
          ${prediction.whyReasons.map(r => `
            <div class="flex items-start gap-2">
              <i data-lucide="check-circle-2" class="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5"></i>
              <span>${r}</span>
            </div>
          `).join('')}
        </div>
      </div>

    </div>

    <!-- 3D Farm Digital Twin for Predicted Crop & Soil/Rainfall Data -->
    ${renderEmbedded3DFarmCard(prediction, input)}

    <!-- Explainable AI (XAI) Attribution Breakdown -->
    <div class="glass-card p-5 space-y-4">
      <div class="flex items-center justify-between border-b border-emerald-950/60 pb-2">
        <h4 class="text-xs font-black uppercase tracking-wider text-white font-mono flex items-center gap-1.5">
          <i data-lucide="bar-chart-2" class="w-4 h-4 text-emerald-400"></i>
          Agronomic Multi-Variable XAI Breakdown
        </h4>
        <span class="text-[10px] text-gray-400">Factor Contribution Weights</span>
      </div>

      <div class="space-y-3 font-mono text-xs">
        ${prediction.xaiAttribution.map(attr => `
          <div class="space-y-1">
            <div class="flex justify-between items-center text-gray-300">
              <span class="font-bold text-white">${attr.factor}</span>
              <span class="text-emerald-400 font-bold">${attr.score} / ${attr.max} pts (${attr.percentage}%)</span>
            </div>
            <div class="w-full h-2 rounded-full bg-gray-900 overflow-hidden border border-gray-800">
              <div class="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-300" style="width: ${attr.percentage}%"></div>
            </div>
            <span class="text-[10px] text-gray-400 block">${attr.detail}</span>
          </div>
        `).join('')}
      </div>
    </div>

    <!-- Fertilizer & Soil Fertility Action Plan -->
    <div class="glass-card p-5 space-y-4 border-l-4 border-l-amber-500">
      <div class="flex items-center justify-between border-b border-emerald-950/60 pb-2">
        <h4 class="text-xs font-black uppercase tracking-wider text-amber-300 font-mono flex items-center gap-1.5">
          <i data-lucide="flask-conical" class="w-4 h-4 text-amber-400"></i>
          Soil Fertility & Fertilizer Prescription for ${primary.name}
        </h4>
        <span class="text-[10px] text-gray-400">Tailored to your soil NPK & pH</span>
      </div>

      <div class="space-y-2.5 text-xs">
        ${prediction.fertilizerPlan.length > 0 ? prediction.fertilizerPlan.map(plan => `
          <div class="p-3 rounded-xl bg-black/40 border border-gray-800 space-y-1">
            <div class="flex items-center justify-between">
              <span class="font-bold text-white flex items-center gap-1.5">
                <i data-lucide="check" class="w-3.5 h-3.5 text-emerald-400"></i>
                ${plan.action}
              </span>
              <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                plan.urgency === 'Critical' ? 'bg-red-500/20 text-red-300 border border-red-500/40' :
                plan.urgency === 'High Priority' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' :
                'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              }">
                ${plan.urgency}
              </span>
            </div>
            <p class="text-[11px] text-gray-300">${plan.dosage}</p>
            <span class="text-[10px] text-gray-500 font-mono block">Target: ${plan.nutrient}</span>
          </div>
        `).join('') : `
          <div class="p-3 rounded-xl bg-emerald-950/30 border border-emerald-800/40 text-emerald-300 text-xs flex items-center gap-2">
            <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-400"></i>
            <span>Current soil NPK reserves and pH are in balanced harmony with this crop. Standard maintenance dose recommended.</span>
          </div>
        `}
      </div>
    </div>

    <!-- Alternative Recommended Crops (Runner-Ups) -->
    <div class="glass-card p-5 space-y-3">
      <div class="flex items-center justify-between border-b border-emerald-950/60 pb-2">
        <h4 class="text-xs font-black uppercase tracking-wider text-white font-mono flex items-center gap-1.5">
          <i data-lucide="layers" class="w-4 h-4 text-teal-400"></i>
          Viable Alternative Crop Options
        </h4>
        <span class="text-[10px] text-gray-400">Top 3 Runner-Ups</span>
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
        ${prediction.alternatives.map((alt, idx) => `
          <div class="p-3.5 rounded-xl bg-gray-950/70 border border-emerald-900/50 space-y-1.5 flex flex-col justify-between hover:border-emerald-500/50 transition">
            <div>
              <div class="flex items-center justify-between mb-1">
                <span class="text-[10px] font-mono text-gray-400">#${idx + 2} Candidate</span>
                <span class="text-xs font-black text-teal-300 font-mono">${alt.suitabilityScore}%</span>
              </div>
              <h5 class="text-xs font-extrabold text-white leading-snug">${alt.name}</h5>
              <span class="text-[10px] text-gray-400 block">${alt.category}</span>
            </div>
            <div class="border-t border-gray-800 pt-1.5 text-[10px] font-mono text-gray-300">
              <div>Yield: <span class="text-white">${alt.estimatedYieldPerAcre} Qtl/Ac</span></div>
              <div>Profit: <span class="text-emerald-400">₹${alt.netProfitPerAcre.toLocaleString('en-IN')}/Ac</span></div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>

    <!-- Incompatible / High Risk Crops to Avoid -->
    <div class="glass-card p-5 space-y-3 border-l-4 border-l-rose-500">
      <div class="flex items-center justify-between border-b border-emerald-950/60 pb-2">
        <h4 class="text-xs font-black uppercase tracking-wider text-rose-400 font-mono flex items-center gap-1.5">
          <i data-lucide="alert-octagon" class="w-4 h-4 text-rose-400"></i>
          High-Risk Crops to Avoid for this Land Condition
        </h4>
        <span class="text-[10px] text-rose-300/80 font-mono">Drought / Waterlogging / Soil Mismatch</span>
      </div>

      <div class="space-y-2 text-xs">
        ${prediction.avoidCrops.map(c => `
          <div class="p-2.5 rounded-xl bg-rose-950/20 border border-rose-800/40 flex items-start gap-2.5">
            <i data-lucide="x-circle" class="w-4 h-4 text-rose-400 shrink-0 mt-0.5"></i>
            <div>
              <span class="font-bold text-rose-200">${c.name} (${c.suitabilityScore}% match)</span>
              <p class="text-[11px] text-gray-300 mt-0.5">${c.reason}</p>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

export function renderCropRecommendationPage(state) {
  const lang = state?.lang || 'en';
  const t = translations[lang] || translations.en;
  const activeTab = state.cropRecTab || 'prediction';

  const activeFarm = state.activeFarm || {};
  const farmSoil = activeFarm.soil || {};

  const input = state.farmerPredictionInput || {
    farm: {
      acres: 5,
      season: 'Kharif',
      irrigation: activeFarm.irrigationType || 'Drip',
      previousCrop: 'Fallow / None'
    },
    soil: {
      type: activeFarm.soilType || 'Medium Black Vertisol',
      fertilityIndex: farmSoil.soilScore || 76,
      n: farmSoil.nitrogen || 240,
      p: farmSoil.phosphorus || 45,
      k: farmSoil.potassium || 180,
      ph: farmSoil.ph || 7.2,
      oc: 0.65,
      moisture: farmSoil.moisture || 38
    },
    climate: {
      rainfall: 650,
      temp: farmSoil.temperature || 28,
      humidity: farmSoil.humidity || 65
    }
  };

  const prediction = predictFarmerCropSelection(input);

  // 100+ Catalog filter & recommendations
  const categoryFilter = state.cropCategoryFilter || 'All';
  const searchQuery = state.cropSearchQuery || '';
  const recommendations = calculateCropSuitability(state.activeFarm, state.customSoil, categoryFilter, searchQuery);
  const selectedCropId = state.selectedCropId || (recommendations[0] ? recommendations[0].id : 'c-01');
  const selectedCrop = recommendations.find(c => c.id === selectedCropId) || recommendations[0];

  const categories = cropCategories;

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      
      <!-- Page Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <div class="w-8 h-8 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-md shadow-emerald-900/40">
              <i data-lucide="sparkles" class="w-4 h-4"></i>
            </div>
            <h1 class="text-2xl font-black text-white tracking-tight font-['Outfit']">
              AI Crop Selection & Soil-Rainfall Prediction Model
            </h1>
            <span class="px-2.5 py-0.5 rounded text-xs font-mono font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              AGRONOMIC ML ENGINE
            </span>
          </div>
          <p class="text-xs text-gray-400 mt-1">
            Predicts the highest-yielding and most profitable crops based on your farm acreage, soil fertility index, soil contents (N, P, K, pH, OC), and expected rainfall.
          </p>
        </div>

        <!-- Quick Top Links -->
        <div class="flex items-center gap-2">
          <a href="#/crop-compare" class="px-3.5 py-2 rounded-xl bg-emerald-950/80 border border-emerald-700/50 text-emerald-300 hover:bg-emerald-900/60 text-xs font-bold transition flex items-center gap-1.5 text-decoration-none">
            <i data-lucide="columns-4" class="w-4 h-4 text-emerald-400"></i>
            Compare 4 Crops
          </a>
          <button id="btn-print-advisory" class="px-3.5 py-2 rounded-xl bg-gray-900 border border-gray-700 text-gray-300 hover:text-white hover:border-gray-500 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer">
            <i data-lucide="printer" class="w-4 h-4"></i>
            Print Advisory
          </button>
        </div>
      </div>

      <!-- Tab Navigation Switcher -->
      <div class="flex items-center gap-2 border-b border-emerald-950/80 pb-2">
        <button id="tab-btn-prediction" class="px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 cursor-pointer ${
          activeTab === 'prediction'
            ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-700/30 border border-emerald-400'
            : 'bg-emerald-950/40 text-gray-400 hover:text-white border border-emerald-900/60'
        }">
          <i data-lucide="brain-circuit" class="w-4 h-4"></i>
          <span>🔮 Farmer Soil & Rainfall Prediction Model</span>
        </button>

        <button id="tab-btn-catalog" class="px-4 py-2 rounded-xl text-xs font-extrabold transition flex items-center gap-2 cursor-pointer ${
          activeTab === 'catalog'
            ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-700/30 border border-emerald-400'
            : 'bg-emerald-950/40 text-gray-400 hover:text-white border border-emerald-900/60'
        }">
          <i data-lucide="database" class="w-4 h-4"></i>
          <span>📚 100+ Crops Agronomic Catalog</span>
        </button>
      </div>

      <!-- ======================================================== -->
      <!-- TAB 1: INTERACTIVE FARMER PREDICTION MODEL               -->
      <!-- ======================================================== -->
      <div id="section-prediction-tab" class="${activeTab === 'prediction' ? 'block' : 'hidden'} space-y-6">

        <!-- 1-Click Realistic Farm Presets Bar -->
        <div class="glass-card p-4 space-y-2">
          <div class="flex items-center justify-between">
            <span class="text-[11px] font-black uppercase tracking-wider text-emerald-400 font-mono flex items-center gap-1.5">
              <i data-lucide="sparkles" class="w-3.5 h-3.5"></i>
              Quick 1-Click Realistic Farm Scenarios:
            </span>
            <span class="text-[10px] text-gray-400">Click any preset to autofill farm, soil contains, and rainfall</span>
          </div>
          <div class="flex flex-wrap items-center gap-2 pt-1">
            <button data-preset="activeFarm" class="preset-btn px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 hover:bg-emerald-900/80 hover:text-white transition cursor-pointer flex items-center gap-1">
              <span>🌿 Load Current Active Farm Sensors</span>
            </button>
            <button data-preset="blackSoilCottonSoybean" class="preset-btn px-3 py-1.5 rounded-lg text-xs font-bold bg-gray-900 border border-gray-700 text-gray-300 hover:border-emerald-500 hover:text-white transition cursor-pointer flex items-center gap-1">
              <span>🌾 Black Vertisol (Cotton / Soybean)</span>
            </button>
            <button data-preset="alluvialPaddyBasin" class="preset-btn px-3 py-1.5 rounded-lg text-xs font-bold bg-gray-900 border border-gray-700 text-gray-300 hover:border-emerald-500 hover:text-white transition cursor-pointer flex items-center gap-1">
              <span>🌱 Alluvial Basin (Paddy / Sugarcane)</span>
            </button>
            <button data-preset="drylandRedSoilPulses" class="preset-btn px-3 py-1.5 rounded-lg text-xs font-bold bg-gray-900 border border-gray-700 text-gray-300 hover:border-emerald-500 hover:text-white transition cursor-pointer flex items-center gap-1">
              <span>🌾 Red Soil Dryland (Millets / Pulses)</span>
            </button>
            <button data-preset="sandyLoamDripVeg" class="preset-btn px-3 py-1.5 rounded-lg text-xs font-bold bg-gray-900 border border-gray-700 text-gray-300 hover:border-emerald-500 hover:text-white transition cursor-pointer flex items-center gap-1">
              <span>🧪 Sandy Loam Drip (Vegetables / Spices)</span>
            </button>
          </div>
        </div>

        <!-- Two-Column Layout: Inputs (Left) and Prediction Results (Right) -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          
          <!-- LEFT COLUMN: Farmer Input Form (5 Cols) -->
          <div class="lg:col-span-5 space-y-4">
            <div class="glass-card p-5 space-y-5">
              
              <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
                <h3 class="text-sm font-extrabold text-white flex items-center gap-2">
                  <i data-lucide="sliders" class="w-4 h-4 text-emerald-400"></i>
                  <span>Enter Your Farm & Soil Data</span>
                </h3>
                <span class="text-[10px] text-emerald-400 font-mono font-bold bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                  REAL-TIME DYNAMIC INFERENCE
                </span>
              </div>

              <!-- Section 1: Farm Profile -->
              <div class="space-y-3">
                <span class="text-[10px] font-black uppercase tracking-wider text-emerald-400/90 font-mono">1. Farm & Cultivation Profile</span>
                
                <div class="grid grid-cols-2 gap-3 text-xs">
                  <!-- Farm Size (Acres) -->
                  <div>
                    <label class="block text-gray-300 font-bold mb-1">Farm Area (Acres):</label>
                    <input id="input-farm-acres" type="number" step="0.5" min="0.5" max="100" value="${input.farm.acres}" class="w-full bg-gray-950 border border-emerald-800/60 rounded-xl px-3 py-2 text-white font-mono focus:border-emerald-400 focus:outline-none" />
                  </div>

                  <!-- Season -->
                  <div>
                    <label class="block text-gray-300 font-bold mb-1">Target Season:</label>
                    <select id="input-farm-season" class="w-full bg-gray-950 border border-emerald-800/60 rounded-xl px-2.5 py-2 text-white font-bold focus:border-emerald-400 focus:outline-none cursor-pointer">
                      <option value="Kharif" ${input.farm.season === 'Kharif' ? 'selected' : ''}>Kharif (Monsoon / Autumn)</option>
                      <option value="Rabi" ${input.farm.season === 'Rabi' ? 'selected' : ''}>Rabi (Winter / Spring)</option>
                      <option value="Zaid" ${input.farm.season === 'Zaid' ? 'selected' : ''}>Zaid (Summer)</option>
                      <option value="Annual" ${input.farm.season === 'Annual' ? 'selected' : ''}>Perennial / Annual</option>
                    </select>
                  </div>
                </div>

                <div class="grid grid-cols-2 gap-3 text-xs">
                  <!-- Irrigation Type -->
                  <div>
                    <label class="block text-gray-300 font-bold mb-1">Irrigation Method:</label>
                    <select id="input-farm-irrigation" class="w-full bg-gray-950 border border-emerald-800/60 rounded-xl px-2.5 py-2 text-white font-bold focus:border-emerald-400 focus:outline-none cursor-pointer">
                      <option value="Rainfed" ${input.farm.irrigation === 'Rainfed' ? 'selected' : ''}>Rainfed (No Irrigation)</option>
                      <option value="Drip" ${input.farm.irrigation === 'Drip' ? 'selected' : ''}>Drip Irrigation (High Efficiency)</option>
                      <option value="Sprinkler" ${input.farm.irrigation === 'Sprinkler' ? 'selected' : ''}>Sprinkler System</option>
                      <option value="Canal" ${input.farm.irrigation === 'Canal' ? 'selected' : ''}>Canal / Well Flood</option>
                    </select>
                  </div>

                  <!-- Previous Crop -->
                  <div>
                    <label class="block text-gray-300 font-bold mb-1">Previous Crop Harvested:</label>
                    <select id="input-farm-prev-crop" class="w-full bg-gray-950 border border-emerald-800/60 rounded-xl px-2.5 py-2 text-white font-bold focus:border-emerald-400 focus:outline-none cursor-pointer">
                      <option value="Fallow / None" ${input.farm.previousCrop === 'Fallow / None' ? 'selected' : ''}>Fallow / New Land</option>
                      <option value="Soybean" ${input.farm.previousCrop === 'Soybean' ? 'selected' : ''}>Soybean (Legume)</option>
                      <option value="Wheat" ${input.farm.previousCrop === 'Wheat' ? 'selected' : ''}>Wheat</option>
                      <option value="Cotton" ${input.farm.previousCrop === 'Cotton' ? 'selected' : ''}>Cotton (Exhaustive)</option>
                      <option value="Sugarcane" ${input.farm.previousCrop === 'Sugarcane' ? 'selected' : ''}>Sugarcane (Heavy Feeder)</option>
                      <option value="Rice" ${input.farm.previousCrop === 'Rice' ? 'selected' : ''}>Rice / Paddy</option>
                      <option value="Chickpea" ${input.farm.previousCrop === 'Chickpea' ? 'selected' : ''}>Chickpea / Gram</option>
                      <option value="Millets" ${input.farm.previousCrop === 'Millets' ? 'selected' : ''}>Millets / Bajra</option>
                    </select>
                  </div>
                </div>
              </div>

              <!-- Section 2: Soil Fertility & Soil Contains -->
              <div class="space-y-3 border-t border-emerald-950/60 pt-4">
                <span class="text-[10px] font-black uppercase tracking-wider text-emerald-400/90 font-mono">2. Soil Fertility & Soil Contains</span>
                
                <div class="grid grid-cols-2 gap-3 text-xs">
                  <!-- Soil Type -->
                  <div>
                    <label class="block text-gray-300 font-bold mb-1">Soil Type / Texture:</label>
                    <select id="input-soil-type" class="w-full bg-gray-950 border border-emerald-800/60 rounded-xl px-2.5 py-2 text-white font-bold focus:border-emerald-400 focus:outline-none cursor-pointer">
                      <option value="Medium Black Vertisol" ${input.soil.type === 'Medium Black Vertisol' ? 'selected' : ''}>Medium Black Vertisol</option>
                      <option value="Deep Black Vertisol" ${input.soil.type === 'Deep Black Vertisol' ? 'selected' : ''}>Deep Black Vertisol (Clayey)</option>
                      <option value="Fertile Alluvial Loam" ${input.soil.type === 'Fertile Alluvial Loam' ? 'selected' : ''}>Fertile Alluvial Loam</option>
                      <option value="Red Sandy Loam" ${input.soil.type === 'Red Sandy Loam' ? 'selected' : ''}>Red Sandy Loam</option>
                      <option value="Well-Drained Sandy Loam" ${input.soil.type === 'Well-Drained Sandy Loam' ? 'selected' : ''}>Well-Drained Sandy Loam</option>
                      <option value="Laterite / Acidic Soil" ${input.soil.type === 'Laterite / Acidic Soil' ? 'selected' : ''}>Laterite / Acidic Soil</option>
                    </select>
                  </div>

                  <!-- Soil Fertility Index -->
                  <div>
                    <div class="flex justify-between items-center mb-1">
                      <label class="text-gray-300 font-bold">Fertility Index:</label>
                      <span id="label-fertility-val" class="text-emerald-400 font-mono font-bold">${input.soil.fertilityIndex}/100</span>
                    </div>
                    <input id="input-fertility-idx" type="range" min="30" max="98" value="${input.soil.fertilityIndex}" class="w-full accent-emerald-500 cursor-pointer" />
                  </div>
                </div>

                <!-- Sliders for N, P, K, pH, OC -->
                <div class="space-y-3 font-mono text-xs pt-1">
                  <!-- Nitrogen (N) -->
                  <div>
                    <div class="flex justify-between text-gray-300 mb-1">
                      <span>Available Nitrogen (N):</span>
                      <span id="label-n-val" class="text-emerald-400 font-bold">${input.soil.n} kg/ha</span>
                    </div>
                    <input id="input-soil-n" type="range" min="80" max="450" value="${input.soil.n}" class="w-full accent-emerald-500 cursor-pointer" />
                  </div>

                  <!-- Phosphorus (P) -->
                  <div>
                    <div class="flex justify-between text-gray-300 mb-1">
                      <span>Available Phosphorus (P):</span>
                      <span id="label-p-val" class="text-teal-300 font-bold">${input.soil.p} kg/ha</span>
                    </div>
                    <input id="input-soil-p" type="range" min="10" max="110" value="${input.soil.p}" class="w-full accent-teal-500 cursor-pointer" />
                  </div>

                  <!-- Potassium (K) -->
                  <div>
                    <div class="flex justify-between text-gray-300 mb-1">
                      <span>Available Potassium (K):</span>
                      <span id="label-k-val" class="text-blue-300 font-bold">${input.soil.k} kg/ha</span>
                    </div>
                    <input id="input-soil-k" type="range" min="50" max="380" value="${input.soil.k}" class="w-full accent-blue-500 cursor-pointer" />
                  </div>

                  <!-- Soil pH -->
                  <div>
                    <div class="flex justify-between text-gray-300 mb-1">
                      <span>Soil Reaction (pH):</span>
                      <span id="label-ph-val" class="text-purple-300 font-bold">${input.soil.ph} pH</span>
                    </div>
                    <input id="input-soil-ph" type="range" min="4.5" max="9.0" step="0.1" value="${input.soil.ph}" class="w-full accent-purple-500 cursor-pointer" />
                  </div>

                  <!-- Organic Carbon (OC) -->
                  <div>
                    <div class="flex justify-between text-gray-300 mb-1">
                      <span>Organic Carbon (OC):</span>
                      <span id="label-oc-val" class="text-amber-300 font-bold">${input.soil.oc}%</span>
                    </div>
                    <input id="input-soil-oc" type="range" min="0.2" max="1.5" step="0.05" value="${input.soil.oc}" class="w-full accent-amber-500 cursor-pointer" />
                  </div>
                </div>
              </div>

              <!-- Section 3: Rainfall & Climate -->
              <div class="space-y-3 border-t border-emerald-950/60 pt-4">
                <span class="text-[10px] font-black uppercase tracking-wider text-emerald-400/90 font-mono">3. Expected Rainfall & Climate Window</span>
                
                <div class="space-y-3 font-mono text-xs">
                  <!-- Expected Rainfall -->
                  <div>
                    <div class="flex justify-between text-gray-300 mb-1">
                      <span>Expected Seasonal Rainfall:</span>
                      <span id="label-rain-val" class="text-sky-300 font-bold">${input.climate.rainfall} mm</span>
                    </div>
                    <input id="input-climate-rain" type="range" min="150" max="2200" step="25" value="${input.climate.rainfall}" class="w-full accent-sky-500 cursor-pointer" />
                  </div>

                  <div class="grid grid-cols-2 gap-3">
                    <!-- Temperature -->
                    <div>
                      <div class="flex justify-between text-gray-300 mb-1">
                        <span>Avg Temp:</span>
                        <span id="label-temp-val" class="text-amber-300 font-bold">${input.climate.temp}°C</span>
                      </div>
                      <input id="input-climate-temp" type="range" min="12" max="42" value="${input.climate.temp}" class="w-full accent-amber-500 cursor-pointer" />
                    </div>

                    <!-- Humidity -->
                    <div>
                      <div class="flex justify-between text-gray-300 mb-1">
                        <span>Avg Humidity:</span>
                        <span id="label-hum-val" class="text-teal-300 font-bold">${input.climate.humidity}%</span>
                      </div>
                      <input id="input-climate-hum" type="range" min="20" max="95" value="${input.climate.humidity}" class="w-full accent-teal-500 cursor-pointer" />
                    </div>
                  </div>
                </div>
              </div>

              <!-- Action CTA -->
              <div class="pt-2">
                <button id="btn-run-prediction" class="w-full py-3 rounded-xl font-bold text-white bg-emerald-700 hover:bg-emerald-600 transition text-xs flex items-center justify-center gap-2 cursor-pointer border border-emerald-500/40 shadow-sm">
                  <i data-lucide="calculator" class="w-4 h-4 text-emerald-200"></i>
                  <span>Compute Crop Suitability Analysis</span>
                </button>
              </div>

            </div>
          </div>

          <!-- RIGHT COLUMN: Dynamic AI Prediction Results Container (7 Cols) -->
          <div id="prediction-results-container" class="lg:col-span-7 space-y-6">
            ${renderPredictionResults(prediction, input)}
          </div>

        </div>

      </div>

      <!-- ======================================================== -->
      <!-- TAB 2: 100+ CROPS AGRONOMIC DATABASE CATALOG             -->
      <!-- ======================================================== -->
      <div id="section-catalog-tab" class="${activeTab === 'catalog' ? 'block' : 'hidden'} space-y-6">
        
        <!-- Filter Controls Bar -->
        <div class="glass-card p-4 space-y-3">
          <div class="flex flex-wrap items-center justify-between gap-3">
            <!-- Category Filter Tabs -->
            <div class="flex flex-wrap items-center gap-1.5 overflow-x-auto">
              ${categories.map(cat => `
                <button data-crop-cat="${cat}" class="crop-cat-btn px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                  categoryFilter === cat 
                    ? 'bg-emerald-600 text-white shadow-md' 
                    : 'bg-emerald-950/40 text-gray-400 hover:text-white border border-emerald-900/60'
                }">${cat}</button>
              `).join('')}
            </div>

            <!-- Search Input -->
            <div class="relative min-w-[220px]">
              <input id="crop-search-input" type="text" value="${searchQuery}" placeholder="Search 100+ crops..." class="w-full bg-gray-900 border border-emerald-700/50 rounded-xl px-3.5 py-1.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400" />
            </div>
          </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          <!-- 100+ Crop Recommendation Scroll List -->
          <div class="space-y-3 lg:sticky lg:top-4 lg:self-start">
            <div class="flex items-center justify-between">
              <h3 class="text-xs font-bold text-gray-300 uppercase tracking-wider">Matching Crops (${recommendations.length} Found)</h3>
              <span class="text-[10px] text-emerald-400 font-mono">Sorted by XAI Suitability</span>
            </div>

            <div class="space-y-2.5 max-h-[calc(100vh-140px)] overflow-y-auto pr-1">
              ${recommendations.map((rec, idx) => {
                const isSelected = selectedCrop.id === rec.id;
                return `
                  <button data-crop-id="${rec.id}" class="crop-rec-card w-full text-left p-3.5 rounded-xl transition cursor-pointer border ${
                    isSelected 
                      ? 'bg-gradient-to-r from-emerald-950 to-teal-950 border-emerald-400 shadow-lg shadow-emerald-900/40' 
                      : 'glass-card hover:border-emerald-500/50'
                  }">
                    <div class="flex items-center justify-between mb-1.5">
                      <span class="text-[10px] font-extrabold px-2 py-0.5 rounded-full ${idx === 0 ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-emerald-500/20 text-emerald-300'}">
                        #${idx + 1} Candidate
                      </span>
                      <span class="text-base font-extrabold text-emerald-300 font-mono">${rec.suitabilityScore}%</span>
                    </div>
                    <h4 class="text-sm font-bold text-white truncate">${rec.name}</h4>
                    <p class="text-[11px] text-gray-400 mt-0.5">${rec.category} • ${rec.growthDuration}</p>
                  </button>
                `;
              }).join('')}
            </div>
          </div>

          <!-- Explainable AI (XAI) Attribution Breakdown for Selected Crop -->
          <div class="lg:col-span-2 space-y-6">
            ${renderXAIExplanationCard(selectedCrop)}

            <!-- Detail Card -->
            <div class="glass-card p-6 space-y-4">
              <h4 class="text-sm font-bold text-white">Agronomic Parameters & Resource Duty</h4>
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
                  <span class="text-gray-400 block text-[11px]">Ideal Soil pH</span>
                  <span class="text-sm font-bold text-emerald-300 font-mono">${selectedCrop.idealSoilPh}</span>
                </div>
                <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
                  <span class="text-gray-400 block text-[11px]">Temperature Range</span>
                  <span class="text-sm font-bold text-amber-300 font-mono">${selectedCrop.idealTemp}</span>
                </div>
                <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
                  <span class="text-gray-400 block text-[11px]">Water Requirement</span>
                  <span class="text-sm font-bold text-blue-300 font-mono">${selectedCrop.waterRequirement}</span>
                </div>
                <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
                  <span class="text-gray-400 block text-[11px]">Expected Yield</span>
                  <span class="text-sm font-bold text-teal-300 font-mono">${selectedCrop.expectedYield}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  `;
}

export function initCropRecommendationHooks(state, setState) {
  // Lucide Icons
  if (typeof lucide !== 'undefined' && lucide.createIcons) {
    lucide.createIcons();
  }

  // Tab switching
  const tabBtnPred = document.getElementById('tab-btn-prediction');
  const tabBtnCat = document.getElementById('tab-btn-catalog');
  if (tabBtnPred) {
    tabBtnPred.addEventListener('click', () => {
      setState({ cropRecTab: 'prediction' });
    });
  }
  if (tabBtnCat) {
    tabBtnCat.addEventListener('click', () => {
      setState({ cropRecTab: 'catalog' });
    });
  }

  // Helper to gather all form values reliably
  function readFormInputs() {
    const acres = parseFloat(document.getElementById('input-farm-acres')?.value) || 5;
    const season = document.getElementById('input-farm-season')?.value || 'Kharif';
    const irrigation = document.getElementById('input-farm-irrigation')?.value || 'Drip';
    const previousCrop = document.getElementById('input-farm-prev-crop')?.value || 'Fallow / None';

    const soilType = document.getElementById('input-soil-type')?.value || 'Medium Black Vertisol';
    const fertilityIndex = parseInt(document.getElementById('input-fertility-idx')?.value) || 75;
    const n = parseInt(document.getElementById('input-soil-n')?.value) || 220;
    const p = parseInt(document.getElementById('input-soil-p')?.value) || 40;
    const k = parseInt(document.getElementById('input-soil-k')?.value) || 160;
    const ph = parseFloat(document.getElementById('input-soil-ph')?.value) || 6.8;
    const oc = parseFloat(document.getElementById('input-soil-oc')?.value) || 0.6;

    const rainfall = parseInt(document.getElementById('input-climate-rain')?.value) || 600;
    const temp = parseInt(document.getElementById('input-climate-temp')?.value) || 26;
    const humidity = parseInt(document.getElementById('input-climate-hum')?.value) || 65;

    return {
      farm: { acres, season, irrigation, previousCrop },
      soil: { type: soilType, fertilityIndex, n, p, k, ph, oc, moisture: 38 },
      climate: { rainfall, temp, humidity }
    };
  }

  // Real-time Prediction Updater: Updates right container dynamically without page reload!
  function triggerRealtimePrediction() {
    const currentInputs = readFormInputs();
    const newPrediction = predictFarmerCropSelection(currentInputs);
    const container = document.getElementById('prediction-results-container');
    if (container) {
      container.innerHTML = renderPredictionResults(newPrediction, currentInputs);
      if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
      }
      // Dynamically re-simulate 3D Farm Digital Twin to match predicted crop & inputs
      initEmbedded3DFarmTwin(newPrediction, currentInputs);
    }
    // Update state in memory for persistence
    state.farmerPredictionInput = currentInputs;
    state.currentPrediction = newPrediction;
  }

  // Bind live real-time slider listeners (updates label + recalculates prediction instantaneously!)
  const bindLiveSlider = (sliderId, labelId, suffix = '') => {
    const slider = document.getElementById(sliderId);
    const label = document.getElementById(labelId);
    if (slider && label) {
      slider.addEventListener('input', (e) => {
        label.textContent = `${e.target.value}${suffix}`;
        triggerRealtimePrediction();
      });
    }
  };

  bindLiveSlider('input-fertility-idx', 'label-fertility-val', '/100');
  bindLiveSlider('input-soil-n', 'label-n-val', ' kg/ha');
  bindLiveSlider('input-soil-p', 'label-p-val', ' kg/ha');
  bindLiveSlider('input-soil-k', 'label-k-val', ' kg/ha');
  bindLiveSlider('input-soil-ph', 'label-ph-val', ' pH');
  bindLiveSlider('input-soil-oc', 'label-oc-val', '%');
  bindLiveSlider('input-climate-rain', 'label-rain-val', ' mm');
  bindLiveSlider('input-climate-temp', 'label-temp-val', '°C');
  bindLiveSlider('input-climate-hum', 'label-hum-val', '%');

  // Bind live dropdown and number input listeners
  const formElementsToWatch = [
    'input-farm-acres',
    'input-farm-season',
    'input-farm-irrigation',
    'input-farm-prev-crop',
    'input-soil-type'
  ];

  formElementsToWatch.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('change', () => {
        triggerRealtimePrediction();
      });
      el.addEventListener('input', () => {
        triggerRealtimePrediction();
      });
    }
  });

  // Preset Buttons (autofill form fields & recalculate immediately!)
  document.querySelectorAll('.preset-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const presetKey = e.currentTarget.getAttribute('data-preset');
      let preset = null;
      if (presetKey === 'activeFarm') {
        const af = state.activeFarm || {};
        const s = af.soil || {};
        preset = {
          farm: { acres: 5, season: 'Kharif', irrigation: af.irrigationType || 'Drip', previousCrop: 'Fallow / None' },
          soil: {
            type: af.soilType || 'Medium Black Vertisol',
            fertilityIndex: s.soilScore || 78,
            n: s.nitrogen || 240,
            p: s.phosphorus || 45,
            k: s.potassium || 180,
            ph: s.ph || 7.2,
            oc: 0.68,
            moisture: s.moisture || 40
          },
          climate: { rainfall: 650, temp: s.temperature || 28, humidity: s.humidity || 65 }
        };
      } else if (farmerPresets[presetKey]) {
        preset = JSON.parse(JSON.stringify(farmerPresets[presetKey]));
      }

      if (preset) {
        // Update all DOM inputs
        const setVal = (id, val) => { const el = document.getElementById(id); if (el) el.value = val; };
        const setTxt = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };

        setVal('input-farm-acres', preset.farm.acres);
        setVal('input-farm-season', preset.farm.season);
        setVal('input-farm-irrigation', preset.farm.irrigation);
        setVal('input-farm-prev-crop', preset.farm.previousCrop);

        setVal('input-soil-type', preset.soil.type);
        setVal('input-fertility-idx', preset.soil.fertilityIndex);
        setTxt('label-fertility-val', `${preset.soil.fertilityIndex}/100`);

        setVal('input-soil-n', preset.soil.n);
        setTxt('label-n-val', `${preset.soil.n} kg/ha`);

        setVal('input-soil-p', preset.soil.p);
        setTxt('label-p-val', `${preset.soil.p} kg/ha`);

        setVal('input-soil-k', preset.soil.k);
        setTxt('label-k-val', `${preset.soil.k} kg/ha`);

        setVal('input-soil-ph', preset.soil.ph);
        setTxt('label-ph-val', `${preset.soil.ph} pH`);

        setVal('input-soil-oc', preset.soil.oc);
        setTxt('label-oc-val', `${preset.soil.oc}%`);

        setVal('input-climate-rain', preset.climate.rainfall);
        setTxt('label-rain-val', `${preset.climate.rainfall} mm`);

        setVal('input-climate-temp', preset.climate.temp);
        setTxt('label-temp-val', `${preset.climate.temp}°C`);

        setVal('input-climate-hum', preset.climate.humidity);
        setTxt('label-hum-val', `${preset.climate.humidity}%`);

        triggerRealtimePrediction();
      }
    });
  });

  // "Run AI Crop Prediction" CTA Button (visual pulse + explicit recalculation)
  const btnRunPred = document.getElementById('btn-run-prediction');
  if (btnRunPred) {
    btnRunPred.addEventListener('click', () => {
      triggerRealtimePrediction();
      const heroCard = document.getElementById('hero-prediction-card');
      if (heroCard) {
        heroCard.classList.add('ring-4', 'ring-emerald-400');
        setTimeout(() => {
          heroCard.classList.remove('ring-4', 'ring-emerald-400');
        }, 600);
      }
    });
  }

  // Print Advisory Button
  const btnPrint = document.getElementById('btn-print-advisory');
  if (btnPrint) {
    btnPrint.addEventListener('click', () => {
      window.print();
    });
  }

  // Category filter buttons (Catalog tab)
  document.querySelectorAll('.crop-cat-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cat = e.currentTarget.getAttribute('data-crop-cat');
      setState({ cropCategoryFilter: cat });
    });
  });

  // Search input (Catalog tab)
  const searchInput = document.getElementById('crop-search-input');
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      setState({ cropSearchQuery: e.target.value });
    });
  }

  // Crop rec card selection (Catalog tab)
  document.querySelectorAll('.crop-rec-card').forEach(card => {
    card.addEventListener('click', (e) => {
      const cropId = e.currentTarget.getAttribute('data-crop-id');
      setState({ selectedCropId: cropId });
    });
  });

  // Automatically initialize the 3D Farm Digital Twin with the initial recommendation
  setTimeout(() => {
    const embeddedCanvas = document.getElementById('embedded-3d-farm-canvas');
    if (embeddedCanvas) {
      const currentInputs = readFormInputs();
      const currentPred = predictFarmerCropSelection(currentInputs);
      state.farmerPredictionInput = currentInputs;
      state.currentPrediction = currentPred;
      initEmbedded3DFarmTwin(currentPred, currentInputs);
    }
  }, 60);
}
