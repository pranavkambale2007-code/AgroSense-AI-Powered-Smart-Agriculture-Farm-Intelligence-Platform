import { expanded100Crops } from './expandedCropDatabase.js';

// All demo farms removed per user specification.
// Real agricultural farms are now dynamically plotted with 4 boundary points and registered by farmers.
export const demoFarms = [];

export const demoCropDatabase = expanded100Crops.map(c => ({
  id: c.id,
  name: c.name,
  category: c.category,
  season: c.season || "Kharif",
  suitabilityScore: c.suitabilityScore,
  idealSoilPh: c.idealSoilPh,
  idealTemp: c.idealTemp,
  waterRequirement: c.waterRequirement,
  growthDuration: c.growthDuration,
  marketPriceAvg: c.marketPriceAvg,
  expectedYield: c.expectedYield,
  profitPerHa: c.profitPerHa,
  soilPreference: c.soilPreference,
  npkDemand: c.npkDemand,
  diseaseVulnerability: c.keyPests || "Moderate (Scouted regularly)",
  whyFactors: {
    soil: "+28 (Soil profile match)",
    temp: "+22 (Optimal climate window)",
    rain: "+18 (Low moisture risk)",
    ph: "+14 (Nutrient bioavailability)",
    moisture: "+12 (Irrigation access)"
  }
}));

export const demoMandiPrices = [
  { crop: "Wheat", market: "Pune APMC", state: "Maharashtra", minPrice: 2150, maxPrice: 2380, modalPrice: 2275, trend: "+2.4%", date: "2026-09-05" },
  { crop: "Sugarcane", market: "Kolhapur Mandi", state: "Maharashtra", minPrice: 3200, maxPrice: 3550, modalPrice: 3400, trend: "+1.1%", date: "2026-09-05" },
  { crop: "Cotton", market: "Rajkot APMC", state: "Gujarat", minPrice: 6850, maxPrice: 7350, modalPrice: 7120, trend: "-0.8%", date: "2026-09-05" },
  { crop: "Soybean", market: "Latur Mandi", state: "Maharashtra", minPrice: 4400, maxPrice: 4750, modalPrice: 4620, trend: "+3.2%", date: "2026-09-05" },
  { crop: "Onion", market: "Lasalgaon APMC", state: "Maharashtra", minPrice: 1600, maxPrice: 2100, modalPrice: 1850, trend: "+5.6%", date: "2026-09-05" },
  { crop: "Gram (Chickpea)", market: "Ludhiana Mandi", state: "Punjab", minPrice: 5200, maxPrice: 5600, modalPrice: 5440, trend: "0.0%", date: "2026-09-05" }
];

export const sampleDiseaseCases = [
  {
    id: "disease-01",
    crop: "Wheat",
    diseaseName: "Wheat Leaf Rust (Puccinia triticina)",
    confidence: 94.2,
    severity: "Moderate",
    symptoms: [
      "Small oval orange-brown pustules on leaf surface",
      "Yellowing of surrounding leaf tissue",
      "Premature leaf drying during grain filling"
    ],
    recommendedActions: [
      "Consult local Krishi Vigyan Kendra (KVK) agronomist immediately",
      "If confirmed by expert, consider recommended foliar fungicide spray (Tebuconazole @ 1ml/L)",
      "Avoid excess nitrogenous top-dressing which exacerbates rust spread"
    ],
    isSample: true
  },
  {
    id: "disease-02",
    crop: "Cotton",
    diseaseName: "Angular Leaf Spot (Xanthomonas malvacearum)",
    confidence: 93.4,
    severity: "High",
    symptoms: [
      "Angular water-soaked spots bounded by leaf veins",
      "Lesions turn reddish-brown to black over time",
      "Premature defoliation and boll infection under humid conditions"
    ],
    recommendedActions: [
      "Improve air drainage by maintaining recommended plant spacing",
      "Spray copper oxychloride @ 3g/L + Streptocycline @ 100mg/L if infection spreads",
      "Avoid overhead sprinkler irrigation to prevent bacterial water-splash"
    ],
    isSample: true
  },
  {
    id: "disease-03",
    crop: "Tomato / Cotton",
    diseaseName: "Healthy Leaf (No Pathogen Detected)",
    confidence: 98.5,
    severity: "None",
    symptoms: [
      "Vibrant green leaf lamina",
      "No spots, pustules, or wilting detected",
      "Normal cell turgidity"
    ],
    recommendedActions: [
      "Maintain current irrigation and pest scouting schedule",
      "Re-screen if atmospheric humidity rises above 80% for >2 days"
    ],
    isSample: true
  }
];
