// AgroSense Universal Explainable AI (XAI) Recommendation Attribution Component

export function renderXAIExplanationCard(recommendation) {
  const xai = recommendation.xaiBreakdown;

  return `
    <div class="glass-card-accent p-6 space-y-5">
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-2.5">
          <div class="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-bold">
            <i data-lucide="brain-circuit" class="w-5 h-5"></i>
          </div>
          <div>
            <h3 class="text-base font-bold text-white">Explainable AI (XAI) Attribution</h3>
            <p class="text-xs text-amber-300 font-medium">Why is ${recommendation.name} recommended at ${recommendation.suitabilityScore}%?</p>
          </div>
        </div>
        <span class="prototype-badge">XAI MODEL ATTRIBUTION</span>
      </div>

      <!-- Feature Contribution Breakdown -->
      <div class="space-y-3.5">
        ${Object.keys(xai).map(key => {
          const item = xai[key];
          const pct = Math.round((item.score / item.max) * 100);
          return `
            <div class="space-y-1">
              <div class="flex justify-between text-xs font-semibold">
                <span class="text-gray-200">${item.label}</span>
                <span class="text-emerald-400 font-mono">+${item.score} pts (${pct}%)</span>
              </div>
              <div class="w-full h-2.5 rounded-full bg-gray-900 overflow-hidden border border-emerald-950">
                <div class="h-full bg-gradient-to-r from-emerald-500 to-lime-400 rounded-full" style="width: ${pct}%"></div>
              </div>
              <p class="text-[11px] text-gray-400">${item.detail}</p>
            </div>
          `;
        }).join('')}
      </div>

      <!-- AI Reason List -->
      <div class="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40 space-y-1.5">
        <h4 class="text-xs font-extrabold text-emerald-300 uppercase tracking-wider">Key Decision Drivers:</h4>
        <ul class="space-y-1 text-xs text-gray-300">
          ${recommendation.whyExplanation.map(exp => `
            <li class="flex items-start gap-2">
              <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"></i>
              <span>${exp}</span>
            </li>
          `).join('')}
        </ul>
      </div>
    </div>
  `;
}

/**
 * Renders a generic XAI Attribution Card for Soil, Irrigation, Weather, or Farm Health math
 */
export function renderGenericXAIExplanationCard(title, subtitle, formulaString, factorsList) {
  return `
    <div class="glass-card-accent p-6 space-y-4">
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-2.5">
          <div class="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-bold">
            <i data-lucide="brain-circuit" class="w-5 h-5"></i>
          </div>
          <div>
            <h3 class="text-base font-bold text-white">${title}</h3>
            <p class="text-xs text-amber-300 font-medium">${subtitle}</p>
          </div>
        </div>
        <span class="prototype-badge">MATHEMATICAL XAI MODEL</span>
      </div>

      <!-- Trigger Formula Box -->
      <div class="p-3 rounded-xl bg-gray-950/80 border border-emerald-900 font-mono text-xs text-emerald-300">
        <span class="text-[10px] text-gray-400 uppercase font-sans block mb-0.5">Scoring Formula Equation:</span>
        ${formulaString}
      </div>

      <!-- Factor Attribution List -->
      <div class="space-y-2 text-xs">
        <h4 class="text-xs font-bold text-gray-300 uppercase tracking-wider">Factor Contributions & Penalties:</h4>
        ${factorsList.map(item => `
          <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 flex items-center justify-between gap-3">
            <div>
              <span class="font-bold text-white block">${item.label}</span>
              <p class="text-[11px] text-gray-400">${item.note}</p>
            </div>
            <span class="font-mono font-bold text-emerald-400 text-sm shrink-0">${item.value}</span>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}
