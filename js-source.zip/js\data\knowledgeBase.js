// Verified Agricultural Knowledge Base for AgroSense RAG Integration
// Sources: ICAR, Krishi Vigyan Kendra (KVK), Indian Agricultural Research Institute (IARI), State Extension Services

export const knowledgeDocuments = [
  {
    id: "doc-01",
    title: "Nitrogen Management in Medium Black Soils for Wheat and Sugarcane",
    organization: "ICAR - Indian Institute of Soil Science, Bhopal",
    category: "Soil Science",
    status: "Verified",
    url: "https://iiss.icar.gov.in/soil-health-guidelines",
    content: "Medium black soils (Vertisols) in Maharashtra and Madhya Pradesh frequently exhibit Nitrogen deficits during the vegetative stage. Top-dressing with split application of Urea (40% basal, 30% first irrigation, 30% boot stage) enhances Nitrogen Use Efficiency (NUE) by up to 22% compared to single basal dose. Avoid excessive application during high moisture forecast to prevent leaching into groundwater.",
    keywords: ["Nitrogen", "Vertisol", "Wheat", "Urea", "Leaching", "NUE"]
  },
  {
    id: "doc-02",
    title: "Microclimate Management for Fall Armyworm and Blight Control in Maize & Wheat",
    organization: "Krishi Vigyan Kendra (KVK), Pune",
    category: "Pest & Disease Management",
    status: "Verified",
    url: "https://kvkpune.org/crop-protection-bulletin-2025",
    content: "When relative humidity exceeds 85% for more than 48 consecutive hours with temperatures between 24°C and 28°C, fungal spore germination (e.g. Leaf Rust & Blight) increases threefold. Farmers are advised to maintain canopy aeration, delay foliage overhead irrigation, and inspect leaf undersides for rust pustules. Biological control with Neem-based azadirachtin (10,000 ppm) at 3ml/L is recommended at early symptom detection.",
    keywords: ["Fungal Blight", "Humidity", "Spore", "Neem", "Biological Control", "KVK"]
  },
  {
    id: "doc-03",
    title: "Evapotranspiration-Based Drip Irrigation Scheduling for Cotton & Sugarcane",
    organization: "Mahatma Phule Krishi Vidyapeeth (MPKV), Rahuri",
    category: "Irrigation & Water Engineering",
    status: "Verified",
    url: "https://mpkv.ac.in/water-management-tech",
    content: "Crop Coefficient (Kc) for wheat varies from 0.4 (initial stage) to 1.15 (mid-season flowering stage). Irrigation scheduling based on daily ET0 calculation prevents both moisture stress during grain filling and waterlogging. Reducing drip pulse duration by 20% prior to forecasted heavy rainfall events (>15mm) saves energy and prevents root hypoxia.",
    keywords: ["ET0", "Crop Coefficient", "Drip Irrigation", "Waterlogging", "MPKV"]
  },
  {
    id: "doc-04",
    title: "Soil pH Remediation & Organic Carbon Enhancement Guidelines",
    organization: "National Centre of Organic Farming (NCOF), Ghaziabad",
    category: "Soil Health",
    status: "Verified",
    url: "https://ncof.dacnet.nic.in/organic-matter-guide",
    content: "Soil pH between 6.5 and 7.5 provides optimal bioavailability for primary NPK and secondary micronutrients (Zinc, Iron, Manganese). Soils with Organic Carbon < 0.5% benefit from incorporation of Farm Yard Manure (FYM) at 10 tonnes/hectare or green manuring with Sunn Hemp prior to sowing, raising CEC (Cation Exchange Capacity) within 2 crop cycles.",
    keywords: ["Soil pH", "Organic Carbon", "FYM", "Micronutrients", "Green Manure"]
  },
  {
    id: "doc-05",
    title: "APMC Mandi Price Volatility Mitigation Strategies for Smallholders",
    organization: "NABARD & Ministry of Agriculture & Farmers Welfare",
    category: "Market Intelligence",
    status: "Verified",
    url: "https://agmarknet.gov.in/price-trends-analysis",
    content: "Historical mandi price data across Western India shows peak wheat prices occurring between November and January, while harvest gluts in March-April depress prices by 12-18%. Utilizing e-NAM registered scientific warehouses for short-term storage permits farmers to access Negotiable Warehouse Receipts (NWR) financing while waiting for price recovery.",
    keywords: ["APMC Mandi", "e-NAM", "NWR Loans", "Price Volatility", "Storage"]
  }
];
