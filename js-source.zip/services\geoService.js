// AgroSense GIS & Geo-Spatial Boundary Service
// Precision Geodesic Calculations, Shoelace Area Formulas, and Farm Boundary Demarcation

/**
 * Calculates Haversine distance between two GPS coordinates in meters
 */
function haversineDistMeters(lat1, lon1, lat2, lon2) {
  const R = 6378137; // WGS84 Earth radius in meters
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * Calculates geodesic Shoelace area and perimeter for a closed polygon of GPS coordinates
 * @param {Array<[number, number]>} coords - Array of [lat, lng] pairs
 * @returns {{ sqMeters: number, acres: number, hectares: number, perimeterMeters: number }}
 */
function calculatePolygonArea(coords) {
  if (!coords || !Array.isArray(coords) || coords.length < 3) {
    return { sqMeters: 0, acres: 0, hectares: 0, perimeterMeters: 0 };
  }

  const R = 6378137;
  const rad = Math.PI / 180;
  const centerLat = coords.reduce((acc, c) => acc + c[0], 0) / coords.length;
  const cosLat = Math.cos(centerLat * rad);

  // Project spherical coords to local tangent plane in meters
  const xy = coords.map(c => [
    c[1] * rad * R * cosLat, // x (E-W meters)
    c[0] * rad * R           // y (N-S meters)
  ]);

  let area = 0;
  let perimeter = 0;

  for (let i = 0; i < coords.length; i++) {
    const j = (i + 1) % coords.length;
    area += xy[i][0] * xy[j][1] - xy[j][0] * xy[i][1];
    perimeter += haversineDistMeters(coords[i][0], coords[i][1], coords[j][0], coords[j][1]);
  }

  const sqMeters = Math.abs(area) / 2;
  const acres = sqMeters / 4046.8564224;
  const hectares = sqMeters / 10000;

  return {
    sqMeters: Math.round(sqMeters),
    acres: Number(acres.toFixed(2)),
    hectares: Number(hectares.toFixed(2)),
    perimeterMeters: Math.round(perimeter)
  };
}

/**
 * Computes geographic centroid for a list of coordinates
 * @param {Array<[number, number]>} coords 
 * @returns {{ lat: number, lng: number }}
 */
function calculateCentroid(coords) {
  if (!coords || !Array.isArray(coords) || coords.length === 0) {
    return { lat: 18.5204, lng: 73.8567 }; // Default fallback (Pune)
  }
  const sumLat = coords.reduce((acc, c) => acc + c[0], 0);
  const sumLng = coords.reduce((acc, c) => acc + c[1], 0);
  return {
    lat: Number((sumLat / coords.length).toFixed(6)),
    lng: Number((sumLng / coords.length).toFixed(6))
  };
}

/**
 * Calculates Cardinal Direction and Compass Bearing from center to a corner point
 * @param {number} centerLat 
 * @param {number} centerLng 
 * @param {number} ptLat 
 * @param {number} ptLng 
 * @returns {{ bearingDeg: number, label: string, shortLabel: string }}
 */
function getCardinalBearing(centerLat, centerLng, ptLat, ptLng) {
  const rad = Math.PI / 180;
  const y = Math.sin((ptLng - centerLng) * rad) * Math.cos(ptLat * rad);
  const x = Math.cos(centerLat * rad) * Math.sin(ptLat * rad) -
            Math.sin(centerLat * rad) * Math.cos(ptLat * rad) * Math.cos((ptLng - centerLng) * rad);
  let brng = (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
  
  const sectors = [
    { label: 'North', short: 'N' },
    { label: 'North-East', short: 'NE' },
    { label: 'East', short: 'E' },
    { label: 'South-East', short: 'SE' },
    { label: 'South', short: 'S' },
    { label: 'South-West', short: 'SW' },
    { label: 'West', short: 'W' },
    { label: 'North-West', short: 'NW' }
  ];
  
  const idx = Math.round(brng / 45) % 8;
  return {
    bearingDeg: Math.round(brng),
    label: sectors[idx].label,
    shortLabel: sectors[idx].short
  };
}

/**
 * Computes bounding box and extent limits (N, S, E, W)
 */
function calculateBoundingBox(coords) {
  if (!coords || coords.length === 0) return null;
  const lats = coords.map(c => c[0]);
  const lngs = coords.map(c => c[1]);
  const north = Math.max(...lats);
  const south = Math.min(...lats);
  const east = Math.max(...lngs);
  const west = Math.min(...lngs);
  return {
    north,
    south,
    east,
    west,
    maxLat: north,
    minLat: south,
    maxLng: east,
    minLng: west
  };
}

/**
 * Generates 4 realistic farm corner coordinates around a given center point
 * @param {number} centerLat 
 * @param {number} centerLng 
 * @param {number} targetAcres 
 * @returns {Array<[number, number]>} 4 corner coordinates [Point 1 NW, Point 2 NE, Point 3 SE, Point 4 SW]
 */
function generateDemoCorners(centerLat, centerLng, targetAcres = 6.0) {
  const sqMeters = targetAcres * 4046.8564224;
  const sideMeters = Math.sqrt(sqMeters);
  const halfM = sideMeters / 2;
  const rad = Math.PI / 180;
  const dLat = halfM / 111320;
  const dLng = halfM / (111320 * Math.cos(centerLat * rad));

  return [
    [Number((centerLat + dLat * 0.98).toFixed(6)), Number((centerLng - dLng * 1.02).toFixed(6))], // Point 1: NW
    [Number((centerLat + dLat * 1.04).toFixed(6)), Number((centerLng + dLng * 0.96).toFixed(6))], // Point 2: NE
    [Number((centerLat - dLat * 0.96).toFixed(6)), Number((centerLng + dLng * 1.04).toFixed(6))], // Point 3: SE
    [Number((centerLat - dLat * 1.02).toFixed(6)), Number((centerLng - dLng * 0.98).toFixed(6))]  // Point 4: SW
  ];
}

/**
 * Enriched Database of Major Indian Agricultural Centers, Talukas & Districts
 * Powers instant location recognition so farmers know exactly where their farm is located.
 */
const INDIAN_AGRI_PLACES = exports.INDIAN_AGRI_PLACES = [
  // Maharashtra
  { name: 'Haveli, Pune District, Maharashtra', taluka: 'Haveli', district: 'Pune', state: 'Maharashtra', pin: '411028', lat: 18.5204, lng: 73.8567, agroZone: 'Western Maharashtra Plain Zone' },
  { name: 'Baramati, Pune District, Maharashtra', taluka: 'Baramati', district: 'Pune', state: 'Maharashtra', pin: '413102', lat: 18.1519, lng: 74.5772, agroZone: 'Western Maharashtra Scarcity & Canal Zone' },
  { name: 'Shirur, Pune District, Maharashtra', taluka: 'Shirur', district: 'Pune', state: 'Maharashtra', pin: '412210', lat: 18.8258, lng: 74.3779, agroZone: 'Western Maharashtra Plain Zone' },
  { name: 'Junnar, Pune District, Maharashtra', taluka: 'Junnar', district: 'Pune', state: 'Maharashtra', pin: '410502', lat: 19.2069, lng: 73.8767, agroZone: 'Western Ghats Transition Zone' },
  { name: 'Dindori, Nashik District, Maharashtra', taluka: 'Dindori', district: 'Nashik', state: 'Maharashtra', pin: '422202', lat: 20.2014, lng: 73.8340, agroZone: 'Western Ghats Grape & Horticulture Zone' },
  { name: 'Niphad, Nashik District, Maharashtra', taluka: 'Niphad', district: 'Nashik', state: 'Maharashtra', pin: '422303', lat: 20.0833, lng: 74.1167, agroZone: 'Godavari Basin Onion & Grape Zone' },
  { name: 'Yeola, Nashik District, Maharashtra', taluka: 'Yeola', district: 'Nashik', state: 'Maharashtra', pin: '423401', lat: 20.0417, lng: 74.4833, agroZone: 'Nashik Scarcity Zone' },
  { name: 'Pandharpur, Solapur District, Maharashtra', taluka: 'Pandharpur', district: 'Solapur', state: 'Maharashtra', pin: '413304', lat: 17.6778, lng: 75.3248, agroZone: 'Bhima Basin Scarcity Zone' },
  { name: 'Mohol, Solapur District, Maharashtra', taluka: 'Mohol', district: 'Solapur', state: 'Maharashtra', pin: '413213', lat: 17.8184, lng: 75.6473, agroZone: 'Central Maharashtra Scarcity Zone' },
  { name: 'Karveer, Kolhapur District, Maharashtra', taluka: 'Karveer', district: 'Kolhapur', state: 'Maharashtra', pin: '416003', lat: 16.7050, lng: 74.2433, agroZone: 'Panchganga Basin High Rainfall Sub-Montane' },
  { name: 'Shirol, Kolhapur District, Maharashtra', taluka: 'Shirol', district: 'Kolhapur', state: 'Maharashtra', pin: '416103', lat: 16.7333, lng: 74.5833, agroZone: 'Krishna Basin Sugarcane Delta' },
  { name: 'Tasgaon, Sangli District, Maharashtra', taluka: 'Tasgaon', district: 'Sangli', state: 'Maharashtra', pin: '416312', lat: 17.0333, lng: 74.6000, agroZone: 'Sangli Grape & Turmeric Zone' },
  { name: 'Miraj, Sangli District, Maharashtra', taluka: 'Miraj', district: 'Sangli', state: 'Maharashtra', pin: '416410', lat: 16.8286, lng: 74.6475, agroZone: 'Krishna Basin Sugarcane & Vegetable Zone' },
  { name: 'Karad, Satara District, Maharashtra', taluka: 'Karad', district: 'Satara', state: 'Maharashtra', pin: '415110', lat: 17.2889, lng: 74.1844, agroZone: 'Koyna-Krishna Confluence Zone' },
  { name: 'Phaltan, Satara District, Maharashtra', taluka: 'Phaltan', district: 'Satara', state: 'Maharashtra', pin: '415523', lat: 17.9833, lng: 74.4333, agroZone: 'Nira Basin Sugarcane & Dairy Zone' },
  { name: 'Rahata (Shirdi), Ahmednagar District, Maharashtra', taluka: 'Rahata', district: 'Ahmednagar', state: 'Maharashtra', pin: '423107', lat: 19.7042, lng: 74.4842, agroZone: 'Pravara Basin Sugarcane & Guava Zone' },
  { name: 'Sangamner, Ahmednagar District, Maharashtra', taluka: 'Sangamner', district: 'Ahmednagar', state: 'Maharashtra', pin: '422605', lat: 19.5700, lng: 74.2100, agroZone: 'Western Ghats Foot-hills Scarcity Zone' },
  { name: 'Katol, Nagpur District, Maharashtra', taluka: 'Katol', district: 'Nagpur', state: 'Maharashtra', pin: '441302', lat: 21.2721, lng: 78.5833, agroZone: 'Vidarbha Citrus & Cotton Zone' },
  { name: 'Saoner, Nagpur District, Maharashtra', taluka: 'Saoner', district: 'Nagpur', state: 'Maharashtra', pin: '441107', lat: 21.3850, lng: 78.9189, agroZone: 'Kolar River Citrus Belt' },
  { name: 'Achalpur, Amravati District, Maharashtra', taluka: 'Achalpur', district: 'Amravati', state: 'Maharashtra', pin: '444806', lat: 21.2570, lng: 77.5085, agroZone: 'Satpura Foothills Cotton & Soybean Zone' },
  { name: 'Warud, Amravati District, Maharashtra', taluka: 'Warud', district: 'Amravati', state: 'Maharashtra', pin: '444906', lat: 21.4667, lng: 78.2667, agroZone: 'California of Vidarbha (Orange Belt)' },
  { name: 'Paithan, Chhatrapati Sambhaji Nagar, Maharashtra', taluka: 'Paithan', district: 'Chhatrapati Sambhaji Nagar', state: 'Maharashtra', pin: '431107', lat: 19.4833, lng: 75.3833, agroZone: 'Jayakwadi Canal Irrigation Basin' },
  { name: 'Raver, Jalgaon District, Maharashtra', taluka: 'Raver', district: 'Jalgaon', state: 'Maharashtra', pin: '425508', lat: 21.2500, lng: 76.0333, agroZone: 'Khandesh Banana Capital' },

  // Punjab & Haryana
  { name: 'Samrala, Ludhiana District, Punjab', taluka: 'Samrala', district: 'Ludhiana', state: 'Punjab', pin: '141114', lat: 30.8353, lng: 76.1917, agroZone: 'Central Plain Alluvial Wheat-Paddy Zone' },
  { name: 'Khanna, Ludhiana District, Punjab', taluka: 'Khanna', district: 'Ludhiana', state: 'Punjab', pin: '141401', lat: 30.7064, lng: 76.2206, agroZone: 'Asia Largest Grain Mandi Zone' },
  { name: 'Nakodar, Jalandhar District, Punjab', taluka: 'Nakodar', district: 'Jalandhar', state: 'Punjab', pin: '144040', lat: 31.1275, lng: 75.4744, agroZone: 'Bist Doab Alluvial Basin' },
  { name: 'Karnal Central, Karnal District, Haryana', taluka: 'Karnal', district: 'Karnal', state: 'Haryana', pin: '132001', lat: 29.6857, lng: 76.9905, agroZone: 'Indo-Gangetic Basmati Research Zone' },

  // Gujarat
  { name: 'Gondal, Rajkot District, Gujarat', taluka: 'Gondal', district: 'Rajkot', state: 'Gujarat', pin: '360311', lat: 21.9619, lng: 70.7997, agroZone: 'Saurashtra Groundnut & Cotton Delta' },
  { name: 'Jetpur, Rajkot District, Gujarat', taluka: 'Jetpur', district: 'Rajkot', state: 'Gujarat', pin: '360370', lat: 21.7583, lng: 70.7833, agroZone: 'Bhadar Basin Groundnut Belt' },
  { name: 'Keshod, Junagadh District, Gujarat', taluka: 'Keshod', district: 'Junagadh', state: 'Gujarat', pin: '362220', lat: 21.3000, lng: 70.2500, agroZone: 'South Saurashtra Coastal Agro Zone' },

  // Karnataka & South India
  { name: 'Srirangapatna, Mandya District, Karnataka', taluka: 'Srirangapatna', district: 'Mandya', state: 'Karnataka', pin: '571438', lat: 12.4181, lng: 76.6947, agroZone: 'Cauvery River Basin Sugarcane & Paddy Zone' },
  { name: 'Maddur, Mandya District, Karnataka', taluka: 'Maddur', district: 'Mandya', state: 'Karnataka', pin: '571428', lat: 12.5842, lng: 77.0456, agroZone: 'Shimsha Basin Tender Coconut & Paddy' },
  { name: 'Pollachi, Coimbatore District, Tamil Nadu', taluka: 'Pollachi', district: 'Coimbatore', state: 'Tamil Nadu', pin: '642001', lat: 10.6609, lng: 77.0048, agroZone: 'Western Agro-Climatic Coconut & Spices Zone' },
  { name: 'Sulur, Coimbatore District, Tamil Nadu', taluka: 'Sulur', district: 'Coimbatore', state: 'Tamil Nadu', pin: '641402', lat: 11.0267, lng: 77.1264, agroZone: 'Noyyal Basin Maize & Poultry Agro Zone' },
  { name: 'Tenali, Guntur District, Andhra Pradesh', taluka: 'Tenali', district: 'Guntur', state: 'Andhra Pradesh', pin: '522201', lat: 16.2431, lng: 80.6400, agroZone: 'Krishna Delta Chilli & Paddy Zone' },
  { name: 'Jangaon, Warangal District, Telangana', taluka: 'Jangaon', district: 'Warangal', state: 'Telangana', pin: '506167', lat: 17.7233, lng: 79.1833, agroZone: 'Central Telangana Red Soil Cotton & Maize Zone' },

  // Central & Eastern India
  { name: 'Sanwer, Indore District, Madhya Pradesh', taluka: 'Sanwer', district: 'Indore', state: 'Madhya Pradesh', pin: '453551', lat: 22.9772, lng: 75.8286, agroZone: 'Malwa Black Soil Soybean & Wheat Plateau' },
  { name: 'Pindra, Varanasi District, Uttar Pradesh', taluka: 'Pindra', district: 'Varanasi', state: 'Uttar Pradesh', pin: '221206', lat: 25.5342, lng: 82.8361, agroZone: 'Eastern Indo-Gangetic Alluvial Plain' },
  { name: 'Kalna, Purba Bardhaman, West Bengal', taluka: 'Kalna', district: 'Purba Bardhaman', state: 'West Bengal', pin: '713409', lat: 23.2167, lng: 88.3667, agroZone: 'Gangetic Alluvial Rice Bowl of Bengal' }
];

const AGRICULTURAL_DISTRICT_HUBS = exports.AGRICULTURAL_DISTRICT_HUBS = [
  { id: 'pune', name: 'Pune (Haveli / Baramati), Maharashtra', lat: 18.5204, lng: 73.8567, defaultCrop: 'Wheat (HD-2967)', defaultSoil: 'Medium Black Vertisol' },
  { id: 'nashik', name: 'Nashik (Dindori / Niphad), Maharashtra', lat: 20.0059, lng: 73.7898, defaultCrop: 'Onion & Wheat', defaultSoil: 'Red Clay Loam' },
  { id: 'solapur', name: 'Solapur (Pandharpur / Mohol), Maharashtra', lat: 17.6599, lng: 75.3242, defaultCrop: 'Jowar (Sorghum) & Sugarcane', defaultSoil: 'Medium Black Vertisol' },
  { id: 'nagpur', name: 'Nagpur (Katol / Saoner), Maharashtra', lat: 21.1458, lng: 79.0882, defaultCrop: 'Soybean & Cotton', defaultSoil: 'Black Cotton Soil' },
  { id: 'ludhiana', name: 'Ludhiana (Samrala / Khanna), Punjab', lat: 30.9010, lng: 75.8573, defaultCrop: 'Wheat & Basmati Paddy', defaultSoil: 'Alluvial Loam' },
  { id: 'mandya', name: 'Mandya (Cauvery Basin), Karnataka', lat: 12.5218, lng: 76.8951, defaultCrop: 'Sugarcane & Paddy', defaultSoil: 'Red Sandy Loam' },
  { id: 'rajkot', name: 'Rajkot (Gondal / Jetpur), Gujarat', lat: 22.3039, lng: 70.8022, defaultCrop: 'Groundnut & Cotton', defaultSoil: 'Medium Black Vertisol' },
  { id: 'coimbatore', name: 'Coimbatore (Pollachi / Sulur), Tamil Nadu', lat: 11.0168, lng: 76.9558, defaultCrop: 'Maize & Coconut', defaultSoil: 'Red Loam' }
];

/**
 * Finds the nearest known agricultural center and administrative region from GPS coordinates
 * Gives the farmer exact clarity on WHERE their farm is located!
 * @param {number} lat 
 * @param {number} lng 
 */
function findNearestAgriPlace(lat, lng) {
  if (typeof lat !== 'number' || typeof lng !== 'number' || isNaN(lat) || isNaN(lng)) {
    return INDIAN_AGRI_PLACES[0];
  }

  let nearest = INDIAN_AGRI_PLACES[0];
  let minDistanceMeters = Infinity;

  for (const place of INDIAN_AGRI_PLACES) {
    const dist = haversineDistMeters(lat, lng, place.lat, place.lng);
    if (dist < minDistanceMeters) {
      minDistanceMeters = dist;
      nearest = place;
    }
  }

  const distanceKm = Number((minDistanceMeters / 1000).toFixed(1));

  return {
    ...nearest,
    distanceKm,
    formattedLocation: `${nearest.taluka}, ${nearest.district} District, ${nearest.state}`,
    fullSummary: `${nearest.taluka}, ${nearest.district} (${nearest.state}) — PIN ${nearest.pin} [${distanceKm} km from ${nearest.taluka} Center]`
  };
}

/**
 * Searches local Indian agricultural places by keyword or PIN code
 * @param {string} query 
 */
function searchAgriPlaces(query) {
  if (!query || typeof query !== 'string') return [];
  const q = query.toLowerCase().trim();

  return INDIAN_AGRI_PLACES.filter(p =>
    p.name.toLowerCase().includes(q) ||
    p.taluka.toLowerCase().includes(q) ||
    p.district.toLowerCase().includes(q) ||
    p.state.toLowerCase().includes(q) ||
    p.pin.includes(q)
  );
}

/**
 * External Satellite & GIS Map Links
 */
function getGoogleMapsUrl(lat, lng) {
  return `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
}

function getGoogleSatelliteUrl(lat, lng) {
  return `https://www.google.com/maps/@${lat},${lng},17z/data=!3m1!1e3`;
}

function getBhuvanUrl(lat, lng) {
  return `https://bhuvan-app1.nrsc.gov.in/bhuvan2d/bhuvan/bhuvan2d.php?lat=${lat}&lon=${lng}&zoom=16`;
}

/**
 * Safe Empty Farm Template for when zero farms are registered
 */
const emptyFarmTemplate = exports.emptyFarmTemplate = {
  id: 'unregistered',
  name: 'No Farm Registered',
  farmerName: '',
  location: 'No GPS Location Demarcated',
  geoCoords: { lat: 18.5204, lng: 73.8567 },
  boundaryPolygon: [],
  sizeAcres: 0,
  soilType: 'Medium Black Vertisol',
  irrigationType: 'Drip Irrigation & Borewell',
  currentCrop: 'None',
  previousCrop: 'None',
  sowingDate: new Date().toISOString().split('T')[0],
  expectedHarvest: new Date().toISOString().split('T')[0],
  healthScore: 0,
  waterStatus: 'Pending Registration',
  diseaseRisk: 'None',
  weatherRisk: 'None',
  soil: {
    nitrogen: 180,
    phosphorus: 35,
    potassium: 280,
    ph: 7.0,
    temperature: 25.0,
    humidity: 60,
    moisture: 30.0,
    organicCarbon: 0.55,
    electricalConductivity: 0.65,
    soilScore: 75
  },
  weatherCurrent: {
    temp: 26.0,
    condition: 'Sunny',
    humidity: 60,
    windSpeed: 10,
    rainProb: 0,
    uvIndex: 5,
    icon: 'sun'
  }
};

/**
 * Creates a calibrated realistic Farm Profile object with full agronomic, IoT, and GIS attributes
 */
function createRealisticFarmProfile({
  id = null,
  farmerName = 'Farmer',
  farmName = 'My Agricultural Plot',
  location = 'Pune District, Maharashtra',
  crop = 'Wheat',
  soilType = 'Medium Black Vertisol',
  irrigationType = 'Drip Irrigation & Borewell',
  sizeAcres = 6.0,
  boundaryPolygon = [],
  sowingDate = null,
  expectedHarvest = null
}) {
  const farmId = id || `farm-${Date.now()}`;
  const centroid = calculateCentroid(boundaryPolygon);
  const now = new Date();
  
  const sowDateStr = sowingDate || new Date(now.getTime() - 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const harvestDateStr = expectedHarvest || new Date(now.getTime() + 75 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  // Resolve location details from centroid
  const nearestPlace = findNearestAgriPlace(centroid.lat, centroid.lng);
  const detectedLocation = location && location.trim().length > 3 ? location : nearestPlace.formattedLocation;

  // Calibrate baseline soil chemistry according to soil type
  let soilProfile = {
    nitrogen: 195,
    phosphorus: 38,
    potassium: 310,
    ph: 7.2,
    temperature: 24.8,
    humidity: 65,
    moisture: 31.5,
    organicCarbon: 0.62,
    electricalConductivity: 0.78,
    soilScore: 82
  };

  if (soilType.includes('Red')) {
    soilProfile = {
      nitrogen: 215,
      phosphorus: 45,
      potassium: 280,
      ph: 6.6,
      temperature: 25.5,
      humidity: 62,
      moisture: 26.0,
      organicCarbon: 0.55,
      electricalConductivity: 0.65,
      soilScore: 79
    };
  } else if (soilType.includes('Alluvial')) {
    soilProfile = {
      nitrogen: 230,
      phosphorus: 52,
      potassium: 295,
      ph: 7.4,
      temperature: 23.9,
      humidity: 70,
      moisture: 34.0,
      organicCarbon: 0.75,
      electricalConductivity: 0.82,
      soilScore: 86
    };
  } else if (soilType.includes('Sandy')) {
    soilProfile = {
      nitrogen: 160,
      phosphorus: 28,
      potassium: 220,
      ph: 6.8,
      temperature: 27.0,
      humidity: 55,
      moisture: 18.5,
      organicCarbon: 0.42,
      electricalConductivity: 0.50,
      soilScore: 71
    };
  }

  return {
    id: farmId,
    name: farmName,
    farmerName: farmerName,
    location: detectedLocation,
    taluka: nearestPlace.taluka,
    district: nearestPlace.district,
    state: nearestPlace.state,
    pin: nearestPlace.pin,
    agroZone: nearestPlace.agroZone,
    geoCoords: centroid,
    boundaryPolygon: boundaryPolygon,
    sizeAcres: Number(sizeAcres) || 6.0,
    soilType: soilType,
    irrigationType: irrigationType,
    currentCrop: crop,
    previousCrop: 'Fallow / Green Manure',
    sowingDate: sowDateStr,
    expectedHarvest: harvestDateStr,
    healthScore: 84,
    waterStatus: 'Optimal',
    diseaseRisk: 'Low',
    weatherRisk: 'Low',
    soil: soilProfile,
    weatherCurrent: {
      temp: 26.5,
      condition: 'Clear Sky / Sunny',
      humidity: 62,
      windSpeed: 10.5,
      rainProb: 10,
      uvIndex: 6,
      icon: 'sun'
    }
  };
}

/* Module Exports */
exports.haversineDistMeters = haversineDistMeters; exports.calculatePolygonArea = calculatePolygonArea; exports.calculateCentroid = calculateCentroid; exports.getCardinalBearing = getCardinalBearing; exports.calculateBoundingBox = calculateBoundingBox; exports.generateDemoCorners = generateDemoCorners; exports.findNearestAgriPlace = findNearestAgriPlace; exports.searchAgriPlaces = searchAgriPlaces; exports.getGoogleMapsUrl = getGoogleMapsUrl; exports.getGoogleSatelliteUrl = getGoogleSatelliteUrl; exports.getBhuvanUrl = getBhuvanUrl; exports.createRealisticFarmProfile = createRealisticFarmProfile;
