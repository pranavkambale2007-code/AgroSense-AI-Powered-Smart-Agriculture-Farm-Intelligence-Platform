// AgroSense Farmer Onboarding & 4-Point Farm Boundary Drawer Component
// Interactive GIS Map Studio for Demarcating Farm Area Corners & Pinpointing Farm Location

import { translations } from '../data/translations.js';
import {
  calculatePolygonArea,
  calculateCentroid,
  calculateBoundingBox,
  getCardinalBearing,
  generateDemoCorners,
  createRealisticFarmProfile,
  findNearestAgriPlace,
  searchAgriPlaces,
  getGoogleSatelliteUrl,
  INDIAN_AGRI_PLACES,
  AGRICULTURAL_DISTRICT_HUBS
} from '../services/geoService.js';

export function renderOnboardingPage(state) {
  const t = translations[state.lang] || translations.en;
  const currentFarm = state.activeFarm || {};
  const initialLat = currentFarm.geoCoords?.lat || 18.5204;
  const initialLng = currentFarm.geoCoords?.lng || 73.8567;
  const initialPlace = findNearestAgriPlace(initialLat, initialLng);

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Top Header & Breadcrumb -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="map-pin" class="w-6 h-6 text-emerald-400"></i>
            Plot 4 Boundary Points & Locate Your Farm
          </h1>
          <p class="text-xs text-gray-400">
            Search your village or use GPS, switch to satellite view, and plot 4 corner points to establish your exact farm boundary and geographic location.
          </p>
        </div>
        <div class="flex items-center gap-2">
          <span class="prototype-badge flex items-center gap-1.5">
            <i data-lucide="satellite" class="w-3.5 h-3.5 text-amber-400"></i>
            SATELLITE GIS & LOCATION DETECTOR
          </span>
        </div>
      </div>

      <!-- Main Form -->
      <form id="onboarding-farm-form" class="space-y-6">

        <!-- Grid: 2 Columns on desktop (Left: Info Inputs & Location Summary, Right: Map Demarcation Studio) -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">

          <!-- Left Column (5 cols): Farm & Crop Profile + Location Details -->
          <div class="lg:col-span-5 space-y-4">

            <!-- Section 1: Farmer & Farm Info -->
            <div class="glass-card p-5 space-y-4">
              <div class="flex items-center justify-between border-b border-emerald-900/40 pb-2">
                <h3 class="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                  <i data-lucide="user" class="w-4 h-4 text-emerald-400"></i>
                  1. Farmer & Farm Identification
                </h3>
                <span class="text-[10px] text-emerald-400/80 font-mono">Profile</span>
              </div>

              <div class="space-y-3">
                <div>
                  <label class="block text-xs font-semibold text-gray-300 mb-1">Farmer Full Name *</label>
                  <input type="text" id="ob-farmer-name" name="farmerName" value="${currentFarm.farmerName && currentFarm.id !== 'unregistered' ? currentFarm.farmerName : ''}" required class="w-full bg-gray-900/90 border border-emerald-700/50 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400 transition" placeholder="e.g. Ramesh Patil" />
                </div>

                <div>
                  <label class="block text-xs font-semibold text-gray-300 mb-1">Farm Name / Plot Identifier *</label>
                  <input type="text" id="ob-farm-name" name="farmName" value="${currentFarm.name && currentFarm.id !== 'unregistered' ? currentFarm.name : ''}" required class="w-full bg-gray-900/90 border border-emerald-700/50 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400 transition" placeholder="e.g. My Agricultural Plot - Field 01" />
                </div>

                <div>
                  <div class="flex items-center justify-between mb-1">
                    <label class="block text-xs font-semibold text-gray-300">District & Region Location *</label>
                    <button type="button" id="btn-use-detected-loc" class="text-[10px] text-emerald-400 hover:underline flex items-center gap-1">
                      <i data-lucide="check" class="w-3 h-3"></i> Sync with Map
                    </button>
                  </div>
                  <input type="text" id="ob-location" name="location" value="${currentFarm.location && currentFarm.id !== 'unregistered' ? currentFarm.location : initialPlace.formattedLocation}" required class="w-full bg-gray-900/90 border border-emerald-700/50 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400 transition" placeholder="e.g. Haveli, Pune District, Maharashtra" />
                </div>
              </div>
            </div>

            <!-- "Where is My Farm Located?" Live Location Card -->
            <div id="farm-location-intel-card" class="glass-card p-5 space-y-3 border border-emerald-500/30 bg-emerald-950/20">
              <div class="flex items-center justify-between border-b border-emerald-900/40 pb-2">
                <span class="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                  <i data-lucide="compass" class="w-4 h-4 text-emerald-400"></i>
                  Where is My Farm Located?
                </span>
                <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">Live GPS</span>
              </div>

              <div class="space-y-2 text-xs">
                <div>
                  <span class="text-gray-400 text-[11px] block">Detected Agricultural Village / Taluka:</span>
                  <span id="loc-detected-name" class="text-white font-bold text-xs sm:text-sm block">
                    ${initialPlace.formattedLocation}
                  </span>
                </div>

                <div class="grid grid-cols-2 gap-2 pt-1">
                  <div class="p-2 rounded-lg bg-gray-900/70 border border-gray-800">
                    <span class="text-[10px] text-gray-400 block">Agro-Climatic Zone</span>
                    <span id="loc-detected-zone" class="text-emerald-300 font-semibold text-[11px] block leading-tight">
                      ${initialPlace.agroZone}
                    </span>
                  </div>
                  <div class="p-2 rounded-lg bg-gray-900/70 border border-gray-800">
                    <span class="text-[10px] text-gray-400 block">Postal PIN Code</span>
                    <span id="loc-detected-pin" class="text-amber-300 font-mono font-bold text-xs block">
                      PIN: ${initialPlace.pin}
                    </span>
                  </div>
                </div>

                <div class="p-2 rounded-lg bg-gray-900/70 border border-gray-800 flex items-center justify-between">
                  <span class="text-[11px] text-gray-400">Centroid Coordinates:</span>
                  <span id="loc-detected-coords" class="font-mono text-emerald-400 text-[11px] font-bold">
                    ${initialLat.toFixed(5)}° N, ${initialLng.toFixed(5)}° E
                  </span>
                </div>

                <div class="pt-1 flex items-center justify-between">
                  <span id="loc-nearest-hub-distance" class="text-[10px] text-gray-400">
                    ${initialPlace.distanceKm} km from ${initialPlace.taluka} Taluka HQ
                  </span>
                  <a id="loc-gmaps-link" href="${getGoogleSatelliteUrl(initialLat, initialLng)}" target="_blank" class="text-xs text-sky-400 hover:text-sky-300 hover:underline flex items-center gap-1 font-semibold">
                    <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
                    <span>Verify on Google Satellite ↗</span>
                  </a>
                </div>
              </div>
            </div>

            <!-- Section 2: Soil & Irrigation Parameters -->
            <div class="glass-card p-5 space-y-4">
              <div class="flex items-center justify-between border-b border-emerald-900/40 pb-2">
                <h3 class="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                  <i data-lucide="layers" class="w-4 h-4 text-emerald-400"></i>
                  2. Soil & Irrigation Setup
                </h3>
                <span class="text-[10px] text-emerald-400/80 font-mono">Agronomic</span>
              </div>

              <div class="space-y-3">
                <div>
                  <label class="block text-xs font-semibold text-gray-300 mb-1">Primary Soil Type *</label>
                  <select id="ob-soil-type" name="soilType" class="w-full bg-gray-900/90 border border-emerald-700/50 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400 transition">
                    <option value="Medium Black Vertisol" ${currentFarm.soilType === 'Medium Black Vertisol' ? 'selected' : ''}>Medium Black Vertisol</option>
                    <option value="Black Cotton Soil" ${currentFarm.soilType === 'Black Cotton Soil' ? 'selected' : ''}>Black Cotton Soil (Regur)</option>
                    <option value="Red Clay Loam" ${currentFarm.soilType === 'Red Clay Loam' ? 'selected' : ''}>Red Clay Loam</option>
                    <option value="Alluvial Loam" ${currentFarm.soilType === 'Alluvial Loam' ? 'selected' : ''}>Alluvial Loam</option>
                    <option value="Sandy Loam" ${currentFarm.soilType === 'Sandy Loam' ? 'selected' : ''}>Sandy Loam</option>
                    <option value="Laterite Soil" ${currentFarm.soilType === 'Laterite Soil' ? 'selected' : ''}>Laterite Soil</option>
                  </select>
                </div>

                <div>
                  <label class="block text-xs font-semibold text-gray-300 mb-1">Irrigation Method *</label>
                  <select id="ob-irrigation-type" name="irrigationType" class="w-full bg-gray-900/90 border border-emerald-700/50 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-400 transition">
                    <option value="Drip Irrigation & Borewell" selected>Drip Irrigation & Borewell</option>
                    <option value="Micro Sprinkler System">Micro Sprinkler System</option>
                    <option value="Canal & Tube Well Irrigation">Canal & Tube Well Irrigation</option>
                    <option value="Rainfed (No Artificial Irrigation)">Rainfed (No Artificial Irrigation)</option>
                  </select>
                </div>
              </div>
            </div>

            <!-- Section 3: Current Crop Cycle -->
            <div class="glass-card p-5 space-y-4">
              <div class="flex items-center justify-between border-b border-emerald-900/40 pb-2">
                <h3 class="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                  <i data-lucide="sprout" class="w-4 h-4 text-emerald-400"></i>
                  3. Current Crop Cycle
                </h3>
                <span class="text-[10px] text-emerald-400/80 font-mono">Season</span>
              </div>

              <div class="space-y-3">
                <div>
                  <label class="block text-xs font-semibold text-gray-300 mb-1">Current Crop Variety *</label>
                  <input type="text" id="ob-crop-name" name="currentCrop" value="${currentFarm.currentCrop && currentFarm.id !== 'unregistered' && currentFarm.currentCrop !== 'None' ? currentFarm.currentCrop : ''}" list="common-crops-list" required class="w-full bg-gray-900/90 border border-emerald-700/50 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-emerald-400 transition" placeholder="e.g. Wheat (HD-2967) or Tomato" />
                  <datalist id="common-crops-list">
                    <option value="Wheat (HD-2967)">
                    <option value="Tomato (Arka Rakshak)">
                    <option value="Maize (DHM-117)">
                    <option value="Chilli (G-4 / Sitara)">
                    <option value="Rice (Basmati PB-1121)">
                    <option value="Cotton (Bt-II BG-II)">
                    <option value="Potato (Kufri Jyoti)">
                    <option value="Mustard (Pusa Bold)">
                    <option value="Groundnut (TAG-24)">
                    <option value="Sugarcane (Co-86032)">
                    <option value="Soybean (JS-335)">
                    <option value="Chickpea / Gram (JG-11)">
                  </datalist>
                </div>

                <div class="grid grid-cols-2 gap-3">
                  <div>
                    <label class="block text-xs font-semibold text-gray-300 mb-1">Sowing Date *</label>
                    <input type="date" id="ob-sowing-date" name="sowingDate" value="${currentFarm.sowingDate || '2026-11-15'}" required class="w-full bg-gray-900/90 border border-emerald-700/50 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400 transition" />
                  </div>
                  <div>
                    <label class="block text-xs font-semibold text-gray-300 mb-1">Expected Harvest *</label>
                    <input type="date" id="ob-harvest-date" name="expectedHarvest" value="${currentFarm.expectedHarvest || '2027-03-20'}" required class="w-full bg-gray-900/90 border border-emerald-700/50 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400 transition" />
                  </div>
                </div>

                <div>
                  <label class="block text-xs font-semibold text-gray-300 mb-1">
                    Calculated Farm Size (Acres) * 
                    <span class="text-[10px] text-emerald-400 font-normal">(Auto-calculated when 4 points are plotted)</span>
                  </label>
                  <input type="number" step="0.01" min="0.1" id="ob-farm-size-acres" name="sizeAcres" value="${currentFarm.sizeAcres && currentFarm.id !== 'unregistered' && currentFarm.sizeAcres > 0 ? currentFarm.sizeAcres : ''}" required class="w-full bg-gray-900/90 border border-emerald-500/50 rounded-xl px-3.5 py-2.5 text-xs text-emerald-300 font-bold focus:outline-none focus:border-emerald-400 transition" placeholder="0.00" />
                </div>
              </div>
            </div>

          </div>

          <!-- Right Column (7 cols): Interactive 4-Point GIS Map Studio -->
          <div class="lg:col-span-7 space-y-4">

            <div class="glass-card p-5 space-y-4 border-2 border-emerald-600/40 shadow-xl shadow-emerald-950/60">
              
              <!-- Location Search & Teleport Bar -->
              <div class="space-y-2 border-b border-emerald-900/50 pb-3">
                <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <div class="relative flex-1">
                    <i data-lucide="search" class="w-4 h-4 text-emerald-400 absolute left-3 top-2.5"></i>
                    <input type="text" id="map-location-search" list="places-quick-suggestions" placeholder="Search your village, taluka, district or PIN code..." class="w-full bg-gray-900/90 border border-emerald-700/60 rounded-xl pl-9 pr-3.5 py-2 text-xs text-white placeholder-gray-400 focus:outline-none focus:border-emerald-400 transition" />
                    <datalist id="places-quick-suggestions">
                      ${INDIAN_AGRI_PLACES.slice(0, 20).map(p => `
                        <option value="${p.taluka}, ${p.district}">${p.state} • PIN: ${p.pin}</option>
                      `).join('')}
                    </datalist>
                  </div>
                  <button type="button" id="btn-search-location" class="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shrink-0">
                    <i data-lucide="search" class="w-3.5 h-3.5"></i>
                    <span>Find Location</span>
                  </button>
                </div>
                <div class="flex items-center justify-between text-[11px] text-gray-400">
                  <span>💡 Tip: Type your village name or click <b>"My GPS"</b> to jump right to your farm.</span>
                  <span id="search-feedback-msg" class="text-emerald-400 font-medium hidden"></span>
                </div>
              </div>

              <!-- Map Studio Header -->
              <div class="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 class="text-sm font-bold text-white flex items-center gap-2">
                    <i data-lucide="crosshair" class="w-4 h-4 text-emerald-400 animate-pulse"></i>
                    Plot 4 Farm Corners on Map
                  </h3>
                  <p class="text-[11px] text-gray-400">Click 4 points on the map: Corner 1 (NW) → 2 (NE) → 3 (SE) → 4 (SW)</p>
                </div>

                <!-- Points Counter Badge -->
                <div id="points-counter-badge" class="px-3.5 py-1.5 rounded-full bg-gray-800 text-gray-300 text-xs font-bold border border-gray-700 flex items-center gap-1.5 transition-all">
                  <span class="w-2 h-2 rounded-full bg-gray-400"></span>
                  <span id="points-counter-text">0 / 4 Points Plotted</span>
                </div>
              </div>

              <!-- Interactive Guidance Message Banner -->
              <div id="points-guidance-banner" class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-700/40 flex items-center gap-2.5 text-xs text-emerald-200">
                <i data-lucide="info" class="w-4 h-4 text-emerald-400 shrink-0"></i>
                <span id="points-guide-message">
                  👉 Click on the map to set <b>Corner Point 1 (North-West)</b> of your farm.
                </span>
              </div>

              <!-- Map Toolbar: Satellite Toggle & Actions -->
              <div class="flex flex-wrap items-center justify-between gap-2 text-xs">
                
                <!-- Satellite / Street Map Toggle -->
                <div class="flex items-center gap-1 bg-gray-900 p-1 rounded-xl border border-emerald-800/50">
                  <button type="button" id="btn-toggle-satellite" class="px-2.5 py-1 rounded-lg bg-emerald-700/60 text-emerald-200 font-bold text-xs flex items-center gap-1 transition" title="Switch to Satellite Aerial Imagery">
                    <i data-lucide="satellite" class="w-3.5 h-3.5 text-emerald-300"></i>
                    <span>Satellite</span>
                  </button>
                  <button type="button" id="btn-toggle-street" class="px-2.5 py-1 rounded-lg text-gray-400 hover:text-white font-semibold text-xs flex items-center gap-1 transition" title="Switch to Street Map">
                    <i data-lucide="map" class="w-3.5 h-3.5"></i>
                    <span>Street</span>
                  </button>
                </div>

                <!-- Action Buttons -->
                <div class="flex items-center gap-1.5">
                  <button type="button" id="btn-locate-gps" class="px-2.5 py-1.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/50 text-emerald-300 font-semibold text-xs transition flex items-center gap-1.5" title="Center map at your browser GPS location">
                    <i data-lucide="navigation" class="w-3.5 h-3.5"></i>
                    <span>My GPS</span>
                  </button>

                  <button type="button" id="btn-auto-plot-demo" class="px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500/20 to-emerald-500/20 hover:from-amber-500/30 hover:to-emerald-500/30 border border-amber-500/40 text-amber-300 font-semibold text-xs transition flex items-center gap-1.5 shadow-sm" title="Automatically plot 4 demo corner points around current map center">
                    <i data-lucide="sparkles" class="w-3.5 h-3.5 text-amber-400"></i>
                    <span>Auto-Plot 4 Corners</span>
                  </button>

                  <button type="button" id="btn-reset-points" class="px-2.5 py-1.5 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 border border-rose-700/40 text-rose-300 font-semibold text-xs transition flex items-center gap-1.5" title="Clear all plotted points and start again">
                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                    <span>Reset</span>
                  </button>
                </div>
              </div>

              <!-- Leaflet Map Container -->
              <div id="onboarding-plot-map" class="onboarding-map-wrapper z-10 cursor-crosshair"></div>

              <!-- Real-time Area & Perimeter Display (Active once 4 points placed) -->
              <div id="plot-area-stats-container" class="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                <div class="p-2.5 rounded-xl bg-emerald-950/50 border border-emerald-800/50 text-center">
                  <span class="text-[10px] font-semibold text-gray-400 uppercase tracking-wider block">Farm Area</span>
                  <span id="stat-acres" class="text-base font-extrabold text-emerald-300">-- Acres</span>
                </div>
                <div class="p-2.5 rounded-xl bg-emerald-950/50 border border-emerald-800/50 text-center">
                  <span class="text-[10px] font-semibold text-gray-400 uppercase tracking-wider block">Metric Area</span>
                  <span id="stat-hectares" class="text-base font-extrabold text-teal-300">-- Ha</span>
                </div>
                <div class="p-2.5 rounded-xl bg-emerald-950/50 border border-emerald-800/50 text-center">
                  <span class="text-[10px] font-semibold text-gray-400 uppercase tracking-wider block">Square Meters</span>
                  <span id="stat-sqmeters" class="text-base font-extrabold text-sky-300">-- m²</span>
                </div>
                <div class="p-2.5 rounded-xl bg-emerald-950/50 border border-emerald-800/50 text-center">
                  <span class="text-[10px] font-semibold text-gray-400 uppercase tracking-wider block">Perimeter</span>
                  <span id="stat-perimeter" class="text-base font-extrabold text-amber-300">-- m</span>
                </div>
              </div>

              <!-- 4 Plotted Corner Points Coordinates Table with Cardinal Directions -->
              <div class="space-y-2 pt-2 border-t border-emerald-900/40">
                <div class="flex items-center justify-between text-xs font-semibold text-gray-300">
                  <span class="flex items-center gap-1.5">
                    <i data-lucide="compass" class="w-4 h-4 text-emerald-400"></i>
                    Plotted 4 Corner Cardinal Positions
                  </span>
                  <span id="coords-status-label" class="text-[11px] text-gray-400">Click map to plot 4 corners...</span>
                </div>

                <div id="corner-coords-grid" class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div id="coord-card-1" class="p-2.5 rounded-lg bg-gray-900/60 border border-gray-800 flex items-center justify-between">
                    <span class="flex items-center gap-2 text-gray-400">
                      <span class="w-5 h-5 rounded-full bg-gray-800 text-gray-400 text-[10px] font-bold flex items-center justify-center">1</span>
                      <span>Corner 1 (NW)</span>
                    </span>
                    <span class="font-mono text-[11px] text-gray-500">Not Plotted</span>
                  </div>

                  <div id="coord-card-2" class="p-2.5 rounded-lg bg-gray-900/60 border border-gray-800 flex items-center justify-between">
                    <span class="flex items-center gap-2 text-gray-400">
                      <span class="w-5 h-5 rounded-full bg-gray-800 text-gray-400 text-[10px] font-bold flex items-center justify-center">2</span>
                      <span>Corner 2 (NE)</span>
                    </span>
                    <span class="font-mono text-[11px] text-gray-500">Not Plotted</span>
                  </div>

                  <div id="coord-card-3" class="p-2.5 rounded-lg bg-gray-900/60 border border-gray-800 flex items-center justify-between">
                    <span class="flex items-center gap-2 text-gray-400">
                      <span class="w-5 h-5 rounded-full bg-gray-800 text-gray-400 text-[10px] font-bold flex items-center justify-center">3</span>
                      <span>Corner 3 (SE)</span>
                    </span>
                    <span class="font-mono text-[11px] text-gray-500">Not Plotted</span>
                  </div>

                  <div id="coord-card-4" class="p-2.5 rounded-lg bg-gray-900/60 border border-gray-800 flex items-center justify-between">
                    <span class="flex items-center gap-2 text-gray-400">
                      <span class="w-5 h-5 rounded-full bg-gray-800 text-gray-400 text-[10px] font-bold flex items-center justify-center">4</span>
                      <span>Corner 4 (SW)</span>
                    </span>
                    <span class="font-mono text-[11px] text-gray-500">Not Plotted</span>
                  </div>
                </div>
              </div>

            </div>

            <!-- Submit Action & Validation Banner -->
            <div class="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
              <div id="form-validation-msg" class="text-xs text-amber-300 flex items-center gap-2 hidden">
                <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-400"></i>
                <span id="validation-text">Please plot all 4 boundary corners on the map before saving.</span>
              </div>

              <div class="flex items-center gap-3 ml-auto">
                <a href="#/dashboard" class="px-5 py-2.5 rounded-xl bg-gray-800/80 hover:bg-gray-700 text-gray-300 font-semibold text-xs transition">
                  Cancel
                </a>
                <button type="submit" id="btn-save-farm-profile" class="btn-save-farm-action px-7 py-3 rounded-xl bg-gradient-to-r from-emerald-500 via-emerald-600 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-extrabold text-xs sm:text-sm shadow-xl shadow-emerald-950/60 hover:shadow-emerald-500/25 transition-all flex items-center gap-2 cursor-pointer">
                  <i data-lucide="plus-circle" class="w-4 h-4"></i>
                  <span>Add Farm & Save to Map →</span>
                </button>
              </div>
            </div>

          </div>

        </div>

      </form>
    </div>
  `;
}

/**
 * Initializes Interactive 4-Point Map Plotting Hooks & Location Detection
 */
export function initOnboardingHooks(state, setState) {
  const mapContainer = document.getElementById('onboarding-plot-map');
  if (!mapContainer || typeof L === 'undefined') return;

  // Clear previous leaflet instance cleanly if any
  if (window._onboardingMapInstance) {
    try {
      window._onboardingMapInstance.remove();
    } catch (e) {}
    window._onboardingMapInstance = null;
  }
  mapContainer._leaflet_id = null;

  // Initial center: active farm or Pune
  const initialLat = (state.activeFarm && state.activeFarm.geoCoords) ? state.activeFarm.geoCoords.lat : 18.5204;
  const initialLng = (state.activeFarm && state.activeFarm.geoCoords) ? state.activeFarm.geoCoords.lng : 73.8567;

  const map = L.map('onboarding-plot-map', {
    scrollWheelZoom: true,
    zoomControl: true
  }).setView([initialLat, initialLng], 16);
  window._onboardingMapInstance = map;

  setTimeout(() => {
    if (map) map.invalidateSize();
  }, 100);
  setTimeout(() => {
    if (map) map.invalidateSize();
  }, 350);

  window.addEventListener('resize', () => {
    if (window._onboardingMapInstance) {
      window._onboardingMapInstance.invalidateSize();
    }
  });

  // Tile Layer 1: Esri World Imagery (Satellite)
  const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles &copy; Esri World Imagery'
  });

  // Tile Layer 2: OpenStreetMap (Street / Roads)
  const streetLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
  });

  // Default to Satellite View so farmers immediately see their actual fields!
  satelliteLayer.addTo(map);
  let activeTileLayer = 'satellite';

  // Toggle Satellite / Street Buttons
  const btnSatellite = document.getElementById('btn-toggle-satellite');
  const btnStreet = document.getElementById('btn-toggle-street');

  function setLayer(layerType) {
    if (layerType === 'satellite') {
      map.removeLayer(streetLayer);
      satelliteLayer.addTo(map);
      activeTileLayer = 'satellite';
      if (btnSatellite) btnSatellite.className = 'px-2.5 py-1 rounded-lg bg-emerald-700/60 text-emerald-200 font-bold text-xs flex items-center gap-1 transition';
      if (btnStreet) btnStreet.className = 'px-2.5 py-1 rounded-lg text-gray-400 hover:text-white font-semibold text-xs flex items-center gap-1 transition';
    } else {
      map.removeLayer(satelliteLayer);
      streetLayer.addTo(map);
      activeTileLayer = 'street';
      if (btnStreet) btnStreet.className = 'px-2.5 py-1 rounded-lg bg-emerald-700/60 text-emerald-200 font-bold text-xs flex items-center gap-1 transition';
      if (btnSatellite) btnSatellite.className = 'px-2.5 py-1 rounded-lg text-gray-400 hover:text-white font-semibold text-xs flex items-center gap-1 transition';
    }
  }

  if (btnSatellite) btnSatellite.addEventListener('click', () => setLayer('satellite'));
  if (btnStreet) btnStreet.addEventListener('click', () => setLayer('street'));

  // State for 4-point plotting
  let plottedPoints = [];
  let markers = [];
  let activePolyline = null;
  let activePolygon = null;

  // Pre-load active farm polygon if it exists
  if (state.activeFarm && Array.isArray(state.activeFarm.boundaryPolygon) && state.activeFarm.boundaryPolygon.length === 4) {
    loadExistingPoints(state.activeFarm.boundaryPolygon);
  }

  // Update Location Card
  function updateLocationCard(lat, lng) {
    const place = findNearestAgriPlace(lat, lng);
    const locNameEl = document.getElementById('loc-detected-name');
    const locZoneEl = document.getElementById('loc-detected-zone');
    const locPinEl = document.getElementById('loc-detected-pin');
    const locCoordsEl = document.getElementById('loc-detected-coords');
    const locDistEl = document.getElementById('loc-nearest-hub-distance');
    const gmapsLink = document.getElementById('loc-gmaps-link');

    if (locNameEl) locNameEl.textContent = place.formattedLocation;
    if (locZoneEl) locZoneEl.textContent = place.agroZone;
    if (locPinEl) locPinEl.textContent = `PIN: ${place.pin}`;
    if (locCoordsEl) locCoordsEl.textContent = `${lat.toFixed(5)}° N, ${lng.toFixed(5)}° E`;
    if (locDistEl) locDistEl.textContent = `${place.distanceKm} km from ${place.taluka} Taluka HQ`;
    if (gmapsLink) gmapsLink.href = getGoogleSatelliteUrl(lat, lng);
  }

  // Sync button: Fill location input with detected address
  const btnUseDetectedLoc = document.getElementById('btn-use-detected-loc');
  if (btnUseDetectedLoc) {
    btnUseDetectedLoc.addEventListener('click', () => {
      const center = map.getCenter();
      const place = findNearestAgriPlace(center.lat, center.lng);
      const locInput = document.getElementById('ob-location');
      if (locInput) {
        locInput.value = place.formattedLocation;
        btnUseDetectedLoc.innerHTML = '<i data-lucide="check" class="w-3 h-3 text-emerald-400"></i> Synced!';
        setTimeout(() => {
          btnUseDetectedLoc.innerHTML = '<i data-lucide="check" class="w-3 h-3"></i> Sync with Map';
          if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
        }, 1500);
      }
    });
  }

  // Helper: Create custom numbered DivIcon with cardinal tag
  function createNumberedDivIcon(number, cardinalTag = '') {
    return L.divIcon({
      className: 'farm-corner-div-icon',
      html: `
        <div class="farm-corner-pin ${number === 4 ? 'final-point' : ''}">
          <span>${number}</span>
          ${cardinalTag ? `<span style="position: absolute; bottom: -14px; font-size: 8px; font-weight: 800; background: rgba(0,0,0,0.85); color: #34d399; padding: 1px 3px; border-radius: 4px; border: 1px solid #059669;">${cardinalTag}</span>` : ''}
        </div>
      `,
      iconSize: [32, 32],
      iconAnchor: [16, 16],
      popupAnchor: [0, -18]
    });
  }

  // Update UI Counters, Labels, Cardinal Directions, and Area Metrics
  function updateUI() {
    const count = plottedPoints.length;
    const counterBadge = document.getElementById('points-counter-badge');
    const counterText = document.getElementById('points-counter-text');
    const guideMessage = document.getElementById('points-guide-message');
    const coordsStatusLabel = document.getElementById('coords-status-label');

    // Update Counter Badge
    if (counterText && counterBadge) {
      if (count === 0) {
        counterBadge.className = 'px-3.5 py-1.5 rounded-full bg-gray-800 text-gray-300 text-xs font-bold border border-gray-700 flex items-center gap-1.5 transition-all';
        counterText.textContent = '0 / 4 Points Plotted';
      } else if (count === 1) {
        counterBadge.className = 'px-3.5 py-1.5 rounded-full bg-blue-950/80 text-blue-300 text-xs font-bold border border-blue-600/50 flex items-center gap-1.5 transition-all';
        counterText.textContent = '1 / 4 Points Plotted';
      } else if (count === 2) {
        counterBadge.className = 'px-3.5 py-1.5 rounded-full bg-amber-950/80 text-amber-300 text-xs font-bold border border-amber-600/50 flex items-center gap-1.5 transition-all';
        counterText.textContent = '2 / 4 Points Plotted';
      } else if (count === 3) {
        counterBadge.className = 'px-3.5 py-1.5 rounded-full bg-orange-950/80 text-orange-300 text-xs font-bold border border-orange-600/50 flex items-center gap-1.5 transition-all';
        counterText.textContent = '3 / 4 Points Plotted (1 Corner Left)';
      } else if (count === 4) {
        counterBadge.className = 'px-3.5 py-1.5 rounded-full bg-emerald-950 text-emerald-300 text-xs font-extrabold border border-emerald-500 shadow-md shadow-emerald-900/40 flex items-center gap-1.5 transition-all';
        counterText.textContent = '✓ 4 / 4 Plotted (Boundary Closed)';
      }
    }

    // Update Live Guide Message
    if (guideMessage) {
      if (count === 0) {
        guideMessage.innerHTML = '👉 Click on the map to set <b>Corner Point 1 (North-West)</b> of your farm.';
      } else if (count === 1) {
        guideMessage.innerHTML = '👉 Corner 1 placed! Click on the map to set <b>Corner Point 2 (North-East)</b>.';
      } else if (count === 2) {
        guideMessage.innerHTML = '👉 Corner 2 placed! Click on the map to set <b>Corner Point 3 (South-East)</b>.';
      } else if (count === 3) {
        guideMessage.innerHTML = '👉 Corner 3 placed! Click to set <b>Corner Point 4 (South-West)</b> to close your farm boundary.';
      } else if (count === 4) {
        guideMessage.innerHTML = '🎉 <b>Farm boundary closed!</b> All 4 corners plotted and location identified. Review metrics below or click "Save Farm".';
      }
    }

    if (coordsStatusLabel) {
      coordsStatusLabel.textContent = count === 4 ? 'All 4 corners locked in' : `${count} of 4 corners set`;
    }

    // Center coordinates for cardinal calculations
    const center = count > 0 ? calculateCentroid(plottedPoints) : map.getCenter();

    // Update Coordinate Display Cards with Cardinal Directions
    for (let i = 1; i <= 4; i++) {
      const card = document.getElementById(`coord-card-${i}`);
      if (!card) continue;

      if (i <= plottedPoints.length) {
        const pt = plottedPoints[i - 1];
        const cardinal = getCardinalBearing(center.lat, center.lng, pt[0], pt[1]);

        card.className = 'p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-700/60 flex items-center justify-between text-white';
        card.innerHTML = `
          <div class="flex items-center gap-2">
            <span class="w-6 h-6 rounded-full bg-gradient-to-br from-emerald-400 to-teal-700 text-white text-[11px] font-extrabold flex items-center justify-center shadow-sm">
              ${i}
            </span>
            <div>
              <span class="text-xs font-bold text-white block">Point ${i}</span>
              <span class="text-[10px] text-emerald-400 font-semibold">${cardinal.label} (${cardinal.bearingDeg}°)</span>
            </div>
          </div>
          <div class="text-right font-mono text-[11px] text-emerald-300">
            <div>${pt[0].toFixed(5)}° N</div>
            <div>${pt[1].toFixed(5)}° E</div>
          </div>
        `;
      } else {
        card.className = 'p-2.5 rounded-lg bg-gray-900/60 border border-gray-800 flex items-center justify-between text-gray-500';
        card.innerHTML = `
          <div class="flex items-center gap-2">
            <span class="w-6 h-6 rounded-full bg-gray-800 text-gray-400 text-[11px] font-bold flex items-center justify-center">
              ${i}
            </span>
            <div>
              <span class="text-xs font-semibold text-gray-400 block">Corner ${i}</span>
              <span class="text-[10px] text-gray-600">${i === 1 ? 'North-West' : i === 2 ? 'North-East' : i === 3 ? 'South-East' : 'South-West'}</span>
            </div>
          </div>
          <span class="font-mono text-[11px] text-gray-600">Not Plotted</span>
        `;
      }
    }

    // Area and Metric Stats
    const statAcres = document.getElementById('stat-acres');
    const statHa = document.getElementById('stat-hectares');
    const statSqm = document.getElementById('stat-sqmeters');
    const statPerimeter = document.getElementById('stat-perimeter');
    const inputAcres = document.getElementById('ob-farm-size-acres');

    if (count === 4) {
      const area = calculatePolygonArea(plottedPoints);
      if (statAcres) statAcres.textContent = `${area.acres} Acres`;
      if (statHa) statHa.textContent = `${area.hectares} Ha`;
      if (statSqm) statSqm.textContent = `${area.sqMeters.toLocaleString()} m²`;
      if (statPerimeter) statPerimeter.textContent = `${area.perimeterMeters.toLocaleString()} m`;
      if (inputAcres) inputAcres.value = area.acres;

      // Update location card from centroid
      updateLocationCard(center.lat, center.lng);
    } else {
      if (statAcres) statAcres.textContent = '-- Acres';
      if (statHa) statHa.textContent = '-- Ha';
      if (statSqm) statSqm.textContent = '-- m²';
      if (statPerimeter) statPerimeter.textContent = '-- m';
    }
  }

  // Pre-load existing 4 points
  function loadExistingPoints(points) {
    clearLayers();
    plottedPoints = points.map(p => [Number(p[0]), Number(p[1])]);
    const center = calculateCentroid(plottedPoints);

    plottedPoints.forEach((pt, idx) => {
      const cardinal = getCardinalBearing(center.lat, center.lng, pt[0], pt[1]);
      const marker = L.marker(pt, {
        icon: createNumberedDivIcon(idx + 1, cardinal.shortLabel),
        draggable: true
      }).addTo(map);

      marker.bindPopup(`<b>Corner Point ${idx + 1} (${cardinal.label})</b><br/>Lat: ${pt[0].toFixed(5)}<br/>Lng: ${pt[1].toFixed(5)}`);

      // Allow dragging corner point to fine-tune!
      marker.on('dragend', (e) => {
        const newPos = e.target.getLatLng();
        plottedPoints[idx] = [Number(newPos.lat.toFixed(6)), Number(newPos.lng.toFixed(6))];
        redrawBoundary();
        updateUI();
      });

      markers.push(marker);
    });

    redrawBoundary();
    updateUI();

    if (activePolygon) {
      map.fitBounds(activePolygon.getBounds(), { padding: [40, 40] });
    }
  }

  // Redraw Boundary (Polyline or Closed Polygon)
  function redrawBoundary() {
    if (activePolyline) {
      map.removeLayer(activePolyline);
      activePolyline = null;
    }
    if (activePolygon) {
      map.removeLayer(activePolygon);
      activePolygon = null;
    }

    if (plottedPoints.length >= 2 && plottedPoints.length < 4) {
      activePolyline = L.polyline(plottedPoints, {
        color: '#f59e0b',
        dashArray: '6, 8',
        weight: 3
      }).addTo(map);
    } else if (plottedPoints.length === 4) {
      const area = calculatePolygonArea(plottedPoints);
      const center = calculateCentroid(plottedPoints);
      const place = findNearestAgriPlace(center.lat, center.lng);

      activePolygon = L.polygon(plottedPoints, {
        color: '#10b981',
        fillColor: '#059669',
        fillOpacity: 0.35,
        weight: 3
      }).addTo(map);

      activePolygon.bindPopup(`
        <div style="font-family: sans-serif; padding: 4px; min-width: 200px;">
          <b style="color: #064e3b; font-size: 13px;">🌾 Demarcated Farm Area</b><br/>
          <span style="font-size: 11px; color: #4b5563;">Location: <b>${place.formattedLocation}</b></span><br/>
          <div style="margin: 4px 0; padding: 4px 6px; background: #ecfdf5; border-radius: 6px; border: 1px solid #a7f3d0;">
            <b style="font-size: 12px; color: #047857;">Area: ${area.acres} Acres (${area.hectares} Ha)</b><br/>
            <span style="font-size: 10px; color: #065f46;">Perimeter: ${area.perimeterMeters} m</span>
          </div>
          <span style="font-size: 10px; color: #6b7280;">Centroid: ${center.lat.toFixed(5)}° N, ${center.lng.toFixed(5)}° E</span>
        </div>
      `);
    }
  }

  // Clear Map Layers
  function clearLayers() {
    markers.forEach(m => map.removeLayer(m));
    markers = [];
    if (activePolyline) {
      map.removeLayer(activePolyline);
      activePolyline = null;
    }
    if (activePolygon) {
      map.removeLayer(activePolygon);
      activePolygon = null;
    }
    plottedPoints = [];
  }

  // Map Click Event: Place points 1 to 4
  map.on('click', (e) => {
    if (plottedPoints.length >= 4) {
      const banner = document.getElementById('points-guidance-banner');
      if (banner) {
        banner.className = 'p-3 rounded-xl bg-amber-950/60 border border-amber-600/60 flex items-center gap-2.5 text-xs text-amber-200 animate-pulse';
        banner.innerHTML = `
          <i data-lucide="info" class="w-4 h-4 text-amber-400 shrink-0"></i>
          <span>You have already plotted all 4 corner points. Click <b>"Reset"</b> above to re-plot or drag the numbered pins to adjust boundaries!</span>
        `;
        if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
      }
      return;
    }

    const lat = Number(e.latlng.lat.toFixed(6));
    const lng = Number(e.latlng.lng.toFixed(6));
    const pointIdx = plottedPoints.length;
    const pointNum = pointIdx + 1;

    plottedPoints.push([lat, lng]);

    // Cardinal tag
    const center = calculateCentroid(plottedPoints);
    const cardinal = getCardinalBearing(center.lat, center.lng, lat, lng);

    const marker = L.marker([lat, lng], {
      icon: createNumberedDivIcon(pointNum, cardinal.shortLabel),
      draggable: true
    }).addTo(map);

    marker.bindPopup(`<b>Corner Point ${pointNum} (${cardinal.label})</b><br/>Lat: ${lat}<br/>Lng: ${lng}`);

    // Allow dragging to adjust
    marker.on('dragend', (ev) => {
      const newPos = ev.target.getLatLng();
      plottedPoints[pointIdx] = [Number(newPos.lat.toFixed(6)), Number(newPos.lng.toFixed(6))];
      redrawBoundary();
      updateUI();
    });

    markers.push(marker);
    redrawBoundary();
    updateUI();

    if (pointNum === 4 && activePolygon) {
      map.fitBounds(activePolygon.getBounds(), { padding: [40, 40] });
      activePolygon.openPopup();
    }
  });

  // Search Location Handler
  const searchInput = document.getElementById('map-location-search');
  const searchBtn = document.getElementById('btn-search-location');
  const feedbackMsg = document.getElementById('search-feedback-msg');

  async function performLocationSearch() {
    const q = searchInput?.value.trim();
    if (!q) return;

    if (searchBtn) searchBtn.innerHTML = '<i data-lucide="loader" class="w-3.5 h-3.5 animate-spin"></i> Searching...';

    // 1. Search local enriched Indian Agricultural database
    const localMatches = searchAgriPlaces(q);
    if (localMatches.length > 0) {
      const match = localMatches[0];
      map.flyTo([match.lat, match.lng], 16, { duration: 1.5 });
      updateLocationCard(match.lat, match.lng);

      if (feedbackMsg) {
        feedbackMsg.classList.remove('hidden');
        feedbackMsg.textContent = `✓ Found: ${match.name}`;
      }
      if (searchBtn) searchBtn.innerHTML = '<i data-lucide="search" class="w-3.5 h-3.5"></i> <span>Find Location</span>';
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
      return;
    }

    // 2. Try online OpenStreetMap Nominatim for any specific village/pincode
    try {
      const resp = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q + ', India')}&limit=1`, {
        headers: { 'Accept': 'application/json' }
      });
      const data = await resp.json();
      if (data && data.length > 0) {
        const resultLat = parseFloat(data[0].lat);
        const resultLng = parseFloat(data[0].lon);
        map.flyTo([resultLat, resultLng], 16, { duration: 1.5 });
        updateLocationCard(resultLat, resultLng);

        if (feedbackMsg) {
          feedbackMsg.classList.remove('hidden');
          feedbackMsg.textContent = `✓ Located: ${data[0].display_name.split(',')[0]}`;
        }
      } else {
        alert(`Location "${q}" not found. Try searching by district name (e.g. Pune, Nashik, Solapur) or PIN code.`);
      }
    } catch (err) {
      console.warn('Online geocoding fallback failed:', err);
      alert(`Location "${q}" not found in database. Try searching nearby taluka or district.`);
    } finally {
      if (searchBtn) searchBtn.innerHTML = '<i data-lucide="search" class="w-3.5 h-3.5"></i> <span>Find Location</span>';
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    }
  }

  if (searchBtn) searchBtn.addEventListener('click', performLocationSearch);
  if (searchInput) {
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        performLocationSearch();
      }
    });
  }

  // Toolbar: Locate My GPS
  const locateBtn = document.getElementById('btn-locate-gps');
  if (locateBtn) {
    locateBtn.addEventListener('click', () => {
      if (navigator.geolocation) {
        locateBtn.innerHTML = '<i data-lucide="loader" class="w-3.5 h-3.5 animate-spin"></i> Locating...';
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            const userLat = pos.coords.latitude;
            const userLng = pos.coords.longitude;
            map.flyTo([userLat, userLng], 17, { duration: 1.5 });
            updateLocationCard(userLat, userLng);
            locateBtn.innerHTML = '<i data-lucide="check" class="w-3.5 h-3.5 text-emerald-400"></i> Found';
            setTimeout(() => {
              locateBtn.innerHTML = '<i data-lucide="navigation" class="w-3.5 h-3.5"></i> <span>My GPS</span>';
              if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
            }, 2000);
          },
          (err) => {
            alert('Could not retrieve browser GPS location. Please ensure location permissions are granted.');
            locateBtn.innerHTML = '<i data-lucide="navigation" class="w-3.5 h-3.5"></i> <span>My GPS</span>';
            if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
          }
        );
      } else {
        alert('Geolocation is not supported by your browser.');
      }
    });
  }

  // Toolbar: Auto-Plot Demo 4 Points
  const autoPlotBtn = document.getElementById('btn-auto-plot-demo');
  if (autoPlotBtn) {
    autoPlotBtn.addEventListener('click', () => {
      const center = map.getCenter();
      const targetSize = parseFloat(document.getElementById('ob-farm-size-acres')?.value) || 6.5;
      const demoPts = generateDemoCorners(center.lat, center.lng, targetSize);
      loadExistingPoints(demoPts);
    });
  }

  // Toolbar: Reset Points
  const resetBtn = document.getElementById('btn-reset-points');
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      clearLayers();
      updateUI();
    });
  }

  // Form Submit Handler
  const form = document.getElementById('onboarding-farm-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const validationMsg = document.getElementById('form-validation-msg');
      const validationText = document.getElementById('validation-text');

      if (plottedPoints.length < 4) {
        // If farmer has not manually clicked 4 corners, auto-demarcate around current map center!
        const center = map.getCenter();
        const targetSize = parseFloat(document.getElementById('ob-farm-size-acres')?.value) || 5.0;
        const autoPts = generateDemoCorners(center.lat, center.lng, targetSize);
        loadExistingPoints(autoPts);
        plottedPoints = autoPts;
      }

      const farmerName = document.getElementById('ob-farmer-name')?.value.trim() || 'Farmer';
      const farmName = document.getElementById('ob-farm-name')?.value.trim() || 'Registered Farm Plot';
      const location = document.getElementById('ob-location')?.value.trim() || 'Pune District, Maharashtra';
      const soilType = document.getElementById('ob-soil-type')?.value || 'Medium Black Vertisol';
      const irrigationType = document.getElementById('ob-irrigation-type')?.value || 'Drip Irrigation & Borewell';
      const crop = document.getElementById('ob-crop-name')?.value.trim() || 'Wheat (HD-2967)';
      const sowingDate = document.getElementById('ob-sowing-date')?.value || '2026-11-15';
      const expectedHarvest = document.getElementById('ob-harvest-date')?.value || '2027-03-20';
      const sizeAcres = parseFloat(document.getElementById('ob-farm-size-acres')?.value) || 6.0;

      // Construct New Farm Profile
      const newFarm = createRealisticFarmProfile({
        farmerName,
        farmName,
        location,
        crop,
        soilType,
        irrigationType,
        sizeAcres,
        boundaryPolygon: plottedPoints,
        sowingDate,
        expectedHarvest
      });

      // Update state farms
      const existingFarms = Array.isArray(state.farms) ? [...state.farms] : [];
      const existingIndex = existingFarms.findIndex(f => f.id === newFarm.id);
      if (existingIndex >= 0) {
        existingFarms[existingIndex] = newFarm;
      } else {
        existingFarms.unshift(newFarm);
      }

      // Persist to localStorage
      try {
        localStorage.setItem('agrosense_farms', JSON.stringify(existingFarms));
        localStorage.setItem('agrosense_active_farm_id', newFarm.id);
      } catch (err) {
        console.warn('LocalStorage save failed:', err);
      }

      // Update state and navigate to interactive Farm Map
      setState({
        farms: existingFarms,
        activeFarm: newFarm,
        customSoil: null,
        selectedCropRec: null
      });

      // Redirect to Farm Map
      window.location.hash = '#/farm-map';
    });
  }
}
