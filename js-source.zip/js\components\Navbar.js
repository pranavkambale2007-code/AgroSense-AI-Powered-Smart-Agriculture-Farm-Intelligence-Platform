// AgroSense Top Header Navbar Component

import { translations } from '../data/translations.js';

export function renderNavbar(state, dispatch) {
  const t = translations[state.lang] || translations.en;
  const currentFarm = state.activeFarm;

  return `
    <header class="bg-[#0b1713]/95 backdrop-blur-md border-b border-emerald-900/40 shrink-0 z-30 px-4 lg:px-8 py-3 flex items-center justify-between min-h-[64px]">
      <!-- Left: Logo & Brand -->
      <div class="flex items-center gap-3">
        <button id="toggle-sidebar-btn" class="lg:hidden p-2 rounded-lg text-emerald-400 hover:bg-emerald-950/60 transition">
          <i data-lucide="menu" class="w-6 h-6"></i>
        </button>
        <a href="#/3d-farm" class="flex items-center gap-2.5 text-decoration-none group">
          <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center shadow-lg shadow-emerald-900/30 group-hover:scale-105 transition">
            <i data-lucide="sprout" class="w-6 h-6 text-white"></i>
          </div>
          <div>
            <div class="flex items-center gap-1.5">
              <span class="font-extrabold text-xl tracking-tight text-white font-['Outfit']">${t.appName || 'AGROSENSE'}</span>
              <span class="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">v2.5.4-prod</span>
            </div>
            <p class="text-[11px] text-emerald-400/80 font-medium hidden sm:block">${t.tagline || 'Data-Driven Smart Agriculture & Crop Recommendation System'}</p>
          </div>
        </a>
      </div>

      <!-- Center: Active Farm Selector & Add Farm Button -->
      <div class="flex items-center gap-2">
        ${state.farms && state.farms.length > 0 ? `
          <div class="hidden md:flex items-center gap-2 bg-emerald-950/40 border border-emerald-800/40 rounded-xl px-3 py-1.5">
            <i data-lucide="map-pin" class="w-4 h-4 text-emerald-400"></i>
            <span class="text-xs text-gray-400 font-medium">Farm:</span>
            <select id="farm-selector" class="bg-transparent text-xs font-semibold text-white focus:outline-none cursor-pointer max-w-[180px] sm:max-w-[220px] truncate">
              ${state.farms.map(f => `
                <option value="${f.id}" ${f.id === (currentFarm?.id) ? 'selected' : ''} class="bg-gray-900 text-white">
                  ${f.name} (${f.currentCrop})
                </option>
              `).join('')}
              <option value="__add_new_farm__" class="bg-emerald-950 text-emerald-300 font-bold">
                ➕ Add New Farm...
              </option>
            </select>
          </div>
        ` : `
          <div class="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-950/40 border border-amber-600/40 text-amber-300 text-xs font-semibold">
            <i data-lucide="alert-circle" class="w-3.5 h-3.5 text-amber-400"></i>
            <span>No Farm Registered</span>
          </div>
        `}
        <a href="#/onboarding" id="btn-nav-add-farm" class="btn-add-farm-action px-2.5 sm:px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white text-xs font-bold shadow-md transition flex items-center gap-1.5 cursor-pointer text-decoration-none" title="Add Farm & Plot 4 Boundary Points">
          <i data-lucide="plus-circle" class="w-4 h-4 shrink-0"></i>
          <span class="hidden sm:inline">${state.farms && state.farms.length > 0 ? 'Add Farm' : 'Plot 4 Points & Register Farm'}</span>
          <span class="sm:hidden font-bold">Add Farm</span>
        </a>
      </div>

      <!-- Right Action Controls -->
      <div class="flex items-center gap-2.5">

        <!-- Landing Page Link Button -->
        <a href="./landing.html" class="px-3 py-2 rounded-xl bg-emerald-950/60 border border-emerald-800/60 text-emerald-200 hover:text-white hover:bg-emerald-900/60 transition flex items-center gap-1.5 cursor-pointer font-semibold text-xs shadow-sm" title="View AgroSense Landing Page">
          <i data-lucide="globe" class="w-4 h-4 text-emerald-400"></i>
          <span class="hidden sm:inline">${t.landingPage || 'Landing Page'}</span>
        </a>


      </div>
    </header>
  `;
}
