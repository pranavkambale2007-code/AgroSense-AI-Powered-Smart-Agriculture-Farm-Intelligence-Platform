const { translations } = require('js/data/translations.js');
const { crop3DProfiles, getCrop3DProfile, archetypeConfigs } = require('js/ml/crop3DProfiles.js');
const { expanded100Crops } = require('js/data/expandedCropDatabase.js');

const activeSimulators = new Map();

/**
 * Intelligent mapper to associate any crop from the 100+ crop database with a 3D botanical mesh
 */
function mapCropTo3DType(cropName = '', category = '') {
  const text = `${cropName} ${category}`.toLowerCase();
  if (text.includes('banana') || text.includes('केला')) return 'banana_plant';
  if (text.includes('rose') || text.includes('गुलाब') || text.includes('flower')) return 'flower_ornamental';
  if (text.includes('wheat') || text.includes('गेहूं') || text.includes('गहू')) return 'grain_wheat';
  if (text.includes('rice') || text.includes('paddy') || text.includes('धान') || text.includes('भात')) return 'paddy';
  if (text.includes('maize') || text.includes('corn') || text.includes('मक्का') || text.includes('मका')) return 'tall_stalk';
  if (text.includes('cotton') || text.includes('कपास')) return 'cotton_boll';
  if (text.includes('tomato') || text.includes('टमाटर')) return 'fruiting_bush';
  if (text.includes('potato') || text.includes('आलू') || text.includes('बटाटा')) return 'potato_crop';
  if (text.includes('chilli') || text.includes('pepper') || text.includes('मिर्च')) return 'chilli_pepper';

  const profile = getCrop3DProfile(cropName);
  if (profile && profile.archetype && !profile.isUnsupported) return profile.archetype;

  if (text.includes('black pepper') || text.includes('pepper') || text.includes('काली मिर्च') || text.includes('काळी मिरी')) return 'black_pepper';
  if (text.includes('cardamom') || text.includes('इलायची') || text.includes('वेलची')) return 'cardamom_clump';
  if (text.includes('marigold') || text.includes('गेंदा') || text.includes('झेंडू')) return 'marigold_flower';
  if (text.includes('cauliflower') || text.includes('फूलगोभी') || text.includes('फ्लॉवर')) return 'cauliflower_crop';
  if (text.includes('garlic') || text.includes('लहसुन') || text.includes('लसूण')) return 'garlic_crop';
  if (text.includes('radish') || text.includes('मूली') || text.includes('मुळा')) return 'radish_crop';
  if (text.includes('coriander') || text.includes('dhaniya') || text.includes('धनिया') || text.includes('कोथिंबीर')) return 'coriander_herb';
  if (text.includes('fenugreek') || text.includes('methi') || text.includes('मेथी')) return 'fenugreek_herb';
  if (text.includes('ginger') || text.includes('adrak') || text.includes('अदरक') || text.includes('आले')) return 'ginger_rhizome';
  if (text.includes('moringa') || text.includes('drumstick') || text.includes('सहजन') || text.includes('शेवगा')) return 'moringa_drumstick';
  if (text.includes('tulsi') || text.includes('holy basil') || text.includes('basil') || text.includes('तुलसी')) return 'tulsi_plant';
  if (text.includes('ashwagandha') || text.includes('अश्वगंधा') || text.includes('withania') || text.includes('senna') || text.includes('सनाय')) return 'ashwagandha_shrub';
  if (text.includes('aloe') || text.includes('एलोवेरा')) return 'succulent_aloe';
  if (text.includes('lemongrass') || text.includes('लेमनग्रास')) return 'lemongrass_tuft';
  if (text.includes('spinach') || text.includes('palak') || text.includes('pudina') || text.includes('mint') || text.includes('stevia')) return 'leafy_greens';
  if (text.includes('rice') || text.includes('paddy') || text.includes('धान') || text.includes('भात')) return 'paddy';
  if (text.includes('barley') || text.includes('जौ')) return 'grain_barley';
  if (text.includes('oat') || text.includes('जई')) return 'oats_panicle';
  if (text.includes('wheat') || text.includes('गेहूं') || text.includes('गहू')) return 'grain_wheat';
  if (text.includes('cotton') || text.includes('कपास')) return 'cotton_boll';
  if (text.includes('sugarcane') || text.includes('cane') || text.includes('गन्ना') || text.includes('ऊस') || text.includes('bamboo')) return 'sugarcane';
  if (text.includes('sunflower') || text.includes('सूरजमुखी')) return 'sunflower';
  if (text.includes('mustard') || text.includes('सरसों') || text.includes('sesame') || text.includes('तिल') || text.includes('safflower')) return 'mustard_bloom';
  if (text.includes('watermelon') || text.includes('melon') || text.includes('gourd') || text.includes('cucumber') || text.includes('tarbuz')) return 'curcurbit_vine';
  if (text.includes('onion') || text.includes('प्याज') || text.includes('कांदा')) return 'onion_garlic';
  if (text.includes('carrot') || text.includes('beet') || text.includes('गाजर')) return 'carrot_radish';
  if (text.includes('cabbage') || text.includes('पत्तागोभी')) return 'cabbage_brassica';
  if (text.includes('potato') || text.includes('आलू') || text.includes('बटाटा')) return 'potato_crop';
  if (text.includes('coconut') || text.includes('नारियल')) return 'palm_coconut';
  if (text.includes('areca') || text.includes('सुपारी')) return 'palm_areca';
  if (text.includes('banana') || text.includes('केला')) return 'banana_plant';
  if (text.includes('coffee')) return 'coffee_shrub';
  if (text.includes('tea') || text.includes('चाय')) return 'tea_bush';
  if (text.includes('nutmeg') || text.includes('clove') || text.includes('cinnamon')) return 'orchard_tree';
  if (text.includes('flower') || text.includes('rose') || text.includes('jasmine') || text.includes('gerbera') || text.includes('tuberose') || text.includes('carnation')) return 'flower_ornamental';
  if (text.includes('sorghum') || text.includes('jowar') || text.includes('ज्वार')) return 'sorghum_jowar';
  if (text.includes('ragi') || text.includes('रागी')) return 'millet_ragi';
  if (text.includes('millet') || text.includes('bajra') || text.includes('बाजरा')) return 'millet_spike';
  if (text.includes('groundnut') || text.includes('peanut') || text.includes('मूंगफली')) return 'groundnut_runner';
  if (text.includes('soybean') || text.includes('pulse') || text.includes('legume') || text.includes('gram') || text.includes('chana') || text.includes('tur') || text.includes('arhar') || text.includes('urad') || text.includes('moong') || text.includes('lentil') || text.includes('pea') || text.includes('bean')) return 'legume_pod';
  if (text.includes('maize') || text.includes('corn') || text.includes('मक्का') || text.includes('मका')) return 'tall_stalk';
  if (text.includes('okra') || text.includes('bhindi') || text.includes('भिंडी')) return 'okra_stalk';
  if (text.includes('chilli') || text.includes('mirch') || text.includes('मिर्च')) return 'chilli_pepper';
  if (text.includes('brinjal') || text.includes('eggplant') || text.includes('बैंगन') || text.includes('वांगी')) return 'brinjal_eggplant';
  if (text.includes('veg') || text.includes('tomato') || text.includes('टमाटर')) return 'fruiting_bush';
  return 'fruiting_bush';
}


// =========================================================================
// REALISTIC BOTANICAL 3D PROCEDURAL ARCHETYPE DRAWING ENGINES
// =========================================================================

function applyLeafTexture(ctx, pattern) {
  if (!pattern) return;
  ctx.save();
  ctx.globalAlpha = 0.28;
  ctx.fillStyle = pattern;
  ctx.fill();
  ctx.restore();
}

function drawPalmCoconut(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const trunkLean = Math.sin(p.seed) * 16 * zScale;
  
  // Flared root base at soil level
  ctx.fillStyle = '#2d1804';
  ctx.beginPath();
  ctx.ellipse(0, 0, 9 * zScale, 4.5 * zScale, 0, 0, Math.PI * 2);
  ctx.fill();

  // Tapered, curved coconut palm trunk
  const crownX = trunkLean + (sway * 0.25);
  const crownY = -pHeight;

  ctx.strokeStyle = '#3f2208';
  ctx.lineWidth = 9.5 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(trunkLean * 0.45, -pHeight * 0.5, crownX, crownY);
  ctx.stroke();

  // Highlight along sunlit trunk flank
  ctx.strokeStyle = '#78350f';
  ctx.lineWidth = 3.2 * zScale;
  ctx.beginPath();
  ctx.moveTo(2 * zScale, 0);
  ctx.quadraticCurveTo(trunkLean * 0.45 + 2 * zScale, -pHeight * 0.5, crownX + 1.5 * zScale, crownY);
  ctx.stroke();

  // Distinct horizontal annular ring scars
  ctx.strokeStyle = '#1c0d02';
  ctx.lineWidth = 1.8 * zScale;
  for (let r = 1; r <= 10; r++) {
    const t = r / 11;
    const rx = trunkLean * 0.45 * t * (1 - t) * 2 + crownX * (t * t);
    const ry = -pHeight * t;
    const ringW = (9.5 - t * 3.5) * zScale;
    ctx.beginPath();
    ctx.moveTo(rx - ringW * 0.5, ry);
    ctx.lineTo(rx + ringW * 0.5, ry);
    ctx.stroke();
  }

  // Clustered large coconuts beneath crown (ovoid drupes with specular glints)
  for (let c = 0; c < 6; c++) {
    const cAng = (c / 6) * Math.PI + 0.15;
    const cDist = 9 * zScale;
    const cx = crownX + Math.cos(cAng) * cDist;
    const cy = crownY + 8 * zScale + Math.sin(cAng) * (5 * zScale);
    
    // Drop shadow under nut
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.beginPath();
    ctx.ellipse(cx, cy + 2 * zScale, 5.5 * zScale, 3 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();

    // Coconut body
    ctx.fillStyle = c % 2 === 0 ? '#65a30d' : '#854d0e';
    ctx.beginPath();
    ctx.ellipse(cx, cy, 5.5 * zScale, 7.5 * zScale, cAng * 0.35, 0, Math.PI * 2);
    ctx.fill();

    // Specular highlight
    ctx.fillStyle = 'rgba(255, 255, 255, 0.42)';
    ctx.beginPath();
    ctx.arc(cx - 1.5 * zScale, cy - 2 * zScale, 1.8 * zScale, 0, Math.PI * 2);
    ctx.fill();
  }

  // Majestic Arching Pinnate Palm Fronds (65-80px long)
  const frondAngles = [-1.45, -1.1, -0.75, -0.4, 0, 0.4, 0.75, 1.1, 1.45];
  frondAngles.forEach((fa, idx) => {
    ctx.save();
    ctx.translate(crownX, crownY);
    ctx.rotate(fa + (sway * 0.05));
    const frondLen = (58 + (idx % 3) * 6) * zScale;

    // Pinnate frond foliage mass envelope with cellular texture
    ctx.fillStyle = idx % 2 === 0 ? '#15803d' : '#166534';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(frondLen * 0.5, -9 * zScale, frondLen, 16 * zScale);
    ctx.quadraticCurveTo(frondLen * 0.5, 9 * zScale, 0, 0);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Central rachis spine
    ctx.strokeStyle = '#14532d';
    ctx.lineWidth = 2.4 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(frondLen * 0.5, -6 * zScale, frondLen, 16 * zScale);
    ctx.stroke();

    // Cascading feather pinnate leaflets
    ctx.strokeStyle = idx % 2 === 0 ? '#22c55e' : '#16a34a';
    ctx.lineWidth = 1.2 * zScale;
    for (let l = 1; l <= 12; l++) {
      const lt = l / 13;
      const lx = frondLen * lt;
      const ly = -6 * zScale * Math.sin(lt * Math.PI) + 16 * zScale * (lt * lt);
      const leafletLen = (1 - Math.abs(lt - 0.5)) * 14 * zScale + 4 * zScale;
      ctx.beginPath();
      ctx.moveTo(lx, ly);
      ctx.lineTo(lx - 3 * zScale, ly + leafletLen);
      ctx.moveTo(lx, ly);
      ctx.lineTo(lx + 3 * zScale, ly + leafletLen);
      ctx.stroke();
    }
    ctx.restore();
  });
}

function drawPalmAreca(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const topX = sway * 0.25;
  
  // Slender, graceful ivory-ringed trunk
  ctx.strokeStyle = '#14532d';
  ctx.lineWidth = 5.2 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(topX, -pHeight);
  ctx.stroke();

  // Distinct pale ivory/white ring bands
  ctx.strokeStyle = '#dcfce7';
  ctx.lineWidth = 1.5 * zScale;
  for (let r = 1; r <= 12; r++) {
    const t = r / 13;
    const ry = -pHeight * t;
    const rx = topX * t;
    ctx.beginPath();
    ctx.moveTo(rx - 3 * zScale, ry);
    ctx.lineTo(rx + 3 * zScale, ry);
    ctx.stroke();
  }

  // Smooth lime crownshaft
  ctx.strokeStyle = '#65a30d';
  ctx.lineWidth = 5.8 * zScale;
  ctx.beginPath();
  ctx.moveTo(topX * 0.82, -pHeight * 0.82);
  ctx.lineTo(topX, -pHeight);
  ctx.stroke();

  // Clustered orange areca betel nuts
  for (let n = 0; n < 12; n++) {
    const nx = topX - 5 * zScale + (n % 4) * 3.2 * zScale;
    const ny = -pHeight * 0.86 + Math.floor(n / 4) * 3.8 * zScale;
    ctx.fillStyle = '#ea580c';
    ctx.beginPath();
    ctx.arc(nx, ny, 2.8 * zScale, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#fdba74';
    ctx.beginPath();
    ctx.arc(nx - 0.8 * zScale, ny - 0.8 * zScale, 0.9 * zScale, 0, Math.PI * 2);
    ctx.fill();
  }

  // Upright feathery fronds
  const frondAngles = [-1.2, -0.75, -0.3, 0.3, 0.75, 1.2];
  frondAngles.forEach(fa => {
    ctx.save();
    ctx.translate(topX, -pHeight);
    ctx.rotate(fa + sway * 0.04);
    const len = 44 * zScale;

    // Frond silhouette with cellular texture
    ctx.fillStyle = '#15803d';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(len * 0.5, -8 * zScale, len, 12 * zScale);
    ctx.quadraticCurveTo(len * 0.5, 4 * zScale, 0, 0);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    ctx.strokeStyle = '#22c55e';
    ctx.lineWidth = 1.6 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(len * 0.5, -8 * zScale, len, 12 * zScale);
    ctx.stroke();

    // Fine pinnate leaflets
    ctx.strokeStyle = '#4ade80';
    ctx.lineWidth = 0.9 * zScale;
    for (let l = 1; l <= 8; l++) {
      const lt = l / 9;
      const lx = len * lt;
      const ly = -8 * zScale * Math.sin(lt * Math.PI) + 12 * zScale * (lt * lt);
      ctx.beginPath();
      ctx.moveTo(lx, ly);
      ctx.lineTo(lx - 2 * zScale, ly + 6 * zScale);
      ctx.moveTo(lx, ly);
      ctx.lineTo(lx + 2 * zScale, ly + 6 * zScale);
      ctx.stroke();
    }
    ctx.restore();
  });
}

function drawBananaPlant(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Massive succulent green pseudostem with overlapping fibrous sheaths
  const crownX = sway * 0.45;
  const crownY = -pHeight * 0.85;

  // Sturdy conical pseudostem base with dry brown sheath rings
  ctx.fillStyle = '#78350f';
  ctx.beginPath();
  ctx.ellipse(0, 1 * zScale, 11 * zScale, 5 * zScale, 0, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 12.0 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.2, -pHeight * 0.45, crownX, crownY);
  ctx.stroke();

  // Fibrous overlapping sheath stripes
  ctx.strokeStyle = '#4ade80';
  ctx.lineWidth = 2.4 * zScale;
  ctx.beginPath();
  ctx.moveTo(2.5 * zScale, 0);
  ctx.quadraticCurveTo(sway * 0.2 + 2.5 * zScale, -pHeight * 0.45, crownX + 2.5 * zScale, crownY);
  ctx.stroke();

  // Giant tropical paddle leaves with realistic pinnate wind slits & ivory midrib
  const leaves = [
    { ang: -1.25, len: 58 * zScale, w: 20 * zScale },
    { ang: -0.75, len: 72 * zScale, w: 24 * zScale },
    { ang: -0.15, len: 78 * zScale, w: 26 * zScale },
    { ang: 0.45, len: 70 * zScale, w: 23 * zScale },
    { ang: 1.05, len: 56 * zScale, w: 19 * zScale }
  ];

  leaves.forEach(lf => {
    ctx.save();
    ctx.translate(crownX, crownY);
    ctx.rotate(lf.ang + sway * 0.06);

    const lfGrad = ctx.createLinearGradient(0, -lf.w * 0.5, 0, lf.w * 0.5);
    lfGrad.addColorStop(0, '#15803d');
    lfGrad.addColorStop(0.5, '#22c55e');
    lfGrad.addColorStop(1, '#166534');
    ctx.fillStyle = lfGrad;

    ctx.beginPath();
    ctx.ellipse(lf.len * 0.5, 0, lf.len * 0.5, lf.w * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Pale green ivory central midrib
    ctx.strokeStyle = '#bbf7d0';
    ctx.lineWidth = 2.4 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(lf.len, 0);
    ctx.stroke();

    // Natural wind tears / pinnate slits along lateral veins
    ctx.strokeStyle = 'rgba(0, 0, 0, 0.25)';
    ctx.lineWidth = 1.0 * zScale;
    for (let sl = 1; sl <= 4; sl++) {
      const sx = lf.len * (sl / 5);
      ctx.beginPath();
      ctx.moveTo(sx, 0);
      ctx.lineTo(sx - 3 * zScale, -lf.w * 0.48);
      ctx.moveTo(sx + 2 * zScale, 0);
      ctx.lineTo(sx + 5 * zScale, lf.w * 0.48);
      ctx.stroke();
    }

    ctx.restore();
  });

  // Heavy hanging pendulous bunch with hands of curved bananas & purple floral bell
  const bunchX = crownX + 4 * zScale;
  const bunchY = crownY + 14 * zScale;

  // Peduncle stalk
  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 3.6 * zScale;
  ctx.beginPath();
  ctx.moveTo(crownX, crownY);
  ctx.quadraticCurveTo(bunchX, bunchY - 6 * zScale, bunchX, bunchY + 18 * zScale);
  ctx.stroke();

  // Spiral tiers (hands) of curved bananas
  for (let b = 0; b < 12; b++) {
    const tier = Math.floor(b / 4);
    const colIdx = b % 4;
    const bx = bunchX + (colIdx - 1.5) * 4.8 * zScale;
    const by = bunchY + tier * 5.8 * zScale;
    const bRot = (colIdx - 1.5) * 0.22;

    ctx.save();
    ctx.translate(bx, by);
    ctx.rotate(bRot);

    // Curved banana finger
    ctx.fillStyle = fruitCol || '#facc15';
    ctx.beginPath();
    ctx.ellipse(0, 0, 3.4 * zScale, 7.5 * zScale, 0.15, 0, Math.PI * 2);
    ctx.fill();

    // Specular highlight
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.ellipse(-0.8 * zScale, 0, 1.2 * zScale, 5.0 * zScale, 0.15, 0, Math.PI * 2);
    ctx.fill();

    // Brown flower scar tip
    ctx.fillStyle = '#451a03';
    ctx.beginPath();
    ctx.arc(0, 5.5 * zScale, 1.1 * zScale, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // Velvety royal-purple terminal banana heart / flower bell
  ctx.fillStyle = '#701a75';
  ctx.beginPath();
  ctx.moveTo(bunchX - 7 * zScale, bunchY + 20 * zScale);
  ctx.lineTo(bunchX + 7 * zScale, bunchY + 20 * zScale);
  ctx.lineTo(bunchX, bunchY + 36 * zScale); // pointed apex
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#a21caf';
  ctx.beginPath();
  ctx.arc(bunchX, bunchY + 22 * zScale, 5.2 * zScale, 0, Math.PI * 2);
  ctx.fill();
}

function drawSugarcane(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Dense stool of 4 jointed culms reaching high (up to 85px)
  const culmConfigs = [
    { sx: -6 * zScale, col: '#701a75', w: 4.8 * zScale, hMult: 0.95, swayMult: 0.6 },  // dark purple-black cane
    { sx: -2 * zScale, col: '#15803d', w: 5.6 * zScale, hMult: 1.15, swayMult: 0.8 },  // deep emerald cane
    { sx: 2.5 * zScale, col: '#b45309', w: 5.2 * zScale, hMult: 1.08, swayMult: 0.75 }, // golden-amber cane
    { sx: 6 * zScale, col: '#166534', w: 4.5 * zScale, hMult: 0.98, swayMult: 0.65 }   // green cane
  ];

  culmConfigs.forEach(c => {
    const topX = c.sx + sway * c.swayMult;
    const topY = -pHeight * c.hMult;

    // Jointed culm stalk
    ctx.strokeStyle = c.col;
    ctx.lineWidth = c.w;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(c.sx, 0);
    ctx.quadraticCurveTo(c.sx + sway * 0.25, topY * 0.5, topX, topY);
    ctx.stroke();

    // Segmented node rings, root primordia & waxy white bloom bands
    const nodes = 7;
    for (let j = 1; j <= nodes; j++) {
      const jt = j / (nodes + 0.5);
      const ny = topY * jt;
      const nx = c.sx + (topX - c.sx) * jt;

      // Swollen node ring
      ctx.strokeStyle = '#451a03';
      ctx.lineWidth = c.w + 1.2 * zScale;
      ctx.beginPath();
      ctx.moveTo(nx - 2.8 * zScale, ny);
      ctx.lineTo(nx + 2.8 * zScale, ny);
      ctx.stroke();

      // Powdery white cuticular wax band beneath node
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.75)';
      ctx.lineWidth = 1.8 * zScale;
      ctx.beginPath();
      ctx.moveTo(nx - 2.5 * zScale, ny + 2.2 * zScale);
      ctx.lineTo(nx + 2.5 * zScale, ny + 2.2 * zScale);
      ctx.stroke();

      // Micro root primordia dots on lower nodes
      if (j <= 3) {
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(nx - 1.2 * zScale, ny + 1.0 * zScale, 0.6 * zScale, 0, Math.PI * 2);
        ctx.arc(nx + 1.2 * zScale, ny + 1.0 * zScale, 0.6 * zScale, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  });

  // Stilt brace roots anchoring into furrow soil
  ctx.strokeStyle = '#78350f';
  ctx.lineWidth = 1.8 * zScale;
  [-7, -3, 3, 7].forEach(bx => {
    ctx.beginPath();
    ctx.moveTo(bx * 0.4 * zScale, -4 * zScale);
    ctx.lineTo(bx * zScale, 2 * zScale);
    ctx.stroke();
  });

  // Arching ribbon leaves cascading from top with ivory midrib
  const tallCulm = culmConfigs[1];
  const apexX = tallCulm.sx + sway * tallCulm.swayMult;
  const apexY = -pHeight * tallCulm.hMult;

  const leafAngles = [-1.1, -0.7, -0.3, 0.3, 0.7, 1.1];
  leafAngles.forEach(ang => {
    ctx.save();
    ctx.translate(apexX, apexY);
    ctx.rotate(ang + sway * 0.05);

    const len = 42 * zScale;
    const lfGrad = ctx.createLinearGradient(0, 0, len, 0);
    lfGrad.addColorStop(0, '#15803d');
    lfGrad.addColorStop(0.7, '#22c55e');
    lfGrad.addColorStop(1, '#86efac');
    ctx.fillStyle = lfGrad;

    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(len * 0.5, -4.5 * zScale, len, 14 * zScale);
    ctx.quadraticCurveTo(len * 0.5, 3.5 * zScale, 0, 0);
    ctx.closePath();
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Pale ivory central midrib
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(len * 0.5, -0.5 * zScale, len, 14 * zScale);
    ctx.stroke();

    ctx.restore();
  });

  // Silver-white plumose arrow inflorescence (silky tassel atop mature cane)
  ctx.save();
  ctx.translate(apexX, apexY - 3 * zScale);
  ctx.rotate(sway * 0.04);
  const arrowH = 24 * zScale;

  ctx.strokeStyle = 'rgba(248, 250, 252, 0.85)';
  ctx.lineWidth = 1.4 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, -arrowH);
  ctx.stroke();

  // Feathery silky plumose branchlets
  ctx.strokeStyle = 'rgba(241, 245, 249, 0.65)';
  ctx.lineWidth = 0.8 * zScale;
  for (let f = 1; f <= 8; f++) {
    const fy = -arrowH * (f / 9);
    const fSpread = (1 - f / 9) * 7.5 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, fy);
    ctx.quadraticCurveTo(-fSpread * 0.5, fy - 3 * zScale, -fSpread, fy - 6 * zScale);
    ctx.moveTo(0, fy);
    ctx.quadraticCurveTo(fSpread * 0.5, fy - 3 * zScale, fSpread, fy - 6 * zScale);
    ctx.stroke();
  }
  ctx.restore();
}

function drawCurcurbitVine(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Sprawling green runners creeping over soil
  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 3.4 * zScale;
  ctx.beginPath();
  ctx.moveTo(-24 * zScale, 2 * zScale);
  ctx.quadraticCurveTo(-10 * zScale, -10 * zScale, 0, 0);
  ctx.quadraticCurveTo(14 * zScale, -6 * zScale, 28 * zScale, 2 * zScale);
  ctx.stroke();

  // Coiled curling vine tendrils
  ctx.strokeStyle = '#4ade80';
  ctx.lineWidth = 1.2 * zScale;
  ctx.beginPath();
  ctx.moveTo(18 * zScale, -1 * zScale);
  ctx.bezierCurveTo(24 * zScale, -10 * zScale, 30 * zScale, -4 * zScale, 32 * zScale, -12 * zScale);
  ctx.stroke();

  // Bright yellow 5-star bell flower
  const flX = -6 * zScale;
  const flY = -4 * zScale;
  ctx.fillStyle = '#facc15';
  for (let fp = 0; fp < 5; fp++) {
    const fpAng = (fp / 5) * Math.PI * 2;
    ctx.beginPath();
    ctx.ellipse(flX + Math.cos(fpAng) * 3 * zScale, flY + Math.sin(fpAng) * 3 * zScale, 2.8 * zScale, 1.6 * zScale, fpAng, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = '#ca8a04';
  ctx.beginPath();
  ctx.arc(flX, flY, 1.4 * zScale, 0, Math.PI * 2);
  ctx.fill();

  // Ruffled palmate leaves
  const vineLeaves = [
    { lx: -14 * zScale, ly: -7 * zScale, s: 1.2 },
    { lx: 2 * zScale, ly: -10 * zScale, s: 1.35 },
    { lx: 20 * zScale, ly: -6 * zScale, s: 1.1 }
  ];
  vineLeaves.forEach(vl => {
    ctx.save();
    ctx.translate(vl.lx, vl.ly);
    ctx.fillStyle = '#16a34a';
    ctx.beginPath();
    ctx.ellipse(0, 0, 11 * zScale * vl.s, 7.5 * zScale * vl.s, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 1.1 * zScale;
    ctx.stroke();
    ctx.restore();
  });

  // BIG, GLORIOUS, UNMISTAKABLE STRIPED WATERMELON (24px wide!)
  const melonX = 8 * zScale;
  const melonY = 2 * zScale;
  const melonRadX = 17 * zScale;
  const melonRadY = 12 * zScale;

  // Dark ground contact shadow on furrow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.55)';
  ctx.beginPath();
  ctx.ellipse(melonX, melonY + 8 * zScale, melonRadX * 1.1, 4.5 * zScale, 0, 0, Math.PI * 2);
  ctx.fill();

  // Watermelon base rind
  const gourdGrad = ctx.createRadialGradient(melonX - 4 * zScale, melonY - 3 * zScale, 3 * zScale, melonX, melonY, melonRadX);
  gourdGrad.addColorStop(0, '#4ade80');
  gourdGrad.addColorStop(0.35, '#16a34a');
  gourdGrad.addColorStop(1, '#064e3b');
  ctx.fillStyle = gourdGrad;
  ctx.beginPath();
  ctx.ellipse(melonX, melonY, melonRadX, melonRadY, 0.08, 0, Math.PI * 2);
  ctx.fill();

  // Jagged light-mint tiger stripes
  ctx.strokeStyle = 'rgba(187, 247, 208, 0.85)';
  ctx.lineWidth = 2.4 * zScale;
  for (let s = -3; s <= 3; s++) {
    const sx = melonX + s * 4.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(sx, melonY - melonRadY * 0.85);
    ctx.lineTo(sx + (s % 2 === 0 ? 1.5 : -1.5) * zScale, melonY);
    ctx.lineTo(sx, melonY + melonRadY * 0.85);
    ctx.stroke();
  }

  // Yellow field spot (where melon rested on ground)
  ctx.fillStyle = 'rgba(254, 240, 138, 0.45)';
  ctx.beginPath();
  ctx.ellipse(melonX - 5 * zScale, melonY + 4 * zScale, 6 * zScale, 3.5 * zScale, 0.2, 0, Math.PI * 2);
  ctx.fill();

  // Curled green stem
  ctx.strokeStyle = '#22c55e';
  ctx.lineWidth = 1.8 * zScale;
  ctx.beginPath();
  ctx.moveTo(melonX - melonRadX * 0.9, melonY);
  ctx.quadraticCurveTo(melonX - melonRadX - 4 * zScale, melonY - 6 * zScale, melonX - melonRadX - 2 * zScale, melonY - 10 * zScale);
  ctx.stroke();
}

function drawCottonBoll(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Sturdy woody-brown monopodial central stem with reddish bark & nodes
  ctx.strokeStyle = '#451a03';
  ctx.lineWidth = 4.6 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.2, -pHeight * 0.5, sway * 0.45, -pHeight * 0.95);
  ctx.stroke();

  // Swollen node rings
  ctx.fillStyle = '#78350f';
  [-pHeight * 0.32, -pHeight * 0.58, -pHeight * 0.82].forEach(ny => {
    ctx.beginPath();
    ctx.ellipse(sway * 0.2 * (ny / (-pHeight * 0.5)), ny, 2.8 * zScale, 1.4 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
  });

  // Alternating sympodial lateral fruiting branches
  const branches = [
    { x1: 0, y1: -pHeight * 0.32, x2: -19 * zScale, y2: -pHeight * 0.52, rot: -0.5 },
    { x1: sway * 0.2, y1: -pHeight * 0.56, x2: 21 * zScale, y2: -pHeight * 0.72, rot: 0.45 },
    { x1: sway * 0.3, y1: -pHeight * 0.78, x2: -15 * zScale, y2: -pHeight * 0.88, rot: -0.4 }
  ];
  branches.forEach(b => {
    ctx.strokeStyle = '#581c87'; // reddish-purple tinged branch
    ctx.lineWidth = 2.6 * zScale;
    ctx.beginPath();
    ctx.moveTo(b.x1, b.y1);
    ctx.quadraticCurveTo((b.x1 + b.x2) * 0.5, (b.y1 + b.y2) * 0.5 - 3 * zScale, b.x2, b.y2);
    ctx.stroke();
  });

  // Authentic 3-to-5 lobed palmate cotton leaves with reddish petioles & radiating veins
  const leaves = [
    { lx: -18 * zScale, ly: -pHeight * 0.54, rot: -0.65, size: 13 * zScale },
    { lx: 20 * zScale, ly: -pHeight * 0.74, rot: 0.60, size: 14 * zScale },
    { lx: -14 * zScale, ly: -pHeight * 0.90, rot: -0.55, size: 12 * zScale },
    { lx: sway * 0.45 + 5 * zScale, ly: -pHeight * 0.96, rot: 0.25, size: 11 * zScale }
  ];

  leaves.forEach(lf => {
    ctx.save();
    ctx.translate(lf.lx, lf.ly);
    ctx.rotate(lf.rot + sway * 0.05);

    // Red petiole
    ctx.strokeStyle = '#991b1b';
    ctx.lineWidth = 1.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(-lf.size * 0.3, -lf.size * 0.4);
    ctx.stroke();

    // 3-to-5 lobed palmate blade
    ctx.fillStyle = '#14532d';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-lf.size * 0.6, -lf.size * 0.5); // left lateral lobe
    ctx.lineTo(-lf.size * 0.3, -lf.size * 0.9);
    ctx.lineTo(0, -lf.size * 1.2);              // central pointed lobe
    ctx.lineTo(lf.size * 0.3, -lf.size * 0.9);
    ctx.lineTo(lf.size * 0.6, -lf.size * 0.5);  // right lateral lobe
    ctx.closePath();
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Radiating palmate venation
    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 0.9 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(0, -lf.size * 1.15);
    ctx.moveTo(0, 0); ctx.lineTo(-lf.size * 0.55, -lf.size * 0.5);
    ctx.moveTo(0, 0); ctx.lineTo(lf.size * 0.55, -lf.size * 0.5);
    ctx.stroke();

    ctx.restore();
  });

  // Green fringed epicalyx bracteoles (Squares) & creamy yellow blossom
  const flowerX = 14 * zScale;
  const flowerY = -pHeight * 0.68;
  // 3 green fringed bracts
  ctx.fillStyle = '#16a34a';
  for (let br = 0; br < 3; br++) {
    const brAng = (br / 3) * Math.PI + Math.PI * 0.5;
    ctx.beginPath();
    ctx.moveTo(flowerX, flowerY);
    ctx.lineTo(flowerX + Math.cos(brAng - 0.25) * 6 * zScale, flowerY + Math.sin(brAng - 0.25) * 6 * zScale);
    ctx.lineTo(flowerX + Math.cos(brAng + 0.25) * 6 * zScale, flowerY + Math.sin(brAng + 0.25) * 6 * zScale);
    ctx.closePath();
    ctx.fill();
  }
  // Creamy yellow blossom petals with pink flush
  ctx.fillStyle = '#fef08a';
  for (let bp = 0; bp < 5; bp++) {
    const bpAng = (bp / 5) * Math.PI * 2;
    ctx.beginPath();
    ctx.ellipse(flowerX + Math.cos(bpAng) * 2.5 * zScale, flowerY + Math.sin(bpAng) * 2.5 * zScale, 1.4 * zScale, 3.2 * zScale, bpAng, 0, Math.PI * 2);
    ctx.fill();
  }
  // Golden stamen column
  ctx.fillStyle = '#f59e0b';
  ctx.beginPath();
  ctx.arc(flowerX, flowerY, 1.5 * zScale, 0, Math.PI * 2);
  ctx.fill();

  // Mature, Open, Voluminous Puffy 4-to-5 Lobed White Cotton Bolls
  const bollNodes = [
    { bx: sway * 0.45, by: -pHeight * 0.90, s: 1.35 },
    { bx: -18 * zScale, by: -pHeight * 0.53, s: 1.15 },
    { bx: 20 * zScale, by: -pHeight * 0.73, s: 1.25 }
  ];

  bollNodes.forEach(bn => {
    const bs = bn.s * zScale;

    // Reflexed dried brown boll capsule carpels (burrs)
    ctx.fillStyle = '#78350f';
    for (let br = 0; br < 4; br++) {
      const bAng = (br / 4) * Math.PI * 2 + 0.35;
      ctx.beginPath();
      ctx.moveTo(bn.bx, bn.by);
      ctx.lineTo(bn.bx + Math.cos(bAng - 0.35) * 9 * bs, bn.by + Math.sin(bAng - 0.35) * 9 * bs);
      ctx.lineTo(bn.bx + Math.cos(bAng) * 11 * bs, bn.by + Math.sin(bAng) * 11 * bs); // sharp reflexed tooth
      ctx.lineTo(bn.bx + Math.cos(bAng + 0.35) * 9 * bs, bn.by + Math.sin(bAng + 0.35) * 9 * bs);
      ctx.closePath();
      ctx.fill();
    }

    // Volumetric fluffy snow-white fiber lobes with soft shadow depth
    const rLobe = 5.8 * bs;
    for (let lobe = 0; lobe < 4; lobe++) {
      const lAngle = (lobe / 4) * Math.PI * 2 + 0.2;
      const lx = bn.bx + Math.cos(lAngle) * (rLobe * 0.85);
      const ly = bn.by + Math.sin(lAngle) * (rLobe * 0.85);

      // Deep drop shadow beneath each fiber lobe
      ctx.fillStyle = '#94a3b8';
      ctx.beginPath();
      ctx.arc(lx + 1.2 * bs, ly + 1.2 * bs, rLobe * 1.05, 0, Math.PI * 2);
      ctx.fill();

      // Soft ambient grey-white
      ctx.fillStyle = '#f1f5f9';
      ctx.beginPath();
      ctx.arc(lx, ly, rLobe, 0, Math.PI * 2);
      ctx.fill();

      // Brilliant pure white crown highlight
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(lx - 0.8 * bs, ly - 0.8 * bs, rLobe * 0.75, 0, Math.PI * 2);
      ctx.fill();
    }

    // Central tuft
    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(bn.bx, bn.by, rLobe * 0.95, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawSunflower(ctx, p, zScale, sway, pHeight, fruitCol, sunX, width, leafPattern) {
  // Sturdy rough hirsute stalk
  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 4.8 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.3, -pHeight * 0.5, sway * 0.75, -pHeight);
  ctx.stroke();

  // Broad cordate (heart-shaped) leaves
  const leafConfigs = [
    { lx: sway * 0.2 - 12 * zScale, ly: -pHeight * 0.4, ang: -0.65, s: 1.2 },
    { lx: sway * 0.45 + 12 * zScale, ly: -pHeight * 0.65, ang: 0.65, s: 1.3 }
  ];
  leafConfigs.forEach(lc => {
    ctx.save();
    ctx.translate(lc.lx, lc.ly);
    ctx.rotate(lc.ang);
    ctx.fillStyle = '#16a34a';
    ctx.beginPath();
    ctx.ellipse(0, 0, 16 * zScale * lc.s, 10 * zScale * lc.s, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);
    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 1.1 * zScale;
    ctx.stroke();
    ctx.restore();
  });

  // MASSIVE RADIANT GOLDEN SUNFLOWER HEAD (28px diameter!)
  const headX = sway * 0.75;
  const headY = -pHeight;
  const discR = 12 * zScale;

  ctx.save();
  ctx.translate(headX, headY);
  // Heliotropism: tilts toward the sun
  const sunAngle = Math.atan2(headY - 60, headX - (sunX || width * 0.5)) + Math.PI * 0.5;
  ctx.rotate(sunAngle * 0.35);

  // Green phyllary calyx cup
  ctx.fillStyle = '#14532d';
  ctx.beginPath();
  ctx.arc(0, 0, discR * 1.35, 0, Math.PI * 2);
  ctx.fill();

  // 20 radiant golden-yellow ray petals
  const petalCount = 20;
  for (let pt = 0; pt < petalCount; pt++) {
    const pAng = (pt / petalCount) * Math.PI * 2;
    const px = Math.cos(pAng) * discR;
    const py = Math.sin(pAng) * discR;
    ctx.fillStyle = pt % 2 === 0 ? '#facc15' : '#f59e0b';
    ctx.beginPath();
    ctx.ellipse(px, py, 7.5 * zScale, 3.2 * zScale, pAng, 0, Math.PI * 2);
    ctx.fill();
  }

  // Large textured dark chocolate/bronze seed disc
  const discGrad = ctx.createRadialGradient(0, 0, 1, 0, 0, discR);
  discGrad.addColorStop(0, '#451a03');
  discGrad.addColorStop(0.7, '#78350f');
  discGrad.addColorStop(1, '#b45309');
  ctx.fillStyle = discGrad;
  ctx.beginPath();
  ctx.arc(0, 0, discR, 0, Math.PI * 2);
  ctx.fill();

  // Spiral seed stippling
  ctx.fillStyle = '#fbbf24';
  for (let s = 1; s <= 28; s++) {
    const sAng = s * 2.4;
    const sDist = Math.sqrt(s / 28) * (discR * 0.85);
    ctx.beginPath();
    ctx.arc(Math.cos(sAng) * sDist, Math.sin(sAng) * sDist, 0.85 * zScale, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawTallStalk(ctx, p, zScale, sway, pHeight, fruitCol, lightingMode, isRaining, isSprinkling, leafPattern) {
  // Robust, jointed green culm (stalk) with distinct node rings (Zea mays)
  ctx.strokeStyle = '#047857';
  ctx.lineWidth = 5.6 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.35, -pHeight * 0.52, sway * 0.75, -pHeight);
  ctx.stroke();

  // Highlight along sunlit flank of stalk
  ctx.strokeStyle = '#34d399';
  ctx.lineWidth = 1.4 * zScale;
  ctx.beginPath();
  ctx.moveTo(1.2 * zScale, 0);
  ctx.quadraticCurveTo(sway * 0.35 + 1.2 * zScale, -pHeight * 0.52, sway * 0.75 + 1.0 * zScale, -pHeight);
  ctx.stroke();

  // Distinct alternating node rings & leaf sheaths
  const nodeLevels = [0.22, 0.40, 0.58, 0.76, 0.90];
  ctx.fillStyle = '#065f46';
  nodeLevels.forEach(t => {
    const ny = -pHeight * t;
    const nx = sway * 0.35 * (t / 0.52);
    ctx.beginPath();
    ctx.ellipse(nx, ny, 3.8 * zScale, 1.6 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
  });

  // Sturdy whorled reddish-purple prop brace roots anchoring into furrow ridge
  ctx.strokeStyle = '#991b1b';
  ctx.lineWidth = 1.8 * zScale;
  [-10, -5, 5, 10].forEach(rx => {
    ctx.beginPath();
    ctx.moveTo(rx * 0.2 * zScale, -6 * zScale);
    ctx.quadraticCurveTo(rx * 0.6 * zScale, -1 * zScale, rx * zScale, 2 * zScale);
    ctx.stroke();
  });

  // 6 Alternating broad ribbon strap leaves with undulating wavy borders & prominent ivory midrib
  const leaves = [
    { side: -1, yPct: 0.28, len: 32 * zScale, w: 9 * zScale, rot: -0.65 },
    { side: 1, yPct: 0.42, len: 35 * zScale, w: 9.5 * zScale, rot: 0.60 },
    { side: -1, yPct: 0.56, len: 34 * zScale, w: 9 * zScale, rot: -0.70 },
    { side: 1, yPct: 0.70, len: 32 * zScale, w: 8.5 * zScale, rot: 0.65 },
    { side: -1, yPct: 0.84, len: 26 * zScale, w: 7.5 * zScale, rot: -0.55 },
    { side: 1, yPct: 0.92, len: 22 * zScale, w: 6.5 * zScale, rot: 0.50 }
  ];

  leaves.forEach(lf => {
    const ly = -pHeight * lf.yPct;
    const lx = (sway * 0.35) * (lf.yPct / 0.52);

    ctx.save();
    ctx.translate(lx, ly);
    ctx.rotate(lf.rot + (sway * 0.08 * lf.side));

    // Arching ribbon leaf blade
    const leafGrad = ctx.createLinearGradient(0, 0, lf.len, 0);
    leafGrad.addColorStop(0, '#059669');
    leafGrad.addColorStop(0.5, '#10b981');
    leafGrad.addColorStop(1, '#047857');
    ctx.fillStyle = leafGrad;

    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(lf.len * 0.45, -lf.w * 0.6, lf.len, 4 * zScale); // arching curve
    ctx.quadraticCurveTo(lf.len * 0.55, lf.w * 0.7, 0, 0);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Prominent ivory-white central midrib
    ctx.strokeStyle = '#ecfdf5';
    ctx.lineWidth = 1.4 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(lf.len * 0.45, -lf.w * 0.1, lf.len, 4 * zScale);
    ctx.stroke();

    ctx.restore();
  });

  // Plump Ear of Corn (Cob) nestled in leaf axil wrapped in husks with cascading silk
  const cobX = sway * 0.35 + 4 * zScale;
  const cobY = -pHeight * 0.54;

  // Outer green protective husk leaves
  ctx.fillStyle = '#15803d';
  ctx.beginPath();
  ctx.ellipse(cobX, cobY, 6.5 * zScale, 15 * zScale, 0.38, 0, Math.PI * 2);
  ctx.fill();

  // Parted husk showing plump golden kernels
  ctx.fillStyle = '#facc15';
  ctx.beginPath();
  ctx.ellipse(cobX + 2.5 * zScale, cobY - 3 * zScale, 4.2 * zScale, 9 * zScale, 0.38, 0, Math.PI * 2);
  ctx.fill();

  // Individual kernel row textures
  ctx.strokeStyle = '#ca8a04';
  ctx.lineWidth = 0.8 * zScale;
  for (let kr = -2; kr <= 2; kr++) {
    ctx.beginPath();
    ctx.moveTo(cobX + 1 * zScale + kr * 1.4 * zScale, cobY - 10 * zScale);
    ctx.lineTo(cobX + 3 * zScale + kr * 1.4 * zScale, cobY + 4 * zScale);
    ctx.stroke();
  }

  // Cascading silk filaments (styles) flowing from cob tip
  ctx.strokeStyle = '#b91c1c';
  ctx.lineWidth = 0.85 * zScale;
  for (let st = -3; st <= 3; st++) {
    ctx.beginPath();
    ctx.moveTo(cobX + 2 * zScale, cobY - 11 * zScale);
    ctx.quadraticCurveTo(cobX + 4 * zScale + st * 2 * zScale, cobY + 2 * zScale, cobX + 2 * zScale + st * 3 * zScale + sway * 0.3, cobY + 12 * zScale);
    ctx.stroke();
  }

  // Large branched terminal staminate tassel at apex shedding golden pollen
  const topX = sway * 0.75;
  const topY = -pHeight;

  // Central spike & lateral spreading tassel branches
  const tasselBranches = [-0.65, -0.35, -0.15, 0, 0.15, 0.35, 0.65];
  ctx.lineWidth = 1.3 * zScale;
  tasselBranches.forEach(ta => {
    const tLen = (14 + Math.abs(ta) * -4 + (ta === 0 ? 5 : 0)) * zScale;
    ctx.strokeStyle = '#d97706';
    ctx.beginPath();
    ctx.moveTo(topX, topY);
    ctx.quadraticCurveTo(topX + Math.sin(ta) * tLen * 0.5, topY - tLen * 0.6, topX + Math.sin(ta) * tLen, topY - tLen);
    ctx.stroke();

    // Golden pollen anther beads along branches
    ctx.fillStyle = '#fde047';
    for (let an = 1; an <= 4; an++) {
      const at = an / 5;
      const ax = topX + Math.sin(ta) * tLen * at;
      const ay = topY - tLen * at;
      ctx.beginPath();
      ctx.arc(ax, ay, 1.1 * zScale, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}

function drawSorghumJowar(ctx, p, zScale, sway, pHeight, fruitCol, lightingMode, leafPattern) {
  // Sturdy upright culm with node collars and prop roots
  ctx.strokeStyle = '#047857';
  ctx.lineWidth = 4.8 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.35, -pHeight * 0.55, sway * 0.8, -pHeight);
  ctx.stroke();

  // Distinct pale node rings along culm
  ctx.strokeStyle = '#a7f3d0';
  ctx.lineWidth = 1.6 * zScale;
  for (let n = 1; n <= 4; n++) {
    const ny = -pHeight * (n / 5);
    const nx = sway * 0.8 * (n / 5);
    ctx.beginPath();
    ctx.moveTo(nx - 3 * zScale, ny);
    ctx.lineTo(nx + 3 * zScale, ny);
    ctx.stroke();
  }

  // Broad distichous leaves with prominent white midrib
  const leafAngles = [-0.65, 0.60, -0.55, 0.50];
  leafAngles.forEach((ang, idx) => {
    const ly = -pHeight * (0.35 + idx * 0.16);
    const lx = sway * (0.25 + idx * 0.16);
    ctx.save();
    ctx.translate(lx, ly);
    ctx.rotate(ang + sway * 0.03);

    // Leaf blade with cellular chloroplast texture
    ctx.fillStyle = '#059669';
    ctx.beginPath();
    ctx.ellipse(0, 0, 26 * zScale, 7 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Distinct pale white central midrib
    ctx.strokeStyle = '#dcfce7';
    ctx.lineWidth = 1.3 * zScale;
    ctx.beginPath();
    ctx.moveTo(-24 * zScale, 0);
    ctx.lineTo(24 * zScale, 0);
    ctx.stroke();

    ctx.restore();
  });

  // MASSIVE DENSE COMPACT GOLDEN-BROWN SEED PANICLE
  const headX = sway * 0.8;
  const headY = -pHeight;
  const headW = 15 * zScale;
  const headH = 30 * zScale;

  ctx.save();
  ctx.translate(headX, headY);
  ctx.rotate(sway * 0.05);

  const headGrad = ctx.createLinearGradient(0, -headH, 0, 0);
  headGrad.addColorStop(0, '#b45309');
  headGrad.addColorStop(0.5, '#d97706');
  headGrad.addColorStop(1, '#78350f');
  ctx.fillStyle = headGrad;
  ctx.beginPath();
  ctx.ellipse(0, -headH * 0.5, headW * 0.5, headH * 0.5, 0, 0, Math.PI * 2);
  ctx.fill();

  // Studded spherical sorghum grain beads with specular reflection
  for (let g = 0; g < 36; g++) {
    const gy = -headH + (g / 36) * headH;
    const gx = (Math.sin(g * 2.4) * headW * 0.42);
    ctx.fillStyle = g % 2 === 0 ? '#fde68a' : '#fbbf24';
    ctx.beginPath();
    ctx.arc(gx, gy, 1.8 * zScale, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#b45309';
    ctx.stroke();
  }
  ctx.restore();
}

function drawMilletSpike(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Sturdy fibrous culm
  ctx.strokeStyle = '#65a30d';
  ctx.lineWidth = 4.2 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.35, -pHeight * 0.6, sway * 0.85, -pHeight);
  ctx.stroke();

  // Linear flat leaf blades with cellular texture
  [-0.6, 0.6, -0.45, 0.45].forEach((ang, idx) => {
    ctx.save();
    ctx.translate(sway * 0.4, -pHeight * (0.35 + idx * 0.15));
    ctx.rotate(ang + sway * 0.03);
    ctx.fillStyle = '#4ade80';
    ctx.beginPath();
    ctx.ellipse(0, 0, 22 * zScale, 5.5 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    ctx.strokeStyle = '#bbf7d0';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(-20 * zScale, 0);
    ctx.lineTo(20 * zScale, 0);
    ctx.stroke();
    ctx.restore();
  });

  // ICONIC RIGID CYLINDRICAL "CANDLE SPIKE" (Bajra / Pearl Millet)
  const headX = sway * 0.85;
  const headY = -pHeight;
  const spikeW = 10 * zScale;
  const spikeH = 40 * zScale;

  ctx.save();
  ctx.translate(headX, headY);
  ctx.rotate(sway * 0.04);

  // Silvery-grey spike core
  const spikeGrad = ctx.createLinearGradient(-spikeW * 0.5, 0, spikeW * 0.5, 0);
  spikeGrad.addColorStop(0, '#64748b');
  spikeGrad.addColorStop(0.5, '#cbd5e1');
  spikeGrad.addColorStop(1, '#475569');
  ctx.fillStyle = spikeGrad;
  ctx.beginPath();
  ctx.roundRect(-spikeW * 0.5, -spikeH, spikeW, spikeH, spikeW * 0.45);
  ctx.fill();

  // Bristling involucral golden bristles
  ctx.strokeStyle = '#fbbf24';
  ctx.lineWidth = 0.9 * zScale;
  for (let br = 0; br < 26; br++) {
    const by = -spikeH + (br / 26) * spikeH;
    ctx.beginPath();
    ctx.moveTo(-spikeW * 0.5, by);
    ctx.lineTo(-spikeW * 0.5 - 5 * zScale, by - 2.5 * zScale);
    ctx.moveTo(spikeW * 0.5, by);
    ctx.lineTo(spikeW * 0.5 + 5 * zScale, by - 2.5 * zScale);
    ctx.stroke();
  }
  ctx.restore();
}

function drawMilletRagi(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Compact stalk topped with 4-6 finger spikes
  ctx.strokeStyle = '#65a30d';
  ctx.lineWidth = 3.2 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.3, -pHeight * 0.55, sway * 0.7, -pHeight);
  ctx.stroke();

  // Folded v-shaped cross-section linear leaves
  [-0.5, 0.5].forEach((ang, idx) => {
    ctx.save();
    ctx.translate(sway * 0.35, -pHeight * (0.4 + idx * 0.22));
    ctx.rotate(ang + sway * 0.04);
    ctx.fillStyle = '#22c55e';
    ctx.beginPath();
    ctx.ellipse(0, 0, 18 * zScale, 4.5 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 0.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(-16 * zScale, 0);
    ctx.lineTo(16 * zScale, 0);
    ctx.stroke();
    ctx.restore();
  });

  const apexX = sway * 0.7;
  const apexY = -pHeight;

  // Hand-like digitate curved fingers (Bird-foot arrangement)
  const fingerAngles = [-1.1, -0.65, -0.2, 0.2, 0.65, 1.1];
  fingerAngles.forEach(fa => {
    ctx.save();
    ctx.translate(apexX, apexY);
    ctx.rotate(fa + (sway * 0.04));
    const flen = 22 * zScale;

    // Curved finger body
    ctx.fillStyle = '#78350f';
    ctx.beginPath();
    ctx.roundRect(-3.0 * zScale, -flen, 6.0 * zScale, flen, 3.0 * zScale);
    ctx.fill();

    // Dense russet-brown grain beads
    ctx.fillStyle = '#b45309';
    for (let g = 0; g < 8; g++) {
      const gy = -flen + g * 2.8 * zScale + 1.5 * zScale;
      ctx.beginPath();
      ctx.arc(-1.4 * zScale, gy, 1.2 * zScale, 0, Math.PI * 2);
      ctx.arc(1.4 * zScale, gy, 1.2 * zScale, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  });
}

function drawOkraStalk(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Stiff erect fibrous green stalk with rough hispid hairs & purple node rings
  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 4.6 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(sway * 0.35, -pHeight);
  ctx.stroke();

  // Distinct reddish-purple node bands
  for (let n = 1; n <= 4; n++) {
    const ny = -pHeight * (n / 4.8);
    const nx = sway * 0.35 * (n / 4.8);
    ctx.strokeStyle = '#701a75';
    ctx.lineWidth = 5.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(nx - 2.5 * zScale, ny);
    ctx.lineTo(nx + 2.5 * zScale, ny);
    ctx.stroke();

    const isLeft = n % 2 === 0;

    // Deeply 3-to-5 lobed cordate palmate leaves
    ctx.save();
    ctx.translate(nx, ny);
    ctx.rotate(isLeft ? -0.55 + sway * 0.04 : 0.55 + sway * 0.04);

    const leafSz = 14 * zScale;
    ctx.fillStyle = '#16a34a';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(leafSz * 0.5, -leafSz * 0.4);
    ctx.lineTo(leafSz * 0.8, -leafSz * 0.8);
    ctx.lineTo(leafSz * 1.1, 0); // central lobe
    ctx.lineTo(leafSz * 0.8, leafSz * 0.8);
    ctx.lineTo(leafSz * 0.5, leafSz * 0.4);
    ctx.closePath();
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Palmate veins
    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 0.9 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(leafSz * 1.05, 0);
    ctx.moveTo(0, 0); ctx.lineTo(leafSz * 0.75, -leafSz * 0.75);
    ctx.moveTo(0, 0); ctx.lineTo(leafSz * 0.75, leafSz * 0.75);
    ctx.stroke();

    // UPWARD-POINTING 5-RIBBED PENTAGONAL LADYFINGER PODS
    const podLen = 22 * zScale;
    const podW = 5.5 * zScale;

    ctx.save();
    ctx.rotate(isLeft ? 0.35 : -0.35); // points sharply UP

    // Pod calyx cup
    ctx.fillStyle = '#14532d';
    ctx.beginPath();
    ctx.ellipse(3 * zScale, -2 * zScale, 3 * zScale, 1.8 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();

    // Tapered pentagonal pod body
    const podGrad = ctx.createLinearGradient(0, -2 * zScale, 0, -podLen);
    podGrad.addColorStop(0, '#16a34a');
    podGrad.addColorStop(0.5, '#22c55e');
    podGrad.addColorStop(1, '#86efac');
    ctx.fillStyle = podGrad;

    ctx.beginPath();
    ctx.moveTo(0, -2 * zScale);
    ctx.lineTo(-podW * 0.5, -2 * zScale);
    ctx.lineTo(0, -podLen); // sharp apical beak
    ctx.lineTo(podW * 0.5, -2 * zScale);
    ctx.closePath();
    ctx.fill();

    // 5 longitudinal ridges
    ctx.strokeStyle = '#14532d';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, -2 * zScale); ctx.lineTo(0, -podLen);
    ctx.moveTo(-podW * 0.25, -2 * zScale); ctx.lineTo(0, -podLen * 0.95);
    ctx.moveTo(podW * 0.25, -2 * zScale); ctx.lineTo(0, -podLen * 0.95);
    ctx.stroke();

    ctx.restore();
    ctx.restore();
  }

  // Spectacular creamy-yellow hibiscus-like flower with deep maroon throat
  const topX = sway * 0.35;
  const topY = -pHeight;

  ctx.save();
  ctx.translate(topX, topY);
  ctx.rotate(sway * 0.05);

  // 5 broad crinkled pale yellow petals
  for (let pt = 0; pt < 5; pt++) {
    const ptAng = (pt / 5) * Math.PI * 2;
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.ellipse(Math.cos(ptAng) * 4.5 * zScale, Math.sin(ptAng) * 4.5 * zScale, 5.2 * zScale, 3.4 * zScale, ptAng + 0.3, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 0.8 * zScale;
    ctx.stroke();
  }

  // Deep crimson/maroon center throat
  ctx.fillStyle = '#7f1d1d';
  ctx.beginPath();
  ctx.arc(0, 0, 3.0 * zScale, 0, Math.PI * 2);
  ctx.fill();

  // Protruding golden staminal column
  ctx.strokeStyle = '#f59e0b';
  ctx.lineWidth = 1.6 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(1.5 * zScale, -4 * zScale);
  ctx.stroke();
  ctx.fillStyle = '#fbbf24';
  ctx.beginPath();
  ctx.arc(1.5 * zScale, -4 * zScale, 1.2 * zScale, 0, Math.PI * 2);
  ctx.fill();

  ctx.restore();
}

function drawOnionGarlic(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const bulbX = 0;
  const bulbY = 2 * zScale;
  const bulbR = 9.0 * zScale;

  // Root plate & dense cluster of feeder roots digging down into loam
  ctx.strokeStyle = '#fef3c7';
  ctx.lineWidth = 1.0 * zScale;
  for (let r = -4; r <= 4; r++) {
    ctx.beginPath();
    ctx.moveTo(bulbX + r * 1.8 * zScale, bulbY + bulbR * 0.8);
    ctx.quadraticCurveTo(bulbX + (r * 2.2 + (r % 2 === 0 ? 2 : -2)) * zScale, bulbY + bulbR * 0.8 + 6 * zScale, bulbX + r * 2.5 * zScale, bulbY + bulbR * 0.8 + 12 * zScale);
    ctx.stroke();
  }

  // Swollen tunic bulb with papery tunic coats
  const bulbGrad = ctx.createRadialGradient(bulbX - 2.5 * zScale, bulbY - 2 * zScale, 2 * zScale, bulbX, bulbY, bulbR);
  bulbGrad.addColorStop(0, '#f87171');
  bulbGrad.addColorStop(0.45, fruitCol || '#b91c1c'); // rich ruby-red onion tunic
  bulbGrad.addColorStop(1, '#450a0a');
  ctx.fillStyle = bulbGrad;

  ctx.beginPath();
  ctx.ellipse(bulbX, bulbY, bulbR, bulbR * 0.85, 0, 0, Math.PI * 2);
  ctx.fill();

  // Papery dry tunic striations
  ctx.strokeStyle = 'rgba(254, 202, 202, 0.45)';
  ctx.lineWidth = 0.8 * zScale;
  for (let s = -3; s <= 3; s++) {
    ctx.beginPath();
    ctx.ellipse(bulbX + s * 1.6 * zScale, bulbY, bulbR * 0.35, bulbR * 0.8, s * 0.1, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Hollow tubular scapes (cylindrical green leaves)
  const scapes = [-0.35, -0.15, 0.05, 0.25, 0.45];
  scapes.forEach(sa => {
    ctx.save();
    ctx.translate(bulbX, bulbY - bulbR * 0.7);
    ctx.rotate(sa + sway * 0.035);

    const slen = pHeight * 1.15;
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 3.2 * zScale;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(sa * 6 * zScale, -slen * 0.6, sa * 12 * zScale, -slen);
    ctx.stroke();

    // Waxy light bloom streak with cellular texture
    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 1.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(0.8 * zScale, 0);
    ctx.quadraticCurveTo(sa * 6 * zScale + 0.8 * zScale, -slen * 0.6, sa * 12 * zScale + 0.8 * zScale, -slen);
    ctx.stroke();

    ctx.restore();
  });

  // Spherical globose flowering umbel head
  const umbelX = bulbX + sway * 0.4;
  const umbelY = -pHeight * 1.25;
  const umbelR = 6.5 * zScale;

  ctx.save();
  ctx.translate(umbelX, umbelY);

  // Papery spathe bracts
  ctx.fillStyle = '#fef08a';
  ctx.beginPath();
  ctx.moveTo(0, 2 * zScale);
  ctx.lineTo(-3 * zScale, 6 * zScale);
  ctx.lineTo(3 * zScale, 6 * zScale);
  ctx.closePath();
  ctx.fill();

  // Dense sphere of star florets
  ctx.fillStyle = '#ffffff';
  ctx.beginPath();
  ctx.arc(0, 0, umbelR, 0, Math.PI * 2);
  ctx.fill();

  // Individual miniature floret petals
  ctx.strokeStyle = '#dcfce7';
  ctx.lineWidth = 0.8 * zScale;
  for (let f = 0; f < 16; f++) {
    const fa = (f / 16) * Math.PI * 2;
    const fx = Math.cos(fa) * umbelR;
    const fy = Math.sin(fa) * umbelR;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(fx, fy);
    ctx.stroke();
    ctx.fillStyle = '#e2e8f0';
    ctx.beginPath();
    ctx.arc(fx, fy, 1.2 * zScale, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawCarrotRadish(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Conical taproot shoulder pushing out of furrow crest
  const rootCol = fruitCol || '#ea580c';
  const rootW = 6.5 * zScale;
  const rootDepth = 15 * zScale;

  // Taproot body
  const rootGrad = ctx.createLinearGradient(-rootW, -2 * zScale, rootW, -2 * zScale);
  rootGrad.addColorStop(0, rootCol);
  rootGrad.addColorStop(0.3, '#fdba74'); // sunlit shoulder highlight
  rootGrad.addColorStop(1, '#9a3412');
  ctx.fillStyle = rootGrad;

  ctx.beginPath();
  ctx.moveTo(-rootW, -3 * zScale);
  ctx.quadraticCurveTo(-rootW * 0.8, rootDepth * 0.5, 0, rootDepth); // tapered root tip
  ctx.quadraticCurveTo(rootW * 0.8, rootDepth * 0.5, rootW, -3 * zScale);
  ctx.closePath();
  ctx.fill();

  // Horizontal lenticels & root rings
  ctx.strokeStyle = '#7c2d12';
  ctx.lineWidth = 0.9 * zScale;
  for (let l = 1; l <= 4; l++) {
    const ly = l * 3.0 * zScale - 2 * zScale;
    const lw = rootW * (1 - l / 5);
    ctx.beginPath();
    ctx.moveTo(-lw * 0.8, ly);
    ctx.lineTo(lw * 0.8, ly);
    ctx.stroke();
  }

  // Fine lateral feeder root hairs
  ctx.strokeStyle = '#fef08a';
  ctx.lineWidth = 0.7 * zScale;
  for (let r = 1; r <= 3; r++) {
    const ry = r * 3.5 * zScale;
    ctx.beginPath();
    ctx.moveTo(-rootW * 0.5, ry); ctx.lineTo(-rootW * 0.5 - 3 * zScale, ry + 2 * zScale);
    ctx.moveTo(rootW * 0.5, ry); ctx.lineTo(rootW * 0.5 + 3 * zScale, ry + 2 * zScale);
    ctx.stroke();
  }

  // Dense rosette of airy, feathery 2-3 pinnate compound carrot frills
  const fronds = [-0.75, -0.45, -0.15, 0.15, 0.45, 0.75];
  fronds.forEach(fa => {
    ctx.save();
    ctx.translate(0, -3 * zScale);
    ctx.rotate(fa + sway * 0.045);

    const len = pHeight * 1.1;
    // Central rachis
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 1.4 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -len);
    ctx.stroke();

    // Delicate dissected lace-like leaf segments
    ctx.strokeStyle = '#22c55e';
    ctx.lineWidth = 0.85 * zScale;
    for (let f = 1; f <= 7; f++) {
      const fy = -len * (f / 7.5);
      const fSpan = (1 - f / 8.5) * 7.5 * zScale;

      ctx.beginPath();
      ctx.moveTo(0, fy);
      ctx.lineTo(-fSpan, fy - 2.5 * zScale);
      ctx.lineTo(-fSpan - 2 * zScale, fy - 1 * zScale);
      ctx.moveTo(0, fy);
      ctx.lineTo(fSpan, fy - 2.5 * zScale);
      ctx.lineTo(fSpan + 2 * zScale, fy - 1 * zScale);
      ctx.stroke();
    }
    ctx.restore();
  });
}

function drawCabbageBrassica(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const headR = 12 * zScale;

  // Broad spreading wavy outer wrapper leaves resting on soil
  const leafAngles = [0, 0.9, 1.8, 2.7, 3.6, 4.5, 5.4];
  leafAngles.forEach(la => {
    const lx = Math.cos(la) * 7 * zScale;
    const ly = Math.sin(la) * 4 * zScale - headR * 0.4;
    const leafLen = 18 * zScale;
    const leafW = 11 * zScale;

    ctx.save();
    ctx.translate(lx, ly);
    ctx.rotate(la);

    const wrapGrad = ctx.createRadialGradient(0, 0, 2 * zScale, 0, 0, leafLen);
    wrapGrad.addColorStop(0, '#15803d');
    wrapGrad.addColorStop(0.7, '#166534');
    wrapGrad.addColorStop(1, '#14532d');
    ctx.fillStyle = wrapGrad;

    ctx.beginPath();
    ctx.ellipse(0, 0, leafLen, leafW, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Distinct pale white/ivory radiating venation
    ctx.strokeStyle = '#bbf7d0';
    ctx.lineWidth = 1.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(-leafLen * 0.7, 0); ctx.lineTo(leafLen * 0.7, 0);
    ctx.stroke();

    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 0.8 * zScale;
    for (let v = -2; v <= 2; v++) {
      ctx.beginPath();
      ctx.moveTo(v * 4 * zScale, 0);
      ctx.lineTo(v * 4 * zScale + 3 * zScale, -leafW * 0.65);
      ctx.moveTo(v * 4 * zScale, 0);
      ctx.lineTo(v * 4 * zScale + 3 * zScale, leafW * 0.65);
      ctx.stroke();
    }

    ctx.restore();
  });

  // Solid, crisp, tightly-wrapped pale green / cream cabbage head ON TOP
  const headGrad = ctx.createRadialGradient(-3 * zScale, -headR * 0.8, 2 * zScale, 0, -headR * 0.55, headR);
  headGrad.addColorStop(0, '#dcfce7'); // sunlit pale waxy center
  headGrad.addColorStop(0.5, '#86efac');
  headGrad.addColorStop(1, '#22c55e');
  ctx.fillStyle = headGrad;

  ctx.beginPath();
  ctx.arc(0, -headR * 0.55, headR, 0, Math.PI * 2);
  ctx.fill();

  // Overlapping savoyed leaf fold contours
  ctx.strokeStyle = '#4ade80';
  ctx.lineWidth = 1.2 * zScale;
  ctx.beginPath();
  ctx.arc(-2 * zScale, -headR * 0.6, headR * 0.75, 0.4, 2.6);
  ctx.arc(2 * zScale, -headR * 0.5, headR * 0.7, 3.2, 5.8);
  ctx.stroke();
}

function drawPotatoCrop(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Robust herbaceous multi-stem bush with winged angled stems
  const mainStems = [
    { dx: -7 * zScale, dy: -pHeight * 0.85, rot: -0.22 + sway * 0.15 },
    { dx: sway * 0.3, dy: -pHeight * 0.95, rot: sway * 0.12 },
    { dx: 8 * zScale, dy: -pHeight * 0.82, rot: 0.25 + sway * 0.14 }
  ];

  ctx.lineCap = 'round';
  mainStems.forEach(stem => {
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 3.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(stem.dx * 0.5, stem.dy * 0.5, stem.dx, stem.dy);
    ctx.stroke();

    // Winged stem ridge highlight
    ctx.strokeStyle = '#4ade80';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(1 * zScale, 0);
    ctx.quadraticCurveTo(stem.dx * 0.5 + 1 * zScale, stem.dy * 0.5, stem.dx + 0.5 * zScale, stem.dy);
    ctx.stroke();
  });

  // Imparipinnate compound leaves: paired lateral leaflets + large terminal leaflet + small intercalary leaflets
  const leafNodes = [
    { x: -5 * zScale, y: -pHeight * 0.35, rot: -0.65 },
    { x: 5 * zScale, y: -pHeight * 0.42, rot: 0.60 },
    { x: -9 * zScale, y: -pHeight * 0.62, rot: -0.75 },
    { x: 9 * zScale, y: -pHeight * 0.68, rot: 0.70 },
    { x: sway * 0.3, y: -pHeight * 0.92, rot: 0 }
  ];

  leafNodes.forEach(ln => {
    ctx.save();
    ctx.translate(ln.x, ln.y);
    ctx.rotate(ln.rot);

    // Dark olive-green compound foliage with visible veins
    const leafletColor = '#166534';
    const veinColor = '#86efac';

    // Terminal large ovate leaflet
    ctx.fillStyle = leafletColor;
    ctx.beginPath();
    ctx.ellipse(0, -9 * zScale, 6.2 * zScale, 9.5 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    ctx.strokeStyle = veinColor;
    ctx.lineWidth = 0.9 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -18 * zScale);
    // Lateral veinlets
    ctx.moveTo(-4 * zScale, -11 * zScale); ctx.lineTo(0, -8 * zScale); ctx.lineTo(4 * zScale, -11 * zScale);
    ctx.moveTo(-4.5 * zScale, -6 * zScale); ctx.lineTo(0, -3 * zScale); ctx.lineTo(4.5 * zScale, -6 * zScale);
    ctx.stroke();

    // Paired lateral leaflets
    [-1, 1].forEach(side => {
      ctx.fillStyle = '#15803d';
      ctx.beginPath();
      ctx.ellipse(side * 8 * zScale, -5 * zScale, 4.8 * zScale, 7 * zScale, side * 0.45, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);

      // Tiny intercalary leaflets between pairs
      ctx.fillStyle = '#16a34a';
      ctx.beginPath();
      ctx.ellipse(side * 3.8 * zScale, -1 * zScale, 2.2 * zScale, 3.2 * zScale, side * 0.3, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.restore();
  });

  // Apical cluster of star-shaped potato flowers (violet/white with yellow stamen cone)
  const flowerX = sway * 0.3 + 2 * zScale;
  const flowerY = -pHeight * 0.98;
  [-3, 3].forEach(off => {
    const fx = flowerX + off * zScale;
    const fy = flowerY + (off > 0 ? -3 * zScale : 0);
    // 5 violet-white star petals
    ctx.fillStyle = '#e0e7ff';
    for (let pIdx = 0; pIdx < 5; pIdx++) {
      const pAng = (pIdx / 5) * Math.PI * 2;
      ctx.beginPath();
      ctx.ellipse(fx + Math.cos(pAng) * 3 * zScale, fy + Math.sin(pAng) * 3 * zScale, 1.6 * zScale, 3 * zScale, pAng, 0, Math.PI * 2);
      ctx.fill();
    }
    // Golden-yellow anther cone
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(fx, fy, 1.8 * zScale, 0, Math.PI * 2);
    ctx.fill();
  });

  // Subterranean stolons & realistic russet potato tubers with eyes nestled in topsoil
  const tubers = [
    { tx: -9 * zScale, ty: 4 * zScale, rw: 8.5 * zScale, rh: 5.5 * zScale, rot: 0.25 },
    { tx: 8 * zScale, ty: 5.5 * zScale, rw: 9 * zScale, rh: 6 * zScale, rot: -0.20 },
    { tx: -1 * zScale, ty: 7 * zScale, rw: 7 * zScale, rh: 4.8 * zScale, rot: 0.05 }
  ];

  tubers.forEach(tb => {
    // White-yellow stolon rootlet
    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(tb.tx * 0.5, tb.ty * 0.3, tb.tx, tb.ty);
    ctx.stroke();

    // Russet brown skin with depth gradient
    const tubGrad = ctx.createRadialGradient(tb.tx - 2 * zScale, tb.ty - 1.5 * zScale, 1, tb.tx, tb.ty, tb.rw);
    tubGrad.addColorStop(0, '#ca8a04');
    tubGrad.addColorStop(0.55, '#854d0e');
    tubGrad.addColorStop(1, '#451a03');
    ctx.fillStyle = tubGrad;
    ctx.beginPath();
    ctx.ellipse(tb.tx, tb.ty, tb.rw, tb.rh, tb.rot, 0, Math.PI * 2);
    ctx.fill();

    // Fine potato eyes (dormant buds) & lenticels
    ctx.fillStyle = '#291403';
    [-0.5, 0, 0.45].forEach(et => {
      const ex = tb.tx + Math.cos(tb.rot) * (tb.rw * et);
      const ey = tb.ty + Math.sin(tb.rot) * (tb.rh * et);
      ctx.beginPath();
      ctx.arc(ex, ey, 1.1 * zScale, 0, Math.PI * 2);
      ctx.fill();
    });
  });
}

function drawBrinjalEggplant(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Sturdy purple-tinged woody-herbaceous main stalk
  ctx.strokeStyle = '#3b0764';
  ctx.lineWidth = 4.2 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.15, -pHeight * 0.45, sway * 0.3, -pHeight * 0.9);
  ctx.stroke();

  // Lateral branches
  const branches = [
    { bx1: sway * 0.1, by1: -pHeight * 0.35, bx2: -14 * zScale, by2: -pHeight * 0.55 },
    { bx1: sway * 0.2, by1: -pHeight * 0.52, bx2: 15 * zScale, by2: -pHeight * 0.72 }
  ];
  branches.forEach(b => {
    ctx.strokeStyle = '#4c1d95';
    ctx.lineWidth = 2.6 * zScale;
    ctx.beginPath();
    ctx.moveTo(b.bx1, b.by1);
    ctx.lineTo(b.bx2, b.by2);
    ctx.stroke();
  });

  // Large velvety ovate-oblong leaves with sinuate wavy lobed margins and purple veins
  const leafSpans = [
    { lx: -15 * zScale, ly: -pHeight * 0.56, rot: -0.55, len: 14 * zScale, w: 9 * zScale },
    { lx: 16 * zScale, ly: -pHeight * 0.73, rot: 0.50, len: 13 * zScale, w: 8.5 * zScale },
    { lx: sway * 0.3 - 4 * zScale, ly: -pHeight * 0.92, rot: -0.25, len: 12 * zScale, w: 8 * zScale },
    { lx: sway * 0.3 + 6 * zScale, ly: -pHeight * 0.88, rot: 0.35, len: 12 * zScale, w: 7.8 * zScale }
  ];

  leafSpans.forEach(ls => {
    ctx.save();
    ctx.translate(ls.lx, ls.ly);
    ctx.rotate(ls.rot);

    // Deep forest green blade
    ctx.fillStyle = '#14532d';
    ctx.beginPath();
    ctx.ellipse(0, 0, ls.len, ls.w, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Purple midrib and primary veins
    ctx.strokeStyle = '#6b21a8';
    ctx.lineWidth = 1.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(-ls.len * 0.9, 0); ctx.lineTo(ls.len * 0.9, 0);
    ctx.moveTo(-ls.len * 0.4, -ls.w * 0.6); ctx.lineTo(0, 0); ctx.lineTo(ls.len * 0.4, -ls.w * 0.6);
    ctx.moveTo(-ls.len * 0.4, ls.w * 0.6); ctx.lineTo(0, 0); ctx.lineTo(ls.len * 0.4, ls.w * 0.6);
    ctx.stroke();

    ctx.restore();
  });

  // Violet star flower with bright yellow stamen cone
  const flX = -12 * zScale;
  const flY = -pHeight * 0.62;
  ctx.fillStyle = '#a855f7';
  for (let s = 0; s < 5; s++) {
    const sAng = (s / 5) * Math.PI * 2;
    ctx.beginPath();
    ctx.ellipse(flX + Math.cos(sAng) * 3 * zScale, flY + Math.sin(sAng) * 3 * zScale, 1.8 * zScale, 3.2 * zScale, sAng, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = '#facc15';
  ctx.beginPath();
  ctx.arc(flX, flY, 2 * zScale, 0, Math.PI * 2);
  ctx.fill();

  // LARGE, GLOSSY ROYAL-PURPLE TEARDROP EGGPLANTS
  const eggplants = [
    { ex: 14 * zScale, ey: -pHeight * 0.52, ew: 8.5 * zScale, eh: 17 * zScale, rot: 0.18 },
    { ex: -6 * zScale, ey: -pHeight * 0.38, ew: 7.2 * zScale, eh: 14 * zScale, rot: -0.15 }
  ];

  eggplants.forEach(egg => {
    // Pedicel (stem)
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 2.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(egg.ex, egg.ey - egg.eh * 0.5 - 5 * zScale);
    ctx.lineTo(egg.ex, egg.ey - egg.eh * 0.5);
    ctx.stroke();

    // Spiky 5-toothed green calyx hood with prickly lobes
    ctx.fillStyle = '#15803d';
    ctx.beginPath();
    for (let c = 0; c < 5; c++) {
      const cAng = (c / 5) * Math.PI + Math.PI;
      const cLen = 7 * zScale;
      ctx.lineTo(egg.ex + Math.cos(cAng) * egg.ew * 0.9, egg.ey - egg.eh * 0.45 + Math.sin(cAng) * (3 * zScale));
      ctx.lineTo(egg.ex + Math.cos(cAng + 0.3) * cLen, egg.ey - egg.eh * 0.45 + 5 * zScale);
    }
    ctx.closePath();
    ctx.fill();

    // Deep lustrous purple body with volumetric gradient
    const eggGrad = ctx.createRadialGradient(egg.ex - egg.ew * 0.35, egg.ey, 1, egg.ex, egg.ey, egg.eh * 0.7);
    eggGrad.addColorStop(0, '#6b21a8');
    eggGrad.addColorStop(0.35, '#3b0764');
    eggGrad.addColorStop(0.85, '#1e1b4b');
    eggGrad.addColorStop(1, '#0f0e17');
    ctx.fillStyle = eggGrad;
    ctx.beginPath();
    ctx.ellipse(egg.ex, egg.ey, egg.ew, egg.eh * 0.5, egg.rot, 0, Math.PI * 2);
    ctx.fill();

    // Long curved specular high-gloss glint
    ctx.fillStyle = 'rgba(255, 255, 255, 0.62)';
    ctx.beginPath();
    ctx.ellipse(egg.ex - egg.ew * 0.35, egg.ey - egg.eh * 0.12, 1.8 * zScale, 5.5 * zScale, egg.rot - 0.1, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawFruitingBush(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Staked indeterminate vine structure with bamboo support & twine
  const stakeX = sway * 0.15;
  ctx.strokeStyle = '#78350f';
  ctx.lineWidth = 3.4 * zScale;
  ctx.lineCap = 'butt';
  ctx.beginPath();
  ctx.moveTo(stakeX + 6 * zScale, 0);
  ctx.lineTo(stakeX + 6 * zScale, -pHeight * 1.05);
  ctx.stroke();

  // Natural twine ties
  ctx.strokeStyle = '#fef08a';
  ctx.lineWidth = 1.0 * zScale;
  [-pHeight * 0.35, -pHeight * 0.65, -pHeight * 0.9].forEach(tieY => {
    ctx.beginPath();
    ctx.arc(stakeX + 5 * zScale, tieY, 3 * zScale, 0, Math.PI * 2);
    ctx.stroke();
  });

  // Main vigorous branching vine with glandular hairs
  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 4.2 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.3 - 5 * zScale, -pHeight * 0.45, sway * 0.4, -pHeight * 0.95);
  ctx.stroke();

  // Lateral fruiting branches
  const branches = [
    { x1: 0, y1: -pHeight * 0.28, x2: -15 * zScale, y2: -pHeight * 0.48 },
    { x1: sway * 0.2, y1: -pHeight * 0.52, x2: 17 * zScale, y2: -pHeight * 0.72 },
    { x1: sway * 0.35, y1: -pHeight * 0.75, x2: -12 * zScale, y2: -pHeight * 0.88 }
  ];
  branches.forEach(b => {
    ctx.strokeStyle = '#16a34a';
    ctx.lineWidth = 2.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(b.x1, b.y1);
    ctx.quadraticCurveTo((b.x1 + b.x2) * 0.5, (b.y1 + b.y2) * 0.5 - 4 * zScale, b.x2, b.y2);
    ctx.stroke();
  });

  // Deeply dentate, serrated tomato foliage with strong vein relief
  const leafPositions = [
    { lx: -16 * zScale, ly: -pHeight * 0.50, rot: -0.55 },
    { lx: 18 * zScale, ly: -pHeight * 0.74, rot: 0.50 },
    { lx: -14 * zScale, ly: -pHeight * 0.90, rot: -0.65 },
    { lx: sway * 0.4 + 4 * zScale, ly: -pHeight * 0.96, rot: 0.25 },
    { lx: -6 * zScale, ly: -pHeight * 0.35, rot: -0.45 },
    { lx: 8 * zScale, ly: -pHeight * 0.42, rot: 0.40 }
  ];

  leafPositions.forEach(lp => {
    ctx.save();
    ctx.translate(lp.lx, lp.ly);
    ctx.rotate(lp.rot);

    // Compound dentate leaflet outline
    ctx.fillStyle = '#14532d';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(-4 * zScale, -5 * zScale);
    ctx.lineTo(-6.5 * zScale, -4 * zScale);
    ctx.lineTo(-4.5 * zScale, -9 * zScale);
    ctx.lineTo(-7 * zScale, -8 * zScale);
    ctx.lineTo(0, -16 * zScale); // tip
    ctx.lineTo(7 * zScale, -8 * zScale);
    ctx.lineTo(4.5 * zScale, -9 * zScale);
    ctx.lineTo(6.5 * zScale, -4 * zScale);
    ctx.lineTo(4 * zScale, -5 * zScale);
    ctx.closePath();
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Pale green midvein and serrate ribs
    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(0, -15 * zScale);
    ctx.moveTo(-4 * zScale, -7 * zScale); ctx.lineTo(0, -5 * zScale); ctx.lineTo(4 * zScale, -7 * zScale);
    ctx.moveTo(-3 * zScale, -12 * zScale); ctx.lineTo(0, -10 * zScale); ctx.lineTo(3 * zScale, -12 * zScale);
    ctx.stroke();

    ctx.restore();
  });

  // Clusters of bright yellow star-shaped flowers
  const flowerTrusses = [
    { fx: -10 * zScale, fy: -pHeight * 0.62 },
    { fx: 12 * zScale, fy: -pHeight * 0.84 }
  ];
  flowerTrusses.forEach(ft => {
    for (let fl = 0; fl < 3; fl++) {
      const flAng = (fl / 3) * Math.PI * 0.8;
      const flX = ft.fx + Math.cos(flAng) * 4 * zScale;
      const flY = ft.fy + Math.sin(flAng) * 3 * zScale;

      ctx.fillStyle = '#facc15';
      for (let pIdx = 0; pIdx < 5; pIdx++) {
        const pa = (pIdx / 5) * Math.PI * 2;
        ctx.beginPath();
        ctx.ellipse(flX + Math.cos(pa) * 2.2 * zScale, flY + Math.sin(pa) * 2.2 * zScale, 1.2 * zScale, 2.4 * zScale, pa, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = '#15803d';
      ctx.beginPath();
      ctx.arc(flX, flY, 1.2 * zScale, 0, Math.PI * 2);
      ctx.fill();
    }
  });

  // Ripening Truss of Scarlet Beefsteak Tomatoes (Green $\to$ Breaker $\to$ Radiant Red)
  const tomatoTruss = [
    { tx: -11 * zScale, ty: -pHeight * 0.44, r: 8.5 * zScale, stage: 'ripe' },
    { tx: -5 * zScale, ty: -pHeight * 0.40, r: 7.2 * zScale, stage: 'ripe' },
    { tx: 13 * zScale, ty: -pHeight * 0.65, r: 7.8 * zScale, stage: 'breaker' },
    { tx: 8 * zScale, ty: -pHeight * 0.70, r: 6.2 * zScale, stage: 'green' }
  ];

  tomatoTruss.forEach(tom => {
    // Pedicel stem
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 1.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(tom.tx, tom.ty - tom.r * 0.9 - 4 * zScale);
    ctx.lineTo(tom.tx, tom.ty - tom.r * 0.8);
    ctx.stroke();

    // Volumetric 3D gradient matching ripening stage
    const tGrad = ctx.createRadialGradient(tom.tx - tom.r * 0.35, tom.ty - tom.r * 0.35, 1, tom.tx, tom.ty, tom.r);
    if (tom.stage === 'ripe') {
      tGrad.addColorStop(0, '#f87171');
      tGrad.addColorStop(0.35, '#dc2626');
      tGrad.addColorStop(0.85, '#991b1b');
      tGrad.addColorStop(1, '#450a0a');
    } else if (tom.stage === 'breaker') {
      tGrad.addColorStop(0, '#fde047');
      tGrad.addColorStop(0.40, '#f97316');
      tGrad.addColorStop(0.85, '#ea580c');
      tGrad.addColorStop(1, '#7c2d12');
    } else {
      tGrad.addColorStop(0, '#86efac');
      tGrad.addColorStop(0.45, '#22c55e');
      tGrad.addColorStop(0.85, '#15803d');
      tGrad.addColorStop(1, '#14532d');
    }

    ctx.fillStyle = tGrad;
    ctx.beginPath();
    ctx.arc(tom.tx, tom.ty, tom.r, 0, Math.PI * 2);
    ctx.fill();

    // 5-to-6 Pointed Star Calyx (Green Sepals)
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 1.6 * zScale;
    for (let sep = 0; sep < 5; sep++) {
      const sepAng = (sep / 5) * Math.PI * 2;
      ctx.beginPath();
      ctx.moveTo(tom.tx, tom.ty - tom.r * 0.85);
      ctx.lineTo(tom.tx + Math.cos(sepAng) * (tom.r * 0.65), tom.ty - tom.r * 0.85 + Math.sin(sepAng) * (tom.r * 0.65));
      ctx.stroke();
    }

    // High-gloss specular highlight arc
    ctx.fillStyle = 'rgba(255, 255, 255, 0.72)';
    ctx.beginPath();
    ctx.ellipse(tom.tx - tom.r * 0.35, tom.ty - tom.r * 0.35, tom.r * 0.3, tom.r * 0.2, -0.4, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawChilliPepper(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Dichotomous branching woody bush with purple node joints
  const mainX = sway * 0.3;
  ctx.strokeStyle = '#166534';
  ctx.lineWidth = 3.6 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(mainX * 0.5, -pHeight * 0.45);
  ctx.stroke();

  // Swollen purple-ringed node
  ctx.fillStyle = '#4c1d95';
  ctx.beginPath();
  ctx.arc(mainX * 0.5, -pHeight * 0.45, 2.4 * zScale, 0, Math.PI * 2);
  ctx.fill();

  // Y-fork secondary branches
  const yBranches = [
    { x1: mainX * 0.5, y1: -pHeight * 0.45, x2: mainX - 12 * zScale, y2: -pHeight * 0.82 },
    { x1: mainX * 0.5, y1: -pHeight * 0.45, x2: mainX + 13 * zScale, y2: -pHeight * 0.85 }
  ];
  yBranches.forEach(yb => {
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 2.6 * zScale;
    ctx.beginPath();
    ctx.moveTo(yb.x1, yb.y1);
    ctx.lineTo(yb.x2, yb.y2);
    ctx.stroke();

    // Tertiary branch tips
    ctx.strokeStyle = '#16a34a';
    ctx.lineWidth = 1.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(yb.x2, yb.y2);
    ctx.lineTo(yb.x2 + (yb.x2 > 0 ? 6 : -6) * zScale, -pHeight * 0.98);
    ctx.stroke();
  });

  // Glossy emerald lanceolate leaves with tapered spear points & herringbone veins
  const leaves = [
    { lx: -11 * zScale, ly: -pHeight * 0.52, rot: -0.65, len: 13 * zScale, w: 5.5 * zScale },
    { lx: 12 * zScale, ly: -pHeight * 0.55, rot: 0.60, len: 14 * zScale, w: 5.8 * zScale },
    { lx: mainX - 14 * zScale, ly: -pHeight * 0.84, rot: -0.75, len: 12 * zScale, w: 5.2 * zScale },
    { lx: mainX + 15 * zScale, ly: -pHeight * 0.86, rot: 0.70, len: 13 * zScale, w: 5.4 * zScale },
    { lx: mainX - 3 * zScale, ly: -pHeight * 0.96, rot: -0.20, len: 11 * zScale, w: 4.8 * zScale },
    { lx: mainX + 4 * zScale, ly: -pHeight * 0.97, rot: 0.25, len: 11 * zScale, w: 4.8 * zScale }
  ];

  leaves.forEach(lf => {
    ctx.save();
    ctx.translate(lf.lx, lf.ly);
    ctx.rotate(lf.rot);

    // Vivid emerald green blade (Capsicum hallmark)
    const leafGrad = ctx.createLinearGradient(0, -lf.len, 0, lf.len);
    leafGrad.addColorStop(0, '#10b981');
    leafGrad.addColorStop(0.5, '#059669');
    leafGrad.addColorStop(1, '#047857');
    ctx.fillStyle = leafGrad;
    ctx.beginPath();
    ctx.ellipse(0, 0, lf.w, lf.len, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Ivory/light-green central midrib & lateral herringbone veins
    ctx.strokeStyle = '#a7f3d0';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, -lf.len * 0.9); ctx.lineTo(0, lf.len * 0.9);
    // Lateral veins branching at 45 degrees
    ctx.moveTo(-lf.w * 0.7, -lf.len * 0.4); ctx.lineTo(0, -lf.len * 0.2); ctx.lineTo(lf.w * 0.7, -lf.len * 0.4);
    ctx.moveTo(-lf.w * 0.7, lf.len * 0.2); ctx.lineTo(0, lf.len * 0.4); ctx.lineTo(lf.w * 0.7, lf.len * 0.2);
    ctx.stroke();

    ctx.restore();
  });

  // Pendant white 5-petaled star flowers with purple anthers
  const flowerPositions = [
    { fx: mainX * 0.5 - 2 * zScale, fy: -pHeight * 0.48 },
    { fx: mainX + 9 * zScale, fy: -pHeight * 0.80 }
  ];
  flowerPositions.forEach(fl => {
    ctx.fillStyle = '#ffffff';
    for (let pIdx = 0; pIdx < 5; pIdx++) {
      const pa = (pIdx / 5) * Math.PI * 2;
      ctx.beginPath();
      ctx.ellipse(fl.fx + Math.cos(pa) * 2 * zScale, fl.fy + Math.sin(pa) * 2 * zScale, 1.0 * zScale, 2.2 * zScale, pa, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = '#7c3aed';
    ctx.beginPath();
    ctx.arc(fl.fx, fl.fy, 1.2 * zScale, 0, Math.PI * 2);
    ctx.fill();
  });

  // Glossy, Slender, Curved Pendant Chillies (Vibrant Emerald Green & Fiery Scarlet Red)
  const chillies = [
    { cx: mainX - 8 * zScale, cy: -pHeight * 0.48, len: 16 * zScale, curve: 4 * zScale, col: '#dc2626', calyx: '#15803d' },
    { cx: mainX + 9 * zScale, cy: -pHeight * 0.52, len: 17 * zScale, curve: -4.5 * zScale, col: '#16a34a', calyx: '#14532d' },
    { cx: mainX - 4 * zScale, cy: -pHeight * 0.78, len: 14 * zScale, curve: 3.5 * zScale, col: '#ef4444', calyx: '#15803d' },
    { cx: mainX + 6 * zScale, cy: -pHeight * 0.82, len: 13 * zScale, curve: -3 * zScale, col: '#22c55e', calyx: '#14532d' }
  ];

  chillies.forEach(ch => {
    // Pedicel stem attaching chilli to node
    ctx.strokeStyle = ch.calyx;
    ctx.lineWidth = 1.6 * zScale;
    ctx.beginPath();
    ctx.moveTo(ch.cx, ch.cy - 3 * zScale);
    ctx.lineTo(ch.cx, ch.cy);
    ctx.stroke();

    // 5-toothed calyx cap
    ctx.fillStyle = ch.calyx;
    ctx.beginPath();
    ctx.arc(ch.cx, ch.cy, 2.8 * zScale, Math.PI, 0);
    ctx.fill();

    // Curved tapering chilli pepper body
    ctx.strokeStyle = ch.col;
    ctx.lineWidth = 3.6 * zScale;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(ch.cx, ch.cy + 1 * zScale);
    ctx.quadraticCurveTo(ch.cx + ch.curve, ch.cy + ch.len * 0.6, ch.cx + ch.curve * 0.6, ch.cy + ch.len);
    ctx.stroke();

    // Tapering pointy tip
    ctx.lineWidth = 1.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(ch.cx + ch.curve * 0.6, ch.cy + ch.len - 3 * zScale);
    ctx.lineTo(ch.cx + ch.curve * 0.4, ch.cy + ch.len);
    ctx.stroke();

    // High-gloss specular reflection glint
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.65)';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(ch.cx + ch.curve * 0.2, ch.cy + 3 * zScale);
    ctx.quadraticCurveTo(ch.cx + ch.curve * 0.7, ch.cy + ch.len * 0.5, ch.cx + ch.curve * 0.4, ch.cy + ch.len * 0.8);
    ctx.stroke();
  });
}

function drawGroundnutRunner(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Low-prostrate spreading runner canopy with trailing horizontal branches
  const runners = [
    { rx: -18 * zScale, ry: -pHeight * 0.35, rot: -0.4 },
    { rx: -7 * zScale, ry: -pHeight * 0.48, rot: -0.15 },
    { rx: 7 * zScale, ry: -pHeight * 0.46, rot: 0.18 },
    { rx: 19 * zScale, ry: -pHeight * 0.32, rot: 0.42 }
  ];

  // Runner stems
  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 2.4 * zScale;
  ctx.lineCap = 'round';
  runners.forEach(r => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(r.rx * 0.5, -4 * zScale, r.rx, r.ry);
    ctx.stroke();
  });

  // Tetrafoliolate compound leaves (2 pairs of obovate leaflets)
  runners.forEach(r => {
    ctx.save();
    ctx.translate(r.rx, r.ry);
    ctx.rotate(r.rot + sway * 0.05);

    // 4 obovate leaflets
    const leafletOffsets = [
      { ox: -5 * zScale, oy: -6 * zScale, rot: -0.4 },
      { ox: 5 * zScale, oy: -6 * zScale, rot: 0.4 },
      { ox: -6 * zScale, oy: 2 * zScale, rot: -0.7 },
      { ox: 6 * zScale, oy: 2 * zScale, rot: 0.7 }
    ];

    leafletOffsets.forEach(lo => {
      ctx.fillStyle = '#16a34a';
      ctx.beginPath();
      ctx.ellipse(lo.ox, lo.oy, 4.2 * zScale, 6.5 * zScale, lo.rot, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);

      // Pale central vein
      ctx.strokeStyle = '#86efac';
      ctx.lineWidth = 0.8 * zScale;
      ctx.beginPath();
      ctx.moveTo(lo.ox, lo.oy - 4 * zScale);
      ctx.lineTo(lo.ox, lo.oy + 4 * zScale);
      ctx.stroke();
    });

    ctx.restore();
  });

  // Golden-yellow papilionaceous (pea-like) flowers
  for (let f = 0; f < 3; f++) {
    const fx = (f - 1) * 10 * zScale + sway * 0.1;
    const fy = -pHeight * 0.52;
    // Standard petal (banner)
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    ctx.arc(fx, fy - 2 * zScale, 3.2 * zScale, 0, Math.PI * 2);
    ctx.fill();
    // Wings & keel
    ctx.fillStyle = '#ea580c';
    ctx.beginPath();
    ctx.ellipse(fx, fy + 1 * zScale, 2 * zScale, 3 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();

    // Downward geotropic pegs (gynophores) piercing the soil surface
    ctx.strokeStyle = '#ca8a04';
    ctx.lineWidth = 1.4 * zScale;
    ctx.beginPath();
    ctx.moveTo(fx, fy + 2 * zScale);
    ctx.quadraticCurveTo(fx + (f % 2 === 0 ? 3 : -3) * zScale, 1 * zScale, fx + (f % 2 === 0 ? 2 : -2) * zScale, 6 * zScale);
    ctx.stroke();
  }

  // Subterranean reticulated peanut pods in the soil horizon
  const pods = [
    { px: -11 * zScale, py: 5.5 * zScale, pw: 7.5 * zScale, ph: 3.8 * zScale, rot: 0.25 },
    { px: 0, py: 7 * zScale, pw: 8 * zScale, ph: 4 * zScale, rot: -0.1 },
    { px: 12 * zScale, py: 6 * zScale, pw: 7.8 * zScale, ph: 3.9 * zScale, rot: -0.22 }
  ];

  pods.forEach(pod => {
    // Tan-brown shell with constriction between the two kernels
    ctx.fillStyle = '#b45309';
    ctx.beginPath();
    ctx.ellipse(pod.px - pod.pw * 0.25, pod.py, pod.pw * 0.38, pod.ph, pod.rot, 0, Math.PI * 2);
    ctx.ellipse(pod.px + pod.pw * 0.25, pod.py, pod.pw * 0.35, pod.ph * 0.95, pod.rot, 0, Math.PI * 2);
    ctx.fill();

    // Constricted waist
    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.arc(pod.px, pod.py, pod.ph * 0.8, 0, Math.PI * 2);
    ctx.stroke();

    // Reticulated shell netting stipples
    ctx.fillStyle = '#fef3c7';
    ctx.beginPath();
    ctx.arc(pod.px - 2 * zScale, pod.py - 1 * zScale, 0.9 * zScale, 0, Math.PI * 2);
    ctx.arc(pod.px + 2 * zScale, pod.py + 0.5 * zScale, 0.9 * zScale, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawBarley(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  ctx.strokeStyle = '#d97706';
  ctx.lineWidth = 2.6 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.4, -pHeight * 0.5, sway, -pHeight);
  ctx.stroke();

  // Alternate flat linear leaves with clasping auricles
  [-0.45, 0.45].forEach((side, idx) => {
    const ly = -pHeight * (0.35 + idx * 0.25);
    const lx = sway * (0.35 + idx * 0.25);
    ctx.save();
    ctx.translate(lx, ly);
    ctx.rotate(side * 0.6 + sway * 0.04);
    ctx.fillStyle = '#65a30d';
    ctx.beginPath();
    ctx.ellipse(0, 0, 18 * zScale, 3.8 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    ctx.strokeStyle = '#bef264';
    ctx.lineWidth = 0.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(-16 * zScale, 0);
    ctx.lineTo(16 * zScale, 0);
    ctx.stroke();
    ctx.restore();
  });

  // Barley Spikelets with 45px long parallel bearded awns
  const headX = sway;
  const headY = -pHeight;
  for (let s = 0; s < 8; s++) {
    const sy = headY + s * 3.6 * zScale - 20 * zScale;
    const isLeft = s % 2 === 0;
    const sx = headX + (isLeft ? -2.4 : 2.4) * zScale;

    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.ellipse(sx, sy, 4.2 * zScale, 2.2 * zScale, isLeft ? -0.3 : 0.3, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Ultra-Long Parallel Golden Awn Beards
    const awnLen = 42 * zScale;
    ctx.strokeStyle = '#fbbf24';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx + (isLeft ? -6 * zScale : 6 * zScale), sy - awnLen);
    ctx.stroke();
  }
}

function drawOats(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  ctx.strokeStyle = '#65a30d';
  ctx.lineWidth = 2.4 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.4, -pHeight * 0.5, sway * 0.7, -pHeight);
  ctx.stroke();

  // Linear-lanceolate leaves with blue-green bloom
  [-0.4, 0.4].forEach((side, idx) => {
    const ly = -pHeight * (0.32 + idx * 0.22);
    const lx = sway * 0.4 * (0.32 + idx * 0.22);
    ctx.save();
    ctx.translate(lx, ly);
    ctx.rotate(side * 0.55 + sway * 0.03);
    ctx.fillStyle = '#16a34a';
    ctx.beginPath();
    ctx.ellipse(0, 0, 20 * zScale, 4.2 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 0.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(-18 * zScale, 0);
    ctx.lineTo(18 * zScale, 0);
    ctx.stroke();
    ctx.restore();
  });

  // Pyramidal panicle with drooping pendulous spikelets
  const apexX = sway * 0.7;
  const apexY = -pHeight;
  for (let tier = 1; tier <= 5; tier++) {
    const ty = apexY + tier * 5 * zScale - 22 * zScale;
    const spread = (6 - tier) * 4.5 * zScale;

    [-1, 1].forEach(side => {
      const bx = apexX + side * spread;
      const by = ty + 3.5 * zScale;
      ctx.strokeStyle = '#a3e635';
      ctx.lineWidth = 0.8 * zScale;
      ctx.beginPath();
      ctx.moveTo(apexX, ty);
      ctx.lineTo(bx, by);
      ctx.stroke();

      ctx.fillStyle = '#fde047';
      ctx.beginPath();
      ctx.ellipse(bx, by + 2 * zScale, 3.2 * zScale, 1.6 * zScale, side * 0.4, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);
    });
  }
}

function drawMustardBloom(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 2.8 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(sway * 0.4, -pHeight * 0.6);
  ctx.lineTo(sway * 0.7, -pHeight);
  ctx.stroke();

  // Lyrate lower leaves and upper lanceolate leaves
  [-0.55, 0.55].forEach((side, idx) => {
    const ly = -pHeight * (0.25 + idx * 0.2);
    const lx = sway * 0.4 * (0.25 + idx * 0.2);
    ctx.save();
    ctx.translate(lx, ly);
    ctx.rotate(side * 0.6);
    ctx.fillStyle = '#16a34a';
    ctx.beginPath();
    ctx.ellipse(0, 0, 16 * zScale, 6 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);
    ctx.restore();
  });

  // Slender silique pods
  ctx.strokeStyle = '#65a30d';
  ctx.lineWidth = 1.4 * zScale;
  for (let s = 1; s <= 4; s++) {
    const sy = -pHeight * (s / 5);
    ctx.beginPath();
    ctx.moveTo(sway * 0.4, sy);
    ctx.lineTo(sway * 0.4 + (s % 2 === 0 ? 8 : -8) * zScale, sy - 8 * zScale);
    ctx.stroke();
  }

  // Bright yellow 4-petal cruciform flowers
  const apexX = sway * 0.7;
  const apexY = -pHeight;
  for (let f = 0; f < 8; f++) {
    const fa = (f / 8) * Math.PI * 2;
    const fx = apexX + Math.cos(fa) * 6 * zScale;
    const fy = apexY + Math.sin(fa) * 5 * zScale;
    ctx.fillStyle = fruitCol || '#fde047';
    for (let cp = 0; cp < 4; cp++) {
      const cpAng = (cp / 4) * Math.PI * 2;
      ctx.beginPath();
      ctx.ellipse(fx + Math.cos(cpAng) * 2.5 * zScale, fy + Math.sin(cpAng) * 2.5 * zScale, 2.2 * zScale, 1.4 * zScale, cpAng, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

function drawLegumePod(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Erect branching bushy stems with tawny pubescence (Soybean / Pigeon Pea / Pulses / Gram)
  const stems = [
    { x1: 0, y1: 0, x2: sway * 0.2 - 8 * zScale, y2: -pHeight * 0.78, rot: -0.25 },
    { x1: 0, y1: 0, x2: sway * 0.35, y2: -pHeight * 0.95, rot: 0.05 },
    { x1: 0, y1: 0, x2: sway * 0.2 + 9 * zScale, y2: -pHeight * 0.82, rot: 0.22 }
  ];

  ctx.lineCap = 'round';
  stems.forEach(st => {
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 3.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(st.x1, st.y1);
    ctx.quadraticCurveTo((st.x1 + st.x2) * 0.5, (st.y1 + st.y2) * 0.5, st.x2, st.y2);
    ctx.stroke();

    // Fine golden-tawny hairs highlight
    ctx.strokeStyle = '#84cc16';
    ctx.lineWidth = 0.9 * zScale;
    ctx.beginPath();
    ctx.moveTo(st.x1 + 1 * zScale, st.y1);
    ctx.quadraticCurveTo((st.x1 + st.x2) * 0.5 + 1 * zScale, (st.y1 + st.y2) * 0.5, st.x2 + 0.5 * zScale, st.y2);
    ctx.stroke();
  });

  // True trifoliate compound leaves with distinct petiolules & herringbone venation
  const trifoliateNodes = [
    { x: -9 * zScale, y: -pHeight * 0.45, rot: -0.55 },
    { x: 10 * zScale, y: -pHeight * 0.52, rot: 0.50 },
    { x: -7 * zScale, y: -pHeight * 0.72, rot: -0.40 },
    { x: 8 * zScale, y: -pHeight * 0.75, rot: 0.38 },
    { x: sway * 0.35, y: -pHeight * 0.94, rot: 0 }
  ];

  trifoliateNodes.forEach(tn => {
    ctx.save();
    ctx.translate(tn.x, tn.y);
    ctx.rotate(tn.rot);

    // Common petiole
    ctx.strokeStyle = '#16a34a';
    ctx.lineWidth = 1.4 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(0, -5 * zScale);
    ctx.stroke();

    // 3 distinct leaflets (terminal + 2 lateral)
    const leaflets = [
      { lx: 0, ly: -11 * zScale, rot: 0, len: 8.5 * zScale, w: 5.5 * zScale },
      { lx: -6 * zScale, ly: -7 * zScale, rot: -0.65, len: 7.2 * zScale, w: 4.8 * zScale },
      { lx: 6 * zScale, ly: -7 * zScale, rot: 0.65, len: 7.2 * zScale, w: 4.8 * zScale }
    ];

    leaflets.forEach(lf => {
      ctx.fillStyle = '#15803d';
      ctx.beginPath();
      ctx.ellipse(lf.lx, lf.ly, lf.w, lf.len, lf.rot, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);

      // Pale central vein
      ctx.strokeStyle = '#86efac';
      ctx.lineWidth = 0.8 * zScale;
      ctx.beginPath();
      ctx.moveTo(lf.lx - Math.sin(lf.rot) * (lf.len * 0.8), lf.ly - Math.cos(lf.rot) * (lf.len * 0.8));
      ctx.lineTo(lf.lx + Math.sin(lf.rot) * (lf.len * 0.8), lf.ly + Math.cos(lf.rot) * (lf.len * 0.8));
      ctx.stroke();
    });

    ctx.restore();
  });

  // Small pale purple/pink papilionaceous flowers at leaf axils
  [-pHeight * 0.50, -pHeight * 0.70].forEach(flY => {
    [-4, 4].forEach(side => {
      const flX = side * zScale;
      ctx.fillStyle = '#e9d5ff';
      ctx.beginPath();
      ctx.arc(flX, flY, 2.2 * zScale, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#9333ea';
      ctx.beginPath();
      ctx.arc(flX, flY + 0.5 * zScale, 1.2 * zScale, 0, Math.PI * 2);
      ctx.fill();
    });
  });

  // Dense clusters of pendant fuzzy curved legume pods with visible seed bulges
  const podClusters = [
    { px: -8 * zScale, py: -pHeight * 0.38, rot: -0.45 },
    { px: 7 * zScale, py: -pHeight * 0.42, rot: 0.40 },
    { px: -5 * zScale, py: -pHeight * 0.62, rot: -0.30 },
    { px: 6 * zScale, py: -pHeight * 0.65, rot: 0.35 }
  ];

  podClusters.forEach(pc => {
    for (let pIdx = 0; pIdx < 2; pIdx++) {
      const podAngle = pc.rot + (pIdx === 0 ? -0.15 : 0.25);
      const podLen = 15 * zScale;
      const podW = 5.2 * zScale;

      ctx.save();
      ctx.translate(pc.px + (pIdx * 2.5 * zScale), pc.py + (pIdx * 3 * zScale));
      ctx.rotate(podAngle);

      // Curved pod body
      ctx.fillStyle = fruitCol || '#84cc16';
      ctx.beginPath();
      ctx.roundRect(-podW * 0.5, 0, podW, podLen, 2.4 * zScale);
      ctx.fill();

      // Pod suture line & terminal beak
      ctx.strokeStyle = '#4d7c0f';
      ctx.lineWidth = 1.0 * zScale;
      ctx.beginPath();
      ctx.moveTo(0, 0); ctx.lineTo(0, podLen);
      ctx.lineTo(2 * zScale, podLen + 3 * zScale); // beak
      ctx.stroke();

      // Distinct rounded seed bulges (3-4 developing seeds inside pod)
      for (let s = 1; s <= 3; s++) {
        const sY = s * 3.6 * zScale - 0.5 * zScale;
        ctx.fillStyle = '#65a30d';
        ctx.beginPath();
        ctx.arc(0, sY, 1.8 * zScale, 0, Math.PI * 2);
        ctx.fill();

        // Highlight glint on seed bulge
        ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
        ctx.beginPath();
        ctx.arc(-0.6 * zScale, sY - 0.5 * zScale, 0.7 * zScale, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }
  });
}

function drawWheat(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Dense clump of 4-6 golden-green tillers emerging from the crown
  const tillers = [
    { dx: sway * 0.2 - 6 * zScale, h: pHeight * 0.88, rot: -0.15 },
    { dx: sway * 0.5 - 2 * zScale, h: pHeight * 0.98, rot: -0.05 },
    { dx: sway * 0.8 + 1 * zScale, h: pHeight * 1.02, rot: 0.04 },
    { dx: sway * 0.6 + 5 * zScale, h: pHeight * 0.92, rot: 0.12 }
  ];

  tillers.forEach(til => {
    // Culm (stalk) with nodes
    ctx.strokeStyle = '#d97706';
    ctx.lineWidth = 2.4 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(til.dx * 0.5, -til.h * 0.5, til.dx, -til.h);
    ctx.stroke();

    // Node bands along culm
    ctx.fillStyle = '#78350f';
    [-til.h * 0.35, -til.h * 0.65].forEach(ny => {
      const nx = til.dx * (ny / -til.h);
      ctx.beginPath();
      ctx.ellipse(nx, ny, 1.8 * zScale, 1.0 * zScale, 0, 0, Math.PI * 2);
      ctx.fill();
    });

    // Arching linear flag leaves with prominent parallel venation
    [-0.45, 0.45].forEach(side => {
      const ly = -til.h * (side < 0 ? 0.42 : 0.62);
      const lx = til.dx * (ly / -til.h);
      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 2.0 * zScale;
      ctx.beginPath();
      ctx.moveTo(lx, ly);
      ctx.quadraticCurveTo(lx + side * 16 * zScale + sway * 0.3, ly - 6 * zScale, lx + side * 22 * zScale + sway * 0.4, ly + 8 * zScale);
      ctx.stroke();

      // Central parallel vein
      ctx.strokeStyle = '#86efac';
      ctx.lineWidth = 0.8 * zScale;
      ctx.beginPath();
      ctx.moveTo(lx, ly);
      ctx.quadraticCurveTo(lx + side * 16 * zScale + sway * 0.3, ly - 6 * zScale, lx + side * 22 * zScale + sway * 0.4, ly + 8 * zScale);
      ctx.stroke();
    });

    // Stately Golden-Amber Spike (Ear) with 2-ranked overlapping spikelets
    const headX = til.dx;
    const headY = -til.h;
    const spikeLen = 22 * zScale;

    // Central rachis axis
    ctx.strokeStyle = '#b45309';
    ctx.lineWidth = 1.6 * zScale;
    ctx.beginPath();
    ctx.moveTo(headX, headY);
    ctx.lineTo(headX + til.rot * 8 * zScale, headY - spikeLen);
    ctx.stroke();

    // 8-10 Alternating spikelets with glumes & long slender awns (beards)
    for (let s = 0; s < 9; s++) {
      const sT = s / 9;
      const sy = headY - sT * spikeLen;
      const isLeft = s % 2 === 0;
      const sx = headX + (isLeft ? -3.2 : 3.2) * zScale;

      // Golden spikelet glume body
      const gGrad = ctx.createLinearGradient(sx, sy, sx, sy - 3 * zScale);
      gGrad.addColorStop(0, '#f59e0b');
      gGrad.addColorStop(0.5, '#fbbf24');
      gGrad.addColorStop(1, '#fef08a');
      ctx.fillStyle = gGrad;
      ctx.beginPath();
      ctx.ellipse(sx, sy, 4.8 * zScale, 2.6 * zScale, isLeft ? -0.32 : 0.32, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);

      // Glume outline
      ctx.strokeStyle = '#92400e';
      ctx.lineWidth = 0.8 * zScale;
      ctx.stroke();

      // Long slender bristly awn (beard) with sunlight glint
      const awnAngle = isLeft ? (-0.65 + til.rot) : (0.65 + til.rot);
      const awnLen = (20 + (s % 3) * 3) * zScale;
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 0.85 * zScale;
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx + Math.sin(awnAngle) * awnLen, sy - Math.cos(awnAngle) * awnLen);
      ctx.stroke();
    }
  });
}

function drawPaddy(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Shallow flooded paddy water layer ripple ring
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.65)';
  ctx.lineWidth = 1.2 * zScale;
  ctx.beginPath();
  ctx.ellipse(0, 1 * zScale, 11 * zScale, 4.5 * zScale, 0, 0, Math.PI * 2);
  ctx.stroke();

  // Dense clump of 6-8 lush green tillers rooted in flooded soil
  const tillers = [
    { offX: -7 * zScale, curveX: sway * 0.4 - 12 * zScale, h: pHeight * 0.82, rot: -0.28 },
    { offX: -3 * zScale, curveX: sway * 0.6 - 4 * zScale, h: pHeight * 0.95, rot: -0.12 },
    { offX: 0, curveX: sway * 0.75, h: pHeight * 1.05, rot: 0.02 },
    { offX: 3 * zScale, curveX: sway * 0.6 + 5 * zScale, h: pHeight * 0.96, rot: 0.14 },
    { offX: 7 * zScale, curveX: sway * 0.4 + 13 * zScale, h: pHeight * 0.84, rot: 0.26 }
  ];

  tillers.forEach(til => {
    // Upright green culm
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 2.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(til.offX, 0);
    ctx.quadraticCurveTo(til.offX * 0.5 + til.curveX * 0.5, -til.h * 0.55, til.curveX, -til.h);
    ctx.stroke();

    // Arching slender blades with prominent ligule collar
    [-0.5, 0.5].forEach(side => {
      const by = -til.h * (side < 0 ? 0.38 : 0.58);
      const bx = til.offX + (til.curveX - til.offX) * (by / -til.h);
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 1.8 * zScale;
      ctx.beginPath();
      ctx.moveTo(bx, by);
      ctx.quadraticCurveTo(bx + side * 18 * zScale + sway * 0.3, by - 8 * zScale, bx + side * 24 * zScale + sway * 0.4, by + 12 * zScale);
      ctx.stroke();

      // Pale midrib
      ctx.strokeStyle = '#86efac';
      ctx.lineWidth = 0.7 * zScale;
      ctx.beginPath();
      ctx.moveTo(bx, by);
      ctx.quadraticCurveTo(bx + side * 18 * zScale + sway * 0.3, by - 8 * zScale, bx + side * 24 * zScale + sway * 0.4, by + 12 * zScale);
      ctx.stroke();
    });

    // Gracefully Drooping Arching Panicle laden with golden grains (caryopses)
    const panX = til.curveX;
    const panY = -til.h;
    const panDroopX = panX + (til.rot >= 0 ? 12 : -12) * zScale + sway * 0.3;
    const panDroopY = panY + 16 * zScale;

    // Panicle primary branch axis
    ctx.strokeStyle = '#ca8a04';
    ctx.lineWidth = 1.3 * zScale;
    ctx.beginPath();
    ctx.moveTo(panX, panY);
    ctx.quadraticCurveTo((panX + panDroopX) * 0.5, panY - 3 * zScale, panDroopX, panDroopY);
    ctx.stroke();

    // 8-10 Golden rice grains attached in alternating clusters with tiny awns
    for (let g = 0; g < 9; g++) {
      const gt = g / 9;
      const gx = panX + (panDroopX - panX) * gt + (g % 2 === 0 ? -2.2 : 2.2) * zScale;
      const gy = panY + (panDroopY - panY) * gt + (g % 2 === 0 ? 1.5 : -1.5) * zScale;

      // Plump golden paddy grain
      ctx.fillStyle = fruitCol || '#facc15';
      ctx.beginPath();
      ctx.ellipse(gx, gy, 3.4 * zScale, 1.8 * zScale, til.rot + 0.4, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);

      ctx.strokeStyle = '#854d0e';
      ctx.lineWidth = 0.7 * zScale;
      ctx.stroke();

      // Tiny terminal awn
      ctx.strokeStyle = '#fef08a';
      ctx.lineWidth = 0.6 * zScale;
      ctx.beginPath();
      ctx.moveTo(gx, gy);
      ctx.lineTo(gx + (til.rot >= 0 ? 3 : -3) * zScale, gy + 3 * zScale);
      ctx.stroke();
    }
  });
}

function drawTeaBush(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Pruned flat-topped table hedge with tender light-green flush
  ctx.strokeStyle = '#14532d';
  ctx.lineWidth = 3.4 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(-6 * zScale, -pHeight * 0.5);
  ctx.moveTo(0, 0);
  ctx.lineTo(6 * zScale, -pHeight * 0.5);
  ctx.stroke();

  // Dense flat-topped canopy
  ctx.fillStyle = '#166534';
  ctx.beginPath();
  ctx.roundRect(-16 * zScale, -pHeight, 32 * zScale, pHeight * 0.65, 4 * zScale);
  ctx.fill();
  applyLeafTexture(ctx, leafPattern);

  // Tender light-green "two leaves and a bud" flush
  ctx.fillStyle = '#86efac';
  for (let b = -3; b <= 3; b++) {
    const bx = b * 4.2 * zScale;
    const by = -pHeight - 2 * zScale;
    ctx.beginPath();
    ctx.ellipse(bx, by, 1.8 * zScale, 3.2 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);
  }
}

function drawCoffeeShrub(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  ctx.strokeStyle = '#3f2208';
  ctx.lineWidth = 4.2 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(sway * 0.3, -pHeight);
  ctx.stroke();

  // Horizontal lateral branches with glossy leaves & crimson cherries
  for (let tier = 1; tier <= 3; tier++) {
    const ty = -pHeight * (tier / 3.8);
    const tx = sway * 0.3 * (tier / 3.8);
    const span = (4 - tier) * 10 * zScale;

    [-1, 1].forEach(side => {
      ctx.strokeStyle = '#3f2208';
      ctx.lineWidth = 2.0 * zScale;
      ctx.beginPath();
      ctx.moveTo(tx, ty);
      ctx.lineTo(tx + side * span, ty + 3 * zScale);
      ctx.stroke();

      // Leaves
      ctx.fillStyle = '#14532d';
      ctx.beginPath();
      ctx.ellipse(tx + side * (span * 0.7), ty + 3 * zScale, 7 * zScale, 3.5 * zScale, side * 0.2, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);

      // Pale midrib
      ctx.strokeStyle = '#4ade80';
      ctx.lineWidth = 0.8 * zScale;
      ctx.beginPath();
      ctx.moveTo(tx + side * (span * 0.7 - 5 * zScale), ty + 3 * zScale);
      ctx.lineTo(tx + side * (span * 0.7 + 5 * zScale), ty + 3 * zScale);
      ctx.stroke();

      // Crimson coffee cherries
      for (let ch = 0; ch < 3; ch++) {
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(tx + side * (span * 0.4 + ch * 2.5 * zScale), ty + 2 * zScale, 2.2 * zScale, 0, Math.PI * 2);
        ctx.fill();
      }
    });
  }
}

function drawOrchardTree(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Sturdy woody trunk splitting into scaffold branches
  const topX = sway * 0.3;
  ctx.strokeStyle = '#3f2208';
  ctx.lineWidth = 8.5 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(topX, -pHeight * 0.55);
  ctx.stroke();

  // Scaffold branches
  ctx.lineWidth = 4.5 * zScale;
  ctx.beginPath();
  ctx.moveTo(topX, -pHeight * 0.55);
  ctx.lineTo(topX - 16 * zScale, -pHeight * 0.85);
  ctx.moveTo(topX, -pHeight * 0.55);
  ctx.lineTo(topX + 16 * zScale, -pHeight * 0.85);
  ctx.stroke();

  // Rounded dense foliage dome
  const crownY = -pHeight * 0.85;
  const crownR = 20 * zScale;
  ctx.fillStyle = '#14532d';
  ctx.beginPath();
  ctx.arc(topX, crownY, crownR, 0, Math.PI * 2);
  ctx.fill();
  applyLeafTexture(ctx, leafPattern);

  ctx.fillStyle = '#15803d';
  ctx.beginPath();
  ctx.arc(topX - 4 * zScale, crownY - 4 * zScale, crownR * 0.85, 0, Math.PI * 2);
  ctx.fill();
  applyLeafTexture(ctx, leafPattern);

  // Aromatic plantation spice buds and foliage highlights
  for (let f = 0; f < 5; f++) {
    const fa = (f / 5) * Math.PI * 2;
    const fx = topX + Math.cos(fa) * (crownR * 0.65);
    const fy = crownY + Math.sin(fa) * (crownR * 0.65);
    ctx.fillStyle = fruitCol || '#15803d';
    ctx.beginPath();
    ctx.arc(fx, fy, 1.8 * zScale, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawFlowerOrnamental(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 2.6 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.35, -pHeight * 0.55, sway * 0.8, -pHeight);
  ctx.stroke();

  // Lanceolate green stem leaves
  [-0.45, 0.45].forEach((side, idx) => {
    ctx.save();
    ctx.translate(sway * 0.4 * (0.35 + idx * 0.25), -pHeight * (0.35 + idx * 0.25));
    ctx.rotate(side * 0.5);
    ctx.fillStyle = '#16a34a';
    ctx.beginPath();
    ctx.ellipse(0, 0, 14 * zScale, 4.5 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);
    ctx.restore();
  });

  const apexX = sway * 0.8;
  const apexY = -pHeight;
  const bloomRad = 11 * zScale;

  ctx.save();
  ctx.translate(apexX, apexY);
  ctx.fillStyle = fruitCol || '#f97316';
  for (let p = 0; p < 14; p++) {
    const pAng = (p / 14) * Math.PI * 2;
    const px = Math.cos(pAng) * (bloomRad * 0.65);
    const py = Math.sin(pAng) * (bloomRad * 0.65);
    ctx.beginPath();
    ctx.ellipse(px, py, bloomRad * 0.45, bloomRad * 0.32, pAng, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.fillStyle = '#fde047';
  ctx.beginPath();
  ctx.arc(0, 0, bloomRad * 0.3, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawGingerTurmeric(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Subterranean knotted multi-fingered aromatic rhizomes in Horizon B / Topsoil
  const rzCol = fruitCol || '#ca8a04';
  const rzHighlight = '#facc15';
  const rzDark = '#78350f';

  // Rhizome cluster with segmented fingers, growth annuli rings, and feeder roots
  const fingers = [
    { fx: -8 * zScale, fy: 3.5 * zScale, fw: 9 * zScale, fh: 4.5 * zScale, rot: 0.25 },
    { fx: 0, fy: 5.5 * zScale, fw: 11 * zScale, fh: 5.2 * zScale, rot: -0.05 },
    { fx: 9 * zScale, fy: 4.0 * zScale, fw: 9.5 * zScale, fh: 4.8 * zScale, rot: -0.28 },
    { fx: -4 * zScale, fy: 8.0 * zScale, fw: 7.5 * zScale, fh: 3.8 * zScale, rot: 0.15 }
  ];

  fingers.forEach(fg => {
    // Rhizome bulbous finger body
    ctx.fillStyle = rzCol;
    ctx.beginPath();
    ctx.ellipse(fg.fx, fg.fy, fg.fw * 0.5, fg.fh * 0.5, fg.rot, 0, Math.PI * 2);
    ctx.fill();

    // Growth annuli / segmental rings
    ctx.strokeStyle = rzDark;
    ctx.lineWidth = 0.9 * zScale;
    for (let ring = -2; ring <= 2; ring++) {
      const rx = fg.fx + ring * (fg.fw * 0.18);
      ctx.beginPath();
      ctx.ellipse(rx, fg.fy, 1.2 * zScale, fg.fh * 0.45, fg.rot + 0.3, 0, Math.PI * 2);
      ctx.stroke();
    }

    // Specular highlight on rhizome shoulder
    ctx.fillStyle = rzHighlight;
    ctx.beginPath();
    ctx.arc(fg.fx - 1.5 * zScale, fg.fy - 1.2 * zScale, 1.2 * zScale, 0, Math.PI * 2);
    ctx.fill();
  });

  // Fibrous root tendrils descending into loam soil
  ctx.strokeStyle = '#fef08a';
  ctx.lineWidth = 0.8 * zScale;
  [-7, -2, 3, 8].forEach(rx => {
    ctx.beginPath();
    ctx.moveTo(rx * zScale, 6 * zScale);
    ctx.quadraticCurveTo((rx + 2) * zScale, 11 * zScale, (rx - 1) * zScale, 15 * zScale);
    ctx.stroke();
  });

  // 3 erect pseudostems formed by overlapping leaf sheaths
  const pseudostems = [
    { sx: -4 * zScale, h: pHeight * 0.88, swayMult: 0.65, rot: -0.1 },
    { sx: 0, h: pHeight * 1.05, swayMult: 0.85, rot: 0.02 },
    { sx: 4.5 * zScale, h: pHeight * 0.82, swayMult: 0.6, rot: 0.12 }
  ];

  pseudostems.forEach(ps => {
    const topX = ps.sx + sway * ps.swayMult;
    const topY = -ps.h;

    // Pseudostem culm
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 3.6 * zScale;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(ps.sx, 0);
    ctx.quadraticCurveTo(ps.sx + sway * 0.25, -ps.h * 0.5, topX, topY);
    ctx.stroke();

    // Sheath lines
    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 0.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(ps.sx - 1 * zScale, 0);
    ctx.lineTo(topX - 0.5 * zScale, topY * 0.7);
    ctx.stroke();

    // Alternating distichous (2-ranked) lush lanceolate leaves
    for (let l = 1; l <= 5; l++) {
      const lt = l / 5.5;
      const ly = -ps.h * lt;
      const lx = ps.sx + (topX - ps.sx) * lt;
      const isLeft = l % 2 === 0;
      const leafLen = 28 * zScale * (1 - lt * 0.35);
      const leafW = 8.5 * zScale * (1 - lt * 0.25);
      const leafAngle = isLeft ? -0.75 + (sway * 0.04) : 0.75 + (sway * 0.04);

      ctx.save();
      ctx.translate(lx, ly);
      ctx.rotate(leafAngle);

      // Lanceolate blade with acute tip
      const lfGrad = ctx.createLinearGradient(0, 0, leafLen, 0);
      lfGrad.addColorStop(0, '#16a34a');
      lfGrad.addColorStop(0.7, '#22c55e');
      lfGrad.addColorStop(1, '#4ade80');
      ctx.fillStyle = lfGrad;

      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(leafLen * 0.45, -leafW * 0.5, leafLen, 0);
      ctx.quadraticCurveTo(leafLen * 0.45, leafW * 0.5, 0, 0);
      ctx.closePath();
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);

      // Pale central midrib
      ctx.strokeStyle = '#dcfce7';
      ctx.lineWidth = 1.0 * zScale;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(leafLen * 0.95, 0);
      ctx.stroke();

      // Translucent parallel venation lines
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.28)';
      ctx.lineWidth = 0.6 * zScale;
      for (let v = 1; v <= 3; v++) {
        const vt = v / 4;
        ctx.beginPath();
        ctx.moveTo(leafLen * vt * 0.5, -leafW * 0.25 * vt);
        ctx.lineTo(leafLen * (vt * 0.5 + 0.35), -leafW * 0.35);
        ctx.moveTo(leafLen * vt * 0.5, leafW * 0.25 * vt);
        ctx.lineTo(leafLen * (vt * 0.5 + 0.35), leafW * 0.35);
        ctx.stroke();
      }

      ctx.restore();
    }
  });

  // Stately terminal cone inflorescence with green and pink/white bracts
  const apexStem = pseudostems[1];
  const apexX = apexStem.sx + sway * apexStem.swayMult;
  const apexY = -apexStem.h;

  ctx.save();
  ctx.translate(apexX, apexY);
  ctx.rotate(sway * 0.05);

  const coneH = 14 * zScale;
  const coneW = 6.5 * zScale;
  for (let tier = 0; tier < 4; tier++) {
    const ty = -tier * 3.2 * zScale;
    const tw = coneW * (1 - tier * 0.15);
    ctx.fillStyle = tier >= 2 ? '#fbcfe8' : '#86efac';
    ctx.beginPath();
    ctx.ellipse(0, ty, tw * 0.5, 2.2 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = tier >= 2 ? '#db2777' : '#15803d';
    ctx.lineWidth = 0.7 * zScale;
    ctx.stroke();
  }
  ctx.restore();
}


function drawMoringaDrumstick(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const trunkW = 6.2 * zScale;
  const crownY = -pHeight * 0.65;

  ctx.strokeStyle = '#94a3b8';
  ctx.lineWidth = trunkW;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.2, crownY * 0.5, sway * 0.4, crownY);
  ctx.stroke();

  ctx.strokeStyle = '#64748b';
  ctx.lineWidth = 1 * zScale;
  for (let r = 1; r <= 5; r++) {
    const ry = crownY * (r / 6);
    ctx.beginPath();
    ctx.moveTo(-trunkW * 0.45, ry);
    ctx.lineTo(trunkW * 0.45, ry);
    ctx.stroke();
  }

  const branches = [
    { startX: sway * 0.4, startY: crownY, endX: -18 * zScale + sway * 0.6, endY: -pHeight * 0.95 },
    { startX: sway * 0.4, startY: crownY, endX: 18 * zScale + sway * 0.6, endY: -pHeight * 0.92 },
    { startX: sway * 0.4, startY: crownY * 0.9, endX: -10 * zScale + sway * 0.5, endY: -pHeight * 1.05 },
    { startX: sway * 0.4, startY: crownY * 0.9, endX: 11 * zScale + sway * 0.5, endY: -pHeight * 1.02 }
  ];

  branches.forEach(b => {
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 2.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(b.startX, b.startY);
    ctx.quadraticCurveTo((b.startX + b.endX) * 0.5, (b.startY + b.endY) * 0.5 - 3 * zScale, b.endX, b.endY);
    ctx.stroke();

    ctx.fillStyle = '#4ade80';
    for (let f = 0; f < 5; f++) {
      const fx = b.endX + (f - 2) * (3.8 * zScale);
      const fy = b.endY + (Math.sin(f * 2) * 3 * zScale);
      ctx.beginPath();
      ctx.ellipse(fx, fy, 4.5 * zScale, 3.2 * zScale, 0.2, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);
    }

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.arc(b.endX, b.endY - 2 * zScale, 1.6 * zScale, 0, Math.PI * 2);
    ctx.arc(b.endX + 2.5 * zScale, b.endY - 1 * zScale, 1.3 * zScale, 0, Math.PI * 2);
    ctx.fill();
  });

  // Hanging pendulous drumstick pods
  const drumsticks = [
    { bx: -14 * zScale + sway * 0.5, by: -pHeight * 0.88, len: 26 * zScale },
    { bx: -6 * zScale + sway * 0.4, by: -pHeight * 0.82, len: 28 * zScale },
    { bx: 8 * zScale + sway * 0.5, by: -pHeight * 0.85, len: 25 * zScale },
    { bx: 15 * zScale + sway * 0.6, by: -pHeight * 0.80, len: 27 * zScale }
  ];

  drumsticks.forEach(d => {
    const podSway = Math.sin(sway * 0.1) * 3 * zScale;
    ctx.strokeStyle = '#3f6212';
    ctx.lineWidth = 1 * zScale;
    ctx.beginPath();
    ctx.moveTo(d.bx, d.by);
    ctx.lineTo(d.bx + podSway * 0.2, d.by + 4 * zScale);
    ctx.stroke();

    ctx.strokeStyle = fruitCol || '#65a30d';
    ctx.lineWidth = 2.4 * zScale;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(d.bx + podSway * 0.2, d.by + 4 * zScale);
    ctx.quadraticCurveTo(d.bx + podSway * 0.6, d.by + d.len * 0.5, d.bx + podSway, d.by + d.len);
    ctx.stroke();

    ctx.strokeStyle = '#a3e635';
    ctx.lineWidth = 0.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(d.bx + podSway * 0.2, d.by + 4 * zScale);
    ctx.quadraticCurveTo(d.bx + podSway * 0.6, d.by + d.len * 0.5, d.bx + podSway, d.by + d.len);
    ctx.stroke();

    for (let k = 1; k <= 3; k++) {
      const ky = d.by + 4 * zScale + (k / 4) * d.len;
      ctx.fillStyle = '#4d7c0f';
      ctx.beginPath();
      ctx.arc(d.bx + podSway * (k / 4), ky, 1.4 * zScale, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}


function drawSucculentAloe(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const leafSpokes = [
    { ang: -0.75, len: pHeight * 0.85, w: 4.8 * zScale },
    { ang: -0.45, len: pHeight * 0.95, w: 5.2 * zScale },
    { ang: -0.18, len: pHeight * 1.05, w: 5.5 * zScale },
    { ang: 0.18, len: pHeight * 1.05, w: 5.5 * zScale },
    { ang: 0.45, len: pHeight * 0.95, w: 5.2 * zScale },
    { ang: 0.75, len: pHeight * 0.85, w: 4.8 * zScale },
    { ang: -0.08, len: pHeight * 0.90, w: 4.2 * zScale },
    { ang: 0.08, len: pHeight * 0.90, w: 4.2 * zScale }
  ];

  leafSpokes.forEach(spoke => {
    ctx.save();
    ctx.rotate(spoke.ang + sway * 0.02);
    const len = spoke.len;
    const halfW = spoke.w * 0.5;

    const leafGrad = ctx.createLinearGradient(0, 0, 0, -len);
    leafGrad.addColorStop(0, '#065f46');
    leafGrad.addColorStop(0.5, '#059669');
    leafGrad.addColorStop(1, '#34d399');
    ctx.fillStyle = leafGrad;

    ctx.beginPath();
    ctx.moveTo(-halfW, 0);
    ctx.quadraticCurveTo(-halfW * 0.8, -len * 0.6, 0, -len);
    ctx.quadraticCurveTo(halfW * 0.8, -len * 0.6, halfW, 0);
    ctx.closePath();
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    ctx.strokeStyle = '#6ee7b7';
    ctx.lineWidth = 1 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -len * 0.92);
    ctx.stroke();

    // Marginal teeth
    ctx.fillStyle = '#f8fafc';
    for (let t = 1; t <= 5; t++) {
      const ty = -len * (t / 6);
      const curW = halfW * (1 - (t / 6.5));
      ctx.beginPath();
      ctx.moveTo(-curW, ty);
      ctx.lineTo(-curW - 1.2 * zScale, ty - 0.8 * zScale);
      ctx.lineTo(-curW, ty - 1.6 * zScale);
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(curW, ty);
      ctx.lineTo(curW + 1.2 * zScale, ty - 0.8 * zScale);
      ctx.lineTo(curW, ty - 1.6 * zScale);
      ctx.fill();
    }
    ctx.restore();
  });

  // Tall bloom spike
  const spikeH = pHeight * 1.5;
  ctx.strokeStyle = '#047857';
  ctx.lineWidth = 2 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(sway * 0.2, -spikeH * 0.5, sway * 0.5, -spikeH);
  ctx.stroke();

  const apexX = sway * 0.5;
  const apexY = -spikeH;
  for (let f = 0; f < 8; f++) {
    const fy = apexY + f * 2.8 * zScale;
    const isLeft = f % 2 === 0;
    const fx = apexX + (isLeft ? -2.2 : 2.2) * zScale;
    ctx.fillStyle = f < 4 ? '#f59e0b' : '#ea580c';
    ctx.beginPath();
    ctx.ellipse(fx, fy, 2 * zScale, 1.2 * zScale, isLeft ? -0.4 : 0.4, 0, Math.PI * 2);
    ctx.fill();
  }
}

function drawLemongrassTuft(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  ctx.fillStyle = '#cbd5e1';
  ctx.beginPath();
  ctx.ellipse(0, 0, 7 * zScale, 3.5 * zScale, 0, 0, Math.PI * 2);
  ctx.fill();
  applyLeafTexture(ctx, leafPattern);
  ctx.fillStyle = '#7c3aed';
  ctx.beginPath();
  ctx.ellipse(0, -2 * zScale, 5 * zScale, 2.8 * zScale, 0, 0, Math.PI * 2);
  ctx.fill();
  applyLeafTexture(ctx, leafPattern);

  const bladeConfigs = [
    { ang: -0.9, len: pHeight * 0.85, curl: -18 * zScale },
    { ang: -0.7, len: pHeight * 1.05, curl: -22 * zScale },
    { ang: -0.5, len: pHeight * 1.20, curl: -18 * zScale },
    { ang: -0.3, len: pHeight * 1.35, curl: -12 * zScale },
    { ang: -0.1, len: pHeight * 1.45, curl: -5 * zScale },
    { ang: 0.1, len: pHeight * 1.45, curl: 5 * zScale },
    { ang: 0.3, len: pHeight * 1.35, curl: 12 * zScale },
    { ang: 0.5, len: pHeight * 1.20, curl: 18 * zScale },
    { ang: 0.7, len: pHeight * 1.05, curl: 22 * zScale },
    { ang: 0.9, len: pHeight * 0.85, curl: 18 * zScale },
    { ang: -0.2, len: pHeight * 1.30, curl: -8 * zScale },
    { ang: 0.0, len: pHeight * 1.40, curl: 0 },
    { ang: 0.2, len: pHeight * 1.30, curl: 8 * zScale }
  ];

  bladeConfigs.forEach((b, bIdx) => {
    const windCurl = sway * 0.4;
    const midX = Math.sin(b.ang) * (b.len * 0.6) + windCurl * 0.5;
    const midY = -Math.cos(b.ang) * (b.len * 0.6);
    const tipX = Math.sin(b.ang) * b.len + b.curl + windCurl;
    const tipY = -Math.cos(b.ang) * b.len + Math.abs(b.curl) * 0.35;

    ctx.strokeStyle = bIdx % 2 === 0 ? '#16a34a' : '#22c55e';
    ctx.lineWidth = (bIdx < 10 ? 2.4 : 1.8) * zScale;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(midX, midY, tipX, tipY);
    ctx.stroke();

    ctx.strokeStyle = '#dcfce7';
    ctx.lineWidth = 0.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(midX, midY, tipX, tipY);
    ctx.stroke();
  });
}

function drawLeafyGreens(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const leaves = [
    { ang: -0.85, len: pHeight * 0.85, w: 8 * zScale },
    { ang: -0.55, len: pHeight * 1.05, w: 9 * zScale },
    { ang: -0.25, len: pHeight * 1.15, w: 9.5 * zScale },
    { ang: 0.0, len: pHeight * 1.25, w: 10 * zScale },
    { ang: 0.25, len: pHeight * 1.15, w: 9.5 * zScale },
    { ang: 0.55, len: pHeight * 1.05, w: 9 * zScale },
    { ang: 0.85, len: pHeight * 0.85, w: 8 * zScale }
  ];

  leaves.forEach((lf, idx) => {
    ctx.save();
    ctx.rotate(lf.ang + sway * 0.04);
    const len = lf.len;
    const halfW = lf.w * 0.5;

    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 1.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -len * 0.45);
    ctx.stroke();

    const leafGrad = ctx.createRadialGradient(0, -len * 0.7, 1, 0, -len * 0.7, halfW);
    leafGrad.addColorStop(0, '#15803d');
    leafGrad.addColorStop(0.7, '#166534');
    leafGrad.addColorStop(1, '#14532d');
    ctx.fillStyle = leafGrad;

    ctx.beginPath();
    ctx.moveTo(0, -len * 0.4);
    ctx.quadraticCurveTo(-halfW * 1.2, -len * 0.65, -halfW * 0.8, -len * 0.9);
    ctx.quadraticCurveTo(0, -len * 1.05, halfW * 0.8, -len * 0.9);
    ctx.quadraticCurveTo(halfW * 1.2, -len * 0.65, 0, -len * 0.4);
    ctx.closePath();
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    ctx.strokeStyle = '#4ade80';
    ctx.lineWidth = 0.9 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, -len * 0.4);
    ctx.lineTo(0, -len * 0.95);
    for (let v = 1; v <= 3; v++) {
      const vy = -len * (0.45 + v * 0.14);
      ctx.moveTo(0, vy);
      ctx.lineTo(-halfW * 0.65, vy - 2 * zScale);
      ctx.moveTo(0, vy);
      ctx.lineTo(halfW * 0.65, vy - 2 * zScale);
    }
    ctx.stroke();

    if (idx % 2 === 0) {
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      ctx.beginPath();
      ctx.arc(halfW * 0.3, -len * 0.72, 1.1 * zScale, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  });
}

function drawBlackPepperClimber(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const postH = pHeight * 0.95;
  ctx.fillStyle = '#475569';
  ctx.fillRect(-3 * zScale, -postH, 6 * zScale, postH);
  ctx.fillStyle = '#64748b';
  ctx.fillRect(-3 * zScale, -postH, 2.5 * zScale, postH);

  // Twining woody vine with swollen nodes climbing the post
  ctx.strokeStyle = '#3e2723';
  ctx.lineWidth = 3.5 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.quadraticCurveTo(5 * zScale, -postH * 0.25, -2 * zScale, -postH * 0.5);
  ctx.quadraticCurveTo(-6 * zScale, -postH * 0.75, 1 * zScale, -postH);
  ctx.stroke();

  // Broad, glossy dark-green heart-shaped (cordate) leaves
  const leaves = [
    { y: -postH * 0.2, side: -1, sz: 9 * zScale },
    { y: -postH * 0.35, side: 1, sz: 10 * zScale },
    { y: -postH * 0.5, side: -1, sz: 11 * zScale },
    { y: -postH * 0.65, side: 1, sz: 11.5 * zScale },
    { y: -postH * 0.8, side: -1, sz: 11 * zScale },
    { y: -postH * 0.92, side: 1, sz: 9.5 * zScale }
  ];

  leaves.forEach(lf => {
    const lx = lf.side * (4 * zScale);
    const ly = lf.y;
    ctx.save();
    ctx.translate(lx, ly);
    ctx.rotate(lf.side * 0.5 + sway * 0.05);

    // Heart-shaped leaf
    ctx.fillStyle = '#14532d';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.bezierCurveTo(lf.side * lf.sz * 0.8, -lf.sz * 0.5, lf.side * lf.sz * 1.1, lf.sz * 0.4, 0, lf.sz);
    ctx.bezierCurveTo(-lf.side * lf.sz * 0.2, lf.sz * 0.4, -lf.side * lf.sz * 0.2, -lf.sz * 0.3, 0, 0);
    ctx.closePath();
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Midrib
    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 0.8 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, lf.sz * 0.9);
    ctx.stroke();
    ctx.restore();
  });

  // Pendulous hanging peppercorn spike catkins (berries ripening green to crimson)
  const spikes = [
    { y: -postH * 0.32, x: 6 * zScale, len: 14 * zScale },
    { y: -postH * 0.48, x: -7 * zScale, len: 16 * zScale },
    { y: -postH * 0.62, x: 8 * zScale, len: 18 * zScale },
    { y: -postH * 0.76, x: -8 * zScale, len: 15 * zScale }
  ];

  spikes.forEach((spk, sIdx) => {
    const topSx = spk.x;
    const topSy = spk.y;
    const botSx = spk.x + sway * 0.3;
    const botSy = spk.y + spk.len;

    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(topSx, topSy);
    ctx.lineTo(botSx, botSy);
    ctx.stroke();

    // Rows of round peppercorns along spike
    const berryCount = 6;
    for (let b = 0; b < berryCount; b++) {
      const bt = b / (berryCount - 1);
      const bx = topSx + (botSx - topSx) * bt + ((b % 2 === 0 ? -1 : 1) * 1.5 * zScale);
      const by = topSy + (botSy - topSy) * bt;

      ctx.fillStyle = (sIdx % 2 === 0 && b > 3) ? (fruitCol || '#dc2626') : '#16a34a';
      ctx.beginPath();
      ctx.arc(bx, by, 1.8 * zScale, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}

function drawCardamomClump(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Subterranean rhizome crown mound
  ctx.fillStyle = '#451a03';
  ctx.beginPath();
  ctx.ellipse(0, 0, 16 * zScale, 5 * zScale, 0, 0, Math.PI * 2);
  ctx.fill();

  // Multi-stemmed clump of 5 erect reed-like pseudostems
  const stems = [
    { ang: -0.32, h: pHeight * 0.85, baseW: 4.2 * zScale },
    { ang: -0.15, h: pHeight * 1.05, baseW: 5.0 * zScale },
    { ang: 0.0, h: pHeight * 1.15, baseW: 5.5 * zScale },
    { ang: 0.18, h: pHeight * 1.0, baseW: 4.8 * zScale },
    { ang: 0.35, h: pHeight * 0.82, baseW: 4.0 * zScale }
  ];

  stems.forEach((st, sIdx) => {
    const tipX = Math.sin(st.ang) * st.h + sway * (0.3 + sIdx * 0.05);
    const tipY = -Math.cos(st.ang) * st.h;

    // Jointed reedy pseudostem
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = st.baseW;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(tipX * 0.5, tipY * 0.5, tipX, tipY);
    ctx.stroke();

    // Two-ranked (distichous) lanceolate dark green arching leaves
    for (let l = 1; l <= 5; l++) {
      const lt = l / 5.5;
      const lx = tipX * lt;
      const ly = tipY * lt;
      const isLeft = (l + sIdx) % 2 === 0;
      const leafLen = 22 * zScale;
      const leafW = 7 * zScale;
      const leafAng = (isLeft ? -0.85 : 0.85) + sway * 0.04;

      ctx.save();
      ctx.translate(lx, ly);
      ctx.rotate(leafAng);

      ctx.fillStyle = '#14532d';
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(leafLen * 0.5, -leafW * 0.5, leafLen, 0);
      ctx.quadraticCurveTo(leafLen * 0.5, leafW * 0.5, 0, 0);
      ctx.closePath();
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);

      // Pale central midrib
      ctx.strokeStyle = '#dcfce7';
      ctx.lineWidth = 0.9 * zScale;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(leafLen * 0.95, 0);
      ctx.stroke();
      ctx.restore();
    }
  });

  // Horizontal trailing panicles (floral scapes) creeping along soil with 3-angled capsules
  [-12 * zScale, 12 * zScale].forEach((sx, idx) => {
    ctx.strokeStyle = '#166534';
    ctx.lineWidth = 1.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(sx * 0.5, 3 * zScale, sx, 1 * zScale);
    ctx.stroke();

    // 3-angled green cardamom capsules
    for (let c = 0; c < 3; c++) {
      const cx = sx * (0.4 + c * 0.3);
      const cy = 1 * zScale + Math.sin(c) * 1.5 * zScale;
      ctx.fillStyle = fruitCol || '#84cc16';
      ctx.beginPath();
      ctx.ellipse(cx, cy, 3.2 * zScale, 1.8 * zScale, idx === 0 ? -0.2 : 0.2, 0, Math.PI * 2);
      ctx.fill();

      // Ribbing lines
      ctx.strokeStyle = '#a3e635';
      ctx.lineWidth = 0.6 * zScale;
      ctx.beginPath();
      ctx.moveTo(cx - 3 * zScale, cy);
      ctx.lineTo(cx + 3 * zScale, cy);
      ctx.stroke();
    }
  });
}

function drawMarigoldBush(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const topX = sway * 0.3;
  const bushH = pHeight * 0.85;

  // Bushy branching herbaceous stems
  const branches = [
    { ex: -16 * zScale, ey: -bushH * 0.7 },
    { ex: -8 * zScale, ey: -bushH * 0.92 },
    { ex: 0, ey: -bushH },
    { ex: 8 * zScale, ey: -bushH * 0.9 },
    { ex: 16 * zScale, ey: -bushH * 0.68 }
  ];

  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 2.4 * zScale;
  ctx.lineCap = 'round';
  branches.forEach(b => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(b.ex * 0.4, b.ey * 0.5, b.ex + topX * 0.5, b.ey);
    ctx.stroke();
  });

  // Feathery, deeply pinnatifid ferny dark green foliage
  branches.forEach(b => {
    for (let l = 1; l <= 3; l++) {
      const lt = l / 4;
      const lx = b.ex * lt;
      const ly = b.ey * lt;
      ctx.fillStyle = '#166534';
      ctx.beginPath();
      ctx.ellipse(lx, ly, 6.5 * zScale, 3.2 * zScale, b.ex < 0 ? -0.4 : 0.4, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);
    }
  });

  // Radiant dense ruffled pompom marigold flower heads (saffron orange & golden yellow)
  const flowerHeads = [
    { x: -16 * zScale, y: -bushH * 0.7, r: 7.5 * zScale, col: '#ea580c' },
    { x: -8 * zScale, y: -bushH * 0.92, r: 8.5 * zScale, col: '#f59e0b' },
    { x: 0, y: -bushH, r: 9.5 * zScale, col: fruitCol || '#f97316' },
    { x: 8 * zScale, y: -bushH * 0.9, r: 8.2 * zScale, col: '#f59e0b' },
    { x: 16 * zScale, y: -bushH * 0.68, r: 7.2 * zScale, col: '#ea580c' },
    { x: -4 * zScale, y: -bushH * 0.6, r: 7.0 * zScale, col: '#dc2626' },
    { x: 5 * zScale, y: -bushH * 0.55, r: 6.8 * zScale, col: '#f59e0b' }
  ];

  flowerHeads.forEach(fh => {
    const fx = fh.x + topX * 0.5;
    const fy = fh.y;

    // Green cup calyx at flower base
    ctx.fillStyle = '#15803d';
    ctx.beginPath();
    ctx.ellipse(fx, fy + fh.r * 0.45, fh.r * 0.45, fh.r * 0.35, 0, 0, Math.PI * 2);
    ctx.fill();

    // Multi-layered ruffled pompom flower head
    ctx.fillStyle = fh.col;
    ctx.beginPath();
    ctx.arc(fx, fy, fh.r, 0, Math.PI * 2);
    ctx.fill();

    for (let pet = 0; pet < 8; pet++) {
      const pa = (pet / 8) * Math.PI * 2;
      const px = fx + Math.cos(pa) * (fh.r * 0.65);
      const py = fy + Math.sin(pa) * (fh.r * 0.65);
      ctx.fillStyle = pet % 2 === 0 ? '#fef08a' : fh.col;
      ctx.beginPath();
      ctx.arc(px, py, fh.r * 0.42, 0, Math.PI * 2);
      ctx.fill();
    }

    // Dense inner golden tuft center
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(fx, fy, fh.r * 0.35, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawCauliflower(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const cRadius = 14 * zScale;
  const curdY = -cRadius * 1.1;

  // Outer spreading glaucous blue-green leaves
  const outerLeaves = [-1.3, -0.9, -0.4, 0.4, 0.9, 1.3];
  outerLeaves.forEach((ang, idx) => {
    ctx.save();
    ctx.rotate(ang + sway * 0.03);
    const leafLen = 28 * zScale;
    const leafW = 12 * zScale;

    ctx.fillStyle = idx % 2 === 0 ? '#0f766e' : '#047857';
    ctx.beginPath();
    ctx.ellipse(0, -leafLen * 0.5, leafW * 0.5, leafLen * 0.5, 0, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Broad white central rib
    ctx.strokeStyle = '#f1f5f9';
    ctx.lineWidth = 2.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -leafLen * 0.85);
    ctx.stroke();
    ctx.restore();
  });

  // Central pebbled creamy-white to ivory curd dome
  ctx.save();
  ctx.translate(0, curdY);

  const curdGrad = ctx.createRadialGradient(0, -2 * zScale, 2, 0, 0, cRadius);
  curdGrad.addColorStop(0, '#ffffff');
  curdGrad.addColorStop(0.65, fruitCol || '#fefce8');
  curdGrad.addColorStop(1, '#e2e8f0');
  ctx.fillStyle = curdGrad;
  ctx.beginPath();
  ctx.arc(0, 0, cRadius, 0, Math.PI * 2);
  ctx.fill();

  // Curd pebbled floret clusters
  const florets = [
    { x: -5 * zScale, y: -4 * zScale, r: 4.5 * zScale },
    { x: 5 * zScale, y: -4 * zScale, r: 4.5 * zScale },
    { x: -6 * zScale, y: 3 * zScale, r: 4.2 * zScale },
    { x: 6 * zScale, y: 3 * zScale, r: 4.2 * zScale },
    { x: 0, y: -1 * zScale, r: 5.2 * zScale },
    { x: 0, y: -7 * zScale, r: 4.0 * zScale },
    { x: 0, y: 7 * zScale, r: 4.2 * zScale }
  ];

  florets.forEach(fl => {
    ctx.fillStyle = '#f8fafc';
    ctx.beginPath();
    ctx.arc(fl.x, fl.y, fl.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 0.6 * zScale;
    ctx.stroke();
  });
  ctx.restore();

  // Inner wrapper leaves curving protectively inward over curd margins
  const innerWrappers = [-0.6, -0.2, 0.2, 0.6];
  innerWrappers.forEach(ang => {
    ctx.save();
    ctx.rotate(ang + sway * 0.02);
    ctx.fillStyle = '#10b981';
    ctx.beginPath();
    ctx.ellipse(0, curdY, 4.5 * zScale, 11 * zScale, 0.2, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, curdY);
    ctx.stroke();
    ctx.restore();
  });
}

function drawGarlicBulb(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const bulbH = 10 * zScale;
  const bulbW = 12 * zScale;

  // Fibrous root beard
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 0.8 * zScale;
  for (let r = -4; r <= 4; r++) {
    ctx.beginPath();
    ctx.moveTo(r * 1.4 * zScale, bulbH * 0.4);
    ctx.lineTo(r * 2.0 * zScale + (Math.sin(r) * 2 * zScale), bulbH * 0.9);
    ctx.stroke();
  }

  // Segmented white/purple bulb cloves
  const bulbGrad = ctx.createRadialGradient(-2 * zScale, 0, 1, 0, 0, bulbW * 0.6);
  bulbGrad.addColorStop(0, '#ffffff');
  bulbGrad.addColorStop(0.7, fruitCol || '#f8fafc');
  bulbGrad.addColorStop(1, '#cbd5e1');
  ctx.fillStyle = bulbGrad;
  ctx.beginPath();
  ctx.ellipse(0, 0, bulbW * 0.5, bulbH * 0.45, 0, 0, Math.PI * 2);
  ctx.fill();

  // Subtle purple striated clove ridges
  ctx.strokeStyle = 'rgba(168, 85, 247, 0.35)';
  ctx.lineWidth = 1.0 * zScale;
  [-3 * zScale, 0, 3 * zScale].forEach(cx => {
    ctx.beginPath();
    ctx.moveTo(cx, -bulbH * 0.4);
    ctx.quadraticCurveTo(cx * 1.3, 0, cx * 0.6, bulbH * 0.4);
    ctx.stroke();
  });

  // Flat V-shaped keeled linear green leaves
  const leaves = [
    { ang: -0.65, len: pHeight * 0.85 },
    { ang: -0.35, len: pHeight * 1.05 },
    { ang: -0.1, len: pHeight * 1.18 },
    { ang: 0.15, len: pHeight * 1.15 },
    { ang: 0.4, len: pHeight * 1.0 },
    { ang: 0.7, len: pHeight * 0.8 }
  ];

  leaves.forEach((lf, idx) => {
    ctx.save();
    ctx.rotate(lf.ang + sway * 0.05);

    ctx.fillStyle = idx % 2 === 0 ? '#15803d' : '#166534';
    ctx.beginPath();
    ctx.moveTo(-1.8 * zScale, 0);
    ctx.lineTo(-0.8 * zScale, -lf.len);
    ctx.lineTo(0, -lf.len - 3 * zScale);
    ctx.lineTo(0.8 * zScale, -lf.len);
    ctx.lineTo(1.8 * zScale, 0);
    ctx.closePath();
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);

    // Central V-crease keel
    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 0.9 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -lf.len);
    ctx.stroke();
    ctx.restore();
  });

  // Coiling circular flower scape with pointed beaked spathe umbel
  ctx.strokeStyle = '#22c55e';
  ctx.lineWidth = 1.6 * zScale;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  const scapeH = pHeight * 1.25;
  ctx.quadraticCurveTo(12 * zScale + sway * 0.3, -scapeH * 0.6, 2 * zScale, -scapeH * 0.85);
  ctx.quadraticCurveTo(-6 * zScale, -scapeH * 0.95, 0, -scapeH);
  ctx.stroke();

  // Beaked spathe capsule
  ctx.fillStyle = '#f8fafc';
  ctx.beginPath();
  ctx.ellipse(0, -scapeH, 2.5 * zScale, 4.5 * zScale, 0.1, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#a855f7';
  ctx.lineWidth = 0.7 * zScale;
  ctx.stroke();
}

function drawRadishTaproot(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const rootH = 22 * zScale;
  const rootW = 6.5 * zScale;

  // Soil-level crown and taproot body
  const rGrad = ctx.createLinearGradient(0, -rootH * 0.35, 0, rootH * 0.65);
  rGrad.addColorStop(0, fruitCol || '#f8fafc');
  rGrad.addColorStop(0.3, '#f1f5f9');
  rGrad.addColorStop(1, '#ffffff');

  ctx.fillStyle = rGrad;
  ctx.beginPath();
  ctx.moveTo(-rootW * 0.5, -rootH * 0.3);
  ctx.quadraticCurveTo(-rootW * 0.55, 0, -rootW * 0.35, rootH * 0.45);
  ctx.lineTo(0, rootH * 0.75);
  ctx.lineTo(rootW * 0.35, rootH * 0.45);
  ctx.quadraticCurveTo(rootW * 0.55, 0, rootW * 0.5, -rootH * 0.3);
  ctx.closePath();
  ctx.fill();

  // Crimson/rose flush on crown if red radish variant
  if (fruitCol && (fruitCol.includes('red') || fruitCol.includes('881337') || fruitCol.includes('dc2626') || fruitCol.includes('ea580c'))) {
    ctx.fillStyle = '#e11d48';
    ctx.beginPath();
    ctx.ellipse(0, -rootH * 0.28, rootW * 0.48, rootH * 0.12, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Spreading basal rosette of deeply lyrate-pinnatifid coarse leaves
  const leaves = [
    { ang: -1.0, len: pHeight * 0.8 },
    { ang: -0.6, len: pHeight * 1.05 },
    { ang: -0.2, len: pHeight * 1.2 },
    { ang: 0.2, len: pHeight * 1.2 },
    { ang: 0.6, len: pHeight * 1.05 },
    { ang: 1.0, len: pHeight * 0.8 }
  ];

  leaves.forEach((lf, idx) => {
    ctx.save();
    ctx.translate(0, -rootH * 0.3);
    ctx.rotate(lf.ang + sway * 0.05);

    ctx.fillStyle = idx % 2 === 0 ? '#16a34a' : '#15803d';
    ctx.beginPath();
    ctx.ellipse(0, -lf.len * 0.85, 5.5 * zScale, 6.5 * zScale, 0, 0, Math.PI * 2);
    ctx.fill();

    for (let lb = 1; lb <= 3; lb++) {
      const ly = -lf.len * (lb * 0.22);
      ctx.beginPath();
      ctx.ellipse(-3.5 * zScale, ly, 3.2 * zScale, 2.0 * zScale, -0.4, 0, Math.PI * 2);
      ctx.ellipse(3.5 * zScale, ly, 3.2 * zScale, 2.0 * zScale, 0.4, 0, Math.PI * 2);
      ctx.fill();
    }
    applyLeafTexture(ctx, leafPattern);

    // Pale midrib
    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(0, -lf.len * 0.85);
    ctx.stroke();
    ctx.restore();
  });
}

function drawGingerRhizome(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  // Knobby palmate golden-tan subterranean rhizome hands
  ctx.fillStyle = fruitCol || '#d97706';
  ctx.beginPath();
  ctx.ellipse(0, 2 * zScale, 14 * zScale, 5 * zScale, 0, 0, Math.PI * 2);
  ctx.ellipse(-8 * zScale, 3 * zScale, 6 * zScale, 4 * zScale, -0.3, 0, Math.PI * 2);
  ctx.ellipse(8 * zScale, 3 * zScale, 6 * zScale, 4 * zScale, 0.3, 0, Math.PI * 2);
  ctx.fill();

  // Ringed rhizome scale nodes
  ctx.strokeStyle = '#92400e';
  ctx.lineWidth = 0.9 * zScale;
  [-6 * zScale, -2 * zScale, 2 * zScale, 6 * zScale].forEach(rx => {
    ctx.beginPath();
    ctx.moveTo(rx, 0);
    ctx.lineTo(rx, 4 * zScale);
    ctx.stroke();
  });

  // Slender erect pseudostems with distichous lanceolate leaves
  const shoots = [
    { ang: -0.18, h: pHeight * 0.9 },
    { ang: 0.0, h: pHeight * 1.15 },
    { ang: 0.2, h: pHeight * 0.95 }
  ];

  shoots.forEach(sh => {
    const tipX = Math.sin(sh.ang) * sh.h + sway * 0.3;
    const tipY = -Math.cos(sh.ang) * sh.h;

    ctx.strokeStyle = '#16a34a';
    ctx.lineWidth = 3.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(tipX * 0.5, tipY * 0.5, tipX, tipY);
    ctx.stroke();

    for (let l = 1; l <= 4; l++) {
      const lt = l / 4.5;
      const lx = tipX * lt;
      const ly = tipY * lt;
      const isLeft = l % 2 === 0;

      ctx.save();
      ctx.translate(lx, ly);
      ctx.rotate((isLeft ? -0.7 : 0.7) + sway * 0.04);
      ctx.fillStyle = '#15803d';
      ctx.beginPath();
      ctx.ellipse(10 * zScale, 0, 10 * zScale, 3.2 * zScale, 0, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);
      ctx.restore();
    }
  });
}

function drawCorianderHerb(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const topX = sway * 0.35;
  const herbH = pHeight * 0.85;

  // Slender, delicate multi-branched green stems
  const stems = [
    { ex: -12 * zScale, ey: -herbH * 0.7 },
    { ex: -4 * zScale, ey: -herbH * 0.95 },
    { ex: 5 * zScale, ey: -herbH * 0.92 },
    { ex: 14 * zScale, ey: -herbH * 0.68 }
  ];

  ctx.strokeStyle = '#22c55e';
  ctx.lineWidth = 1.8 * zScale;
  ctx.lineCap = 'round';
  stems.forEach(s => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(s.ex * 0.4, s.ey * 0.5, s.ex + topX * 0.4, s.ey);
    ctx.stroke();
  });

  // Lower broad fan-shaped lobed leaves
  [-8 * zScale, 8 * zScale].forEach((bx, idx) => {
    ctx.save();
    ctx.translate(bx, -herbH * 0.25);
    ctx.rotate(idx === 0 ? -0.6 : 0.6);
    ctx.fillStyle = '#16a34a';
    ctx.beginPath();
    ctx.arc(0, 0, 4.5 * zScale, 0, Math.PI * 2);
    ctx.fill();
    applyLeafTexture(ctx, leafPattern);
    ctx.restore();
  });

  // Upper finely dissected thread-like feathery foliage
  stems.forEach(s => {
    for (let f = 1; f <= 3; f++) {
      const ft = f / 3.5;
      const fx = s.ex * ft + topX * 0.3;
      const fy = s.ey * ft;
      ctx.strokeStyle = '#15803d';
      ctx.lineWidth = 1.0 * zScale;
      ctx.beginPath();
      ctx.moveTo(fx, fy);
      ctx.lineTo(fx - 4 * zScale, fy - 3 * zScale);
      ctx.moveTo(fx, fy);
      ctx.lineTo(fx + 4 * zScale, fy - 3 * zScale);
      ctx.stroke();
    }
  });

  // Delicate compound umbels of pale pink/white flowers and round green seeds
  stems.forEach(s => {
    const ux = s.ex + topX * 0.4;
    const uy = s.ey;

    // Umbel rays
    ctx.strokeStyle = '#86efac';
    ctx.lineWidth = 0.7 * zScale;
    for (let r = -2; r <= 2; r++) {
      const rx = ux + r * 2.8 * zScale;
      const ry = uy - 3.5 * zScale;
      ctx.beginPath();
      ctx.moveTo(ux, uy);
      ctx.lineTo(rx, ry);
      ctx.stroke();

      // Flower florets / green seeds
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.arc(rx, ry, 1.2 * zScale, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}

function drawFenugreekHerb(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const topX = sway * 0.3;
  const herbH = pHeight * 0.8;

  // Slender erect quadrangular stems
  const stems = [
    { ex: -9 * zScale, ey: -herbH * 0.85 },
    { ex: 0, ey: -herbH },
    { ex: 9 * zScale, ey: -herbH * 0.88 }
  ];

  ctx.strokeStyle = '#15803d';
  ctx.lineWidth = 2.0 * zScale;
  ctx.lineCap = 'round';
  stems.forEach(s => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(s.ex * 0.4, s.ey * 0.5, s.ex + topX * 0.3, s.ey);
    ctx.stroke();
  });

  // Characteristic trifoliate obovate clover-like leaves (Methi leaves)
  stems.forEach(s => {
    for (let t = 1; t <= 3; t++) {
      const tt = t / 3.5;
      const tx = s.ex * tt + topX * 0.2;
      const ty = s.ey * tt;

      ctx.save();
      ctx.translate(tx, ty);
      const leafSize = 4.2 * zScale;
      ctx.fillStyle = '#16a34a';

      // Center leaflet
      ctx.beginPath();
      ctx.ellipse(0, -leafSize, leafSize * 0.6, leafSize, 0, 0, Math.PI * 2);
      ctx.fill();

      // Left leaflet
      ctx.beginPath();
      ctx.ellipse(-leafSize * 0.7, -leafSize * 0.5, leafSize * 0.5, leafSize * 0.85, -0.6, 0, Math.PI * 2);
      ctx.fill();

      // Right leaflet
      ctx.beginPath();
      ctx.ellipse(leafSize * 0.7, -leafSize * 0.5, leafSize * 0.5, leafSize * 0.85, 0.6, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);

      ctx.restore();

      // Slender curved sickle-shaped beaked seed pods in axils
      if (t === 2) {
        ctx.strokeStyle = '#84cc16';
        ctx.lineWidth = 1.0 * zScale;
        ctx.beginPath();
        ctx.moveTo(tx, ty);
        ctx.quadraticCurveTo(tx + (s.ex < 0 ? -5 : 5) * zScale, ty - 6 * zScale, tx + (s.ex < 0 ? -8 : 8) * zScale, ty - 8 * zScale);
        ctx.stroke();
      }
    }
  });
}

function drawTulsiPlant(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const bushH = pHeight * 0.85;
  const topX = sway * 0.35;

  // Profusely branched quadrangular purple-green stems radiating from base
  const stems = [
    { ex: -12 * zScale, ey: -bushH * 0.75, cpx: -8 * zScale, cpy: -bushH * 0.35 },
    { ex: -5 * zScale, ey: -bushH * 0.95, cpx: -3 * zScale, cpy: -bushH * 0.5 },
    { ex: 4 * zScale, ey: -bushH * 0.98, cpx: 2 * zScale, cpy: -bushH * 0.5 },
    { ex: 12 * zScale, ey: -bushH * 0.72, cpx: 8 * zScale, cpy: -bushH * 0.35 }
  ];

  ctx.strokeStyle = '#4a044e'; // Rich purple-green tint of holy basil stem
  ctx.lineWidth = 2.4 * zScale;
  ctx.lineCap = 'round';
  stems.forEach(s => {
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(s.cpx, s.cpy, s.ex + topX * 0.3, s.ey);
    ctx.stroke();
  });

  // Opposite decussate aromatic ovate leaves with serrated margins
  stems.forEach(s => {
    for (let t = 1; t <= 3; t++) {
      const frac = t / 3.8;
      const lx = s.ex * frac + topX * 0.2;
      const ly = s.ey * frac;
      const lSize = 4.5 * zScale * (1 - frac * 0.2);

      // Decussate leaf pairs (left & right)
      [-1, 1].forEach(side => {
        ctx.save();
        ctx.translate(lx, ly);
        ctx.rotate((side * 0.55) + (sway * 0.04));
        ctx.fillStyle = '#14532d'; // Dark holy basil green
        ctx.beginPath();
        ctx.ellipse(side * lSize * 0.6, -lSize * 0.2, lSize * 0.75, lSize * 0.45, side * 0.3, 0, Math.PI * 2);
        ctx.fill();
        applyLeafTexture(ctx, leafPattern);

        // Delicate central vein
        ctx.strokeStyle = '#86efac';
        ctx.lineWidth = 0.5 * zScale;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(side * lSize * 1.1, -lSize * 0.3);
        ctx.stroke();
        ctx.restore();
      });
    }

    // Terminal inflorescence spike (Manjari) with purple tubular verticillasters
    const tipX = s.ex + topX * 0.3;
    const tipY = s.ey;
    const spikeH = 14 * zScale;

    ctx.strokeStyle = '#581c87';
    ctx.lineWidth = 1.0 * zScale;
    ctx.beginPath();
    ctx.moveTo(tipX, tipY);
    ctx.lineTo(tipX + topX * 0.2, tipY - spikeH);
    ctx.stroke();

    // Whorls of tiny sacred purple-pink florets along terminal spike
    for (let w = 1; w <= 5; w++) {
      const wy = tipY - (w / 5.5) * spikeH;
      const wx = tipX + topX * 0.2 * (w / 5.5);
      ctx.fillStyle = fruitCol || '#c084fc';
      ctx.beginPath();
      ctx.ellipse(wx - 1.5 * zScale, wy, 1.2 * zScale, 0.8 * zScale, -0.2, 0, Math.PI * 2);
      ctx.ellipse(wx + 1.5 * zScale, wy, 1.2 * zScale, 0.8 * zScale, 0.2, 0, Math.PI * 2);
      ctx.fill();
    }
  });
}

function drawAshwagandhaShrub(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern) {
  const shrubH = pHeight * 0.95;
  const topX = sway * 0.25;

  // Woody, tomentose branching stems with light ash-grey/olive bark
  const mainBranches = [
    { ex: -14 * zScale, ey: -shrubH * 0.78, cpx: -8 * zScale, cpy: -shrubH * 0.4 },
    { ex: -4 * zScale, ey: -shrubH * 0.96, cpx: -2 * zScale, cpy: -shrubH * 0.5 },
    { ex: 5 * zScale, ey: -shrubH * 0.92, cpx: 3 * zScale, cpy: -shrubH * 0.48 },
    { ex: 15 * zScale, ey: -shrubH * 0.74, cpx: 9 * zScale, cpy: -shrubH * 0.38 }
  ];

  ctx.strokeStyle = '#65a30d'; // Olive-grey tomentose stem
  ctx.lineWidth = 3.2 * zScale;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.lineTo(0, -shrubH * 0.25);
  ctx.stroke();

  mainBranches.forEach(b => {
    ctx.strokeStyle = '#4d7c0f';
    ctx.lineWidth = 2.2 * zScale;
    ctx.beginPath();
    ctx.moveTo(0, -shrubH * 0.25);
    ctx.quadraticCurveTo(b.cpx, b.cpy, b.ex + topX * 0.3, b.ey);
    ctx.stroke();
  });

  // Dull velvety olive-green elliptic leaves
  mainBranches.forEach(b => {
    for (let i = 1; i <= 3; i++) {
      const frac = i / 3.5;
      const lx = b.ex * frac + topX * 0.2;
      const ly = -shrubH * 0.25 + (b.ey - (-shrubH * 0.25)) * frac;
      const leafW = 5.5 * zScale;
      const leafH = 7.5 * zScale;

      ctx.save();
      ctx.translate(lx, ly);
      ctx.rotate((i % 2 === 0 ? 0.4 : -0.4) + sway * 0.03);
      ctx.fillStyle = '#3f6212'; // Dull velvety olive green
      ctx.beginPath();
      ctx.ellipse(0, -leafH * 0.5, leafW * 0.5, leafH * 0.5, 0, 0, Math.PI * 2);
      ctx.fill();
      applyLeafTexture(ctx, leafPattern);

      ctx.strokeStyle = '#a3e635';
      ctx.lineWidth = 0.6 * zScale;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(0, -leafH);
      ctx.stroke();
      ctx.restore();

      // Characteristic papery inflated calyx lanterns (accrescent calyx) enclosing small orange-red berries
      if (i >= 2) {
        const calyxX = lx + (b.ex < 0 ? -3 : 3) * zScale;
        const calyxY = ly + 2 * zScale;

        // Papery outer lantern husk (pale greenish-straw)
        ctx.fillStyle = 'rgba(234, 179, 8, 0.75)';
        ctx.strokeStyle = '#ca8a04';
        ctx.lineWidth = 0.8 * zScale;
        ctx.beginPath();
        ctx.ellipse(calyxX, calyxY, 3.2 * zScale, 4.2 * zScale, 0.1, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Enclosed bright orange-red Ayurvedic berry inside lantern
        ctx.fillStyle = fruitCol || '#ea580c';
        ctx.beginPath();
        ctx.arc(calyxX, calyxY + 0.5 * zScale, 1.6 * zScale, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  });
}


function renderThreeDFarmCanvas(containerId, state = {}) {
  const lang = state?.lang || 'en';
  const t = translations[lang] || translations.en;

  return `
    <div class="glass-card p-6 relative overflow-hidden space-y-6">
      <!-- Header Controls Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h2 class="text-xl font-extrabold text-white flex items-center gap-2">
              <i data-lucide="box" class="w-6 h-6 text-emerald-400"></i>
              ${t.nav?.threeDFarm || 'Advanced 3D Smart Farm & Crop Environment Simulator'}
            </h2>
            <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              ${t.threeDFarmBadge || 'PHOTOREALISTIC 3D & DRONE ENGINE'}
            </span>
          </div>
          <p class="text-xs text-gray-400 mt-1">
            ${t.threeDFarmSub || 'Heightmap terrain, PBR loam texture, instanced wind-swaying foliage, solar bloom rays & drone telemetry'}
          </p>
        </div>

        <!-- Simulation Control Bar -->
        <div class="flex flex-wrap items-center gap-2 text-xs">
          <!-- Crop Type Selector -->
          <div class="flex items-center gap-1.5 bg-[#064e3b]/80 border border-emerald-400/80 rounded-xl px-3 py-1.5 backdrop-blur shadow-md">
            <i data-lucide="sprout" class="w-4 h-4 text-emerald-300"></i>
            <span class="text-emerald-200 font-extrabold text-xs tracking-wide">${t.cropMeshLabel || 'Crop Mesh'}:</span>
            <select id="sim-3d-crop-select" style="color-scheme: dark; background-color: #064e3b; color: #ffffff;" class="bg-[#064e3b] text-white border border-emerald-400/80 rounded-lg px-2.5 py-1 text-xs font-bold cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-300 shadow-inner">
              <optgroup label="🌾 Cereals & Millets" style="background-color: #022c22; color: #6ee7b7; font-weight: 800;">
                <option value="paddy" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌾 Rice / Paddy (Flooded Field)</option>
                <option value="grain_wheat" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌾 Wheat (Golden Canopy)</option>
                <option value="tall_stalk" selected style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌽 Maize / Corn (Tall Stalk)</option>
                <option value="sorghum_jowar" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌾 Jowar / Sorghum (Dense Golden Panicles)</option>
                <option value="millet_spike" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌾 Bajra / Pearl Millet (Bristly Candle Spikes)</option>
                <option value="millet_ragi" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌾 Ragi (Digitate Finger Heads)</option>
                <option value="grain_barley" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌾 Barley (Long Golden Bearded Awns)</option>
                <option value="oats_panicle" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌾 Oats (Drooping Open Pyramidal Panicles)</option>
              </optgroup>
              <optgroup label="🎋 Cash & Commercial Crops" style="background-color: #022c22; color: #6ee7b7; font-weight: 800;">
                <option value="sugarcane" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🎋 Sugarcane (Segmented Jointed Canes)</option>
                <option value="cotton_boll" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">☁️ Cotton (Fluffy White Bolls)</option>
              </optgroup>
              <optgroup label="🫘 Pulses & Oilseeds" style="background-color: #022c22; color: #6ee7b7; font-weight: 800;">
                <option value="legume_pod" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🫘 Soybean, Pulses & Gram (Fuzzy Pods)</option>
                <option value="groundnut_runner" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🥜 Groundnut (Subterranean Pegs & Pods)</option>
                <option value="sunflower" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌻 Sunflower (Sun-Tracking Ray Florets)</option>
                <option value="mustard_bloom" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌼 Mustard / Sarson (Canary Yellow Blooms & Pods)</option>
              </optgroup>
              <optgroup label="🍅 Vegetables & Solanaceous" style="background-color: #022c22; color: #6ee7b7; font-weight: 800;">
                <option value="fruiting_bush" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🍅 Tomato (Staked Vine & Beefsteak Trusses)</option>
                <option value="chilli_pepper" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌶️ Chilli Pepper (Glossy Hanging Pods)</option>
                <option value="brinjal_eggplant" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🍆 Brinjal / Eggplant (Teardrop Fruit & Prickly Calyx)</option>
                <option value="okra_stalk" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌿 Okra / Bhindi (Pentagonal Pods & Hibiscus Bloom)</option>
                <option value="potato_crop" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🥔 Potato (Stolon Tubers & Star Flowers)</option>
              </optgroup>
              <optgroup label="🥬 Brassicas, Roots & Greens" style="background-color: #022c22; color: #6ee7b7; font-weight: 800;">
                <option value="cauliflower_crop" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🥦 Cauliflower (Ivory Curd & Wrapper Leaves)</option>
                <option value="cabbage_brassica" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🥬 Cabbage (Savoyed Dense Head)</option>
                <option value="garlic_crop" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🧄 Garlic (Compound Tunic Bulb & Scape)</option>
                <option value="onion_garlic" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🧅 Onion (Tunic Bulbs & Hollow Scapes)</option>
                <option value="radish_crop" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🥕 Radish (Crisp White/Pink Taproot & Lyrate Rosette)</option>
                <option value="carrot_radish" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🥕 Carrot (Ribbed Orange Taproot & Lace Frills)</option>
                <option value="leafy_greens" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🥬 Spinach & Palak (Tender Oval Leaves)</option>
                <option value="coriander_herb" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌿 Coriander / Dhaniya (Delicate Umbels & Seed Spheres)</option>
                <option value="fenugreek_herb" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌱 Fenugreek / Methi (Trifoliate Leaves & Pods)</option>
              </optgroup>
              <optgroup label="🍈 Cucurbits & Field Vines" style="background-color: #022c22; color: #6ee7b7; font-weight: 800;">
                <option value="curcurbit_vine" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🍉 Watermelon, Gourds & Cucurbits (Creeping Vines & Tendrils)</option>
              </optgroup>
              <optgroup label="🌴 Plantation & Commercial Crops" style="background-color: #022c22; color: #6ee7b7; font-weight: 800;">
                <option value="banana_plant" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🍌 Banana (Paddle Leaves, Bunch & Floral Heart)</option>
                <option value="palm_coconut" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌴 Coconut Palm (15m Arching Canopy & Clusters)</option>
                <option value="palm_areca" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌴 Areca Palm (Ringed Stalk & Betel Nut Clusters)</option>
                <option value="moringa_drumstick" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌿 Drumstick / Moringa (Hanging Pods & Feathery Canopy)</option>
                <option value="coffee_shrub" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">☕ Coffee Shrub (Crimson Cherries & Glossy Leaves)</option>
                <option value="tea_bush" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🍵 Tea Bush (Pruned Plucking Table)</option>
              </optgroup>
              <optgroup label="🌶️ Spices & Condiments" style="background-color: #022c22; color: #6ee7b7; font-weight: 800;">
                <option value="black_pepper" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌶️ Black Pepper (Woody Climber Vine & Hanging Catkins)</option>
                <option value="cardamom_clump" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌿 Cardamom (Reedy Clump, Distichous Leaves & Seed Pods)</option>
                <option value="ginger_rhizome" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🫚 Ginger (Knobby Rhizome Hands & Reedy Shoots)</option>
                <option value="ginger_turmeric" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🫚 Turmeric (Golden Rhizome Knuckles & Flower Spike)</option>
              </optgroup>
              <optgroup label="🌿 Medicinal & Aromatic Crops" style="background-color: #022c22; color: #6ee7b7; font-weight: 800;">
                <option value="tulsi_plant" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌿 Tulsi / Holy Basil (Sacred Aromatic Bush & Purple Spikes)</option>
                <option value="ashwagandha_shrub" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🍃 Ashwagandha (Ayurvedic Shrub & Papery Calyx Lanterns)</option>
                <option value="lemongrass_tuft" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌾 Lemongrass (Aromatic Dense Clump & Arching Blades)</option>
                <option value="succulent_aloe" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🪴 Aloe Vera (Toothed Spiky Rosette & Bloom Spire)</option>
              </optgroup>
              <optgroup label="🌸 Floriculture & Commercial Flowers" style="background-color: #022c22; color: #6ee7b7; font-weight: 800;">
                <option value="marigold_flower" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌼 Marigold / Genda (Ruffled Pompom Heads & Ferny Leaves)</option>
                <option value="flower_ornamental" style="background-color: #064e3b; color: #ffffff; font-weight: 700;">🌸 Rose & Commercial Floriculture (Vibrant Petals)</option>
              </optgroup>
            </select>
          </div>

          <!-- Lighting / Atmosphere Selector -->
          <div class="flex items-center gap-1.5 bg-[#78350f]/80 border border-amber-400/80 rounded-xl px-3 py-1.5 backdrop-blur shadow-md">
            <i data-lucide="sun" class="w-4 h-4 text-amber-300"></i>
            <span class="text-amber-200 font-extrabold text-xs tracking-wide">${t.lightingLabel || 'Lighting'}:</span>
            <select id="sim-3d-lighting-select" style="color-scheme: dark; background-color: #78350f; color: #ffffff;" class="bg-[#78350f] text-white border border-amber-400/80 rounded-lg px-2.5 py-1 text-xs font-bold cursor-pointer focus:outline-none focus:ring-2 focus:ring-amber-300 shadow-inner">
              <option value="sunrise" style="background-color: #78350f; color: #ffffff; font-weight: 700;" class="py-1.5 font-bold">🌅 ${t.lightSunrise || 'Sunrise (Dawn Horizon / Morning Rays)'}</option>
              <option value="day" selected style="background-color: #78350f; color: #ffffff; font-weight: 700;" class="py-1.5 font-bold">☀️ ${t.lightDay || 'Daylight Solar Rays'}</option>
              <option value="sunset" style="background-color: #78350f; color: #ffffff; font-weight: 700;" class="py-1.5 font-bold">🌇 ${t.lightSunset || 'Golden Sunset Glow'}</option>
              <option value="night" style="background-color: #78350f; color: #ffffff; font-weight: 700;" class="py-1.5 font-bold">🌙 ${t.lightNight || 'Night IoT Telemetry'}</option>
            </select>
          </div>

          <!-- 3D Drone Scanner Toggle Button -->
          <button id="btn-3d-toggle-drone" class="px-3.5 py-2 rounded-xl font-extrabold bg-emerald-600 text-white border border-emerald-400 shadow-lg shadow-emerald-600/30 transition flex items-center gap-1.5 cursor-pointer">
            <i data-lucide="scan" class="w-4 h-4 text-emerald-200 animate-pulse"></i> <span>3D Drone: ON</span>
          </button>

          <!-- 3D Sprinklers Toggle Button -->
          <button id="btn-3d-toggle-sprinkler" class="px-3.5 py-2 rounded-xl font-extrabold bg-blue-500 text-white border border-blue-400 shadow-lg shadow-blue-500/30 transition flex items-center gap-1.5 cursor-pointer">
            <i data-lucide="droplets" class="w-4 h-4 text-white animate-bounce"></i> <span>Sprinklers: ON</span>
          </button>

          <!-- Weather Rain Toggle Button -->
          <button id="btn-3d-toggle-weather" class="px-3.5 py-2 rounded-xl font-extrabold bg-teal-500 text-white border border-teal-400 shadow-lg shadow-teal-500/30 transition flex items-center gap-1.5 cursor-pointer">
            <i data-lucide="cloud-rain" class="w-4 h-4 text-white animate-pulse"></i> <span>Rain: ON</span>
          </button>
        </div>
      </div>

      <!-- 3D Canvas Viewport -->
      <div class="relative w-full h-[500px] rounded-2xl overflow-hidden bg-gray-950 border border-emerald-950/80 shadow-2xl">
        <canvas id="${containerId}" class="w-full h-full block cursor-grab active:cursor-grabbing"></canvas>

        <!-- Dynamic Overlay Telemetry Pin Badges with Crisp High-Contrast Glass Backdrop -->
        <div class="absolute top-4 left-4 bg-gray-950/90 backdrop-blur-md border border-emerald-500/40 rounded-xl p-3.5 text-xs space-y-1.5 font-mono shadow-2xl z-20">
          <div class="text-[10px] text-emerald-400 uppercase tracking-wider font-extrabold flex items-center gap-1.5 border-b border-emerald-900/60 pb-1">
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            ${t.soilStratumTelemetry || '3D Soil Stratum & Canopy Telemetry'}
          </div>
          <div class="text-white flex justify-between gap-4"><span>Horizon A (Topsoil):</span><span class="text-emerald-300 font-bold">42.5% Moisture</span></div>
          <div class="text-white flex justify-between gap-4"><span>Horizon B (Subsoil):</span><span class="text-teal-300 font-bold">68.1% Moisture</span></div>
          <div class="text-white flex justify-between gap-4"><span>Root Zone (Z):</span><span class="text-amber-300 font-bold">45 cm Depth</span></div>
        </div>

        <!-- Atmospheric & Wind Telemetry Overlay -->
        <div class="absolute bottom-4 right-4 bg-gray-950/90 backdrop-blur-md border border-gray-800/80 rounded-xl p-3.5 text-xs space-y-1.5 font-mono shadow-2xl z-20">
          <div class="text-[10px] text-amber-400 uppercase tracking-wider font-extrabold flex items-center gap-1.5 border-b border-gray-800 pb-1">
            <i data-lucide="wind" class="w-3.5 h-3.5 text-amber-400"></i>
            ${t.windDroneTelemetry || 'Field Wind & Drone Telemetry'}
          </div>
          <div class="text-gray-300 flex justify-between gap-4"><span>${t.windVelocityLabel || 'Wind Velocity'}:</span><span class="text-amber-300 font-bold" id="sim-wind-val">15.0 km/h</span></div>
          <div class="text-gray-300 flex justify-between gap-4"><span>Drone Scanner:</span><span class="text-emerald-300 font-bold" id="sim-drone-val">Laser Grid Active</span></div>
        </div>
      </div>

      <!-- Real-World Botanical Reference & Digital Twin Fidelity Card -->
      <div id="sim-botanical-card" class="p-4 rounded-2xl bg-gradient-to-br from-gray-950 via-emerald-950/40 to-gray-950 border border-emerald-500/40 shadow-2xl text-white space-y-3">
        <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-emerald-800/50 pb-2.5">
          <div class="flex items-center gap-2.5">
            <span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
            <div>
              <h4 class="font-extrabold text-sm text-emerald-300 flex items-center gap-1.5">
                <i data-lucide="microscope" class="w-4 h-4 text-emerald-400"></i>
                Real-World Botanical Specimen vs. 3D Farm Digital Twin
              </h4>
              <p class="text-[11px] text-gray-400 font-mono">Calibrated against Google Botanical & ICAR / FAO Agronomic Standards</p>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-1 rounded-full bg-emerald-900/80 border border-emerald-500/60 text-emerald-300 text-[11px] font-bold font-mono">
              Fidelity: 100% Calibrated
            </span>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <!-- Real Photo Thumbnail with Badge -->
          <div class="md:col-span-4 lg:col-span-3 flex flex-col items-center">
            <div class="relative group w-full max-w-[200px] aspect-square rounded-xl overflow-hidden border-2 border-emerald-500/50 shadow-lg bg-black">
              <img id="botanical-ref-photo" src="images/healthy_crops/wheat_healthy.jpg" alt="Botanical Reference" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
              <div class="absolute bottom-0 inset-x-0 bg-black/80 backdrop-blur-sm px-2 py-1 text-center">
                <span class="text-[10px] text-emerald-300 font-bold uppercase tracking-wider">Real Field Photo</span>
              </div>
            </div>
          </div>

          <!-- Botanical Traits & Height Calibration Metrics -->
          <div class="md:col-span-8 lg:col-span-9 space-y-2 text-xs">
            <div class="flex flex-wrap items-center gap-2">
              <span id="botanical-crop-name" class="font-bold text-sm text-white">Wheat (Triticum aestivum)</span>
              <span id="botanical-crop-family" class="px-2 py-0.5 rounded bg-gray-800 text-gray-300 font-mono text-[10px]">Family: Poaceae</span>
              <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700/60 font-mono text-[10px]" id="botanical-height-tag">Height: 0.8 – 1.1 m</span>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-2 font-mono text-[11px] pt-1">
              <div class="p-2 rounded-lg bg-gray-900/90 border border-gray-800 space-y-0.5">
                <div class="text-gray-400 flex items-center gap-1 font-sans font-semibold"><i data-lucide="ruler" class="w-3 h-3 text-amber-400"></i> Height Metric:</div>
                <div class="text-amber-300 font-bold" id="botanical-height-val">0.8 – 1.1 m (Tiller Clump)</div>
                <div class="text-[10px] text-gray-500" id="botanical-twin-height">3D Twin Scale: 46px</div>
              </div>
              <div class="p-2 rounded-lg bg-gray-900/90 border border-gray-800 space-y-0.5">
                <div class="text-gray-400 flex items-center gap-1 font-sans font-semibold"><i data-lucide="layers" class="w-3 h-3 text-emerald-400"></i> Stem / Culm:</div>
                <div class="text-emerald-300 font-bold truncate" id="botanical-stem-val">Hollow culm with solid node rings</div>
                <div class="text-[10px] text-gray-500">PBR Chloroplast Granulation</div>
              </div>
              <div class="p-2 rounded-lg bg-gray-900/90 border border-gray-800 space-y-0.5">
                <div class="text-gray-400 flex items-center gap-1 font-sans font-semibold"><i data-lucide="sparkles" class="w-3 h-3 text-blue-400"></i> Texture / Fruit:</div>
                <div class="text-blue-300 font-bold truncate" id="botanical-fruit-val">Bearded awns with spikelets</div>
                <div class="text-[10px] text-gray-500">Multi-strata Soil Loam</div>
              </div>
            </div>

            <div class="p-2 rounded-lg bg-black/40 border border-emerald-900/50 text-[11px] text-gray-300 space-y-1">
              <div><strong class="text-emerald-400">Foliage Architecture:</strong> <span id="botanical-foliage-desc">Linear flag leaves with parallel venation, auricles and ligules</span></div>
              <div><strong class="text-amber-400">Reproductive Morphology:</strong> <span id="botanical-reprod-desc">Erect golden-amber spikes with 2-ranked overlapping spikelets and long bristly awns</span></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Simulator Slider Controls Row -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs">
        <div class="p-3.5 rounded-xl bg-gray-950/90 border border-gray-800 space-y-1.5 shadow-md">
          <div class="flex justify-between text-gray-300"><span>${t.windVelocityLabel || 'Wind Velocity'}:</span><span class="text-emerald-400 font-bold" id="val-sim-wind">15 km/h</span></div>
          <input type="range" id="slider-sim-wind" min="0" max="40" value="15" class="w-full accent-emerald-500 cursor-pointer" />
        </div>

        <div class="p-3.5 rounded-xl bg-gray-950/90 border border-gray-800 space-y-1.5 shadow-md">
          <div class="flex justify-between text-gray-300"><span>${t.sprinklerSprayLabel || 'Sprinkler Spray Intensity'}:</span><span class="text-blue-400 font-bold" id="val-sim-sprinkler">150 Drops/sec</span></div>
          <input type="range" id="slider-sim-sprinkler" min="50" max="300" step="10" value="150" class="w-full accent-blue-500 cursor-pointer" />
        </div>

        <div class="p-3.5 rounded-xl bg-gray-950/90 border border-gray-800 space-y-1.5 shadow-md">
          <div class="flex justify-between text-gray-300"><span>${t.rainfallIntensityLabel || 'Rainfall Intensity'}:</span><span class="text-teal-300 font-bold" id="val-sim-rain">350 Rain Drops</span></div>
          <input type="range" id="slider-sim-rain" min="100" max="500" step="20" value="350" class="w-full accent-teal-400 cursor-pointer" />
        </div>
      </div>
    </div>
  `;
}

function initThreeDFarmCanvas(canvasId, state = {}, customOptions = {}) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  // Cleanly stop any existing animation loop for this canvas instance
  if (activeSimulators.has(canvasId)) {
    cancelAnimationFrame(activeSimulators.get(canvasId));
    activeSimulators.delete(canvasId);
  }

  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;

  const parentWidth = canvas.parentElement.clientWidth || 800;
  const parentHeight = canvas.parentElement.clientHeight || 500;
  canvas.width = parentWidth * dpr;
  canvas.height = parentHeight * dpr;
  ctx.scale(dpr, dpr);

  let width = parentWidth;
  let height = parentHeight;

  function handleResize() {
    if (!canvas || !canvas.parentElement) return;
    const currentDpr = window.devicePixelRatio || 1;
    const newW = canvas.parentElement.clientWidth || 800;
    const newH = canvas.parentElement.clientHeight || 500;
    if (canvas.width !== Math.floor(newW * currentDpr) || canvas.height !== Math.floor(newH * currentDpr)) {
      canvas.width = Math.floor(newW * currentDpr);
      canvas.height = Math.floor(newH * currentDpr);
      ctx.scale(currentDpr, currentDpr);
      width = newW;
      height = newH;
    }
  }
  window.addEventListener('resize', handleResize);

  // Extract Farmer Profile & Prediction Parameters dynamically
  const input = customOptions.input || state.farmerPredictionInput || {};
  const farm = input.farm || {};
  const soil = input.soil || {};
  const climate = input.climate || {};
  const primaryCrop = customOptions.primaryCrop || state.currentPrediction?.primaryCrop;

  const rawCropIdentifier = customOptions.cropId || customOptions.cropName || primaryCrop?.id || primaryCrop?.name || 'c-01';
  let cropProfile = getCrop3DProfile(rawCropIdentifier);
  let cropType = customOptions.cropType || cropProfile.archetype;

  const soilTypeName = customOptions.soilType || soil.type || 'Medium Black Vertisol';
  const soilOCVal = soil.oc !== undefined ? Number(soil.oc) : 0.65;
  const irrigationMethod = customOptions.irrigation || farm.irrigation || 'Drip';
  const rainfallVal = customOptions.rainfall !== undefined ? Number(customOptions.rainfall) : (climate.rainfall !== undefined ? Number(climate.rainfall) : 600);
  const tempVal = customOptions.temp !== undefined ? Number(customOptions.temp) : (climate.temp !== undefined ? Number(climate.temp) : 26);
  const humidityVal = customOptions.humidity !== undefined ? Number(customOptions.humidity) : (climate.humidity !== undefined ? Number(climate.humidity) : 65);
  const acresVal = customOptions.acres || farm.acres || 5;

  let lightingMode = tempVal > 30 ? 'sunset' : (tempVal < 20 ? 'sunrise' : 'day');
  let isRaining = rainfallVal > 400;
  let isSprinkling = irrigationMethod === 'Sprinkler';
  let isDroneActive = true;
  let windSpeed = Math.min(35, Math.max(8, 12 + Math.round((humidityVal - 50) * 0.2)));
  let sprinklerCount = 150;
  let rainCount = Math.min(500, Math.max(0, Math.round((rainfallVal / 2000) * 500)));
  let angle = 0;
  let droneX = width * 0.2;
  let droneY = 85;
  let droneDirection = 1;
  let wetnessFactor = Math.min(1.0, Math.max(0.2, (rainfallVal / 1200) + (isSprinkling ? 0.35 : 0)));

  // Resolve dynamic soil colors based on farmer's selected soil texture and organic carbon %
  const soilLower = (soilTypeName || '').toLowerCase();
  const ocDark = 1 - Math.min(0.22, Math.max(0, (soilOCVal - 0.4) * 0.18));
  let baseSoilR = 26, baseSoilG = 24, baseSoilB = 22; // Default Deep Black Vertisol
  let subSoilR = 18, subSoilG = 16, subSoilB = 14;

  if (soilLower.includes('red') || soilLower.includes('laterite')) {
    // Red Sandy Loam / Laterite: Terracotta red-brown
    baseSoilR = 142; baseSoilG = 52; baseSoilB = 28;
    subSoilR = 90; subSoilG = 30; subSoilB = 16;
  } else if (soilLower.includes('alluvial') || soilLower.includes('silt')) {
    // Fertile Alluvial Loam: Golden-brown riverbed silt
    baseSoilR = 98; baseSoilG = 70; baseSoilB = 38;
    subSoilR = 58; subSoilG = 42; subSoilB = 22;
  } else if (soilLower.includes('sandy')) {
    // Warm Sandy Loam: Sun-drenched sand
    baseSoilR = 155; baseSoilG = 120; baseSoilB = 72;
    subSoilR = 98; subSoilG = 75; subSoilB = 45;
  } else if (soilLower.includes('clay')) {
    // Heavy Clay
    baseSoilR = 36; baseSoilG = 30; baseSoilB = 25;
    subSoilR = 24; subSoilG = 20; subSoilB = 16;
  }

  baseSoilR = Math.round(baseSoilR * ocDark);
  baseSoilG = Math.round(baseSoilG * ocDark);
  baseSoilB = Math.round(baseSoilB * ocDark);

  // Generate Instanced Plants Seed Matrix with customized botanical archetype spacing & rows
  let plantInstances = [];
  function regeneratePlantMatrix(type) {
    const arch = mapCropTo3DType(type);
    const config = (typeof archetypeConfigs !== 'undefined' && archetypeConfigs[arch]) ? archetypeConfigs[arch] : {
      numRows: 5, plantsPerRow: 14, rowStartY: 0.52, rowSpacing: 22, baseHeight: 50, fruitScale: 1.8, stagger: true
    };

    plantInstances = [];
    const numRows = config.numRows || 6;
    const plantsPerRow = config.plantsPerRow || 16;
    const rowStartY = config.rowStartY || 0.52;
    const rowSpacing = config.rowSpacing || 22;

    for (let r = 0; r < numRows; r++) {
      const rowY = height * rowStartY - 10 + r * rowSpacing;
      const zScale = 0.45 + (r / Math.max(1, numRows - 1)) * 0.55;
      const staggerOffset = (config.stagger && r % 2 === 1) ? (width / Math.max(1, plantsPerRow - 1)) * 0.5 : 0;

      for (let c = 0; c < plantsPerRow; c++) {
        const baseX = (width / Math.max(1, plantsPerRow - 1)) * c + staggerOffset;
        if (baseX < -40 || baseX > width + 40) continue;
        const jitterX = (Math.random() - 0.5) * (14 * zScale);
        plantInstances.push({
          row: r,
          col: c,
          x: baseX + jitterX,
          y: rowY,
          zScale: zScale,
          heightScale: 0.90 + Math.random() * 0.20,
          tiltAngle: (Math.random() - 0.5) * 0.12,
          leafAngle: Math.random() * Math.PI * 2,
          seed: Math.random() * 100
        });
      }
    }
  }

  regeneratePlantMatrix(cropType);

  // Pollen & Dust Motes Particle Engine
  const pollenMotes = [];
  for (let p = 0; p < 45; p++) {
    pollenMotes.push({
      x: Math.random() * width,
      y: Math.random() * height * 0.7,
      size: 1 + Math.random() * 2,
      vx: (Math.random() - 0.5) * 0.6,
      vy: -0.2 - Math.random() * 0.4,
      alpha: 0.3 + Math.random() * 0.5,
      phase: Math.random() * Math.PI * 2
    });
  }

  // Multi-Scale Volumetric Cloud Particle Engine with Rich Fractal Billow Hierarchy (18-22 Lobes)
  const clouds = [
    {
      x: width * 0.05, y: 38, size: 82, speed: 0.22,
      billows: [
        { dx: 0, dy: 0, r: 1.0, seed: 1.1 },
        { dx: 28, dy: -12, r: 0.78, seed: 2.3 },
        { dx: -30, dy: -10, r: 0.74, seed: 3.7 },
        { dx: 54, dy: 4, r: 0.58, seed: 4.2 },
        { dx: -52, dy: 6, r: 0.55, seed: 5.9 },
        { dx: 16, dy: -22, r: 0.68, seed: 6.4 },
        { dx: -14, dy: -20, r: 0.64, seed: 7.1 },
        { dx: 40, dy: -16, r: 0.60, seed: 8.5 },
        { dx: -38, dy: -14, r: 0.58, seed: 9.3 },
        { dx: 70, dy: 14, r: 0.42, seed: 10.1 },
        { dx: -68, dy: 16, r: 0.40, seed: 11.2 },
        { dx: 8, dy: -30, r: 0.50, seed: 12.3 },
        { dx: -8, dy: -28, r: 0.48, seed: 13.4 },
        { dx: 30, dy: 10, r: 0.52, seed: 14.5 },
        { dx: -28, dy: 12, r: 0.50, seed: 15.6 }
      ]
    },
    {
      x: width * 0.44, y: 20, size: 115, speed: 0.28,
      billows: [
        { dx: 0, dy: 0, r: 1.0, seed: 16.2 },
        { dx: 38, dy: -16, r: 0.82, seed: 17.5 },
        { dx: -40, dy: -14, r: 0.78, seed: 18.8 },
        { dx: 72, dy: 6, r: 0.62, seed: 19.1 },
        { dx: -70, dy: 8, r: 0.58, seed: 20.6 },
        { dx: 22, dy: -30, r: 0.72, seed: 21.3 },
        { dx: -20, dy: -26, r: 0.68, seed: 22.9 },
        { dx: 54, dy: -22, r: 0.64, seed: 23.4 },
        { dx: -50, dy: -18, r: 0.60, seed: 24.2 },
        { dx: 92, dy: 16, r: 0.44, seed: 25.1 },
        { dx: -88, dy: 18, r: 0.42, seed: 26.2 },
        { dx: 12, dy: -38, r: 0.54, seed: 27.3 },
        { dx: -10, dy: -36, r: 0.52, seed: 28.4 },
        { dx: 42, dy: 12, r: 0.56, seed: 29.5 },
        { dx: -38, dy: 14, r: 0.54, seed: 30.6 }
      ]
    },
    {
      x: width * 0.82, y: 44, size: 88, speed: 0.24,
      billows: [
        { dx: 0, dy: 0, r: 1.0, seed: 31.5 },
        { dx: 32, dy: -14, r: 0.78, seed: 32.1 },
        { dx: -34, dy: -12, r: 0.74, seed: 33.4 },
        { dx: 60, dy: 6, r: 0.58, seed: 34.8 },
        { dx: -58, dy: 8, r: 0.55, seed: 35.3 },
        { dx: 18, dy: -24, r: 0.66, seed: 36.7 },
        { dx: -16, dy: -22, r: 0.62, seed: 37.2 },
        { dx: 45, dy: -18, r: 0.60, seed: 38.5 },
        { dx: -42, dy: -16, r: 0.56, seed: 39.3 },
        { dx: 75, dy: 14, r: 0.40, seed: 40.1 },
        { dx: -72, dy: 16, r: 0.38, seed: 41.2 }
      ]
    }
  ];

  // Rain Streak Particle Engine
  let raindrops = [];
  function generateRaindrops(count) {
    raindrops = [];
    for (let i = 0; i < count; i++) {
      raindrops.push({
        x: Math.random() * width * 1.5 - width * 0.25,
        y: Math.random() * height,
        speed: 9 + Math.random() * 9,
        length: 18 + Math.random() * 18,
        alpha: 0.35 + Math.random() * 0.45
      });
    }
  }
  generateRaindrops(rainCount);

  // Sprinkler Nozzle Array
  const sprinklerNozzles = [
    { x: width * 0.22, y: height * 0.54 },
    { x: width * 0.50, y: height * 0.53 },
    { x: width * 0.78, y: height * 0.54 }
  ];

  // Water Spray Mist Particle Engine
  let mistParticles = [];
  function generateMistParticles(count) {
    mistParticles = [];
    for (let i = 0; i < count; i++) {
      const nozzle = sprinklerNozzles[i % sprinklerNozzles.length];
      mistParticles.push({
        nozzleIdx: i % sprinklerNozzles.length,
        x: nozzle.x,
        y: nozzle.y - 18,
        vx: (Math.random() - 0.5) * 12,
        vy: -6 - Math.random() * 7,
        size: 2.2 + Math.random() * 2.8,
        alpha: 0.75 + Math.random() * 0.25,
        life: Math.random() * 35
      });
    }
  }
  generateMistParticles(sprinklerCount);

  const splashRings = [];

  // Displaced Heightmap Terrain Elevation Function
  function getTerrainHeight(x, baseY) {
    const hill1 = Math.sin(x * 0.006 + 0.5) * 9;
    const hill2 = Math.cos(x * 0.015) * 4;
    return baseY + hill1 + hill2;
  }

  // -------------------------------------------------------------
  // PROCEDURAL ULTRA-HIGH-RESOLUTION TEXTURE PATTERN GENERATORS
  // -------------------------------------------------------------
  function createProceduralSoilPattern() {
    const pCanvas = document.createElement('canvas');
    pCanvas.width = 512;
    pCanvas.height = 512;
    const pCtx = pCanvas.getContext('2d');

    // Base rich organic loam earth
    pCtx.fillStyle = '#26160e';
    pCtx.fillRect(0, 0, 512, 512);

    // Micro-clod aggregates, humus pockets & mineral crumb structure (Horizon A)
    for (let i = 0; i < 4800; i++) {
      const px = Math.random() * 512;
      const py = Math.random() * 512;
      const pSize = 0.8 + Math.random() * 3.6;
      const shade = Math.random();
      if (shade < 0.40) {
        pCtx.fillStyle = 'rgba(14, 7, 4, 0.82)'; // dark humus organic crevice
      } else if (shade < 0.72) {
        pCtx.fillStyle = 'rgba(68, 40, 24, 0.75)'; // rich crumb loam clump
      } else if (shade < 0.88) {
        pCtx.fillStyle = 'rgba(125, 82, 52, 0.60)'; // sun-dried topsoil highlight
      } else if (shade < 0.96) {
        pCtx.fillStyle = 'rgba(215, 190, 165, 0.68)'; // quartz mineral & crystalline sand speck
      } else {
        pCtx.fillStyle = 'rgba(92, 60, 34, 0.70)'; // decomposed straw/stalk fiber fragment
      }
      pCtx.beginPath();
      pCtx.ellipse(px, py, pSize, pSize * 0.72, Math.random() * Math.PI, 0, Math.PI * 2);
      pCtx.fill();
    }

    // Micro-fissures, root hairs & crumb fractures
    pCtx.strokeStyle = 'rgba(12, 6, 3, 0.65)';
    pCtx.lineWidth = 1.1;
    for (let f = 0; f < 85; f++) {
      let fx = Math.random() * 512;
      let fy = Math.random() * 512;
      pCtx.beginPath();
      pCtx.moveTo(fx, fy);
      for (let s = 0; s < 4; s++) {
        fx += (Math.random() - 0.5) * 14;
        fy += Math.random() * 11;
        pCtx.lineTo(fx, fy);
      }
      pCtx.stroke();
    }

    // Fine organic straw fibers embedded in topsoil
    pCtx.strokeStyle = 'rgba(180, 140, 95, 0.55)';
    pCtx.lineWidth = 0.8;
    for (let sf = 0; sf < 120; sf++) {
      const sx = Math.random() * 512;
      const sy = Math.random() * 512;
      const sLen = 4 + Math.random() * 8;
      const sAng = Math.random() * Math.PI;
      pCtx.beginPath();
      pCtx.moveTo(sx, sy);
      pCtx.lineTo(sx + Math.cos(sAng) * sLen, sy + Math.sin(sAng) * sLen);
      pCtx.stroke();
    }

    return ctx.createPattern(pCanvas, 'repeat');
  }

  function createProceduralSubsoilPattern() {
    const pCanvas = document.createElement('canvas');
    pCanvas.width = 512;
    pCanvas.height = 512;
    const pCtx = pCanvas.getContext('2d');

    // Base dense compacted subsoil clay/silt (Horizon B)
    pCtx.fillStyle = '#180c05';
    pCtx.fillRect(0, 0, 512, 512);

    // Geological sedimentary horizontal strata bands
    for (let b = 0; b < 512; b += 16) {
      pCtx.fillStyle = b % 32 === 0 ? 'rgba(56, 28, 14, 0.55)' : 'rgba(16, 8, 3, 0.48)';
      pCtx.fillRect(0, b, 512, 11);
    }

    // Sedimentary gravel & mineral pebble inclusions
    for (let g = 0; g < 900; g++) {
      const gx = Math.random() * 512;
      const gy = Math.random() * 512;
      const gr = 1.2 + Math.random() * 4.2;
      pCtx.fillStyle = Math.random() > 0.5 ? 'rgba(105, 85, 68, 0.65)' : 'rgba(46, 28, 18, 0.80)';
      pCtx.beginPath();
      pCtx.ellipse(gx, gy, gr, gr * 0.62, Math.random() * Math.PI, 0, Math.PI * 2);
      pCtx.fill();
    }

    return ctx.createPattern(pCanvas, 'repeat');
  }

  function createProceduralSolarPattern() {
    const pCanvas = document.createElement('canvas');
    pCanvas.width = 256;
    pCanvas.height = 256;
    const pCtx = pCanvas.getContext('2d');

    // Photosphere convective plasma base
    pCtx.fillStyle = '#fffdf0';
    pCtx.fillRect(0, 0, 256, 256);

    // Convective granulation bubbling cells
    for (let i = 0; i < 750; i++) {
      const cx = Math.random() * 256;
      const cy = Math.random() * 256;
      const cr = 2 + Math.random() * 5.2;
      const cGrad = pCtx.createRadialGradient(cx, cy, 0, cx, cy, cr);
      cGrad.addColorStop(0, 'rgba(255, 255, 255, 0.98)');
      cGrad.addColorStop(0.55, 'rgba(254, 240, 138, 0.70)');
      cGrad.addColorStop(0.85, 'rgba(245, 158, 11, 0.45)');
      cGrad.addColorStop(1, 'rgba(194, 65, 12, 0.25)');
      pCtx.fillStyle = cGrad;
      pCtx.beginPath();
      pCtx.arc(cx, cy, cr, 0, Math.PI * 2);
      pCtx.fill();
    }

    // 3 Magnetic Solar Sunspots (Umbra Core & Penumbra Filaments)
    const sunspots = [
      { x: 105, y: 110, r: 7.5 },
      { x: 145, y: 135, r: 5.5 },
      { x: 160, y: 120, r: 4.0 }
    ];
    sunspots.forEach(spot => {
      // Penumbra (lighter brown outer fringe with radial filaments)
      pCtx.fillStyle = 'rgba(120, 53, 15, 0.75)';
      pCtx.beginPath();
      pCtx.arc(spot.x, spot.y, spot.r * 1.7, 0, Math.PI * 2);
      pCtx.fill();

      // Umbra (dark black-brown magnetic core)
      pCtx.fillStyle = '#1a0602';
      pCtx.beginPath();
      pCtx.arc(spot.x, spot.y, spot.r, 0, Math.PI * 2);
      pCtx.fill();

      // Penumbra radial filament strokes
      pCtx.strokeStyle = 'rgba(180, 83, 9, 0.6)';
      pCtx.lineWidth = 0.8;
      for (let f = 0; f < 12; f++) {
        const ang = (f / 12) * Math.PI * 2;
        pCtx.beginPath();
        pCtx.moveTo(spot.x + Math.cos(ang) * spot.r, spot.y + Math.sin(ang) * spot.r);
        pCtx.lineTo(spot.x + Math.cos(ang) * (spot.r * 1.8), spot.y + Math.sin(ang) * (spot.r * 1.8));
        pCtx.stroke();
      }
    });

    return pCanvas;
  }

  // Procedural dual-frequency lobed billow drawer for realistic organic cumulus clouds
  function drawTexturedBillowPuff(targetCtx, bx, by, br, seed) {
    targetCtx.beginPath();
    const steps = 28;
    for (let i = 0; i <= steps; i++) {
      const theta = (i / steps) * Math.PI * 2;
      const displacement = Math.sin(theta * 5 + seed) * 0.14 + Math.cos(theta * 9 + seed * 1.5) * 0.08 + Math.sin(theta * 14) * 0.035;
      const curR = br * (1 + displacement);
      const px = bx + Math.cos(theta) * curR;
      const py = by + Math.sin(theta) * curR;
      if (i === 0) targetCtx.moveTo(px, py);
      else targetCtx.lineTo(px, py);
    }
    targetCtx.closePath();
  }

  // Procedural organic straw mulch and decomposed crop residue pattern
  function createProceduralMulchTillagePattern() {
    const pCanvas = document.createElement('canvas');
    pCanvas.width = 256;
    pCanvas.height = 256;
    const pCtx = pCanvas.getContext('2d');

    // Transparent background allowing loam soil strata to show underneath
    pCtx.clearRect(0, 0, 256, 256);

    // Decomposed straw mulch, dried stalk fibers & organic residues
    for (let i = 0; i < 280; i++) {
      const mx = Math.random() * 256;
      const my = Math.random() * 256;
      const mLen = 6 + Math.random() * 18;
      const mAng = (Math.random() - 0.5) * 0.8 + 0.2; // oriented along tillage direction
      const mW = 1.0 + Math.random() * 2.2;

      // Color variation: golden wheat straw, weathered chaff, decomposed humus fiber
      const mulchColors = [
        'rgba(217, 180, 110, 0.72)', // golden straw
        'rgba(180, 142, 85, 0.65)',  // weathered chaff
        'rgba(146, 110, 68, 0.58)',  // decomposed brown humus fiber
        'rgba(238, 214, 155, 0.80)', // bright sunlit straw splinter
        'rgba(110, 80, 50, 0.45)'    // moist bottom residue
      ];
      pCtx.strokeStyle = mulchColors[Math.floor(Math.random() * mulchColors.length)];
      pCtx.lineWidth = mW;
      pCtx.lineCap = 'round';
      pCtx.beginPath();
      pCtx.moveTo(mx, my);
      const cpx = mx + Math.cos(mAng) * (mLen * 0.5) + (Math.random() - 0.5) * 3;
      const cpy = my + Math.sin(mAng) * (mLen * 0.5) + (Math.random() - 0.5) * 3;
      const endX = mx + Math.cos(mAng) * mLen;
      const endY = my + Math.sin(mAng) * mLen;
      pCtx.quadraticCurveTo(cpx, cpy, endX, endY);
      pCtx.stroke();
    }

    // Small organic flakes / crop debris fragments
    for (let f = 0; f < 140; f++) {
      const fx = Math.random() * 256;
      const fy = Math.random() * 256;
      const fr = 1.2 + Math.random() * 2.8;
      pCtx.fillStyle = Math.random() > 0.5 ? 'rgba(163, 126, 74, 0.55)' : 'rgba(92, 64, 38, 0.65)';
      pCtx.beginPath();
      pCtx.ellipse(fx, fy, fr, fr * 0.55, Math.random() * Math.PI, 0, Math.PI * 2);
      pCtx.fill();
    }

    return ctx.createPattern(pCanvas, 'repeat');
  }

  // Procedural cellular leaf cuticle and micro-venation pattern
  function createProceduralLeafPattern() {
    const pCanvas = document.createElement('canvas');
    pCanvas.width = 128;
    pCanvas.height = 128;
    const pCtx = pCanvas.getContext('2d');

    // Base cuticle waxy chlorophyll emerald
    pCtx.fillStyle = '#15803d';
    pCtx.fillRect(0, 0, 128, 128);

    // Microscopic cellular chloroplast granulation
    for (let c = 0; c < 220; c++) {
      const cx = Math.random() * 128;
      const cy = Math.random() * 128;
      const cr = 1.5 + Math.random() * 3.5;
      const cGrad = pCtx.createRadialGradient(cx, cy, 0, cx, cy, cr);
      cGrad.addColorStop(0, 'rgba(74, 222, 128, 0.45)');
      cGrad.addColorStop(0.7, 'rgba(34, 197, 94, 0.25)');
      cGrad.addColorStop(1, 'rgba(21, 128, 61, 0)');
      pCtx.fillStyle = cGrad;
      pCtx.beginPath();
      pCtx.arc(cx, cy, cr, 0, Math.PI * 2);
      pCtx.fill();
    }

    // Secondary & tertiary leaf veinlet anastomosing reticulation
    pCtx.strokeStyle = 'rgba(134, 239, 172, 0.28)';
    pCtx.lineWidth = 0.65;
    for (let v = 0; v < 35; v++) {
      let vx = Math.random() * 128;
      let vy = Math.random() * 128;
      pCtx.beginPath();
      pCtx.moveTo(vx, vy);
      for (let seg = 0; seg < 3; seg++) {
        vx += (Math.random() - 0.5) * 12;
        vy += (Math.random() - 0.5) * 12;
        pCtx.lineTo(vx, vy);
      }
      pCtx.stroke();
    }

    // Micro dewdrop glistening highlight
    for (let d = 0; d < 12; d++) {
      const dx = Math.random() * 128;
      const dy = Math.random() * 128;
      pCtx.fillStyle = 'rgba(255, 255, 255, 0.65)';
      pCtx.beginPath();
      pCtx.arc(dx, dy, 0.9, 0, Math.PI * 2);
      pCtx.fill();
    }

    return ctx.createPattern(pCanvas, 'repeat');
  }

  const soilPattern = createProceduralSoilPattern();
  const subsoilPattern = createProceduralSubsoilPattern();
  const solarCanvas = createProceduralSolarPattern();
  const mulchPattern = createProceduralMulchTillagePattern();
  const leafPattern = createProceduralLeafPattern();

  function drawScene() {
    ctx.clearRect(0, 0, width, height);

    // Update Soil Wetness State
    if (isRaining || isSprinkling) {
      if (wetnessFactor < 1.0) wetnessFactor += 0.005;
    } else {
      if (wetnessFactor > 0.3) wetnessFactor -= 0.002;
    }

    const horizonY = height * 0.52;

    // -------------------------------------------------------------
    // 1. SKY DOME, SUN FLARE, GOD RAYS & CELESTIAL ATMOSPHERE
    // -------------------------------------------------------------
    const skyGrad = ctx.createLinearGradient(0, 0, 0, horizonY + 20);
    if (isRaining) {
      skyGrad.addColorStop(0, '#071018');
      skyGrad.addColorStop(0.5, '#0e1d28');
      skyGrad.addColorStop(1, '#172c3a');
    } else if (lightingMode === 'sunrise') {
      // Magnificent dawn sunrise: pre-dawn indigo zenith to radiant golden dawn horizon
      skyGrad.addColorStop(0, '#0a0618');
      skyGrad.addColorStop(0.28, '#361234');
      skyGrad.addColorStop(0.55, '#7c1a45');
      skyGrad.addColorStop(0.78, '#c44330');
      skyGrad.addColorStop(0.92, '#f07b22');
      skyGrad.addColorStop(1, '#fbbf24');
    } else if (lightingMode === 'sunset') {
      skyGrad.addColorStop(0, '#210d05');
      skyGrad.addColorStop(0.4, '#5e2309');
      skyGrad.addColorStop(0.75, '#a34211');
      skyGrad.addColorStop(1, '#d97724');
    } else if (lightingMode === 'night') {
      skyGrad.addColorStop(0, '#020609');
      skyGrad.addColorStop(0.6, '#061318');
      skyGrad.addColorStop(1, '#0b2126');
    } else { // Daylight
      skyGrad.addColorStop(0, '#041812');
      skyGrad.addColorStop(0.4, '#0a3024');
      skyGrad.addColorStop(0.8, '#134e3c');
      skyGrad.addColorStop(1, '#1c6952');
    }
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, width, horizonY + 20);

    // Sun / Moon Position dynamically adapted to Temperature & Cultivation Season
    const sunAltitude = tempVal > 30 ? (horizonY - 160) : (tempVal < 20 ? (horizonY - 25) : (horizonY - 110));
    const sunX = lightingMode === 'sunset' ? width * 0.82 : (lightingMode === 'sunrise' ? width * 0.22 : width * 0.72);
    const sunY = sunAltitude + Math.sin(angle * 0.8) * 3;

    if (lightingMode !== 'night') {
      const isStormy = rainfallVal > 1100;
      // 1A. Volumetric God Rays (Light Shafts) with subtle shimmer
      ctx.save();
      for (let r = -6; r <= 6; r++) {
        const rayAlpha = isStormy 
          ? (0.05 + Math.sin(angle * 1.5 + r) * 0.02)
          : (0.12 + Math.sin(angle * 1.5 + r) * 0.04) * (lightingMode === 'sunrise' ? 1.4 : (lightingMode === 'sunset' ? 1.3 : 1.0));
        
        if (isStormy) {
          ctx.fillStyle = `rgba(186, 230, 253, ${rayAlpha})`;
        } else if (lightingMode === 'sunrise') {
          ctx.fillStyle = `rgba(253, 186, 116, ${rayAlpha})`;
        } else if (lightingMode === 'sunset') {
          ctx.fillStyle = `rgba(251, 146, 60, ${rayAlpha})`;
        } else {
          ctx.fillStyle = `rgba(254, 240, 138, ${rayAlpha})`;
        }
        ctx.beginPath();
        ctx.moveTo(sunX, sunY);
        const raySpread = lightingMode === 'sunrise' ? 120 : 95;
        const targetOffset = lightingMode === 'sunrise' ? 160 : -180;
        ctx.lineTo(sunX + r * raySpread + targetOffset, height);
        ctx.lineTo(sunX + r * raySpread + targetOffset + 90, height);
        ctx.closePath();
        ctx.fill();
      }
      ctx.restore();

      // 1B. Outer Chromosphere, Dynamic Prominences & Coronal Filaments
      ctx.beginPath();
      ctx.arc(sunX, sunY, tempVal > 30 ? 190 : 160, 0, Math.PI * 2);
      const outerCorona = ctx.createRadialGradient(sunX, sunY, 12, sunX, sunY, tempVal > 30 ? 190 : 160);
      const coronaColor = isStormy ? '186, 230, 253' : (lightingMode === 'sunset' ? '245, 158, 11' : (lightingMode === 'sunrise' ? '251, 113, 133' : '253, 224, 71'));
      outerCorona.addColorStop(0, `rgba(${coronaColor}, ${isStormy ? 0.45 : 0.70})`);
      outerCorona.addColorStop(0.25, `rgba(${coronaColor}, ${isStormy ? 0.18 : 0.32})`);
      outerCorona.addColorStop(0.68, `rgba(${coronaColor}, 0.08)`);
      outerCorona.addColorStop(1, `rgba(${coronaColor}, 0)`);
      ctx.fillStyle = outerCorona;
      ctx.fill();

      // 48 Coronal Plasma Filament Threads
      ctx.save();
      ctx.strokeStyle = `rgba(${coronaColor}, 0.35)`;
      ctx.lineWidth = 0.9;
      for (let f = 0; f < 48; f++) {
        const fAngle = (f / 48) * Math.PI * 2 + Math.sin(angle * 2 + f) * 0.05;
        const fLen = 42 + Math.sin(angle * 3 + f * 1.5) * 15;
        ctx.beginPath();
        ctx.moveTo(sunX + Math.cos(fAngle) * 28, sunY + Math.sin(fAngle) * 28);
        ctx.lineTo(sunX + Math.cos(fAngle) * (28 + fLen), sunY + Math.sin(fAngle) * (28 + fLen));
        ctx.stroke();
      }
      ctx.restore();

      // 8 Dynamic Solar Prominence Eruptive Plasma Arcs
      ctx.save();
      for (let p = 0; p < 8; p++) {
        const pAngle = (p / 8) * Math.PI * 2 + 0.25;
        const loopR = 12 + Math.sin(angle * 2.8 + p) * 5;
        const loopBaseX = sunX + Math.cos(pAngle) * 27;
        const loopBaseY = sunY + Math.sin(pAngle) * 27;
        ctx.strokeStyle = lightingMode === 'sunrise' ? 'rgba(244, 63, 94, 0.8)' : (lightingMode === 'sunset' ? 'rgba(239, 68, 68, 0.8)' : 'rgba(245, 158, 11, 0.75)');
        ctx.lineWidth = 2.0;
        ctx.beginPath();
        ctx.arc(loopBaseX, loopBaseY, loopR, pAngle - Math.PI * 0.4, pAngle + Math.PI * 0.4);
        ctx.stroke();
      }
      ctx.restore();

      // 1C. Anamorphic Horizontal Flare Streak & Multi-Stage Starburst
      const streakGrad = ctx.createLinearGradient(sunX - 250, sunY, sunX + 250, sunY);
      streakGrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
      streakGrad.addColorStop(0.22, 'rgba(56, 189, 248, 0.25)'); // Cyan anamorphic edge
      streakGrad.addColorStop(0.44, `rgba(${coronaColor}, 0.35)`);
      streakGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0.98)');
      streakGrad.addColorStop(0.56, `rgba(${coronaColor}, 0.35)`);
      streakGrad.addColorStop(0.78, 'rgba(244, 114, 182, 0.25)'); // Rose anamorphic edge
      streakGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
      ctx.fillStyle = streakGrad;
      ctx.fillRect(sunX - 250, sunY - 3, 500, 6);

      // Multi-Stage Starburst Diffraction Rays (8 Primary + 24 Secondary)
      ctx.strokeStyle = `rgba(${coronaColor}, 0.60)`;
      ctx.lineWidth = 1.6;
      for (let s = 0; s < 8; s++) {
        const sAngle = (s * Math.PI / 4) + Math.PI / 8;
        ctx.beginPath();
        ctx.moveTo(sunX, sunY);
        ctx.lineTo(sunX + Math.cos(sAngle) * 105, sunY + Math.sin(sAngle) * 105);
        ctx.stroke();
      }
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.28)';
      ctx.lineWidth = 0.8;
      for (let s = 0; s < 24; s++) {
        const sAngle = (s * Math.PI / 12);
        ctx.beginPath();
        ctx.moveTo(sunX, sunY);
        ctx.lineTo(sunX + Math.cos(sAngle) * 65, sunY + Math.sin(sAngle) * 65);
        ctx.stroke();
      }

      // 1D. Photosphere Solar Disc with Convective Granulation & Magnetic Sunspots
      ctx.save();
      ctx.beginPath();
      ctx.arc(sunX, sunY, 30, 0, Math.PI * 2);
      ctx.clip();

      // Base white-hot solar core
      const coreGrad = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, 30);
      coreGrad.addColorStop(0, '#ffffff');
      coreGrad.addColorStop(0.42, '#fffbeb');
      coreGrad.addColorStop(0.80, lightingMode === 'sunrise' ? '#f472b6' : (lightingMode === 'sunset' ? '#fb923c' : '#fef08a'));
      coreGrad.addColorStop(1, lightingMode === 'sunrise' ? '#e11d48' : (lightingMode === 'sunset' ? '#c2410c' : '#f59e0b'));
      ctx.fillStyle = coreGrad;
      ctx.fill();

      // Overlay Solar Convective Granulation & Sunspots Canvas
      ctx.globalAlpha = 0.52;
      ctx.translate(sunX, sunY);
      ctx.rotate(angle * 0.05);
      ctx.drawImage(solarCanvas, -35, -35, 70, 70);
      ctx.restore();

      // Solar Limb Darkening Ring
      ctx.save();
      ctx.beginPath();
      ctx.arc(sunX, sunY, 30, 0, Math.PI * 2);
      ctx.lineWidth = 2.8;
      ctx.strokeStyle = lightingMode === 'sunrise' ? 'rgba(225, 29, 72, 0.75)' : (lightingMode === 'sunset' ? 'rgba(194, 65, 12, 0.75)' : 'rgba(217, 119, 6, 0.6)');
      ctx.stroke();
      ctx.restore();

      // 1E. Prismatic Lens Flare Discs with Chromatic Aberration & Hexagonal Blades
      const centerX = width * 0.5;
      const centerY = height * 0.5;
      const dirX = centerX - sunX;
      const dirY = centerY - sunY;

      // Aperture Flare 1 (Prismatic Violet/Magenta Halo)
      ctx.beginPath();
      ctx.arc(sunX + dirX * 0.38, sunY + dirY * 0.38, 22, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(192, 132, 252, 0.18)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(236, 72, 153, 0.35)';
      ctx.lineWidth = 1.2;
      ctx.stroke();

      // Aperture Flare 2 (Warm Golden Disc)
      ctx.beginPath();
      ctx.arc(sunX + dirX * 0.72, sunY + dirY * 0.72, 32, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(251, 191, 36, 0.14)';
      ctx.fill();

      // Aperture Flare 3 (Hexagonal Aperture Blades with Cyan Chromatic Fringe)
      const hexX = sunX + dirX * 1.12;
      const hexY = sunY + dirY * 1.12;
      const hexR = 38;
      ctx.beginPath();
      for (let h = 0; h < 6; h++) {
        const hAngle = (h * Math.PI / 3) + 0.2;
        const hx = hexX + Math.cos(hAngle) * hexR;
        const hy = hexY + Math.sin(hAngle) * hexR;
        if (h === 0) ctx.moveTo(hx, hy);
        else ctx.lineTo(hx, hy);
      }
      ctx.closePath();
      ctx.fillStyle = 'rgba(45, 212, 191, 0.09)';
      ctx.fill();
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.32)';
      ctx.lineWidth = 1.5;
      ctx.stroke();

    } else if (lightingMode === 'night') {
      // Celestial Moon with Crater Shading & Luminous Corona
      ctx.beginPath();
      ctx.arc(width * 0.8, horizonY - 140, 22, 0, Math.PI * 2);
      const moonGrad = ctx.createRadialGradient(width * 0.8, horizonY - 140, 4, width * 0.8, horizonY - 140, 65);
      moonGrad.addColorStop(0, 'rgba(248, 250, 252, 0.98)');
      moonGrad.addColorStop(0.35, 'rgba(226, 232, 240, 0.45)');
      moonGrad.addColorStop(0.7, 'rgba(148, 163, 184, 0.12)');
      moonGrad.addColorStop(1, 'rgba(148, 163, 184, 0)');
      ctx.fillStyle = moonGrad;
      ctx.fill();

      // Moon Craters
      ctx.fillStyle = 'rgba(100, 116, 139, 0.25)';
      ctx.beginPath();
      ctx.arc(width * 0.8 - 6, horizonY - 142, 4, 0, Math.PI * 2);
      ctx.arc(width * 0.8 + 4, horizonY - 136, 5, 0, Math.PI * 2);
      ctx.arc(width * 0.8 + 3, horizonY - 146, 3, 0, Math.PI * 2);
      ctx.fill();
    }

    // -------------------------------------------------------------
    // 1F. VOLUMETRIC FRACTAL CLOUDS, SILVER LINING & VIRGA TRAILS
    // -------------------------------------------------------------
    clouds.forEach(c => {
      ctx.save();
      const cx = c.x;
      const cy = c.y;
      const r = c.size;

      // Trailing Virga Vapor & Rain Tendrils beneath cloud base
      ctx.save();
      ctx.strokeStyle = isRaining ? 'rgba(71, 85, 105, 0.28)' : (lightingMode === 'sunrise' ? 'rgba(244, 114, 182, 0.15)' : 'rgba(255, 255, 255, 0.08)');
      ctx.lineWidth = 1.2;
      for (let v = -5; v <= 5; v++) {
        const vx = cx + v * (r * 0.16);
        const vy = cy + r * 0.35;
        const vWind = windSpeed * 0.8;
        ctx.beginPath();
        ctx.moveTo(vx, vy);
        ctx.quadraticCurveTo(vx - vWind * 0.5, vy + 25, vx - vWind, vy + 45);
        ctx.stroke();
      }
      ctx.restore();

      // Base Ambient Shadow across all composite billows
      c.billows.forEach(b => {
        const bx = cx + b.dx;
        const by = cy + b.dy + b.r * r * 0.2;
        const br = b.r * r;
        drawTexturedBillowPuff(ctx, bx, by, br, b.seed);
        const baseGrad = ctx.createRadialGradient(bx, by + br * 0.35, 2, bx, by + br * 0.35, br);
        if (isRaining) {
          baseGrad.addColorStop(0, 'rgba(15, 23, 42, 0.95)');
          baseGrad.addColorStop(1, 'rgba(30, 41, 59, 0.7)');
        } else if (lightingMode === 'sunrise') {
          baseGrad.addColorStop(0, 'rgba(76, 29, 72, 0.80)');
          baseGrad.addColorStop(1, 'rgba(131, 24, 67, 0.45)');
        } else if (lightingMode === 'sunset') {
          baseGrad.addColorStop(0, 'rgba(76, 29, 149, 0.75)');
          baseGrad.addColorStop(1, 'rgba(124, 45, 18, 0.5)');
        } else {
          baseGrad.addColorStop(0, 'rgba(15, 45, 38, 0.55)');
          baseGrad.addColorStop(1, 'rgba(30, 75, 60, 0.25)');
        }
        ctx.fillStyle = baseGrad;
        ctx.fill();
      });

      // 3D Subsurface Scattering & Volume for Billow Lobes
      c.billows.forEach(b => {
        const bx = cx + b.dx;
        const by = cy + b.dy;
        const br = b.r * r * 0.92;
        drawTexturedBillowPuff(ctx, bx, by, br, b.seed);
        const topGrad = ctx.createRadialGradient(bx - br * 0.25, by - br * 0.35, 1, bx - br * 0.1, by - br * 0.2, br);
        if (isRaining) {
          topGrad.addColorStop(0, 'rgba(148, 163, 184, 0.65)');
          topGrad.addColorStop(0.7, 'rgba(71, 85, 105, 0.3)');
          topGrad.addColorStop(1, 'rgba(51, 65, 85, 0.05)');
        } else if (lightingMode === 'sunrise') {
          topGrad.addColorStop(0, 'rgba(255, 241, 242, 0.98)');
          topGrad.addColorStop(0.40, 'rgba(254, 205, 211, 0.85)');
          topGrad.addColorStop(0.75, 'rgba(244, 63, 94, 0.35)');
          topGrad.addColorStop(1, 'rgba(190, 24, 93, 0.05)');
        } else if (lightingMode === 'sunset') {
          topGrad.addColorStop(0, 'rgba(254, 215, 170, 0.98)');
          topGrad.addColorStop(0.45, 'rgba(251, 146, 60, 0.75)');
          topGrad.addColorStop(0.85, 'rgba(194, 65, 12, 0.35)');
          topGrad.addColorStop(1, 'rgba(124, 45, 18, 0.05)');
        } else {
          topGrad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
          topGrad.addColorStop(0.55, 'rgba(241, 245, 249, 0.65)');
          topGrad.addColorStop(0.85, 'rgba(203, 213, 225, 0.25)');
          topGrad.addColorStop(1, 'rgba(148, 163, 184, 0.04)');
        }
        ctx.fillStyle = topGrad;
        ctx.fill();

        // Silver-Lining Sunlit Rim Highlight on upper contour
        ctx.strokeStyle = lightingMode === 'sunrise' ? 'rgba(254, 215, 170, 0.60)' : (lightingMode === 'sunset' ? 'rgba(254, 240, 138, 0.50)' : 'rgba(255, 255, 255, 0.45)');
        ctx.lineWidth = 1.0;
        ctx.stroke();
      });

      ctx.restore();

      // Cloud Ground Shadow projected onto the terrain
      ctx.fillStyle = 'rgba(0, 0, 0, 0.22)';
      ctx.beginPath();
      ctx.ellipse(cx + 60, horizonY + 32, r * 1.5, r * 0.38, 0.1, 0, Math.PI * 2);
      ctx.fill();

      // Drifting Motion
      c.x += c.speed + (windSpeed * 0.025);
      if (c.x - c.size * 2 > width) c.x = -c.size * 2.5;
    });

    // Distance Horizon Fog Layer
    const fogGrad = ctx.createLinearGradient(0, horizonY - 30, 0, horizonY + 25);
    const fogColor = isRaining ? '15, 29, 40' : (lightingMode === 'sunrise' ? '185, 65, 85' : (lightingMode === 'sunset' ? '163, 66, 17' : '22, 87, 67'));
    fogGrad.addColorStop(0, `rgba(${fogColor}, 0)`);
    fogGrad.addColorStop(0.6, `rgba(${fogColor}, 0.45)`);
    fogGrad.addColorStop(1, `rgba(${fogColor}, 0.85)`);
    ctx.fillStyle = fogGrad;
    ctx.fillRect(0, horizonY - 30, width, 55);

    // -------------------------------------------------------------
    // 2. DISPLACED HEIGHTMAP TERRAIN & TACTILE PBR LOAM SOIL PATTERN
    // -------------------------------------------------------------
    // Topsoil Layer (Horizon A) with noise heightmap curve
    ctx.beginPath();
    ctx.moveTo(0, getTerrainHeight(0, horizonY));
    for (let x = 0; x <= width; x += 15) {
      ctx.lineTo(x, getTerrainHeight(x, horizonY));
    }
    ctx.lineTo(width, horizonY + 65);
    ctx.lineTo(0, horizonY + 75);
    ctx.closePath();

    // PBR Soil Loam Gradient (darkens with wetness)
    const wetDark = 1 - (wetnessFactor * 0.38);
    const topsoilGrad = ctx.createLinearGradient(0, horizonY, 0, horizonY + 65);
    if (lightingMode === 'night') {
      topsoilGrad.addColorStop(0, `rgb(${Math.round(baseSoilR * 0.35 * wetDark)}, ${Math.round(baseSoilG * 0.35 * wetDark)}, ${Math.round((baseSoilB + 10) * 0.35 * wetDark)})`);
      topsoilGrad.addColorStop(1, `rgb(${Math.round(subSoilR * 0.35 * wetDark)}, ${Math.round(subSoilG * 0.35 * wetDark)}, ${Math.round((subSoilB + 10) * 0.35 * wetDark)})`);
    } else if (lightingMode === 'sunrise') {
      topsoilGrad.addColorStop(0, `rgb(${Math.round((baseSoilR + 25) * wetDark)}, ${Math.round((baseSoilG + 10) * wetDark)}, ${Math.round((baseSoilB + 15) * wetDark)})`);
      topsoilGrad.addColorStop(1, `rgb(${Math.round(subSoilR * wetDark)}, ${Math.round(subSoilG * wetDark)}, ${Math.round(subSoilB * wetDark)})`);
    } else if (lightingMode === 'sunset') {
      topsoilGrad.addColorStop(0, `rgb(${Math.round((baseSoilR + 20) * wetDark)}, ${Math.round((baseSoilG + 8) * wetDark)}, ${Math.round(baseSoilB * wetDark)})`);
      topsoilGrad.addColorStop(1, `rgb(${Math.round(subSoilR * wetDark)}, ${Math.round(subSoilG * wetDark)}, ${Math.round(subSoilB * wetDark)})`);
    } else {
      topsoilGrad.addColorStop(0, `rgb(${Math.round(baseSoilR * wetDark)}, ${Math.round(baseSoilG * wetDark)}, ${Math.round(baseSoilB * wetDark)})`);
      topsoilGrad.addColorStop(1, `rgb(${Math.round(subSoilR * wetDark)}, ${Math.round(subSoilG * wetDark)}, ${Math.round(subSoilB * wetDark)})`);
    }
    ctx.fillStyle = topsoilGrad;
    ctx.fill();

    // Overlay Tactile Organic Crumb & Loam Soil Pattern
    ctx.save();
    ctx.globalAlpha = 0.72;
    ctx.fillStyle = soilPattern;
    ctx.fill();
    ctx.restore();

    // Subsoil Layer (Horizon B) with Geological Strata & Gravel Pattern
    ctx.beginPath();
    ctx.moveTo(0, horizonY + 75);
    ctx.lineTo(width, horizonY + 65);
    ctx.lineTo(width, height);
    ctx.lineTo(0, height);
    ctx.closePath();

    const subsoilGrad = ctx.createLinearGradient(0, horizonY + 65, 0, height);
    subsoilGrad.addColorStop(0, `rgb(${Math.round(subSoilR * wetDark)}, ${Math.round(subSoilG * wetDark)}, ${Math.round(subSoilB * wetDark)})`);
    subsoilGrad.addColorStop(1, `rgb(${Math.round(subSoilR * 0.5 * wetDark)}, ${Math.round(subSoilG * 0.5 * wetDark)}, ${Math.round(subSoilB * 0.5 * wetDark)})`);
    ctx.fillStyle = subsoilGrad;
    ctx.fill();

    ctx.save();
    ctx.globalAlpha = 0.78;
    ctx.fillStyle = subsoilPattern;
    ctx.fill();
    ctx.restore();

    // Subsoil Capillary Root Network Fibrils (Root Zone Penetration)
    ctx.save();
    ctx.strokeStyle = 'rgba(254, 240, 138, 0.32)';
    ctx.lineWidth = 0.9;
    for (let rx = 35; rx < width; rx += 70) {
      let curX = rx;
      let curY = horizonY + 60;
      ctx.beginPath();
      ctx.moveTo(curX, curY);
      for (let dep = 0; dep < 4; dep++) {
        curX += (dep % 2 === 0 ? 5 : -5);
        curY += 12;
        ctx.lineTo(curX, curY);
      }
      ctx.stroke();
    }
    ctx.restore();

    // Tilled Perspective Furrow Ridges & Valleys with Topsoil Highlights
    for (let f = 0; f < 14; f++) {
      const fX = (width / 14) * f;
      // Ridge vs Valley depth
      ctx.strokeStyle = f % 2 === 0 ? 'rgba(0, 0, 0, 0.45)' : (lightingMode === 'sunrise' ? 'rgba(254, 215, 170, 0.20)' : 'rgba(255, 245, 230, 0.14)');
      ctx.lineWidth = f % 2 === 0 ? 2.8 : 1.6;
      ctx.beginPath();
      ctx.moveTo(width * 0.5, horizonY - 10);
      const endX = fX * 1.4 - width * 0.2;
      ctx.quadraticCurveTo((width * 0.5 + endX) * 0.5, horizonY + 30, endX, height);
      ctx.stroke();

      // Scattered dirt clods along furrow shoulders
      for (let clod = 1; clod <= 3; clod++) {
        const clodT = clod / 3.5;
        const clodX = width * 0.5 + (endX - width * 0.5) * clodT;
        const clodY = horizonY + 20 + clodT * 50;
        ctx.fillStyle = f % 2 === 0 ? 'rgba(26, 15, 9, 0.65)' : 'rgba(125, 82, 52, 0.55)';
        ctx.beginPath();
        ctx.ellipse(clodX, clodY, 3, 1.8, 0.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Organic Straw Mulch & Decomposed Plant Residue Layer along Furrow Shoulders
    if (mulchPattern) {
      ctx.save();
      ctx.globalAlpha = 0.35;
      ctx.fillStyle = mulchPattern;
      ctx.beginPath();
      ctx.moveTo(0, horizonY + 5);
      for (let x = 0; x <= width; x += 15) {
        ctx.lineTo(x, getTerrainHeight(x, horizonY) + 4);
      }
      ctx.lineTo(width, horizonY + 70);
      ctx.lineTo(0, horizonY + 70);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }

    // Wet Soil Darkening & Specular Water Glisten Sheen under active Sprinklers, Rain or Sunrise Dew
    if (isSprinkling || isRaining || lightingMode === 'sunrise') {
      // Glistening specular water sheen streaks in furrow valleys
      ctx.save();
      for (let w = 1; w < 14; w += 2) {
        const wX = (width / 14) * w;
        const endWX = wX * 1.4 - width * 0.2;
        const sheenGrad = ctx.createLinearGradient(0, horizonY + 20, 0, height);
        sheenGrad.addColorStop(0, 'rgba(186, 230, 253, 0)');
        const sheenAlpha = lightingMode === 'sunrise' ? 0.22 : 0.35 * wetnessFactor;
        sheenGrad.addColorStop(0.5, `rgba(254, 240, 138, ${sheenAlpha * 0.5})`);
        sheenGrad.addColorStop(1, `rgba(186, 230, 253, ${sheenAlpha})`);
        ctx.strokeStyle = sheenGrad;
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.moveTo(width * 0.5, horizonY - 5);
        ctx.quadraticCurveTo((width * 0.5 + endWX) * 0.5, horizonY + 30, endWX, height);
        ctx.stroke();
      }
      ctx.restore();

      if (isSprinkling) {
        sprinklerNozzles.forEach(nozzle => {
          ctx.beginPath();
          ctx.ellipse(nozzle.x, horizonY + 8, 85, 22, 0, 0, Math.PI * 2);
          const wetZoneGrad = ctx.createRadialGradient(nozzle.x, horizonY + 8, 5, nozzle.x, horizonY + 8, 85);
          wetZoneGrad.addColorStop(0, 'rgba(8, 20, 15, 0.85)');
          wetZoneGrad.addColorStop(0.55, 'rgba(12, 28, 22, 0.48)');
          wetZoneGrad.addColorStop(1, 'rgba(12, 28, 22, 0)');
          ctx.fillStyle = wetZoneGrad;
          ctx.fill();
        });
      }
    }

    // Drip Irrigation Polyethylene Lateral Lines & Emitter Halos
    if (irrigationMethod === 'Drip') {
      ctx.save();
      const dripRows = (cropProfile && cropProfile.numRows) || 5;
      const dripPlantsPerRow = (cropProfile && cropProfile.plantsPerRow) || 12;
      for (let r = 0; r < dripRows; r++) {
        const rowY = getTerrainHeight(width * 0.5, height * 0.52 - 15 + r * 18);
        const zScale = 0.45 + r * 0.085;
        // Flexible black drip lateral
        ctx.strokeStyle = '#0f172a';
        ctx.lineWidth = Math.max(1.2, 2.4 * zScale);
        ctx.beginPath();
        ctx.moveTo(0, rowY + 3 * zScale);
        ctx.lineTo(width, rowY + 3 * zScale);
        ctx.stroke();

        // Micro-emitters and moisture halos
        for (let c = 0; c < dripPlantsPerRow; c += 2) {
          const emitX = (width / Math.max(1, dripPlantsPerRow - 1)) * c;
          ctx.fillStyle = '#0284c7';
          ctx.fillRect(emitX - 1.5 * zScale, rowY + 2 * zScale, 3 * zScale, 2 * zScale);
          ctx.fillStyle = 'rgba(14, 165, 233, 0.22)';
          ctx.beginPath();
          ctx.ellipse(emitX, rowY + 4 * zScale, 7 * zScale, 2.8 * zScale, 0, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      ctx.restore();
    }

    // Canal / Flood Furrow Water Channels
    if (irrigationMethod === 'Canal' || irrigationMethod === 'Well/Flood') {
      ctx.save();
      for (let w = 0; w < 14; w += 2) {
        const wX = (width / 14) * w;
        const endWX = wX * 1.4 - width * 0.2;
        const canalWaterGrad = ctx.createLinearGradient(0, horizonY + 15, 0, height);
        canalWaterGrad.addColorStop(0, 'rgba(56, 189, 248, 0.25)');
        canalWaterGrad.addColorStop(1, 'rgba(14, 165, 233, 0.55)');
        ctx.strokeStyle = canalWaterGrad;
        ctx.lineWidth = 4.5;
        ctx.beginPath();
        ctx.moveTo(width * 0.5, horizonY);
        ctx.quadraticCurveTo((width * 0.5 + endWX) * 0.5, horizonY + 30, endWX, height);
        ctx.stroke();
      }
      ctx.restore();
    }

    // Paddy Field Water Reflection Layer if Rice
    const activeCropProfile = getCrop3DProfile(cropType) || cropProfile;
    if (cropType === 'rice' || cropType === 'paddy' || (activeCropProfile && activeCropProfile.hasWaterLayer)) {
      const waterGrad = ctx.createLinearGradient(0, horizonY - 6, 0, horizonY + 12);
      waterGrad.addColorStop(0, 'rgba(56, 189, 248, 0.55)');
      waterGrad.addColorStop(1, 'rgba(14, 165, 233, 0.75)');
      ctx.fillStyle = waterGrad;
      ctx.fillRect(0, horizonY - 6, width, 18);
    }

    // Perimeter Wooden Fence Posts & Wire Cables
    for (let fenceX = 20; fenceX < width; fenceX += 90) {
      const fenceY = getTerrainHeight(fenceX, horizonY);
      // Directional Shadow on Soil
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.ellipse(fenceX + 8, fenceY + 2, 10, 3, 0.3, 0, Math.PI * 2);
      ctx.fill();

      // Post Structure with Wood Grain Lines
      ctx.fillStyle = '#68320c';
      ctx.fillRect(fenceX - 2.5, fenceY - 20, 5, 24);
      ctx.fillStyle = '#85420e';
      ctx.fillRect(fenceX - 2.5, fenceY - 20, 2.5, 24);
      // Wood grain lines
      ctx.strokeStyle = '#451a03';
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(fenceX - 1, fenceY - 18);
      ctx.lineTo(fenceX - 1, fenceY + 2);
      ctx.moveTo(fenceX + 1.2, fenceY - 16);
      ctx.lineTo(fenceX + 1.2, fenceY);
      ctx.stroke();

      // Wire Cable
      ctx.strokeStyle = 'rgba(203, 213, 225, 0.5)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(fenceX - 2.5, fenceY - 14);
      ctx.lineTo(fenceX + 87.5, fenceY - 14);
      ctx.stroke();
    }

    // -------------------------------------------------------------
    // 3. INSTANCED PHOTOREALISTIC BOTANICAL CROPS & FOLIAGE TEXTURES
    // -------------------------------------------------------------
    const shadowOffsetX = (sunX - width * 0.5) * -0.07;
    const fruitCol = activeCropProfile.fruitColor || '#f59e0b';
    const effectiveHeightScale = activeCropProfile.heightScale || 1.0;
    const archKey = mapCropTo3DType(cropType);
    const archConf = (typeof archetypeConfigs !== 'undefined' && archetypeConfigs[archKey]) ? archetypeConfigs[archKey] : { baseHeight: 50 };
    const baseHeight = (archConf.baseHeight || 50) * effectiveHeightScale;

    plantInstances.forEach(p => {
      const pY = getTerrainHeight(p.x, p.y);
      const zScale = p.zScale;
      const sway = Math.sin(angle * (windSpeed * 0.12) + p.seed) * (windSpeed * 0.35) * zScale;
      const pHeight = baseHeight * zScale * p.heightScale;

      // Directional Ground Shadow under Crop Stalk (Longer morning shadows in Sunrise)
      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      ctx.beginPath();
      const shadowLength = lightingMode === 'sunrise' ? 20 * zScale : 14 * zScale;
      ctx.ellipse(p.x + shadowOffsetX, pY + 1, shadowLength, 4 * zScale, p.tiltAngle, 0, Math.PI * 2);
      ctx.fill();

      ctx.save();
      ctx.translate(p.x, pY);
      ctx.rotate(p.tiltAngle);

      // -------------------------------------------------------------------
      // BOTANICALLY REALISTIC 3D PROCEDURAL CANOPY DISPATCHER (31 ARCHETYPES)
      // -------------------------------------------------------------------
      const targetArch = archKey || mapCropTo3DType(cropType) || cropType;
      switch (targetArch) {
        case 'palm_coconut':
        case 'coconut':
          drawPalmCoconut(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'palm_areca':
        case 'areca':
        case 'arecanut':
        case 'betelnut':
          drawPalmAreca(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'banana_plant':
        case 'banana':
          drawBananaPlant(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'sugarcane':
        case 'cane':
          drawSugarcane(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'sorghum_jowar':
        case 'sorghum':
        case 'jowar':
          drawSorghumJowar(ctx, p, zScale, sway, pHeight, fruitCol, lightingMode, leafPattern);
          break;
        case 'grain_barley':
        case 'barley':
          drawBarley(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'oats_panicle':
        case 'oats':
        case 'oat':
          drawOats(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'millet_ragi':
        case 'ragi':
          drawMilletRagi(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'millet_spike':
        case 'millet':
        case 'bajra':
          drawMilletSpike(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'okra_stalk':
        case 'okra':
        case 'bhindi':
          drawOkraStalk(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'groundnut_runner':
        case 'groundnut':
        case 'peanut':
          drawGroundnutRunner(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'curcurbit_vine':
        case 'gourd':
        case 'cucumber':
          drawCurcurbitVine(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'black_pepper':
        case 'pepper_climber':
          drawBlackPepperClimber(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'cardamom_clump':
        case 'cardamom':
          drawCardamomClump(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'marigold_flower':
        case 'marigold':
          drawMarigoldBush(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'cauliflower_crop':
        case 'cauliflower':
          drawCauliflower(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'garlic_crop':
        case 'garlic':
          drawGarlicBulb(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'radish_crop':
        case 'radish':
          drawRadishTaproot(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'ginger_rhizome':
          drawGingerRhizome(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'coriander_herb':
        case 'coriander':
          drawCorianderHerb(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'fenugreek_herb':
        case 'fenugreek':
        case 'methi':
          drawFenugreekHerb(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'onion_garlic':
        case 'onion':
          drawOnionGarlic(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'carrot_radish':
        case 'carrot':
          drawCarrotRadish(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'cabbage_brassica':
        case 'cabbage':
          drawCabbageBrassica(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'potato_crop':
        case 'potato':
          drawPotatoCrop(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'ginger_turmeric':
        case 'turmeric':
          drawGingerTurmeric(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'tea_bush':
        case 'tea':
          drawTeaBush(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'coffee_shrub':
        case 'coffee':
          drawCoffeeShrub(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'orchard_tree':
        case 'plantation_tree':
        case 'plantation_spice':
          drawOrchardTree(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'moringa_drumstick':
        case 'moringa':
        case 'drumstick':
          drawMoringaDrumstick(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'tulsi_plant':
        case 'tulsi':
          drawTulsiPlant(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'ashwagandha_shrub':
        case 'ashwagandha':
          drawAshwagandhaShrub(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'succulent_aloe':
        case 'aloe':
          drawSucculentAloe(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'lemongrass_tuft':
        case 'lemongrass':
          drawLemongrassTuft(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'leafy_greens':
        case 'spinach':
        case 'mint':
          drawLeafyGreens(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'brinjal_eggplant':
        case 'brinjal':
        case 'eggplant':
          drawBrinjalEggplant(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'chilli_pepper':
        case 'chilli':
        case 'pepper':
          drawChilliPepper(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'cotton_boll':
        case 'cotton':
          drawCottonBoll(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'sunflower':
          drawSunflower(ctx, p, zScale, sway, pHeight, fruitCol, sunX, width, leafPattern);
          break;
        case 'mustard_bloom':
        case 'mustard':
        case 'sarson':
          drawMustardBloom(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'legume_pod':
        case 'soybean':
        case 'pulse':
        case 'pulses':
        case 'gram':
        case 'tur':
        case 'arhar':
        case 'chana':
        case 'moong':
        case 'urad':
          drawLegumePod(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'grain_wheat':
        case 'wheat':
          drawWheat(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'paddy':
        case 'rice':
          drawPaddy(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'flower_ornamental':
          drawFlowerOrnamental(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
        case 'tall_stalk':
        case 'maize':
        case 'corn':
          drawTallStalk(ctx, p, zScale, sway, pHeight, fruitCol, lightingMode, isRaining, isSprinkling, leafPattern);
          break;
        case 'unsupported_crop':
          // Explicit agronomic survey stake with amber caution flag (NEVER wheat!)
          ctx.fillStyle = '#f59e0b';
          ctx.fillRect(-1.5 * zScale, -pHeight * 0.7, 3 * zScale, pHeight * 0.7);
          ctx.fillStyle = '#d97706';
          ctx.beginPath();
          ctx.moveTo(0, -pHeight * 0.7);
          ctx.lineTo(14 * zScale, -pHeight * 0.7 + 5 * zScale);
          ctx.lineTo(0, -pHeight * 0.7 + 10 * zScale);
          ctx.fill();
          break;
        case 'fruiting_bush':
        case 'tomato':
        case 'vegetable':
        default:
          drawFruitingBush(ctx, p, zScale, sway, pHeight, fruitCol, leafPattern);
          break;
      }

      ctx.restore();
    });

    // -------------------------------------------------------------
    // 4. 3D FIELD IOT POLE & METALLIC SPRINKLER RISERS
    // -------------------------------------------------------------
    // IoT Sensor Telemetry Pole
    const poleX = width * 0.88;
    const poleY = getTerrainHeight(poleX, horizonY);
    ctx.fillStyle = '#334155';
    ctx.fillRect(poleX - 2.5, poleY - 52, 5, 52);
    ctx.fillStyle = '#38bdf8';
    ctx.fillRect(poleX - 8, poleY - 56, 16, 7);
    // Pulsing LED Beacon
    ctx.beginPath();
    ctx.arc(poleX, poleY - 58, 4.5, 0, Math.PI * 2);
    ctx.fillStyle = Math.sin(angle * 4) > 0 ? '#10b981' : '#ef4444';
    ctx.fill();

    // Metallic Sprinkler Head Risers
    sprinklerNozzles.forEach(nozzle => {
      const nY = getTerrainHeight(nozzle.x, nozzle.y);
      ctx.fillStyle = '#64748b';
      ctx.fillRect(nozzle.x - 3.5, nY - 20, 7, 22);
      ctx.fillStyle = '#0284c7';
      ctx.beginPath();
      ctx.arc(nozzle.x, nY - 20, 6, 0, Math.PI * 2);
      ctx.fill();
    });

    // -------------------------------------------------------------
    // 5. INTERACTIVE WATER SPRINKLER ARCS & MIST PARTICLES
    // -------------------------------------------------------------
    if (isSprinkling) {
      sprinklerNozzles.forEach((nozzle, nIdx) => {
        const nY = getTerrainHeight(nozzle.x, nozzle.y);
        for (let a = -3; a <= 3; a++) {
          const streamAngle = (a * 0.18) + Math.sin(angle * 5 + nIdx) * 0.12;
          const streamDist = 70 + Math.abs(a) * 12;
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.8)';
          ctx.lineWidth = 2.0;
          ctx.beginPath();
          ctx.moveTo(nozzle.x, nY - 20);
          const controlX = nozzle.x + Math.sin(streamAngle) * (streamDist * 0.5);
          const controlY = nY - 20 - 42;
          const endX = nozzle.x + Math.sin(streamAngle) * streamDist;
          const endY = nY;
          ctx.quadraticCurveTo(controlX, controlY, endX, endY);
          ctx.stroke();
        }
      });

      // Animated Water Droplets
      mistParticles.forEach(p => {
        const nozzle = sprinklerNozzles[p.nozzleIdx];
        const nY = getTerrainHeight(nozzle.x, nozzle.y);
        ctx.fillStyle = `rgba(56, 189, 248, ${p.alpha})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();

        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.25;
        p.life++;

        if (p.y >= getTerrainHeight(p.x, horizonY)) {
          splashRings.push({ x: p.x, y: p.y, r: 2, alpha: 0.85 });
          p.x = nozzle.x;
          p.y = nY - 20;
          p.vx = (Math.random() - 0.5) * 12;
          p.vy = -6 - Math.random() * 6;
          p.life = 0;
        }
      });

      // Concentric Water Ripples
      for (let i = splashRings.length - 1; i >= 0; i--) {
        const ring = splashRings[i];
        ctx.strokeStyle = `rgba(56, 189, 248, ${ring.alpha})`;
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.ellipse(ring.x, ring.y, ring.r * 2.2, ring.r, 0, 0, Math.PI * 2);
        ctx.stroke();

        ring.r += 0.55;
        ring.alpha -= 0.055;
        if (ring.alpha <= 0) splashRings.splice(i, 1);
      }
    }

    // -------------------------------------------------------------
    // 6. 3D QUADCOPTER SMART DRONE & LASER SCANNING GRID BEAM
    // -------------------------------------------------------------
    if (isDroneActive) {
      droneX += droneDirection * 2.2;
      if (droneX > width * 0.84) droneDirection = -1;
      if (droneX < width * 0.16) droneDirection = 1;
      droneY = 85 + Math.sin(angle * 2.5) * 6;

      const scanGroundY = getTerrainHeight(droneX, horizonY);

      // Dynamic Laser Scanning Grid Cone Projection
      const laserGrad = ctx.createLinearGradient(droneX, droneY, droneX, scanGroundY);
      laserGrad.addColorStop(0, 'rgba(52, 211, 153, 0.55)');
      laserGrad.addColorStop(0.5, 'rgba(52, 211, 153, 0.2)');
      laserGrad.addColorStop(1, 'rgba(52, 211, 153, 0.02)');

      ctx.beginPath();
      ctx.moveTo(droneX, droneY + 10);
      ctx.lineTo(droneX - 55, scanGroundY);
      ctx.lineTo(droneX + 55, scanGroundY);
      ctx.closePath();
      ctx.fillStyle = laserGrad;
      ctx.fill();

      // Sweeping Laser Scan Target Line on Ground
      ctx.strokeStyle = '#34d399';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(droneX - 55, scanGroundY);
      ctx.lineTo(droneX + 55, scanGroundY);
      ctx.stroke();

      // Quadcopter Drone Metallic Frame
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(droneX - 18, droneY - 5, 36, 10);
      ctx.fillStyle = '#334155';
      ctx.fillRect(droneX - 26, droneY - 3, 52, 4);

      // Spinning Rotor Propeller Discs
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.85)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(droneX - 26, droneY - 5, 10, 0, Math.PI * 2);
      ctx.arc(droneX + 26, droneY - 5, 10, 0, Math.PI * 2);
      ctx.stroke();

      // Drone Status LED & Camera Gimbal
      ctx.fillStyle = '#34d399';
      ctx.beginPath();
      ctx.arc(droneX, droneY + 5, 3.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // -------------------------------------------------------------
    // 7. WEATHER RAIN PARTICLES
    // -------------------------------------------------------------
    if (isRaining) {
      raindrops.forEach(drop => {
        ctx.strokeStyle = `rgba(186, 230, 253, ${drop.alpha})`;
        ctx.lineWidth = 2.2;
        ctx.beginPath();
        ctx.moveTo(drop.x, drop.y);
        ctx.lineTo(drop.x - (windSpeed * 0.45), drop.y + drop.length);
        ctx.stroke();

        drop.y += drop.speed;
        drop.x -= (windSpeed * 0.22);
        if (drop.y > height || drop.x < -100) {
          drop.y = -20;
          drop.x = Math.random() * width * 1.5 - width * 0.25;
        }
      });
    }

    // -------------------------------------------------------------
    // 8. AMBIENT POLLEN & DUST MOTES
    // -------------------------------------------------------------
    pollenMotes.forEach(m => {
      ctx.fillStyle = lightingMode === 'sunset' ? `rgba(251, 146, 60, ${m.alpha})` : `rgba(254, 240, 138, ${m.alpha})`;
      ctx.beginPath();
      ctx.arc(m.x, m.y, m.size, 0, Math.PI * 2);
      ctx.fill();

      m.x += m.vx + Math.sin(angle + m.phase) * 0.3;
      m.y += m.vy;
      if (m.y < 0) {
        m.y = height * 0.7;
        m.x = Math.random() * width;
      }
    });

    // -------------------------------------------------------------
    // 9. POST-PROCESSING BLOOM, VIGNETTE & COLOR GRADING
    // -------------------------------------------------------------
    // Subtle Dark Vignette Border Mask
    const vigGrad = ctx.createRadialGradient(width * 0.5, height * 0.5, width * 0.35, width * 0.5, height * 0.5, width * 0.7);
    vigGrad.addColorStop(0, 'rgba(0, 0, 0, 0)');
    vigGrad.addColorStop(1, 'rgba(0, 0, 0, 0.45)');
    ctx.fillStyle = vigGrad;
    ctx.fillRect(0, 0, width, height);

    angle += 0.03;
    if (!document.getElementById(canvasId)) {
      if (activeSimulators.has(canvasId)) {
        cancelAnimationFrame(activeSimulators.get(canvasId));
        activeSimulators.delete(canvasId);
      }
      return;
    }
    const nextAnim = requestAnimationFrame(drawScene);
    activeSimulators.set(canvasId, nextAnim);
  }

  drawScene();

  // Interactive Mouse & Touch Drag Controls for rotating wind breeze & drone perspective
  let isDragging = false;
  let lastMouseX = 0;
  canvas.addEventListener('mousedown', (e) => {
    isDragging = true;
    lastMouseX = e.clientX;
  });
  window.addEventListener('mouseup', () => { isDragging = false; });
  canvas.addEventListener('mousemove', (e) => {
    if (isDragging) {
      const deltaX = e.clientX - lastMouseX;
      lastMouseX = e.clientX;
      windSpeed = Math.max(0, Math.min(40, windSpeed + deltaX * 0.12));
      droneX = Math.max(50, Math.min(width - 50, droneX + deltaX * 0.6));
      const windSlider = document.getElementById('slider-sim-wind');
      if (windSlider) windSlider.value = Math.round(windSpeed);
      const windValLabel = document.getElementById('val-sim-wind');
      if (windValLabel) windValLabel.textContent = `${Math.round(windSpeed)} km/h`;
      const windValLabel2 = document.getElementById('sim-wind-val');
      if (windValLabel2) windValLabel2.textContent = `${Math.round(windSpeed)} km/h`;
    }
  });

  canvas.addEventListener('touchstart', (e) => {
    if (e.touches.length > 0) {
      isDragging = true;
      lastMouseX = e.touches[0].clientX;
    }
  }, { passive: true });
  window.addEventListener('touchend', () => { isDragging = false; });
  canvas.addEventListener('touchmove', (e) => {
    if (isDragging && e.touches.length > 0) {
      const deltaX = e.touches[0].clientX - lastMouseX;
      lastMouseX = e.touches[0].clientX;
      windSpeed = Math.max(0, Math.min(40, windSpeed + deltaX * 0.12));
      droneX = Math.max(50, Math.min(width - 50, droneX + deltaX * 0.6));
    }
  }, { passive: true });

  // Botanical Real-World Specimen Telemetry Synchronizer
  function syncBotanicalTelemetry(arch) {
    const targetArch = mapCropTo3DType(arch) || arch;
    const conf = (typeof archetypeConfigs !== 'undefined' && archetypeConfigs[targetArch]) ? archetypeConfigs[targetArch] : (archetypeConfigs['grain_wheat'] || {});
    const activeProf = getCrop3DProfile(arch);

    const photoEl = document.getElementById('botanical-ref-photo');
    if (photoEl) {
      photoEl.src = conf.realPhotoUrl || 'images/healthy_crops/wheat_healthy.jpg';
      photoEl.alt = `${conf.botanicalName || 'Real Crop Photo'}`;
    }

    const nameEl = document.getElementById('botanical-crop-name');
    if (nameEl) nameEl.textContent = `${activeProf.name || arch} (${conf.botanicalName || 'Botanical Specimen'})`;

    const famEl = document.getElementById('botanical-crop-family');
    if (famEl) famEl.textContent = `Family: ${conf.botanicalFamily || 'Agricultural Flora'}`;

    const heightTag = document.getElementById('botanical-height-tag');
    if (heightTag) heightTag.textContent = `Real Height: ${conf.realWorldHeight || '1.0 – 1.5 m'}`;

    const heightVal = document.getElementById('botanical-height-val');
    if (heightVal) heightVal.textContent = conf.realWorldHeight || '1.0 – 1.5 m';

    const twinH = document.getElementById('botanical-twin-height');
    if (twinH) twinH.textContent = `3D Twin Height: ${conf.baseHeight || 50}px (Scale: ${((conf.baseHeight || 50) / 46).toFixed(1)}x)`;

    const stemVal = document.getElementById('botanical-stem-val');
    if (stemVal) stemVal.textContent = conf.stemTexture ? conf.stemTexture.split(',')[0] : 'Solid culm with nodes';

    const fruitVal = document.getElementById('botanical-fruit-val');
    if (fruitVal) fruitVal.textContent = conf.reproductiveStructure ? conf.reproductiveStructure.split(';')[0] : 'Inflorescence';

    const foliageDesc = document.getElementById('botanical-foliage-desc');
    if (foliageDesc) foliageDesc.textContent = conf.foliageTexture || 'Lush chlorophyll blades with cellular stomata texture';

    const reprodDesc = document.getElementById('botanical-reprod-desc');
    if (reprodDesc) reprodDesc.textContent = conf.reproductiveStructure || 'Characteristic agricultural fruit/seed morphology';

    if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
  }

  // Initial synchronization of real-world botanical traits
  syncBotanicalTelemetry(cropType);

  // Event Listeners for Simulator Controls (if present on page)
  const cropSelect = document.getElementById('sim-3d-crop-select');
  if (cropSelect) {
    if (cropType) cropSelect.value = cropType;
    cropSelect.addEventListener('change', (e) => {
      cropType = e.target.value;
      cropProfile = getCrop3DProfile(cropType);
      regeneratePlantMatrix(cropType);
      syncBotanicalTelemetry(cropType);
    });
  }

  const lightingSelect = document.getElementById('sim-3d-lighting-select');
  if (lightingSelect) {
    if (lightingMode) lightingSelect.value = lightingMode;
    lightingSelect.addEventListener('change', (e) => { lightingMode = e.target.value; });
  }

  const droneBtn = document.getElementById('btn-3d-toggle-drone');
  const droneValLabel = document.getElementById('sim-drone-val');
  if (droneBtn) {
    droneBtn.addEventListener('click', () => {
      isDroneActive = !isDroneActive;
      droneBtn.className = `px-3.5 py-2 rounded-xl font-extrabold border transition flex items-center gap-1.5 cursor-pointer ${
        isDroneActive
          ? 'bg-emerald-600 text-white border-emerald-400 shadow-lg shadow-emerald-600/30'
          : 'bg-gray-800 text-gray-400 border-gray-700'
      }`;
      droneBtn.innerHTML = isDroneActive
        ? `<i data-lucide="scan" class="w-4 h-4 text-emerald-200 animate-pulse"></i> <span>3D Drone: ON</span>`
        : `<i data-lucide="scan" class="w-4 h-4 text-gray-400"></i> <span>3D Drone: OFF</span>`;
      if (droneValLabel) droneValLabel.textContent = isDroneActive ? 'Laser Grid Active' : 'Drone Standby';
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    });
  }

  const sprinklerBtn = document.getElementById('btn-3d-toggle-sprinkler');
  if (sprinklerBtn) {
    sprinklerBtn.addEventListener('click', () => {
      isSprinkling = !isSprinkling;
      sprinklerBtn.className = `px-3.5 py-2 rounded-xl font-extrabold border transition flex items-center gap-1.5 cursor-pointer ${
        isSprinkling
          ? 'bg-blue-500 text-white border-blue-400 shadow-lg shadow-blue-500/30'
          : 'bg-gray-800 text-gray-400 border-gray-700'
      }`;
      sprinklerBtn.innerHTML = isSprinkling
        ? `<i data-lucide="droplets" class="w-4 h-4 text-white animate-bounce"></i> <span>Sprinklers: ON</span>`
        : `<i data-lucide="droplets" class="w-4 h-4 text-gray-400"></i> <span>Sprinklers: OFF</span>`;
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    });
  }

  const rainBtn = document.getElementById('btn-3d-toggle-weather');
  if (rainBtn) {
    rainBtn.addEventListener('click', () => {
      isRaining = !isRaining;
      rainBtn.className = `px-3.5 py-2 rounded-xl font-extrabold border transition flex items-center gap-1.5 cursor-pointer ${
        isRaining
          ? 'bg-teal-500 text-white border-teal-400 shadow-lg shadow-teal-500/30'
          : 'bg-gray-800 text-gray-400 border-gray-700'
      }`;
      rainBtn.innerHTML = isRaining
        ? `<i data-lucide="cloud-rain" class="w-4 h-4 text-white animate-pulse"></i> <span>Rain: ON</span>`
        : `<i data-lucide="cloud-rain" class="w-4 h-4 text-gray-400"></i> <span>Rain: OFF</span>`;
      if (typeof lucide !== 'undefined' && lucide.createIcons) lucide.createIcons();
    });
  }

  const windSlider = document.getElementById('slider-sim-wind');
  const windValLabel = document.getElementById('val-sim-wind');
  const windValLabel2 = document.getElementById('sim-wind-val');
  if (windSlider) {
    windSlider.addEventListener('input', (e) => {
      windSpeed = Number(e.target.value);
      if (windValLabel) windValLabel.textContent = `${windSpeed} km/h`;
      if (windValLabel2) windValLabel2.textContent = `${windSpeed} km/h`;
    });
  }

  const sprinklerSlider = document.getElementById('slider-sim-sprinkler');
  const sprinklerValLabel = document.getElementById('val-sim-sprinkler');
  if (sprinklerSlider) {
    sprinklerSlider.addEventListener('input', (e) => {
      sprinklerCount = Number(e.target.value);
      if (sprinklerValLabel) sprinklerValLabel.textContent = `${sprinklerCount} Drops/sec`;
      generateMistParticles(sprinklerCount);
    });
  }

  const rainSlider = document.getElementById('slider-sim-rain');
  const rainValLabel = document.getElementById('val-sim-rain');
  if (rainSlider) {
    rainSlider.addEventListener('input', (e) => {
      rainCount = Number(e.target.value);
      if (rainValLabel) rainValLabel.textContent = `${rainCount} Rain Drops`;
      generateRaindrops(rainCount);
    });
  }
}

/**
 * Renders an embedded interactive 3D Farm Digital Twin Card directly inside the AI Crop Recommendation Results
 */
function renderEmbedded3DFarmCard(prediction, input) {
  const primary = prediction?.primaryCrop || {};
  const farm = input?.farm || {};
  const soil = input?.soil || {};
  const climate = input?.climate || {};

  const cleanCropName = (primary.name || 'Recommended Crop').split('(')[0].trim();
  const cType = mapCropTo3DType(primary.name, primary.category);
  const cropProfile = getCrop3DProfile(primary.id || primary.name);

  const rainfallVal = climate.rainfall !== undefined ? Number(climate.rainfall) : 600;
  const tempVal = climate.temp !== undefined ? Number(climate.temp) : 26;
  const lightingMode = tempVal > 30 ? 'Sunset' : (tempVal < 20 ? 'Sunrise' : 'Daylight');

  // Top 4 AI Recommendations for Quick-Pick Chips
  const ranked = prediction?.rankedCrops || [];
  const top4Crops = ranked.length > 0 ? ranked.slice(0, 4) : [primary];

  // Group all 100+ crops by category for the 106-Crop selector
  const categoriesMap = new Map();
  expanded100Crops.forEach(c => {
    const cat = c.category || 'Other Crops';
    if (!categoriesMap.has(cat)) categoriesMap.set(cat, []);
    categoriesMap.get(cat).push(c);
  });

  return `
    <!-- Interactive 3D Farm Digital Twin Card -->
    <div id="card-3d-farm-twin" class="glass-card p-5 rounded-2xl border border-emerald-800/60 bg-[#0d1e17] relative overflow-hidden shadow-lg space-y-4">

      <!-- Top Header & Badges -->
      <div class="flex flex-wrap items-center justify-between gap-3 border-b border-emerald-900/60 pb-3">
        <div class="flex items-center gap-2.5">
          <div class="w-9 h-9 rounded-xl bg-emerald-800/80 border border-emerald-600/50 flex items-center justify-center text-white shadow font-bold">
            <i data-lucide="box" class="w-5 h-5 text-emerald-200"></i>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h3 class="text-sm sm:text-base font-bold text-white font-['Outfit'] tracking-tight">
                3D Farm Digital Twin
              </h3>
              <span class="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-900/80 text-emerald-200 border border-emerald-600/50">
                FIELD TWIN ENGINE
              </span>
            </div>
            <p class="text-[11px] text-emerald-300/80 font-medium">
              Real-time synchronization with ${soil.type || 'Soil'}, ${rainfallVal}mm rain, ${tempVal}°C sun & 100+ crop models
            </p>
          </div>
        </div>

        <!-- 106-Crop Interactive Dropdown Selector directly on the 3D card -->
        <div class="flex items-center gap-2">
          <label for="embedded-3d-crop-picker" class="text-[11px] font-mono font-bold text-emerald-300 flex items-center gap-1">
            <i data-lucide="sprout" class="w-3.5 h-3.5 text-emerald-400"></i>
            <span>3D Crop:</span>
          </label>
          <select id="embedded-3d-crop-picker" style="color-scheme: dark; background-color: #031c10; color: #ffffff;" class="bg-[#031c10] text-white border border-emerald-500/60 rounded-xl px-2.5 py-1.5 text-xs font-bold cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-400 shadow-inner max-w-[220px] truncate">
            ${Array.from(categoriesMap.entries()).map(([cat, crops]) => `
              <optgroup label="${cat}" style="background-color: #02130b; color: #34d399; font-weight: 800;">
                ${crops.map(c => `
                  <option value="${c.id}" ${c.id === primary.id ? 'selected' : ''} style="background-color: #031c10; color: #ffffff; font-weight: 600;">
                    ${c.name}
                  </option>
                `).join('')}
              </optgroup>
            `).join('')}
          </select>

          <!-- Dedicated 3D Engine Link -->
          <a href="#/3d-farm" class="px-3 py-1.5 rounded-xl text-xs font-black bg-emerald-950/90 border border-emerald-500/50 text-emerald-300 hover:bg-emerald-800 hover:text-white transition flex items-center gap-1.5 text-decoration-none shadow-sm cursor-pointer ml-1">
            <i data-lucide="maximize-2" class="w-3.5 h-3.5 text-emerald-400"></i>
            <span class="hidden sm:inline">Engine</span>
          </a>
        </div>
      </div>

      <!-- Quick AI Recommendation Chips (#1, #2, #3, #4) -->
      <div class="flex flex-wrap items-center gap-2 pt-1 border-b border-emerald-900/40 pb-2.5">
        <span class="text-[10px] font-mono text-emerald-400 uppercase tracking-wider font-extrabold flex items-center gap-1">
          <i data-lucide="sparkles" class="w-3.5 h-3.5 text-amber-400"></i> AI Top Picks:
        </span>
        ${top4Crops.map((c, idx) => `
          <button type="button" data-crop-id="${c.id}" class="chip-crop-pick px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer ${
            c.id === primary.id
              ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30'
              : 'bg-emerald-950/70 border border-emerald-800/80 text-emerald-300 hover:bg-emerald-800 hover:text-white'
          }">
            <span>${idx === 0 ? '👑 #1' : `#${idx + 1}`} ${c.name.split('(')[0].trim()}</span>
            <span class="opacity-80 text-[10px]">(${c.suitabilityScore || 90}%)</span>
          </button>
        `).join('')}
      </div>

      <!-- Live 3D Viewport with High-Precision Glass Frame -->
      <div class="relative w-full h-[380px] sm:h-[430px] rounded-xl overflow-hidden bg-gray-950 border border-emerald-900/80 shadow-2xl">
        <canvas id="embedded-3d-farm-canvas" class="w-full h-full block cursor-grab active:cursor-grabbing"></canvas>

        <!-- Top Left Field Telemetry HUD Badge -->
        <div class="absolute top-3 left-3 bg-gray-950/92 backdrop-blur-md border border-emerald-500/40 rounded-xl p-3 text-[11px] space-y-1 font-mono shadow-2xl z-10 pointer-events-none">
          <div class="text-[9px] text-emerald-400 uppercase tracking-wider font-extrabold flex items-center gap-1.5 border-b border-emerald-900/60 pb-1">
            <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
            3D Field Telemetry & Botanical Canopy
          </div>
          <div class="text-white flex justify-between gap-3">
            <span class="text-gray-400">Target Crop:</span>
            <span id="hud-crop-name" class="text-emerald-300 font-bold truncate max-w-[150px]">${cleanCropName} (${primary.suitabilityScore || 90}%)</span>
          </div>
          <div class="text-white flex justify-between gap-3">
            <span class="text-gray-400">3D Archetype:</span>
            <span id="hud-crop-mesh" class="text-teal-300 font-bold capitalize">${cType.replace('_', ' ')} Canopy</span>
          </div>
          <div class="text-white flex justify-between gap-3">
            <span class="text-gray-400">Soil Horizon:</span>
            <span id="hud-soil-info" class="text-amber-300 font-bold">${(soil.type || 'Vertisol').split(' ')[0]} (OC ${soil.oc || 0.65}%)</span>
          </div>
          <div class="text-white flex justify-between gap-3">
            <span class="text-gray-400">Irrigation:</span>
            <span id="hud-irrigation-info" class="text-sky-300 font-bold">${farm.irrigation || 'Rainfed'}${cropProfile.hasWaterLayer ? ' • Flooded' : ''}</span>
          </div>
          <div class="text-white flex justify-between gap-3">
            <span class="text-gray-400">Sun & Sky:</span>
            <span id="hud-climate-info" class="text-blue-300 font-bold">${rainfallVal}mm Rain • ${tempVal}°C (${lightingMode})</span>
          </div>
        </div>

        <!-- Top Right Mini Badges -->
        <div class="absolute top-3 right-3 flex items-center gap-1.5 z-10 pointer-events-none">
          <span class="px-2 py-1 rounded-lg text-[10px] font-mono font-bold bg-black/85 backdrop-blur border border-emerald-900 text-emerald-300">
            🚜 ${farm.acres || 5} Acres Plot
          </span>
          <span class="px-2 py-1 rounded-lg text-[10px] font-mono font-bold bg-black/85 backdrop-blur border border-emerald-900 text-amber-300">
            🌾 100+ Crops 3D Twin
          </span>
        </div>

        <!-- Bottom Guidance Strip -->
        <div class="absolute bottom-3 left-3 right-3 flex flex-wrap items-center justify-between gap-2 z-10 pointer-events-none">
          <div class="flex items-center gap-1.5 bg-black/85 backdrop-blur-md border border-emerald-900/80 rounded-lg px-2.5 py-1 text-[10px] font-mono text-emerald-300 shadow-md">
            <i data-lucide="sparkles" class="w-3.5 h-3.5 text-emerald-400"></i>
            <span>Interactive: Drag canvas to alter wind velocity & drone target</span>
          </div>
          <div class="flex items-center gap-1.5 bg-black/85 backdrop-blur-md border border-gray-800 rounded-lg px-2.5 py-1 text-[10px] font-mono text-gray-300 shadow-md">
            <span class="text-emerald-400 font-bold">●</span>
            <span>Real-time Sync with Inputs</span>
          </div>
        </div>
      </div>
    </div>
  `;
}

/**
 * Initializes the embedded 3D Farm Canvas with the given prediction and input parameters
 */
function initEmbedded3DFarmTwin(prediction, input, selectedCropId) {
  const canvas = document.getElementById('embedded-3d-farm-canvas');
  if (!canvas) return;

  const primary = prediction?.primaryCrop || {};
  let activeCropId = selectedCropId || primary.id || primary.name || 'c-01';

  function runTwinSimulation(cropId) {
    activeCropId = cropId;
    const profile = getCrop3DProfile(cropId);
    const matchedCrop = expanded100Crops.find(c => c.id === cropId) || primary;

    initThreeDFarmCanvas('embedded-3d-farm-canvas', {}, {
      cropId: profile.id,
      cropType: profile.archetype,
      cropName: profile.name,
      category: profile.category,
      primaryCrop: matchedCrop,
      input: input,
      soilType: input?.soil?.type,
      irrigation: input?.farm?.irrigation,
      rainfall: input?.climate?.rainfall,
      temp: input?.climate?.temp,
      humidity: input?.climate?.humidity,
      acres: input?.farm?.acres
    });

    // Update HUD display labels
    const hudCrop = document.getElementById('hud-crop-name');
    if (hudCrop) {
      const cleanName = profile.name.split('(')[0].trim();
      const score = matchedCrop.suitabilityScore ? ` (${matchedCrop.suitabilityScore}%)` : '';
      hudCrop.textContent = `${cleanName}${score}`;
    }
    const hudMesh = document.getElementById('hud-crop-mesh');
    if (hudMesh) {
      hudMesh.textContent = `${profile.archetype.replace('_', ' ').toUpperCase()} Canopy`;
    }
    const hudIrr = document.getElementById('hud-irrigation-info');
    if (hudIrr) {
      hudIrr.textContent = `${input?.farm?.irrigation || 'Rainfed'}${profile.hasWaterLayer ? ' • Flooded' : ''}`;
    }

    // Synchronize the dropdown picker value
    const picker = document.getElementById('embedded-3d-crop-picker');
    if (picker && picker.value !== cropId) {
      picker.value = cropId;
    }

    // Update chip active styling
    document.querySelectorAll('.chip-crop-pick').forEach(chip => {
      const cId = chip.getAttribute('data-crop-id');
      if (cId === cropId) {
        chip.className = 'chip-crop-pick px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30';
      } else {
        chip.className = 'chip-crop-pick px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 cursor-pointer bg-emerald-950/70 border border-emerald-800/80 text-emerald-300 hover:bg-emerald-800 hover:text-white';
      }
    });

    if (typeof lucide !== 'undefined' && lucide.createIcons) {
      lucide.createIcons();
    }
  }

  // Initial simulation invocation
  runTwinSimulation(activeCropId);

  // Hook dropdown picker listener
  const cropPicker = document.getElementById('embedded-3d-crop-picker');
  if (cropPicker) {
    cropPicker.addEventListener('change', (e) => {
      runTwinSimulation(e.target.value);
    });
  }

  // Hook recommendation chips listeners
  document.querySelectorAll('.chip-crop-pick').forEach(chip => {
    chip.addEventListener('click', (e) => {
      const cId = e.currentTarget.getAttribute('data-crop-id');
      if (cId) {
        runTwinSimulation(cId);
      }
    });
  });
}




/* Module Exports */
exports.mapCropTo3DType = mapCropTo3DType; exports.applyLeafTexture = applyLeafTexture; exports.renderThreeDFarmCanvas = renderThreeDFarmCanvas; exports.initThreeDFarmCanvas = initThreeDFarmCanvas; exports.renderEmbedded3DFarmCard = renderEmbedded3DFarmCard; exports.initEmbedded3DFarmTwin = initEmbedded3DFarmTwin;
