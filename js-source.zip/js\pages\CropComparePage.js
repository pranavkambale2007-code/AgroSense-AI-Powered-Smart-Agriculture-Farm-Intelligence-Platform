// AgroSense 4-Crop Comparison Matrix Page Component — Multi-Crop Selector Edition

import { demoCropDatabase } from '../data/demoData.js';
import { drawMultiRadarChart, drawBarChart } from '../components/AnalyticsCharts.js';

const SLOT_COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#a855f7'];
const SLOT_FILLS = [
  'rgba(16, 185, 129, 0.22)',
  'rgba(59, 130, 246, 0.22)',
  'rgba(245, 158, 11, 0.22)',
  'rgba(168, 85, 247, 0.22)'
];

function getDefaultCropIds() {
  return [
    demoCropDatabase[0] ? demoCropDatabase[0].id : 'c-01',
    demoCropDatabase[1] ? demoCropDatabase[1].id : 'c-02',
    demoCropDatabase[3] ? demoCropDatabase[3].id : 'c-04',
    demoCropDatabase[25] ? demoCropDatabase[25].id : (demoCropDatabase[4] ? demoCropDatabase[4].id : 'c-05')
  ];
}

export function renderCropComparePage(state) {
  const defaultIds = getDefaultCropIds();
  const selectedIds = (state.selectedCompareCropIds && state.selectedCompareCropIds.length === 4)
    ? state.selectedCompareCropIds
    : defaultIds;

  const crops = selectedIds.map((id, idx) => 
    demoCropDatabase.find(c => c.id === id) || demoCropDatabase[idx] || demoCropDatabase[0]
  );

  return `
    <div class="space-y-8 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-extrabold text-white flex items-center gap-2">
            <i data-lucide="columns-4" class="w-6 h-6 text-emerald-400"></i>
            Interactive Multi-Crop Comparison & Radar Analytics
          </h1>
          <p class="text-xs text-gray-400">Select and compare agronomic demands, water duties, NPK profiles, and expected profits across any 4 crops in real time</p>
        </div>
        <span class="prototype-badge">${demoCropDatabase.length}+ CROPS ENCYCLOPEDIA</span>
      </div>

      <!-- Crop Selector Row (Pick Any 4 Crops) -->
      <div class="glass-card p-5 border border-emerald-800/40 rounded-2xl bg-[#091812]/90 backdrop-blur-md">
        <div class="flex items-center justify-between mb-3.5">
          <h3 class="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-2">
            <i data-lucide="sliders-horizontal" class="w-3.5 h-3.5"></i>
            Select Candidate Crops to Compare (Slot 1 to 4)
          </h3>
          <span class="text-[11px] text-gray-400 font-mono">Live Matrix Sync Enabled</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          ${[0, 1, 2, 3].map(slotIdx => {
            const currentCrop = crops[slotIdx];
            const slotColor = SLOT_COLORS[slotIdx];
            return `
              <div class="space-y-1.5 p-3 rounded-xl bg-black/30 border border-emerald-900/40">
                <div class="flex items-center justify-between">
                  <label class="block text-[11px] font-bold text-gray-300 flex items-center gap-1.5">
                    <span class="w-2.5 h-2.5 rounded-full inline-block" style="background-color: ${slotColor}"></span>
                    Candidate Slot ${slotIdx + 1}
                  </label>
                  <span class="text-[10px] font-mono font-bold text-emerald-400 px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-800/40">
                    ${currentCrop.suitabilityScore}% Fit
                  </span>
                </div>
                <select data-slot-idx="${slotIdx}" class="compare-crop-select w-full bg-gray-900/90 border border-emerald-700/60 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400 cursor-pointer shadow-inner">
                  ${demoCropDatabase.map(c => `
                    <option value="${c.id}" ${c.id === currentCrop.id ? 'selected' : ''}>${c.name}</option>
                  `).join('')}
                </select>
              </div>
            `;
          }).join('')}
        </div>
      </div>

      <!-- Charts Row -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Multi-Axis Radar Chart -->
        <div class="glass-card p-6 space-y-4 border border-emerald-900/40 rounded-2xl bg-[#091812]/90">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <i data-lucide="radar" class="w-4 h-4 text-emerald-400"></i>
              Multi-Axis Agronomic Profile Radar
            </h3>
            <span class="text-[10px] text-gray-400 font-mono">6 Telemetry Axes</span>
          </div>

          <!-- Color Legend -->
          <div class="flex flex-wrap items-center gap-3 pt-0.5 pb-1 border-b border-emerald-950/60">
            ${crops.map((c, i) => `
              <div class="flex items-center gap-1.5 text-[11px] font-semibold text-gray-300">
                <span class="w-2.5 h-2.5 rounded-full shrink-0" style="background-color: ${SLOT_COLORS[i]}"></span>
                <span class="truncate max-w-[110px]" title="${c.name}">${c.name.split(' (')[0]}</span>
              </div>
            `).join('')}
          </div>

          <div class="w-full h-[240px]">
            <canvas id="compare-radar-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>

        <!-- Relative Suitability Index Bar Chart -->
        <div class="glass-card p-6 space-y-4 border border-emerald-900/40 rounded-2xl bg-[#091812]/90">
          <div class="flex items-center justify-between">
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <i data-lucide="bar-chart-3" class="w-4 h-4 text-teal-400"></i>
              Relative Suitability Index (%)
            </h3>
            <span class="text-[10px] text-emerald-400 font-mono">Max 100%</span>
          </div>

          <!-- Color Legend -->
          <div class="flex flex-wrap items-center gap-3 pt-0.5 pb-1 border-b border-emerald-950/60">
            ${crops.map((c, i) => `
              <div class="flex items-center gap-1.5 text-[11px] font-semibold text-gray-300">
                <span class="w-2.5 h-2.5 rounded-full shrink-0" style="background-color: ${SLOT_COLORS[i]}"></span>
                <span class="truncate max-w-[110px]" title="${c.name}">${c.name.split(' (')[0]}: <strong class="text-white">${c.suitabilityScore}%</strong></span>
              </div>
            `).join('')}
          </div>

          <div class="w-full h-[240px]">
            <canvas id="compare-bar-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>
      </div>

      <!-- Matrix Comparison Table -->
      <div class="glass-card p-6 overflow-x-auto border border-emerald-900/40 rounded-2xl bg-[#091812]/90">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-sm font-bold text-white flex items-center gap-2">
            <i data-lucide="table" class="w-4 h-4 text-emerald-400"></i>
            Detailed Agronomic & Commercial Comparison Matrix
          </h3>
          <span class="text-[11px] text-gray-400 font-mono">Side-by-Side Evaluation</span>
        </div>

        <table class="w-full text-left border-collapse text-xs">
          <thead>
            <tr class="border-b border-emerald-800/60 bg-[#07130e]">
              <th class="p-3.5 text-gray-400 uppercase tracking-wider font-extrabold w-48">Parameter</th>
              ${crops.map((c, i) => `
                <th class="p-3.5 text-white font-extrabold text-sm border-l border-emerald-900/50">
                  <div class="flex items-center gap-2">
                    <span class="w-2.5 h-2.5 rounded-full shrink-0" style="background-color: ${SLOT_COLORS[i]}"></span>
                    <i data-lucide="sprout" class="w-4 h-4 text-emerald-400"></i>
                    <span class="truncate">${c.name.split(' (')[0]}</span>
                  </div>
                  <span class="text-[11px] font-mono font-bold block mt-1" style="color: ${SLOT_COLORS[i]}">
                    Slot ${i + 1} • ${c.suitabilityScore}% Suitability
                  </span>
                </th>
              `).join('')}
            </tr>
          </thead>
          <tbody class="divide-y divide-emerald-950/60">
            <tr>
              <td class="p-3 font-bold text-emerald-300">Category</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 text-gray-200 font-medium">${c.category}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">Cultivation Season</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 font-mono text-emerald-400 font-semibold">${c.season || "Kharif"}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">Soil pH Range</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 font-mono text-gray-200">${c.idealSoilPh}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">Temp Range</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 font-mono text-amber-300">${c.idealTemp}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">Water Requirement</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 font-mono text-blue-300">${c.waterRequirement}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">NPK Nutrient Demand</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 font-mono text-teal-300">${c.npkDemand || "80:40:40 kg/ha"}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">Growth Duration</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 text-gray-200">${c.growthDuration}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">Soil Preference</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 text-gray-300 text-[11px] leading-relaxed">${c.soilPreference || "Well-drained Loam"}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">Key Disease Risks</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 text-amber-400 font-semibold">${c.diseaseVulnerability || "Moderate"}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">Market Price Avg</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 font-mono text-emerald-400 font-bold">${c.marketPriceAvg}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">Expected Yield</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 font-mono text-teal-300 font-semibold">${c.expectedYield}</td>`).join('')}
            </tr>
            <tr>
              <td class="p-3 font-bold text-emerald-300">Net Profit Estimate</td>
              ${crops.map(c => `<td class="p-3 border-l border-emerald-900/50 font-mono text-green-400 font-extrabold text-sm">${c.profitPerHa || "₹75,000 - ₹1,10,000"}</td>`).join('')}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `;
}

export function initCropCompareHooks(state, dispatch) {
  const defaultIds = getDefaultCropIds();
  const selectedIds = (state.selectedCompareCropIds && state.selectedCompareCropIds.length === 4)
    ? state.selectedCompareCropIds
    : defaultIds;

  const crops = selectedIds.map((id, idx) => 
    demoCropDatabase.find(c => c.id === id) || demoCropDatabase[idx] || demoCropDatabase[0]
  );

  // Hook up crop selection dropdowns with live reactive updates
  document.querySelectorAll('.compare-crop-select').forEach(select => {
    select.addEventListener('change', (e) => {
      const slotIdx = parseInt(e.target.getAttribute('data-slot-idx'), 10);
      const newCropId = e.target.value;
      const currentIds = [...(state.selectedCompareCropIds && state.selectedCompareCropIds.length === 4 ? state.selectedCompareCropIds : defaultIds)];
      currentIds[slotIdx] = newCropId;

      if (typeof dispatch === 'function') {
        dispatch({ selectedCompareCropIds: currentIds });
      } else if (window.agroSenseApp && typeof window.agroSenseApp.setState === 'function') {
        window.agroSenseApp.setState({ selectedCompareCropIds: currentIds });
      } else if (window.agrosenseApp && typeof window.agrosenseApp.setState === 'function') {
        window.agrosenseApp.setState({ selectedCompareCropIds: currentIds });
      }
    });
  });

  // Calculate 6-axis telemetry data for each of the 4 candidate crops
  const radarAxes = ['Suitability', 'Soil Match', 'Water Duty', 'Yield Potential', 'Market ROI', 'Climate Match'];
  const datasets = crops.map((c, i) => {
    const suitability = c.suitabilityScore || 80;
    const soilScore = c.whyFactors?.soil ? Math.min(98, Math.max(45, parseInt(c.whyFactors.soil) * 2.8 + 20)) : 82;
    const waterScore = Math.min(98, Math.max(35, ((parseInt(c.waterRequirement) || 500) / 1000) * 80 + 20));
    const yieldScore = Math.min(96, Math.max(45, suitability - 4));
    const marketScore = c.profitPerHa ? Math.min(98, Math.max(45, (parseInt(c.profitPerHa.replace(/[^0-9]/g, '').slice(0, 5)) || 65000) / 1200)) : 75;
    const climateScore = c.whyFactors?.temp ? Math.min(96, Math.max(40, parseInt(c.whyFactors.temp) * 2.5 + 25)) : 80;

    return {
      name: c.name,
      color: SLOT_COLORS[i],
      fillColor: SLOT_FILLS[i],
      values: [suitability, soilScore, waterScore, yieldScore, marketScore, climateScore]
    };
  });

  drawMultiRadarChart('compare-radar-canvas', radarAxes, datasets);

  drawBarChart(
    'compare-bar-canvas',
    crops.map(c => c.name.split(' (')[0].slice(0, 14)),
    crops.map(c => c.suitabilityScore),
    SLOT_COLORS,
    100
  );
}
