// AgroSense Government & Admin Dashboard Page Component

function renderAdminDashboardPage(state) {
  const stats = [
    { title: "Registered Farmers", value: "52,480", change: "+12.4%", icon: "users", color: "text-emerald-400" },
    { title: "Active Farm Polygons", value: "68,910", change: "+8.6%", icon: "map", color: "text-teal-400" },
    { title: "Soil Health Records", value: "142,500", change: "+15.2%", icon: "test-tube", color: "text-amber-400" },
    { title: "AI Vision Disease Screening", value: "28,400", change: "+24.1%", icon: "scan-line", color: "text-blue-400" }
  ];

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="settings" class="w-6 h-6 text-emerald-400"></i>
            Government & Admin System Management
          </h1>
          <p class="text-xs text-gray-400">System overview, farmer registry management, ML model status & RAG document verification</p>
        </div>
        <span class="prototype-badge">ADMIN CONTROL PANEL</span>
      </div>

      <!-- Quick Stats Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        ${stats.map(s => `
          <div class="glass-card p-5 space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-gray-400">${s.title}</span>
              <i data-lucide="${s.icon}" class="w-5 h-5 ${s.color}"></i>
            </div>
            <div class="text-2xl font-extrabold text-white font-mono">${s.value}</div>
            <span class="text-[11px] font-bold text-emerald-400 font-mono">${s.change} vs previous month</span>
          </div>
        `).join('')}
      </div>

      <!-- System Quick Links -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <a href="#/admin/models" class="glass-card p-5 space-y-2 text-decoration-none group hover:border-emerald-400 transition">
          <div class="flex items-center justify-between">
            <span class="text-sm font-bold text-white">Model Management</span>
            <i data-lucide="cpu" class="w-5 h-5 text-emerald-400"></i>
          </div>
          <p class="text-xs text-gray-400">Check connectivity status of Crop Recommendation, Vision Screening & Weather Risk models.</p>
        </a>

        <a href="#/knowledge" class="glass-card p-5 space-y-2 text-decoration-none group hover:border-emerald-400 transition">
          <div class="flex items-center justify-between">
            <span class="text-sm font-bold text-white">RAG Knowledge Base</span>
            <i data-lucide="book-open" class="w-5 h-5 text-emerald-400"></i>
          </div>
          <p class="text-xs text-gray-400">Review, approve, or reject verified university & ICAR extension documents.</p>
        </a>

        <a href="#/import-data" class="glass-card p-5 space-y-2 text-decoration-none group hover:border-emerald-400 transition">
          <div class="flex items-center justify-between">
            <span class="text-sm font-bold text-white">Data Quality & CSV Import</span>
            <i data-lucide="file-spreadsheet" class="w-5 h-5 text-emerald-400"></i>
          </div>
          <p class="text-xs text-gray-400">Audit datasets for missing NPK values, duplicate entries & outliers.</p>
        </a>
      </div>
    </div>
  `;
}

/* Module Exports */
exports.renderAdminDashboardPage = renderAdminDashboardPage;
