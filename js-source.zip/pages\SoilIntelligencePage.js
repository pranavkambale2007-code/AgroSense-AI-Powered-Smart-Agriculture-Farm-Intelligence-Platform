// AgroSense Soil Intelligence & Chemistry Analysis Page Component with Spider/Radar Chart

const { analyzeSoilHealth } = require('js/services/soilService.js');
const { renderGenericXAIExplanationCard } = require('js/components/XAIExplanationCard.js');
const { drawRadarChart } = require('js/components/AnalyticsCharts.js');
const { translations } = require('js/data/translations.js');

function renderSoilIntelligencePage(state) {
  const t = translations[state.lang] || translations.en;
  const farm = state.activeFarm;
  const soilData = state.customSoil || farm.soil;
  const analysis = analyzeSoilHealth(soilData);

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Top Title Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="test-tube" class="w-6 h-6 text-emerald-400"></i>
            ${t.nav ? t.nav.soil : 'Soil Intelligence'} & Laboratory Analysis
          </h1>
          <p class="text-xs text-gray-400">Evaluate NPK macro-nutrients, pH balance, organic carbon, and electrical conductivity</p>
        </div>
        <span class="prototype-badge">SOIL CHEMISTRY MODEL</span>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Interactive Soil Form Input Card & What-If Sliders -->
        <div class="glass-card p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-900/40 pb-2">
            <h3 class="text-sm font-bold text-emerald-300 uppercase tracking-wider">What-If Soil Simulator</h3>
            <span class="text-[10px] text-amber-400 font-semibold font-mono">REAL-TIME XAI RE-CALC</span>
          </div>

          <form id="soil-input-form" class="space-y-3 text-xs">
            <div>
              <div class="flex justify-between text-gray-300 mb-1">
                <span>Nitrogen (N) - kg/ha</span>
                <span class="font-mono font-bold text-emerald-400" id="n-val-label">${soilData.nitrogen}</span>
              </div>
              <input type="range" id="input-soil-n" min="50" max="600" step="5" name="nitrogen" value="${soilData.nitrogen}" class="w-full accent-emerald-500 cursor-pointer" />
            </div>

            <div>
              <div class="flex justify-between text-gray-300 mb-1">
                <span>Phosphorus (P) - kg/ha</span>
                <span class="font-mono font-bold text-emerald-400" id="p-val-label">${soilData.phosphorus}</span>
              </div>
              <input type="range" id="input-soil-p" min="10" max="150" step="2" name="phosphorus" value="${soilData.phosphorus}" class="w-full accent-emerald-500 cursor-pointer" />
            </div>

            <div>
              <div class="flex justify-between text-gray-300 mb-1">
                <span>Potassium (K) - kg/ha</span>
                <span class="font-mono font-bold text-emerald-400" id="k-val-label">${soilData.potassium}</span>
              </div>
              <input type="range" id="input-soil-k" min="50" max="500" step="5" name="potassium" value="${soilData.potassium}" class="w-full accent-emerald-500 cursor-pointer" />
            </div>

            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="block text-gray-300 mb-1">Soil pH (3 - 10)</label>
                <input type="number" id="input-soil-ph" step="0.1" name="ph" value="${soilData.ph}" class="w-full bg-gray-900 border border-emerald-700/50 rounded-lg p-2 text-white font-mono focus:outline-none focus:border-emerald-400" />
              </div>
              <div>
                <label class="block text-gray-300 mb-1">Moisture (%)</label>
                <input type="number" id="input-soil-moisture" step="0.1" name="moisture" value="${soilData.moisture}" class="w-full bg-gray-900 border border-emerald-700/50 rounded-lg p-2 text-white font-mono focus:outline-none focus:border-emerald-400" />
              </div>
            </div>

            <div class="grid grid-cols-2 gap-2">
              <div>
                <label class="block text-gray-300 mb-1">Organic Carbon (%)</label>
                <input type="number" id="input-soil-oc" step="0.01" name="organicCarbon" value="${soilData.organicCarbon || 0.65}" class="w-full bg-gray-900 border border-emerald-700/50 rounded-lg p-2 text-white font-mono focus:outline-none focus:border-emerald-400" />
              </div>
              <div>
                <label class="block text-gray-300 mb-1">EC (dS/m)</label>
                <input type="number" id="input-soil-ec" step="0.01" name="electricalConductivity" value="${soilData.electricalConductivity || 0.85}" class="w-full bg-gray-900 border border-emerald-700/50 rounded-lg p-2 text-white font-mono focus:outline-none focus:border-emerald-400" />
              </div>
            </div>

            <button type="submit" class="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition mt-2 cursor-pointer shadow-lg shadow-emerald-900/40">
              ${t.recalculateScore || 'Re-calculate Soil Chemistry Score'}
            </button>
          </form>
        </div>

        <!-- Soil Analysis Results & Radar Chart -->
        <div class="lg:col-span-2 space-y-6">
          <!-- Overall Soil Score Gauge Header -->
          <div class="glass-card-accent p-6 flex flex-wrap items-center justify-between gap-4">
            <div>
              <span class="text-xs font-bold text-emerald-400 uppercase tracking-wider">SOIL FERTILITY INDEX</span>
              <h2 class="text-3xl font-extrabold text-white font-mono">${analysis.overallScore} <span class="text-lg text-gray-400 font-normal">/ 100</span></h2>
              <p class="text-xs text-emerald-300 font-semibold mt-1">${analysis.statusSummary}</p>
            </div>
            <div class="p-3 rounded-xl bg-emerald-950/60 border border-emerald-700/40 text-xs max-w-md">
              <span class="font-bold text-amber-300 block mb-1">AI Soil Assessment:</span>
              <p class="text-gray-300 leading-relaxed">${analysis.summaryAdvice}</p>
            </div>
          </div>

          <!-- DATA SCIENCE SPIDER / RADAR CHART CARD -->
          <div class="glass-card p-6 space-y-3">
            <div class="flex items-center justify-between">
              <div class="flex items-center gap-2">
                <i data-lucide="compass" class="w-5 h-5 text-emerald-400"></i>
                <h3 class="text-sm font-bold text-white">Nutrient Balance Radar / Spider Web Chart</h3>
              </div>
              <span class="text-[10px] text-gray-400 font-mono">Current (Solid) vs Target (Dashed)</span>
            </div>
            <div class="h-60 w-full relative">
              <canvas id="soil-radar-chart" class="w-full h-full"></canvas>
            </div>
          </div>

          <!-- Soil Chemistry Mathematical XAI Card -->
          ${renderGenericXAIExplanationCard(
            "Soil Health Score Mathematical Attribution",
            "Why is Soil Score evaluated at " + analysis.overallScore + "/100?",
            analysis.xaiAttribution.formula,
            analysis.xaiAttribution.deductions.map(d => ({
              label: d.parameter,
              value: `-${d.pointsLost} pts`,
              note: `${d.reason} (${d.formula})`
            }))
          )}

          <!-- Parameter Progress Bars Grid -->
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            ${analysis.breakdown.map(item => `
              <div class="glass-card p-4 space-y-2">
                <div class="flex items-center justify-between text-xs">
                  <span class="font-bold text-white">${item.name}</span>
                  <span class="font-mono font-bold text-emerald-400">${item.value} ${item.unit}</span>
                </div>
                <div class="w-full h-2 rounded-full bg-gray-900 overflow-hidden">
                  <div class="h-full bg-gradient-to-r from-emerald-500 to-lime-400 rounded-full" style="width: ${item.score}%"></div>
                </div>
                <div class="flex items-center justify-between text-[11px]">
                  <span class="text-gray-400">Status: <b class="${item.status.includes('Deficient') || item.status.includes('Low') ? 'text-amber-400' : 'text-emerald-400'}">${item.status}</b></span>
                  <span class="text-gray-500">Ideal: ${item.ideal}</span>
                </div>
                <p class="text-[11px] text-gray-400 pt-1 border-t border-emerald-950/50">${item.advice}</p>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    </div>
  `;
}

function initSoilHooks(state, setState) {
  const farm = state.activeFarm;
  const soil = state.customSoil || farm.soil;

  const nScore = Math.min(100, Math.round((soil.nitrogen / 280) * 100));
  const pScore = Math.min(100, Math.round((soil.phosphorus / 35) * 100));
  const kScore = Math.min(100, Math.round((soil.potassium / 280) * 100));
  const phScore = Math.min(100, Math.round((soil.ph / 7.0) * 100));
  const ocScore = Math.min(100, Math.round(((soil.organicCarbon || 0.65) / 0.7) * 100));
  const moistureScore = Math.min(100, Math.round((soil.moisture / 35) * 100));

  drawRadarChart(
    'soil-radar-chart',
    ['Nitrogen', 'Phosphorus', 'Potassium', 'pH Balance', 'Organic Carbon', 'Moisture'],
    [nScore, pScore, kScore, phScore, ocScore, moistureScore],
    [100, 100, 100, 100, 100, 100]
  );

  const bindLabel = (inputId, labelId) => {
    const input = document.getElementById(inputId);
    const label = document.getElementById(labelId);
    if (input && label) {
      input.addEventListener('input', (e) => { label.textContent = e.target.value; });
    }
  };

  bindLabel('input-soil-n', 'n-val-label');
  bindLabel('input-soil-p', 'p-val-label');
  bindLabel('input-soil-k', 'k-val-label');

  const form = document.getElementById('soil-input-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const nVal = Number(document.getElementById('input-soil-n').value) || 185;
      const pVal = Number(document.getElementById('input-soil-p').value) || 34;
      const kVal = Number(document.getElementById('input-soil-k').value) || 310;
      const phVal = Number(document.getElementById('input-soil-ph').value) || 7.2;
      const moistVal = Number(document.getElementById('input-soil-moisture').value) || 32;
      const ocVal = Number(document.getElementById('input-soil-oc').value) || 0.65;
      const ecVal = Number(document.getElementById('input-soil-ec').value) || 0.85;

      const newSoil = {
        ...soil,
        nitrogen: nVal,
        phosphorus: pVal,
        potassium: kVal,
        ph: phVal,
        moisture: moistVal,
        organicCarbon: ocVal,
        electricalConductivity: ecVal
      };

      if (setState) {
        setState({ customSoil: newSoil });
      }
    });
  }
}

/* Module Exports */
exports.renderSoilIntelligencePage = renderSoilIntelligencePage; exports.initSoilHooks = initSoilHooks;
