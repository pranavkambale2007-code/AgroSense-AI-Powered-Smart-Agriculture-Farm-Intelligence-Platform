// AgroSense Weather Intelligence & Microclimate Infection Risk Service

import { calculateFungalSporeInfectionIndex } from './agronomicEngine.js';

export async function fetchLiveOrDemoWeather(lat = 18.5204, lng = 73.8567) {
  try {
    const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current_weather=true&hourly=temperature_2m,relativehumidity_2m,precipitation_probability,windspeed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max&timezone=auto`);
    
    if (response.ok) {
      const data = await response.json();
      const current = data.current_weather;
      
      const forecast7Days = data.daily.time.slice(0, 7).map((time, idx) => ({
        day: new Date(time).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
        maxTemp: Math.round(data.daily.temperature_2m_max[idx]),
        minTemp: Math.round(data.daily.temperature_2m_min[idx]),
        rainProb: data.daily.precipitation_probability_max ? data.daily.precipitation_probability_max[idx] : 20,
        rainSum: data.daily.precipitation_sum ? data.daily.precipitation_sum[idx] : 0,
        condition: (data.daily.precipitation_sum[idx] > 2) ? "Rainy" : (data.daily.temperature_2m_max[idx] > 32) ? "Sunny / Heat" : "Partly Cloudy"
      }));

      return {
        isLiveApi: true,
        sourceLabel: "Live Open-Meteo Weather API",
        temp: current.temperature,
        windSpeed: current.windspeed,
        humidity: data.hourly.relativehumidity_2m ? data.hourly.relativehumidity_2m[0] : 65,
        condition: current.weathercode > 50 ? "Rainy" : "Partly Cloudy",
        rainProb: data.daily.precipitation_probability_max ? data.daily.precipitation_probability_max[0] : 15,
        forecast: forecast7Days,
        hourly: data.hourly.temperature_2m.slice(0, 8).map((t, idx) => ({
          time: `${idx * 3}:00`,
          temp: Math.round(t),
          humidity: data.hourly.relativehumidity_2m[idx * 3] || 60
        }))
      };
    }
  } catch (err) {
    console.warn("Live weather fetch failed, switching to Demo Weather Mode:", err);
  }

  // Fallback Demo Weather Mode
  return {
    isLiveApi: false,
    sourceLabel: "Demo Weather Mode (Prototype Data)",
    temp: 26.8,
    humidity: 68,
    windSpeed: 12.4,
    condition: "Partly Cloudy",
    rainProb: 25,
    forecast: [
      { day: "Today", maxTemp: 28, minTemp: 19, rainProb: 25, rainSum: 0.5, condition: "Partly Cloudy" },
      { day: "Tomorrow", maxTemp: 31, minTemp: 20, rainProb: 65, rainSum: 14.2, condition: "Heavy Rain" },
      { day: "Wed", maxTemp: 29, minTemp: 18, rainProb: 30, rainSum: 2.0, condition: "Light Rain" },
      { day: "Thu", maxTemp: 32, minTemp: 21, rainProb: 10, rainSum: 0, condition: "Sunny" },
      { day: "Fri", maxTemp: 34, minTemp: 22, rainProb: 5, rainSum: 0, condition: "Heat Stress" },
      { day: "Sat", maxTemp: 33, minTemp: 21, rainProb: 15, rainSum: 0, condition: "Clear" },
      { day: "Sun", maxTemp: 30, minTemp: 19, rainProb: 20, rainSum: 0, condition: "Partly Cloudy" }
    ],
    hourly: [
      { time: "06:00", temp: 20, humidity: 85 },
      { time: "09:00", temp: 24, humidity: 72 },
      { time: "12:00", temp: 28, humidity: 62 },
      { time: "15:00", temp: 29, humidity: 58 },
      { time: "18:00", temp: 26, humidity: 68 },
      { time: "21:00", temp: 22, humidity: 78 }
    ]
  };
}

/**
 * Evaluates comprehensive multi-hazard AI weather risks for precision farm operations
 * Supports real-time sensor streams, weather API forecasts, and what-if simulation overrides
 */
export function evaluateAdvancedWeatherRisks(weatherData, cropKey = 'wheat', phenologicalStage = 'vegetative', simulationOverrides = null) {
  // Apply simulation overrides if provided
  const temp = simulationOverrides?.temp !== undefined ? simulationOverrides.temp : (weatherData?.temp ?? 26.8);
  const humidity = simulationOverrides?.humidity !== undefined ? simulationOverrides.humidity : (weatherData?.humidity ?? 68);
  const windSpeed = simulationOverrides?.windSpeed !== undefined ? simulationOverrides.windSpeed : (weatherData?.windSpeed ?? 12.4);
  
  const forecast = weatherData?.forecast || [
    { day: "Today", maxTemp: 28, minTemp: 19, rainProb: 25, rainSum: 0.5, condition: "Partly Cloudy" },
    { day: "Tomorrow", maxTemp: 31, minTemp: 20, rainProb: 65, rainSum: 14.2, condition: "Heavy Rain" },
    { day: "Wed", maxTemp: 29, minTemp: 18, rainProb: 30, rainSum: 2.0, condition: "Light Rain" },
    { day: "Thu", maxTemp: 32, minTemp: 21, rainProb: 10, rainSum: 0, condition: "Sunny" },
    { day: "Fri", maxTemp: 34, minTemp: 22, rainProb: 5, rainSum: 0, condition: "Heat Stress" },
    { day: "Sat", maxTemp: 33, minTemp: 21, rainProb: 15, rainSum: 0, condition: "Clear" },
    { day: "Sun", maxTemp: 30, minTemp: 19, rainProb: 20, rainSum: 0, condition: "Partly Cloudy" }
  ];

  const maxRainProb = simulationOverrides?.rainProb !== undefined 
    ? simulationOverrides.rainProb 
    : (forecast.length > 0 ? Math.max(...forecast.map(f => f.rainProb)) : 25);

  const maxRainSum = simulationOverrides?.rainSum !== undefined 
    ? simulationOverrides.rainSum 
    : (forecast.length > 0 ? Math.max(...forecast.map(f => f.rainSum)) : 0.5);

  const maxTemp = simulationOverrides?.temp !== undefined
    ? Math.max(simulationOverrides.temp, forecast.length > 0 ? Math.max(...forecast.map(f => f.maxTemp)) : 31)
    : (forecast.length > 0 ? Math.max(...forecast.map(f => f.maxTemp)) : 31);

  const minTemp = forecast.length > 0 ? Math.min(...forecast.map(f => f.minTemp)) : 18;

  // Fungal Spore Index calculation
  const sporeIndex = calculateFungalSporeInfectionIndex(humidity, temp);

  // Normalize crop key
  const crop = (cropKey || 'wheat').toLowerCase();

  // 1. HAZARD: Heavy Rain & Flash Flood / Root Hypoxia Risk
  const rainRiskScore = Math.min(100, Math.round(maxRainProb * 0.55 + maxRainSum * 2.8));
  let rainLevel = "LOW";
  let rainColor = "emerald";
  if (rainRiskScore >= 75) { rainLevel = "CRITICAL"; rainColor = "red"; }
  else if (rainRiskScore >= 50) { rainLevel = "HIGH"; rainColor = "orange"; }
  else if (rainRiskScore >= 30) { rainLevel = "MODERATE"; rainColor = "amber"; }

  let rainCropVuln = "Prolonged surface water film triggers bacterial collar rot and root suffocation.";
  if (crop === 'wheat') rainCropVuln = "Lodging of tall stalks and grain shattering if heavy rain occurs near harvest (DAS 110+).";
  else if (crop === 'cotton') rainCropVuln = "Extreme sensitivity to waterlogging: triggers root hypoxia, sudden wilting (parawilt), and boll shed.";
  else if (crop === 'tomato' || crop === 'chilli') rainCropVuln = "Splashing raindrops trigger soil-borne Late Blight and Phytophthora collar rot within 24 hours.";
  else if (crop === 'potato') rainCropVuln = "Waterlogged ridge furrows cause black leg, soft bacterial tuber rot, and Late Blight epidemics.";
  else if (crop === 'groundnut' || crop === 'soybean') rainCropVuln = "Excessive moisture promotes collar rot, Aspergillus crown rot, and pod rot in soil.";
  else if (crop === 'rice') rainCropVuln = "Paddy is flood-tolerant during vegetative phase, but vulnerable to submergence if young seedlings (<10 DAS).";

  const hazardHeavyRain = {
    id: "risk-heavy-rain",
    hazardKey: "heavy_rain",
    title: "Heavy Rain & Waterlogging Risk",
    titleVernacular: "अत्यधिक वर्षा एवं जलजमाव जोखिम (पाण्याचा निचरा)",
    riskScore: rainRiskScore,
    level: rainLevel,
    color: rainColor,
    icon: "cloud-lightning",
    currentValueStr: `${maxRainProb}% Rain Probability | Forecast: ${maxRainSum} mm`,
    thresholdStr: ">60% probability or >12 mm precipitation threshold",
    triggerFormula: `P(Rain) = ${maxRainProb}% | RainSum = ${maxRainSum}mm | Hypoxia_Index = ${rainRiskScore}/100`,
    cropVulnerability: rainCropVuln,
    expectedImpact: "Soil saturation, root zone oxygen depletion, foliar fungicide wash-off, and mechanical field access blockage.",
    mitigationAction: rainLevel === "LOW" 
      ? "Standard irrigation scheduling. Furrow drains are adequate."
      : "Immediately open drainage trenches at field boundaries. Postpone all nitrogen top-dressing and foliar chemical spraying until the storm clears.",
    emergencyChecklist: [
      "Dig 30cm perimeter contour trenches to divert excess surface runoff away from standing crops.",
      "Postpone synthetic nitrogen (Urea) application — excess rain leaches nitrates into subsoil.",
      "Clear drainage ditches around root zones to ensure zero standing water beyond 6 hours."
    ]
  };

  // 2. HAZARD: Canopy Heatwave & Evaporative Desiccation Risk
  const heatRiskScore = Math.min(100, Math.round(Math.max(0, (maxTemp - 30) * 11)));
  let heatLevel = "LOW";
  let heatColor = "emerald";
  if (heatRiskScore >= 75) { heatLevel = "CRITICAL"; heatColor = "red"; }
  else if (heatRiskScore >= 50) { heatLevel = "HIGH"; heatColor = "orange"; }
  else if (heatRiskScore >= 25) { heatLevel = "MODERATE"; heatColor = "amber"; }

  let heatCropVuln = "High daytime temperatures increase Vapor Pressure Deficit (VPD), accelerating cellular moisture exhaustion.";
  if (crop === 'wheat') heatCropVuln = "Terminal heat stress (>32°C) during milk/dough stage causes premature forced ripening and 20-25% grain weight loss.";
  else if (crop === 'tomato' || crop === 'chilli') heatCropVuln = "Temperatures exceeding 34°C cause pollen sterility, massive blossom drop, and sun-scald on developing fruits.";
  else if (crop === 'maize') heatCropVuln = "Heat above 35°C during tasseling desiccates silk, preventing fertilization and leading to barren, half-filled cobs.";
  else if (crop === 'cotton') heatCropVuln = "Severe heat stress (>36°C) causes square drying, pollen desiccation, and heavy boll drop.";

  const hazardHeatStress = {
    id: "risk-heat-stress",
    hazardKey: "heat_stress",
    title: "Extreme Heatwave & Canopy Desiccation Risk",
    titleVernacular: "लू एवं अत्यधिक तापमान जोखिम (उष्णतेची लाट)",
    riskScore: heatRiskScore,
    level: heatLevel,
    color: heatColor,
    icon: "sun",
    currentValueStr: `Max Temp: ${maxTemp}°C (Ambient: ${temp}°C)`,
    thresholdStr: ">33°C critical threshold for floral anthesis",
    triggerFormula: `T_max = ${maxTemp}°C | ΔT = +${Math.max(0, maxTemp - 30)}°C above baseline | Heat_Index = ${heatRiskScore}/100`,
    cropVulnerability: heatCropVuln,
    expectedImpact: "High Evapotranspiration (ET0 > 6.5 mm/day), temporary afternoon wilting, reduced photosynthetic efficiency, and flower abortion.",
    mitigationAction: heatLevel === "LOW"
      ? "Maintain regular drip pulse irrigation. No thermal stress detected."
      : "Initiate micro-irrigation pulses during early morning (5:00 AM – 7:30 AM). Spray Potassium Nitrate (KNO3 @ 1%) or Kaolin clay (anti-transpirant) to reflect excess solar radiation.",
    emergencyChecklist: [
      "Operate drip irrigation in early morning to lower rhizosphere soil temperature.",
      "Apply 2 inches of organic straw or sugarcane trash mulch over root zones to conserve moisture.",
      "Foliar spray of Potassium Nitrate (13:0:45 @ 10g/L) to maintain stomatal turgor pressure."
    ]
  };

  // 3. HAZARD: Microclimate Fungal Spore Inoculum & Blight Flare-up Risk
  const sporeRiskScore = Math.min(100, Math.round(sporeIndex * 85 + (maxRainProb > 40 ? 15 : 0)));
  let sporeLevel = "LOW";
  let sporeColor = "emerald";
  if (sporeRiskScore >= 75) { sporeLevel = "CRITICAL"; sporeColor = "red"; }
  else if (sporeRiskScore >= 50) { sporeLevel = "HIGH"; sporeColor = "orange"; }
  else if (sporeRiskScore >= 30) { sporeLevel = "MODERATE"; sporeColor = "amber"; }

  let sporeCropVuln = "Favorable relative humidity (>70%) and warm canopy temperatures trigger rapid fungal spore germination.";
  if (crop === 'wheat') sporeCropVuln = "Morning fog coupled with 18-24°C microclimate creates epidemic conditions for Yellow / Stripe Rust (Puccinia striiformis).";
  else if (crop === 'tomato' || crop === 'potato') sporeCropVuln = "Relative humidity >85% and cool nights trigger explosive Late Blight (Phytophthora infestans) zoospore germination.";
  else if (crop === 'groundnut') sporeCropVuln = "High relative humidity (>80%) and warm soil/canopy conditions trigger early/late Tikka leaf spot (Cercospora).";
  else if (crop === 'chilli') sporeCropVuln = "High humidity promotes Anthracnose fruit rot and powdery mildew on lower leaf canopy.";
  else if (crop === 'rice') sporeCropVuln = "Cloudy overcast skies + high humidity trigger Rice Blast (Magnaporthe oryzae) spindle lesions on leaf blades.";

  const hazardFungalSpore = {
    id: "risk-humidity-blight",
    hazardKey: "fungal_spore",
    title: "Fungal Spore Germination & Blight Outbreak Risk",
    titleVernacular: "बुरशीजन्य रोग व झुलसा फैलाव जोखिम (रोग बीजाणू)",
    riskScore: sporeRiskScore,
    level: sporeLevel,
    color: sporeColor,
    icon: "droplets",
    currentValueStr: `Humidity: ${humidity}% | Temp: ${temp}°C | Spore Index: ${sporeIndex}`,
    thresholdStr: "RH > 65% + Temp 20-30°C creates optimal pathogen incubation",
    triggerFormula: `I_spore = f(RH ${humidity}%, T ${temp}°C) = ${sporeIndex} | Spore_Risk = ${sporeRiskScore}/100`,
    cropVulnerability: sporeCropVuln,
    expectedImpact: "Microscopic zoospore germ-tube penetration into stomata, necrotic leaf spots, chlorosis, and rapid secondary sporulation.",
    mitigationAction: sporeLevel === "LOW"
      ? "Microclimate is nominal. Maintain routine canopy scouting."
      : "Apply preventive broad-spectrum bio-fungicide (Trichoderma viride @ 5g/L) or chemical protectant (Mancozeb 75% WP @ 2.5g/L) before continuous leaf wetness exceeds 4 hours.",
    emergencyChecklist: [
      "Prune dense lower foliage (bottom 25cm) to improve inter-row airflow and reduce humidity.",
      "Switch overhead sprinkler irrigation strictly to ground drip lines to eliminate foliar wetness.",
      "Spray systemic protective fungicide (e.g. Azoxystrobin or Propiconazole) at first symptom spot."
    ]
  };

  // 4. HAZARD: Cold Wave & Nocturnal Frost Shock Risk
  const frostRiskScore = Math.min(100, Math.round(Math.max(0, (14 - minTemp) * 10)));
  let frostLevel = "LOW";
  let frostColor = "emerald";
  if (frostRiskScore >= 70) { frostLevel = "CRITICAL"; frostColor = "red"; }
  else if (frostRiskScore >= 45) { frostLevel = "HIGH"; frostColor = "orange"; }
  else if (frostRiskScore >= 20) { frostLevel = "MODERATE"; frostColor = "amber"; }

  const hazardFrost = {
    id: "risk-cold-frost",
    hazardKey: "frost_cold",
    title: "Cold Wave & Nocturnal Frost Shock Risk",
    titleVernacular: "शीत लहर एवं पाला जोखिम (थंडीची लाट / दव पडणे)",
    riskScore: frostRiskScore,
    level: frostLevel,
    color: frostColor,
    icon: "snowflake",
    currentValueStr: `Min Night Temp: ${minTemp}°C`,
    thresholdStr: "<10°C growth stagnation | <4°C cellular radiative frost burn",
    triggerFormula: `T_min = ${minTemp}°C | Frost_Deficit = ${Math.max(0, 14 - minTemp)}°C | Frost_Score = ${frostRiskScore}/100`,
    cropVulnerability: "Sudden temperature drops cause intracellular ice crystal formation, rupturing cell membranes and causing black foliage burn.",
    expectedImpact: "Cold shock slows phosphorus uptake, causes purpling of leaves, and stunts vegetative growth.",
    mitigationAction: frostLevel === "LOW"
      ? "Thermal profile is safe for subtropical and rabi crops."
      : "Give light nocturnal drip or furrow irrigation between 2:00 AM – 5:00 AM (water has high specific heat capacity, releasing latent heat to elevate canopy temp by 1-2°C).",
    emergencyChecklist: [
      "Provide light nocturnal irrigation before dawn to elevate ground heat storage.",
      "Light controlled smoky bio-waste / cow-dung smudge fires on windward farm borders to trap radiant heat.",
      "Spray 0.1% Sulphuric Acid (1 ml / L water) or soluble sulphur to increase cold tolerance in standing crops."
    ]
  };

  // 5. HAZARD: High Wind Squall & Crop Lodging / Spray Drift Risk
  const windRiskScore = Math.min(100, Math.round(Math.max(0, (windSpeed - 10) * 3.8)));
  let windLevel = "LOW";
  let windColor = "emerald";
  if (windRiskScore >= 70) { windLevel = "CRITICAL"; windColor = "red"; }
  else if (windRiskScore >= 45) { windLevel = "HIGH"; windColor = "orange"; }
  else if (windRiskScore >= 20) { windLevel = "MODERATE"; windColor = "amber"; }

  const hazardWind = {
    id: "risk-high-wind",
    hazardKey: "wind_squall",
    title: "High Wind Squall & Crop Lodging / Drift Risk",
    titleVernacular: "तेज आंधी, फसल गिरने व स्प्रे बहाव जोखिम (वादळी वारे)",
    riskScore: windRiskScore,
    level: windLevel,
    color: windColor,
    icon: "wind",
    currentValueStr: `Wind Speed: ${windSpeed} km/h`,
    thresholdStr: ">12 km/h chemical spray drift | >28 km/h physical lodging",
    triggerFormula: `V_wind = ${windSpeed} km/h | Kinetic_Drag = 0.5 × ρ × V² | Wind_Score = ${windRiskScore}/100`,
    cropVulnerability: "Physical bending of mature cereal stalks (wheat, maize, rice); mechanical lodging of vegetable vines and pod drop.",
    expectedImpact: "Uneven foliar pesticide coverage, off-target pesticide drift onto adjacent fields, stalk snapping, and soil crust drying.",
    mitigationAction: windLevel === "LOW"
      ? "Wind velocity is gentle (<12 km/h). Safe for precision spraying and field operations."
      : "Strictly suspend all knapsack pesticide and herbicide spraying to avoid toxic chemical drift. Stake tall indeterminate tomato and chilli vines.",
    emergencyChecklist: [
      "Do NOT spray agricultural chemicals when wind speed exceeds 12 km/h — spray droplets drift up to 50 meters off-target.",
      "Provide bamboo staking and trellis reinforcement for high-value horticultural crops.",
      "Earth up soil around root bases in maize and sugarcane to strengthen root anchorage."
    ]
  };

  // 6. HAZARD: Severe Thunderstorm & Convective Hail Injury Risk
  const hailRiskScore = Math.min(100, Math.round(Math.max(0, (maxTemp - 30) * 5 + (maxRainProb > 50 ? 25 : 0) + (windSpeed > 18 ? 15 : 0))));
  let hailLevel = "LOW";
  let hailColor = "emerald";
  if (hailRiskScore >= 65) { hailLevel = "CRITICAL"; hailColor = "red"; }
  else if (hailRiskScore >= 40) { hailLevel = "HIGH"; hailColor = "orange"; }
  else if (hailRiskScore >= 20) { hailLevel = "MODERATE"; hailColor = "amber"; }

  const hazardHailstorm = {
    id: "risk-hailstorm",
    hazardKey: "hailstorm",
    title: "Convective Storm & Hail Mechanical Injury Risk",
    titleVernacular: "तूफान एवं ओलावृष्टि यांत्रिक क्षति जोखिम (गारपीट)",
    riskScore: hailRiskScore,
    level: hailLevel,
    color: hailColor,
    icon: "zap",
    currentValueStr: `Convective Index: ${hailRiskScore}/100 (Storm Prob: ${maxRainProb}%)`,
    thresholdStr: "High surface heat (>32°C) + sudden cold front triggers hailstones",
    triggerFormula: `Convective_Instability = f(ΔT, Wind ${windSpeed}km/h, P(Rain) ${maxRainProb}%) = ${hailRiskScore}/100`,
    cropVulnerability: "Hailstones tear tender leaf blades, strip flowering blossoms, and create open wounds on stems and developing pods.",
    expectedImpact: "Catastrophic mechanical defoliation and secondary bacterial infection entering through physical hail lacerations.",
    mitigationAction: hailLevel === "LOW"
      ? "Atmosphere is thermally stable. Zero hailstorm alerts in local radar."
      : "Deploy shade nets or protective row covers over high-value vegetable crops. In case of hail damage, spray Copper Oxychloride (3g/L) within 24 hours to disinfect open plant wounds.",
    emergencyChecklist: [
      "Deploy shade nets and row covers over vulnerable vegetable beds and nursery plots.",
      "Inspect foliage immediately after storm for physical lacerations and stem bruising.",
      "Apply broad-spectrum bactericide + fungicide within 24 hours to seal torn plant tissues and block pathogen ingress."
    ]
  };

  const hazards = [
    hazardHeavyRain,
    hazardHeatStress,
    hazardFungalSpore,
    hazardFrost,
    hazardWind,
    hazardHailstorm
  ];

  // Calculate Unified Composite Farm Weather Risk Score (Weighted average prioritizing critical threats)
  const maxIndividualRisk = Math.max(...hazards.map(h => h.riskScore));
  const avgRisk = Math.round(hazards.reduce((sum, h) => sum + h.riskScore, 0) / hazards.length);
  const compositeRiskScore = Math.min(100, Math.round(maxIndividualRisk * 0.65 + avgRisk * 0.35));

  let compositeLevel = "LOW";
  let compositeColor = "emerald";
  if (compositeRiskScore >= 70) { compositeLevel = "CRITICAL"; compositeColor = "red"; }
  else if (compositeRiskScore >= 50) { compositeLevel = "HIGH"; compositeColor = "orange"; }
  else if (compositeRiskScore >= 30) { compositeLevel = "MODERATE"; compositeColor = "amber"; }

  // SPRAY SAFETY WINDOW AI ADVISOR
  let sprayStatus = "SAFE";
  let sprayBadgeText = "Optimal Chemical Spray Window";
  let sprayColor = "emerald";
  let sprayIcon = "shield-check";
  let sprayReason = "Favorable weather: Wind velocity is gentle (<12 km/h), rain probability is low (<30%), and foliage will dry within 2 hours.";
  let sprayBestHours = "Tomorrow 06:30 AM – 09:30 AM or 04:30 PM – 06:30 PM";

  if (windSpeed > 18 || maxRainProb > 60) {
    sprayStatus = "PROHIBITED";
    sprayBadgeText = "Chemical Spray Strictly Prohibited";
    sprayColor = "red";
    sprayIcon = "slash";
    sprayReason = `High hazard conditions: ${windSpeed > 18 ? `Wind speed (${windSpeed} km/h) causes severe off-target chemical drift. ` : ''}${maxRainProb > 60 ? `Heavy rain probability (${maxRainProb}%) will wash away expensive foliar chemicals within hours.` : ''}`;
    sprayBestHours = "Suspend spraying until weather stabilizes (Est. 48 hours post-storm)";
  } else if (windSpeed > 12 || maxRainProb > 35 || maxTemp > 33) {
    sprayStatus = "CAUTION";
    sprayBadgeText = "Caution: Restricted Narrow Spray Window";
    sprayColor = "amber";
    sprayIcon = "alert-triangle";
    sprayReason = `Marginal weather: ${maxTemp > 33 ? 'Afternoon heat exceeds 33°C causing rapid droplet evaporation and leaf phytotoxicity. ' : ''}${windSpeed > 12 ? 'Breezy winds require anti-drift nozzles. ' : ''}${maxRainProb > 35 ? 'Light rain shower possible. ' : ''}`;
    sprayBestHours = "Narrow Window: Early Morning Only (06:00 AM – 08:30 AM)";
  }

  // IRRIGATION GUIDANCE
  let irrigationGuidance = {
    status: "NORMAL_PULSE",
    badge: "Normal Irrigation Pulse",
    color: "emerald",
    advice: "Continue standard drip pulse duration. Ambient soil moisture is adequate."
  };

  if (maxRainProb > 60 && maxRainSum > 10) {
    irrigationGuidance = {
      status: "WITHHOLD_IRRIGATION",
      badge: "Withhold Irrigation (Rain Forecast)",
      color: "blue",
      advice: `Stop drip irrigation for next 36 hours. Natural rainfall (${maxRainSum} mm) will replenish the effective root zone without wasting pumping electricity.`
    };
  } else if (maxTemp > 34) {
    irrigationGuidance = {
      status: "ADVANCE_WATERING",
      badge: "Advance Early Morning Irrigation",
      color: "orange",
      advice: "Increase drip duration by +20% during early morning hours (5:00 AM - 7:30 AM) to counteract extreme afternoon evapotranspiration."
    };
  }

  const spraySafetyObj = {
    status: sprayStatus,
    badgeText: sprayBadgeText,
    statusBadge: sprayBadgeText,
    color: sprayColor,
    icon: sprayIcon,
    reason: sprayReason,
    bestHours: sprayBestHours,
    bestWindow: sprayBestHours,
    rules: {
      tempOk: maxTemp <= 33,
      windOk: windSpeed <= 12,
      rainOk: maxRainProb <= 35
    },
    knapsackRules: [
      "Never spray when wind speed exceeds 12-14 km/h to prevent chemical drift onto non-target crops.",
      "Ensure at least 3-4 hours of rain-free foliage drying time after applying contact fungicides.",
      "Avoid spraying during peak solar hours (11:30 AM – 3:30 PM) when temperatures exceed 33°C to prevent scorch burn.",
      "Always use clean, sediment-free water with neutral pH (6.0 - 7.0) to prevent chemical pesticide degradation."
    ]
  };

  return {
    cropKey: crop,
    phenologicalStage,
    currentTelemetry: {
      temp,
      humidity,
      windSpeed,
      maxTemp,
      minTemp,
      maxRainProb,
      maxRainSum,
      sporeIndex
    },
    compositeRiskScore,
    compositeLevel,
    compositeColor,
    spraySafetyWindow: spraySafetyObj,
    sprayWindow: spraySafetyObj,
    irrigationGuidance,
    hazards,
    topPriorityHazard: hazards.slice().sort((a, b) => b.riskScore - a.riskScore)[0],
    generatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };
}

/**
 * Legacy compatibility wrapper for evaluateWeatherRisks
 */
export function evaluateWeatherRisks(weatherData) {
  const advanced = evaluateAdvancedWeatherRisks(weatherData);
  return advanced.hazards.map(h => ({
    id: h.id,
    title: h.title.toUpperCase(),
    level: h.level,
    color: h.color,
    icon: h.icon,
    mathematicalIndex: parseFloat((h.riskScore / 100).toFixed(2)),
    triggerFormula: h.triggerFormula,
    expectedImpact: h.expectedImpact,
    recommendedAction: h.mitigationAction
  }));
}
