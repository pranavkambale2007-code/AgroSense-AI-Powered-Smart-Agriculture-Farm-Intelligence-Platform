// AgroSense Interactive Farm Notifications & Telemetry Dropdown Component

function renderNotificationsDropdown(state) {
  if (!state.isNotificationsOpen) return '';

  const notifs = state.notifications || [];
  const filter = state.notificationFilter || 'all'; // 'all', 'unread', 'alerts'
  
  const unreadCount = notifs.filter(n => !n.read).length;
  const alertCount = notifs.filter(n => n.type === 'alert' || n.type === 'warning').length;

  const filteredNotifs = notifs.filter(n => {
    if (filter === 'unread') return !n.read;
    if (filter === 'alerts') return n.type === 'alert' || n.type === 'warning';
    return true;
  });

  const getTypeStyle = (type) => {
    switch (type) {
      case 'alert':
        return {
          bg: 'bg-red-500/10 border-red-500/30',
          badge: 'bg-red-500/20 text-red-400 border-red-500/30',
          iconColor: 'text-red-400',
          dot: 'bg-red-500'
        };
      case 'warning':
        return {
          bg: 'bg-amber-500/10 border-amber-500/30',
          badge: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
          iconColor: 'text-amber-400',
          dot: 'bg-amber-500'
        };
      case 'success':
        return {
          bg: 'bg-emerald-500/10 border-emerald-500/30',
          badge: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
          iconColor: 'text-emerald-400',
          dot: 'bg-emerald-500'
        };
      case 'info':
      default:
        return {
          bg: 'bg-teal-500/10 border-teal-500/30',
          badge: 'bg-teal-500/20 text-teal-400 border-teal-500/30',
          iconColor: 'text-teal-400',
          dot: 'bg-teal-500'
        };
    }
  };

  return `
    <div id="notifications-dropdown-menu" class="absolute right-0 top-full mt-2 w-[340px] sm:w-[420px] bg-[#071510] border border-emerald-700/50 rounded-2xl shadow-2xl shadow-black/90 z-50 overflow-hidden backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150">
      
      <!-- Header with "Notifications Received" title and Live status -->
      <div class="p-4 border-b border-emerald-900/60 bg-[#0b1c16]/90 flex items-center justify-between gap-2">
        <div class="flex items-center gap-2.5">
          <div class="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40 relative">
            <i data-lucide="bell" class="w-4 h-4 text-emerald-400"></i>
            <span class="w-2 h-2 rounded-full bg-emerald-400 absolute -top-0.5 -right-0.5"></span>
          </div>
          <div>
            <div class="flex items-center gap-2">
              <h3 class="text-xs font-bold text-white uppercase tracking-wider font-mono">Notifications</h3>
              <span class="px-1.5 py-0.2 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-700/50 text-[9px] font-mono font-bold">UPDATED</span>
            </div>
            <span class="text-[10px] text-gray-400 font-mono">${unreadCount} Unread • ${notifs.length} Total Received</span>
          </div>
        </div>

        <div class="flex items-center gap-1.5">
          <!-- Receive Test Alert Button -->
          <button id="btn-trigger-test-notif" class="px-2 py-1 rounded-lg text-[10px] font-bold bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40 transition cursor-pointer flex items-center gap-1" title="Receive new real-time farm telemetry notification">
            <i data-lucide="radio" class="w-3 h-3 text-amber-400"></i>
            <span>+ Receive Alert</span>
          </button>

          <button id="btn-mark-all-read" class="px-2 py-1 rounded-lg text-[10px] font-bold text-emerald-400 hover:bg-emerald-950 hover:text-emerald-300 border border-emerald-800/40 transition cursor-pointer" title="Mark All as Read">
            Mark all read
          </button>
          <button id="btn-close-notifications" class="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-emerald-900/40 transition cursor-pointer">
            <i data-lucide="x" class="w-4 h-4"></i>
          </button>
        </div>
      </div>

      <!-- Filter Tabs -->
      <div class="px-4 py-2 bg-[#050f0c] border-b border-emerald-950 flex items-center gap-2 text-[11px] font-semibold">
        <button class="notif-filter-btn px-2.5 py-1 rounded-lg transition cursor-pointer ${filter === 'all' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold' : 'text-gray-400 hover:text-white'}" data-filter="all">
          All (${notifs.length})
        </button>
        <button class="notif-filter-btn px-2.5 py-1 rounded-lg transition cursor-pointer ${filter === 'unread' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold' : 'text-gray-400 hover:text-white'}" data-filter="unread">
          Unread (${unreadCount})
        </button>
        <button class="notif-filter-btn px-2.5 py-1 rounded-lg transition cursor-pointer ${filter === 'alerts' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold' : 'text-gray-400 hover:text-white'}" data-filter="alerts">
          Alerts (${alertCount})
        </button>
      </div>

      <!-- Notifications List -->
      <div class="max-h-[380px] overflow-y-auto divide-y divide-emerald-950/60 p-2 space-y-1.5">
        ${filteredNotifs.length === 0 ? `
          <div class="py-8 text-center space-y-2">
            <div class="w-10 h-10 rounded-full bg-emerald-950/40 text-emerald-500 flex items-center justify-center mx-auto border border-emerald-800/30">
              <i data-lucide="check-check" class="w-5 h-5"></i>
            </div>
            <p class="text-xs text-gray-300 font-semibold">All Caught Up!</p>
            <p class="text-[11px] text-gray-500 max-w-xs mx-auto">No notifications found for this filter. All farm telemetry is running nominal.</p>
          </div>
        ` : filteredNotifs.map(n => {
          const style = getTypeStyle(n.type);
          return `
            <div class="p-3 rounded-xl border transition ${style.bg} ${!n.read ? 'ring-1 ring-emerald-500/40' : 'opacity-85 hover:opacity-100'} hover:bg-emerald-950/40 group">
              <div class="flex items-start justify-between gap-2">
                
                <div class="flex items-start gap-2.5 flex-1 min-w-0">
                  <span class="w-2 h-2 rounded-full mt-1.5 shrink-0 ${n.read ? 'bg-transparent border border-gray-600' : style.dot}"></span>
                  
                  <div class="flex-1 min-w-0 space-y-1">
                    <div class="flex items-center gap-1.5 flex-wrap">
                      <span class="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase tracking-wider ${style.badge}">
                        ${n.category || 'TELEMETRY'}
                      </span>
                      <span class="text-[10px] text-emerald-400 font-mono font-bold flex items-center gap-1">
                        <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                        Received: ${n.time}
                      </span>
                    </div>

                    <h4 class="text-xs font-bold text-white leading-tight ${n.read ? 'font-normal text-gray-300' : ''}">
                      ${n.title}
                    </h4>

                    <p class="text-[11px] text-gray-300 leading-relaxed">
                      ${n.message}
                    </p>

                    <div class="pt-1 flex items-center gap-3">
                      ${n.route ? `
                        <a href="#${n.route}" class="btn-notif-route text-[11px] font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 text-decoration-none" data-id="${n.id}">
                          View Details →
                        </a>
                      ` : ''}

                      <button class="btn-toggle-read-notif text-[10px] text-gray-400 hover:text-white transition cursor-pointer" data-id="${n.id}">
                        ${n.read ? 'Mark unread' : 'Mark read'}
                      </button>
                    </div>
                  </div>
                </div>

                <!-- Dismiss Button -->
                <button class="btn-dismiss-notif text-gray-500 hover:text-red-400 p-1 rounded-lg opacity-0 group-hover:opacity-100 transition cursor-pointer" data-id="${n.id}" title="Dismiss">
                  <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                </button>

              </div>
            </div>
          `;
        }).join('')}
      </div>

      <!-- Footer Bar -->
      <div class="p-2.5 bg-[#050f0c] border-t border-emerald-950 flex items-center justify-between text-[10px] font-mono text-gray-400 px-4">
        <span class="flex items-center gap-1.5 text-emerald-400 font-bold">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          ${notifs.length} Notifications Received (Synced)
        </span>
        <button id="btn-clear-all-notifs" class="text-gray-400 hover:text-red-400 transition cursor-pointer">
          Clear all alerts
        </button>
      </div>

    </div>
  `;
}

/* Module Exports */
exports.renderNotificationsDropdown = renderNotificationsDropdown;
