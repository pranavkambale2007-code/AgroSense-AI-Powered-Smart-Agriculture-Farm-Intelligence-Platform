// AgroSense Farm Data Import & Quality Auditor Service

function parseCSVAndAuditQuality(csvString) {
  const lines = csvString.trim().split('\n');
  if (lines.length < 2) {
    return { error: "CSV file is empty or has no header row." };
  }

  const headers = lines[0].split(',').map(h => h.trim().replace(/^["']|["']$/g, ''));
  const rows = [];
  let missingValuesCount = 0;
  let duplicateRowsCount = 0;
  let outlierValuesCount = 0;
  const seenRows = new Set();

  for (let i = 1; i < lines.length; i++) {
    const rawLine = lines[i].trim();
    if (!rawLine) continue;

    if (seenRows.has(rawLine)) {
      duplicateRowsCount++;
    } else {
      seenRows.add(rawLine);
    }

    const values = rawLine.split(',').map(v => v.trim().replace(/^["']|["']$/g, ''));
    const rowObj = {};
    
    headers.forEach((h, idx) => {
      const val = values[idx] !== undefined ? values[idx] : "";
      if (val === "" || val === null || val === undefined || val === "NaN" || val === "null") {
        missingValuesCount++;
        rowObj[h] = null;
      } else {
        const numVal = Number(val);
        if (!isNaN(numVal)) {
          rowObj[h] = numVal;
          // Basic outlier detection rule for typical soil/sensor data
          if (h.toLowerCase().includes('ph') && (numVal < 3 || numVal > 11)) outlierValuesCount++;
          if (h.toLowerCase().includes('nitrogen') && (numVal < 0 || numVal > 1000)) outlierValuesCount++;
        } else {
          rowObj[h] = val;
        }
      }
    });

    rows.push(rowObj);
  }

  const totalCells = rows.length * headers.length;
  const completenessPercentage = totalCells > 0 ? (((totalCells - missingValuesCount) / totalCells) * 100).toFixed(1) : 100;

  return {
    success: true,
    totalRows: rows.length,
    totalColumns: headers.length,
    columns: headers,
    missingValuesCount,
    duplicateRowsCount,
    outlierValuesCount,
    completenessPercentage: Number(completenessPercentage),
    sampleRows: rows.slice(0, 10),
    dataQualityScore: Math.max(40, Math.round(100 - (missingValuesCount * 2) - (duplicateRowsCount * 5) - (outlierValuesCount * 3)))
  };
}

/* Module Exports */
exports.parseCSVAndAuditQuality = parseCSVAndAuditQuality;
