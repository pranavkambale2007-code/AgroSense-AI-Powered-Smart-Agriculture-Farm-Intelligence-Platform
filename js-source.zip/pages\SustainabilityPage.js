// AgroSense Sustainability & Environmental Impact Dashboard Component

function renderSustainabilityPage(state) {
  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="leaf" class="w-6 h-6 text-emerald-400"></i>
            Sustainability & Resource Efficiency Index
          </h1>
          <p class="text-xs text-gray-400">Track groundwater conservation, nitrogen use efficiency (NUE), and carbon sequestration trends</p>
        </div>
        <span class="prototype-badge">SUSTAINABILITY SCORE: 86/100</span>
      </div>

      <!-- Sustainability Metric Cards -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-5">
        <div class="glass-card p-5 space-y-2 border-l-4 border-l-emerald-500">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-gray-400">Water Conservation Index</span>
            <i data-lucide="droplet" class="w-5 h-5 text-blue-400"></i>
          </div>
          <div class="text-2xl font-extrabold text-blue-300 font-mono">+32% Water Efficiency</div>
          <p class="text-xs text-gray-300">Drip pulse scheduling reduced water use by 42,000 Liters compared to flood irrigation.</p>
        </div>

        <div class="glass-card p-5 space-y-2 border-l-4 border-l-amber-500">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-gray-400">Soil Organic Carbon Trend</span>
            <i data-lucide="test-tube" class="w-5 h-5 text-amber-400"></i>
          </div>
          <div class="text-2xl font-extrabold text-amber-300 font-mono">0.58% OC (+0.04%)</div>
          <p class="text-xs text-gray-300">Green manuring and crop residue incorporation improving Vertisol health.</p>
        </div>

        <div class="glass-card p-5 space-y-2 border-l-4 border-l-teal-500">
          <div class="flex items-center justify-between">
            <span class="text-xs font-bold text-gray-400">Carbon Footprint Reduction</span>
            <i data-lucide="shield-check" class="w-5 h-5 text-teal-400"></i>
          </div>
          <div class="text-2xl font-extrabold text-teal-300 font-mono">-18% CO2 Equivalent</div>
          <p class="text-xs text-gray-300">Optimized diesel pump operation and reduced urea volatilization.</p>
        </div>
      </div>

      <!-- AI Sustainability Insights -->
      <div class="p-6 rounded-2xl bg-gradient-to-r from-emerald-950 via-teal-950 to-emerald-900 border border-emerald-500/40 space-y-3">
        <h3 class="text-base font-bold text-white flex items-center gap-2">
          <i data-lucide="sparkles" class="w-5 h-5 text-emerald-400"></i>
          Sustainability Insights:
        </h3>
        <p class="text-xs text-gray-200 leading-relaxed">
          "Your simulated water-use trend decreased compared with the previous period. Maintaining drip irrigation and crop rotation with legumes (e.g. Chickpea) will further enhance soil Nitrogen fixation and lower synthetic fertilizer requirements."
        </p>
      </div>
    </div>
  `;
}

/* Module Exports */
exports.renderSustainabilityPage = renderSustainabilityPage;
