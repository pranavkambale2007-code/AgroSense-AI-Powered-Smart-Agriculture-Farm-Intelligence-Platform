// AgroSense Computer Vision Plant Disease Diagnostics & Farmer Prescription Suite
// Analyzes field leaf photos, extracts visual biomarkers, localizes lesions, and prescribes multi-tiered agronomic solutions

const { renderDiseaseUploader, renderModelStatusBanner } = require('js/components/DiseaseUploader.js');
const { classifyLeafImage,
  analyzeLeafImage,
  getPlantDiseaseById,
  demoLeafSamples,
  getSampleDataUrl,
  getWhyThisHappens,
  healthyCropReferenceModels,
  diseaseVernacularDictionary,
  initDiseaseModel,
  getModelStatus,
  subscribeModelStatus,
  initCropModel,
  getCropModelStatus,
  subscribeCropModelStatus,
  detectCropFromImage } = require('js/services/diseaseService.js');

function renderPlantDiseasePage(state) {
  if (typeof window !== 'undefined') {
    window.__AgroSense_analyzeLeafImage = analyzeLeafImage;
    window.__AgroSense_initDiseaseModel = initDiseaseModel;
    window.__AgroSense_getModelStatus = getModelStatus;
    window.__AgroSense_initCropModel = initCropModel;
    window.__AgroSense_getCropModelStatus = getCropModelStatus;
    window.__AgroSense_detectCropFromImage = detectCropFromImage;
    window.__AgroSense_renderModelStatusBanner = renderModelStatusBanner;
  }
  const diseaseModelStatus = getModelStatus();
  const cropModelStatus = getCropModelStatus();
  const isAwaitingUpload = !state.diseaseImageSrc && (!state.diseaseResult || state.diseaseResult.isInitialPreview);
  const result = state.diseaseResult || classifyLeafImage(null, 'wheat-leaf-rust');
  const currentImage = state.diseaseImageSrc || result.imageSrc || getSampleDataUrl(demoLeafSamples[0].svg);
  const selectedCropHint = state.selectedCropHint || 'all';

  const biomarkers = result.biomarkers || {
    greenPercentage: 48,
    necroticPercentage: 16,
    chlorosisPercentage: 16,
    powderyPercentage: 2,
    rustPercentage: 18
  };

  const isHealthy = result.pathogenType?.toLowerCase().includes('healthy');

  // Severity styling helper
  const getSeverityBadge = (sev) => {
    const s = (sev || '').toLowerCase();
    if (s.includes('none') || s.includes('healthy')) {
      return {
        text: 'Clean (Healthy Tissue)',
        bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
        dot: 'bg-emerald-400'
      };
    }
    if (s.includes('severe') || s.includes('high') || s.includes('critical')) {
      return {
        text: 'Severe Infection (Immediate Action Needed)',
        bg: 'bg-red-500/20 text-red-300 border-red-500/40 animate-pulse',
        dot: 'bg-red-500'
      };
    }
    if (s.includes('moderate')) {
      return {
        text: 'Moderate Infection (Economic Threshold)',
        bg: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
        dot: 'bg-amber-400'
      };
    }
    return {
      text: 'Early / Mild Stage (Preventative Window)',
      bg: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40',
      dot: 'bg-yellow-400'
    };
  };

  const sevBadge = getSeverityBadge(result.severity);

  // Pathogen Category Badge Helper
  const getPathogenBadge = (type) => {
    const t = (type || '').toLowerCase();
    if (t.includes('healthy')) return 'bg-emerald-950/60 text-emerald-300 border-emerald-600/40';
    if (t.includes('rust')) return 'bg-orange-950/60 text-orange-300 border-orange-600/40';
    if (t.includes('mildew') || t.includes('fungal')) return 'bg-purple-950/60 text-purple-300 border-purple-600/40';
    if (t.includes('bacterial')) return 'bg-blue-950/60 text-blue-300 border-blue-600/40';
    if (t.includes('oomycete') || t.includes('blight')) return 'bg-rose-950/60 text-rose-300 border-rose-600/40';
    if (t.includes('virus')) return 'bg-yellow-950/60 text-yellow-300 border-yellow-600/40';
    return 'bg-emerald-950/60 text-emerald-300 border-emerald-600/40';
  };

  const topCandidates = result.topCandidates || [
    { id: result.id, name: result.diseaseName, crop: result.crop, prob: result.confidence || 94.2, category: result.pathogenType, status: "Primary Candidate" }
  ];

  const cropRec = result.cropRecognition || {
    cropKey: result.cropKey || 'tomato',
    cropName: result.crop || 'Tomato',
    confidence: result.confidence || 96.0,
    botanicalClass: 'Dicotyledonae (Solanaceae)',
    leafMorphology: 'Odd-pinnately compound leaf with serrated leaflets',
    marginType: 'Serrated / Dentate lobed margin',
    aspectRatioDescriptor: 'Moderate Ovate (1.3 : 1 to 2.4 : 1)'
  };

  const modelCropRef = healthyCropReferenceModels[cropRec.cropKey] || healthyCropReferenceModels.tomato;

  const healthyBaseline = result.healthyBaseline || {
    cropKey: cropRec.cropKey,
    cropName: cropRec.cropName,
    botanicalClass: cropRec.botanicalClass,
    leafMorphology: cropRec.leafMorphology,
    marginType: cropRec.marginType,
    aspectRatioDescriptor: cropRec.aspectRatioDescriptor,
    svg: modelCropRef.svg,
    realPhotoUrl: modelCropRef.realPhotoUrl || 'images/healthy_crops/tomato_healthy.jpg',
    realPhotoDescription: modelCropRef.realPhotoDescription || 'Natural healthy foliage exhibiting intact cuticular barrier and full chlorophyll density.',
    healthyBiomarkers: modelCropRef.healthyBiomarkers || { green: 96, necrotic: 1, chlorosis: 3, powdery: 0, rust: 0 },
    healthyTraits: modelCropRef.healthyTraits || [
      "Continuous venation with zero necrosis",
      "Rigid structural posture providing optimal solar radiation interception",
      "Intact waxy cuticular barrier preventing spore germ-tube ingress",
      "Zero chlorotic yellow halos or rust pustule eruptions"
    ],
    deviationAnalysis: {
      greenDeficit: Math.max(0, 96 - (biomarkers.greenPercentage || 50)),
      necroticSpread: biomarkers.necroticPercentage || 0,
      chlorosisSpread: biomarkers.chlorosisPercentage || 0,
      powderySpread: biomarkers.powderyPercentage || 0,
      rustSpread: biomarkers.rustPercentage || 0,
      pathogenSpread: (biomarkers.necroticPercentage || 0) + (biomarkers.chlorosisPercentage || 0) + (biomarkers.powderyPercentage || 0) + (biomarkers.rustPercentage || 0),
      healthStatus: isHealthy ? 'Nominal (Healthy Foliage)' : 'Pathological Tissue Loss'
    }
  };

  // Ensure realPhotoUrl is always available
  if (!healthyBaseline.realPhotoUrl && modelCropRef?.realPhotoUrl) {
    healthyBaseline.realPhotoUrl = modelCropRef.realPhotoUrl;
    healthyBaseline.realPhotoDescription = modelCropRef.realPhotoDescription;
  }

  // Representative healthy crop reference models list for comparison gallery
  const healthyCropsList = [
    { key: 'wheat', name: 'Wheat', photo: 'images/healthy_crops/wheat_healthy.jpg', icon: '🌾', desc: 'Vibrant spring-green flag leaf' },
    { key: 'rice', name: 'Paddy / Rice', photo: 'images/healthy_crops/rice_healthy.jpg', icon: '🌾', desc: 'Slender erect silica blade' },
    { key: 'maize', name: 'Maize / Corn', photo: 'images/healthy_crops/maize_healthy.jpg', icon: '🌽', desc: 'Linear blade with ivory midrib' },
    { key: 'sugarcane', name: 'Sugarcane', photo: 'images/healthy_crops/sugarcane_healthy.jpg', icon: '🎋', desc: 'Dense thick erect stalk foliage' },
    { key: 'cotton', name: 'Cotton', photo: 'images/healthy_crops/cotton_healthy.jpg', icon: '☁️', desc: '3-to-5 lobed cordate palmate leaf' },
    { key: 'soybean', name: 'Soybean', photo: 'images/healthy_crops/soybean_healthy.jpg', icon: '🌱', desc: 'Trifoliolate ovate green leaflets' },
    { key: 'mustard', name: 'Mustard', photo: 'images/healthy_crops/mustard_healthy.jpg', icon: '🌼', desc: 'Lyrate-pinnatifid broad foliage' },
    { key: 'chickpea', name: 'Chickpea / Chana', photo: 'images/healthy_crops/chana_healthy.jpg', icon: '🌰', desc: 'Imparipinnate glandular leaflets' },
    { key: 'onion', name: 'Onion', photo: 'images/healthy_crops/onion_healthy.jpg', icon: '🧅', desc: 'Cylindrical hollow succulent blades' },
    { key: 'tomato', name: 'Tomato', photo: 'images/healthy_crops/tomato_healthy.jpg', icon: '🍅', desc: 'Odd-pinnately serrated leaflets' },
    { key: 'potato', name: 'Potato', photo: 'images/healthy_crops/potato_healthy.jpg', icon: '🥔', desc: 'Broad ovate wavy leaflets' },
    { key: 'chilli', name: 'Chilli', photo: 'images/healthy_crops/chilli_healthy.jpg', icon: '🌶️', desc: 'Glossy lanceolate spear blade' },
    { key: 'banana', name: 'Banana', photo: 'images/healthy_crops/banana_healthy.jpg', icon: '🍌', desc: 'Enormous oblong paddle leaf' },
    { key: 'mango', name: 'Mango', photo: 'images/healthy_crops/mango_healthy.jpg', icon: '🥭', desc: 'Leathery lanceolate canopy foliage' },
    { key: 'turmeric', name: 'Turmeric', photo: 'images/healthy_crops/turmeric_healthy.jpg', icon: '🌿', desc: 'Large oblong-elliptic aromatic blade' },
    { key: 'groundnut', name: 'Groundnut', photo: 'images/healthy_crops/groundnut_healthy.jpg', icon: '🥜', desc: 'Clean 4-leaflet tetrafoliolate' }
  ];

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2 printable-disease-report">
      <!-- Title Bar & Model Status -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2.5">
            <i data-lucide="scan-line" class="w-7 h-7 text-emerald-400"></i>
            <span>Computer Vision Plant Pathology & Leaf Disease Diagnostics</span>
          </h1>
          <p class="text-xs text-gray-300 mt-1">
            Real-time foliar biomarker extraction, lesion localization, and multi-tiered chemical, biological & cultural agronomic solutions
          </p>
        </div>

        <div class="flex items-center gap-2.5">
          <button id="btn-print-disease-report" type="button" class="px-3.5 py-1.5 rounded-xl bg-emerald-900/60 hover:bg-emerald-800 text-emerald-200 border border-emerald-500/40 text-xs font-bold font-mono transition flex items-center gap-1.5 cursor-pointer shadow">
            <i data-lucide="printer" class="w-4 h-4"></i>
            <span>Print / Save Prescription</span>
          </button>
          <span class="prototype-badge text-[11px] font-mono">MOBILENET V1 • 38 PLANTVILLAGE CLASSES (14 CROPS)</span>
        </div>
      </div>

      <!-- Expert Advisory & National Helpline Banner -->
      <div class="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 flex flex-wrap items-center justify-between gap-3 text-xs text-amber-200 shadow-lg">
        <div class="flex items-start gap-2.5 max-w-4xl">
          <i data-lucide="shield-alert" class="w-5 h-5 text-amber-400 shrink-0 mt-0.5"></i>
          <div>
            <span class="font-bold text-amber-100">Agricultural Extension & Safety Advisory:</span>
            <span class="text-amber-200/90 ml-1">
              ${result.disclaimer || "AI computer vision screening advisory — cross-verify with your local Krishi Vigyan Kendra (KVK) officer before large-scale chemical pesticide purchase."}
            </span>
          </div>
        </div>
        <div class="flex items-center gap-2 bg-amber-900/50 px-3 py-1.5 rounded-xl border border-amber-500/30 font-mono text-xs">
          <i data-lucide="phone-call" class="w-4 h-4 text-amber-400 animate-pulse"></i>
          <span class="font-bold text-white">Kisan Call Center:</span>
          <a href="tel:18001801551" class="text-amber-300 hover:underline font-extrabold">1800-180-1551</a>
        </div>
      </div>

      <!-- Main Diagnostics Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        <!-- Left Column: Leaf Uploader & Biomarker Breakdown (5 cols) -->
        <div class="lg:col-span-5 space-y-6">
          <!-- Uploader Component -->
          ${renderDiseaseUploader(currentImage, result, selectedCropHint, { disease: diseaseModelStatus, crop: cropModelStatus })}

          <!-- Computer Vision Tissue Biomarker Telemetry Card -->
          <div class="glass-card p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-emerald-950/70 pb-3">
              <div class="flex items-center gap-2">
                <i data-lucide="activity" class="w-4 h-4 text-emerald-400"></i>
                <h4 class="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  Supplementary Foliar Visual Metrics (Color Distribution Only — Non-Diagnostic)
                </h4>
              </div>
              <span class="text-[10px] font-mono text-gray-400">Non-Diagnostic Pixel Scan</span>
            </div>

            <!-- Stacked Color Proportion Bar -->
            <div class="w-full h-3 rounded-full bg-black/60 overflow-hidden flex shadow-inner border border-emerald-950">
              <div class="h-full bg-emerald-500 transition-all duration-500" style="width: ${biomarkers.greenPercentage}%" title="Green Chlorophyll: ${biomarkers.greenPercentage}%"></div>
              <div class="h-full bg-red-700 transition-all duration-500" style="width: ${biomarkers.necroticPercentage}%" title="Necrotic Lesions: ${biomarkers.necroticPercentage}%"></div>
              <div class="h-full bg-amber-400 transition-all duration-500" style="width: ${biomarkers.chlorosisPercentage}%" title="Chlorosis Yellow: ${biomarkers.chlorosisPercentage}%"></div>
              <div class="h-full bg-gray-300 transition-all duration-500" style="width: ${biomarkers.powderyPercentage}%" title="Powdery Mildew: ${biomarkers.powderyPercentage}%"></div>
              <div class="h-full bg-orange-600 transition-all duration-500" style="width: ${biomarkers.rustPercentage}%" title="Rust Spores: ${biomarkers.rustPercentage}%"></div>
            </div>

            <!-- Biomarker Metric Cards -->
            <div class="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs font-mono">
              <div class="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40 space-y-1">
                <div class="flex items-center gap-1.5 text-[11px] text-emerald-300">
                  <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                  <span>Chlorophyll</span>
                </div>
                <div class="text-sm font-extrabold text-white">${biomarkers.greenPercentage}%</div>
                <div class="text-[9px] text-gray-400">Healthy Photosynthetic Tissue</div>
              </div>

              <div class="p-2.5 rounded-xl bg-red-950/30 border border-red-800/40 space-y-1">
                <div class="flex items-center gap-1.5 text-[11px] text-red-300">
                  <span class="w-2 h-2 rounded-full bg-red-500"></span>
                  <span>Necrosis</span>
                </div>
                <div class="text-sm font-extrabold text-white">${biomarkers.necroticPercentage}%</div>
                <div class="text-[9px] text-gray-400">Dead Fungal / Bacterial Cells</div>
              </div>

              <div class="p-2.5 rounded-xl bg-amber-950/30 border border-amber-800/40 space-y-1">
                <div class="flex items-center gap-1.5 text-[11px] text-amber-300">
                  <span class="w-2 h-2 rounded-full bg-amber-400"></span>
                  <span>Chlorosis</span>
                </div>
                <div class="text-sm font-extrabold text-white">${biomarkers.chlorosisPercentage}%</div>
                <div class="text-[9px] text-gray-400">Yellow Halo & Cell Breakdown</div>
              </div>

              <div class="p-2.5 rounded-xl bg-gray-900/60 border border-gray-700/40 space-y-1">
                <div class="flex items-center gap-1.5 text-[11px] text-gray-300">
                  <span class="w-2 h-2 rounded-full bg-gray-300"></span>
                  <span>Mildew / Mycelia</span>
                </div>
                <div class="text-sm font-extrabold text-white">${biomarkers.powderyPercentage}%</div>
                <div class="text-[9px] text-gray-400">White Fungal Epiphytic Coat</div>
              </div>

              <div class="p-2.5 rounded-xl bg-orange-950/30 border border-orange-800/40 space-y-1">
                <div class="flex items-center gap-1.5 text-[11px] text-orange-300">
                  <span class="w-2 h-2 rounded-full bg-orange-500"></span>
                  <span>Rust Pustules</span>
                </div>
                <div class="text-sm font-extrabold text-white">${biomarkers.rustPercentage}%</div>
                <div class="text-[9px] text-gray-400">Urediniospores & Sori</div>
              </div>

              <div class="p-2.5 rounded-xl bg-emerald-950/30 border border-emerald-800/40 space-y-1 flex flex-col justify-between">
                <div class="flex items-center gap-1.5 text-[11px] text-gray-300">
                  <i data-lucide="layers" class="w-3.5 h-3.5 text-emerald-400"></i>
                  <span>Architecture</span>
                </div>
                <div class="text-xs font-bold text-emerald-300">
                  MobileNet V1
                </div>
                <div class="text-[9px] text-gray-400">38-Class LayersModel</div>
              </div>
            </div>
          </div>

          <!-- Real-World Healthy Crops Reference Library (10 Crops Interactive Gallery) -->
          <div class="glass-card p-5 space-y-3 border-l-4 border-l-emerald-500">
            <div class="flex flex-wrap items-center justify-between gap-1 text-xs border-b border-emerald-950 pb-2">
              <span class="text-emerald-300 font-bold font-mono flex items-center gap-1.5">
                <i data-lucide="images" class="w-3.5 h-3.5 text-emerald-400"></i>
                <span>Healthy Crop Reference Library</span>
              </span>
              <span class="text-[10px] font-mono text-gray-400">Tap to inspect baseline</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-2">
              ${healthyCropsList.map(item => {
                const isCurrentCrop = cropRec.cropKey === item.key;
                return `
                  <button type="button" data-healthy-crop="${item.key}" class="healthy-gallery-chip p-2 rounded-xl border text-left transition cursor-pointer flex flex-col items-center gap-1.5 ${
                    isCurrentCrop
                      ? 'bg-emerald-900/90 border-emerald-500 shadow-sm'
                      : 'bg-black/40 border-emerald-900/50 hover:border-emerald-500/60 hover:bg-emerald-950/40'
                  }">
                    <div class="w-12 h-12 rounded-lg overflow-hidden border ${isCurrentCrop ? 'border-emerald-400' : 'border-emerald-800/40'} bg-black">
                      <img src="${item.photo}" alt="${item.name}" class="w-full h-full object-cover" />
                    </div>
                    <span class="text-[10px] font-bold font-mono text-center truncate w-full ${isCurrentCrop ? 'text-emerald-300 font-extrabold' : 'text-gray-300'}">
                      ${item.icon} ${item.name}
                    </span>
                  </button>
                `;
              }).join('')}
            </div>
          </div>

          <!-- Why This Disease Happens in Crops (Etiology, Weather Triggers & Disease Transmission) Card -->
          <div class="glass-card p-5 space-y-4 border-l-4 border-l-amber-500">
            <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950 pb-3">
              <div class="flex items-center gap-2.5">
                <div class="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                  <i data-lucide="microscope" class="w-4 h-4"></i>
                </div>
                <div>
                  <h3 class="text-xs font-black text-white uppercase tracking-wider font-mono">
                    Why This Disease Happens (Etiology)
                  </h3>
                  <p class="text-[10px] text-gray-400">Pathogen sources, microclimate triggers & vectors</p>
                </div>
              </div>
              <span class="px-2 py-0.5 rounded-lg bg-amber-500/15 text-amber-300 border border-amber-500/30 text-[9px] font-mono font-bold">
                PATHOLOGY ETIOLOGY
              </span>
            </div>

            <div class="space-y-3 text-xs">
              <!-- Pathogen Causal Biology -->
              <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-1.5">
                <div class="flex items-center gap-2 text-amber-300 font-bold font-mono text-xs">
                  <i data-lucide="dna" class="w-3.5 h-3.5 text-amber-400"></i>
                  <span>1. Causal Pathogen Biology:</span>
                </div>
                <p class="text-gray-300 leading-relaxed text-xs">
                  ${result.whyThisHappens?.pathogenCause || "Pathogen spores survive in soil debris, volunteer weeds, or infected seeds and germinate under favorable microclimates."}
                </p>
              </div>

              <!-- Weather & Microclimate Triggers -->
              <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-1.5">
                <div class="flex items-center gap-2 text-blue-300 font-bold font-mono text-xs">
                  <i data-lucide="cloud-rain" class="w-3.5 h-3.5 text-blue-400"></i>
                  <span>2. Weather & Environmental Triggers:</span>
                </div>
                <div class="space-y-1 text-gray-300 text-xs">
                  <div class="flex items-center gap-2">
                    <span class="text-white font-mono font-bold w-16">🌡️ Temp:</span>
                    <span>${result.whyThisHappens?.weatherTriggers?.temperature || "18°C - 30°C"}</span>
                  </div>
                  <div class="flex items-center gap-2">
                    <span class="text-white font-mono font-bold w-16">💧 Humidity:</span>
                    <span>${result.whyThisHappens?.weatherTriggers?.humidity || "High relative humidity >80%"}</span>
                  </div>
                  <div class="flex items-center gap-2">
                    <span class="text-white font-mono font-bold w-16">⏱️ Wetness:</span>
                    <span>${result.whyThisHappens?.weatherTriggers?.leafWetness || "Continuous moisture on leaves >4 hours"}</span>
                  </div>
                </div>
              </div>

              <!-- How It Spreads / Transmission -->
              <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-1.5">
                <div class="flex items-center gap-2 text-purple-300 font-bold font-mono text-xs">
                  <i data-lucide="wind" class="w-3.5 h-3.5 text-purple-400"></i>
                  <span>3. Transmission & Spread Mode:</span>
                </div>
                <p class="text-gray-300 leading-relaxed text-xs">
                  ${result.whyThisHappens?.transmissionMode || "Spreads via rain splash from soil onto lower foliage, wind currents, and mechanical tools."}
                </p>
              </div>

              <!-- Predisposing Agronomic Risks -->
              <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-1.5">
                <div class="flex items-center gap-2 text-rose-300 font-bold font-mono text-xs">
                  <i data-lucide="alert-triangle" class="w-3.5 h-3.5 text-rose-400"></i>
                  <span>4. Agronomic Risk Factors:</span>
                </div>
                <ul class="space-y-1 text-gray-300 text-xs list-disc list-inside">
                  ${(Array.isArray(result.whyThisHappens?.riskFactors)
                    ? result.whyThisHappens.riskFactors
                    : (typeof result.whyThisHappens?.riskFactors === 'string'
                        ? [result.whyThisHappens.riskFactors]
                        : [
                            "Overhead sprinkler irrigation causing prolonged foliar moisture.",
                            "Excess chemical nitrogen application producing soft succulent leaves.",
                            "Dense crop spacing restricting ventilation."
                          ])
                  ).map(rf => `<li><span class="text-gray-200">${rf}</span></li>`).join('')}
                </ul>
              </div>
            </div>
          </div>
        </div>

        <!-- Right Column: AI Vision Pathology Diagnosis & Comprehensive Solutions (7 cols) -->
        <div class="lg:col-span-7 space-y-6">

        ${result.isScanning === true ? `
          <!-- Scanning In Progress Indicator Card (Prevents Stale Results) -->
          <div class="glass-card p-8 border-l-4 border-l-emerald-500 space-y-6 shadow-2xl text-center">
            <div class="inline-flex p-4 rounded-3xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 relative">
              <div class="w-12 h-12 border-4 border-emerald-400 border-t-transparent rounded-full animate-spin"></div>
              <i data-lucide="scan-line" class="w-6 h-6 absolute inset-0 m-auto text-emerald-400 animate-pulse"></i>
            </div>
            <div class="space-y-2">
              <span class="text-xs font-mono font-bold uppercase tracking-widest text-emerald-400">Computer Vision Analysis in Progress</span>
              <h3 class="text-xl font-black text-white">Scanning Foliar Pathology & Crop Biomarkers</h3>
              <p class="text-xs text-gray-300 max-w-md mx-auto">
                Running 2-stage neural inference with MobileNet V1 botanical feature extractor and 38-class PlantVillage diagnostic head.
              </p>
            </div>
            <div class="w-48 h-1.5 bg-emerald-950 rounded-full mx-auto overflow-hidden">
              <div class="w-full h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-emerald-500 rounded-full animate-pulse"></div>
            </div>
          </div>
        ` : result.isValidImage === false ? `
          <!-- Image Quality Pre-Screening Rejection / Troubleshooting Card -->
          <div class="glass-card p-6 border-l-4 border-l-amber-500 space-y-5 shadow-2xl">
            <div class="flex items-center gap-3 border-b border-emerald-950 pb-4">
              <div class="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                <i data-lucide="alert-triangle" class="w-6 h-6"></i>
              </div>
              <div>
                <span class="text-[10px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                  Image Quality Pre-Screening Rejected
                </span>
                <h3 class="text-xl font-black text-white">
                  ${result.errorType === 'blank' ? 'Blank / Uniform Image Detected' :
                    result.errorType === 'dark' ? 'Severely Underexposed Image' :
                    result.errorType === 'overexposed' ? 'Severely Overexposed Image' :
                    result.errorType === 'blur' ? 'Image Out of Focus / Blurred' :
                    result.errorType === 'non-plant' ? 'Non-Plant Object Detected' :
                    result.errorType === 'unsupported-crop' ? 'Unsupported Crop Species' :
                    result.errorType === 'file-protocol' ? 'Local Web Server Required for AI Detection' :
                    result.errorType === 'initialization-error' ? 'Model Initialization Failure' :
                    result.errorType === 'uncertain-crop' ? 'Uncertain Crop Identification' :
                    'Specimen Quality Advisory'}
                </h3>
              </div>
            </div>

            <div class="p-4 rounded-xl bg-amber-950/30 border border-amber-500/40 text-amber-200 text-xs leading-relaxed space-y-2">
              <p class="font-bold text-amber-100">${result.validationError || 'The uploaded specimen does not meet computer vision quality standards.'}</p>
              <p class="text-gray-300 text-[11px]">
                To prevent false pathogen diagnoses, AgroSense AI enforces strict pre-inference validation that rejects blank images, non-plant objects, and blurred frames before disease analysis.
              </p>
            </div>

            <div class="space-y-3">
              <h4 class="text-xs font-bold text-gray-200 font-mono uppercase tracking-wider">
                Photo Guidelines for Agricultural Field Diagnostics:
              </h4>
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-1">
                  <div class="text-emerald-400 font-bold font-mono">1. Macro Leaf Focus</div>
                  <p class="text-[11px] text-gray-300">Fill at least 50% of the frame with the crop leaf blade showing veins and lesions clearly.</p>
                </div>
                <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-1">
                  <div class="text-emerald-400 font-bold font-mono">2. Natural Lighting</div>
                  <p class="text-[11px] text-gray-300">Shoot in clear daylight; avoid harsh flashlight glare or deep dark shadows.</p>
                </div>
                <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-1">
                  <div class="text-emerald-400 font-bold font-mono">3. Single Specimen</div>
                  <p class="text-[11px] text-gray-300">Photograph a single representative diseased leaf against a neutral background.</p>
                </div>
              </div>
            </div>

            <div class="flex items-center gap-3 pt-2">
              <button type="button" onclick="document.getElementById('leaf-file-input').click()" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold font-mono transition flex items-center gap-2 cursor-pointer shadow-lg">
                <i data-lucide="upload" class="w-4 h-4"></i>
                <span>Upload Another Photo</span>
              </button>
            </div>
          </div>
        ` : `
          <!-- STAGE 1: CROP SPECIES IDENTIFICATION & HEALTHY BASELINE COMPARISON CARD -->
          <div class="glass-card p-5 space-y-4 border-l-4 border-l-emerald-500 shadow-xl">
            <!-- Header: Stage 1 Pipeline Indicator -->
            <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950 pb-3">
              <div class="flex items-center gap-2.5">
                <div class="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center justify-center font-bold font-mono text-sm shadow">
                  1
                </div>
                <div>
                  <div class="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold">
                    Stage 1 • Foliar Morphology & Crop Species Recognition & Baseline Match
                  </div>
                  <h3 class="text-lg font-black text-white flex items-center gap-2">
                    <span>Crop Recognized:</span>
                    ${isAwaitingUpload ? `
                      <span class="text-amber-300 font-bold">Target crop not detected yet</span>
                    ` : `
                      <span class="text-emerald-300 underline decoration-emerald-500 underline-offset-4">${cropRec.cropName}</span>
                    `}
                  </h3>
                </div>
              </div>
              <div class="flex items-center gap-2">
                ${isAwaitingUpload ? `
                  <span class="px-3 py-1 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm flex items-center gap-1.5">
                    <i data-lucide="scan" class="w-4 h-4 text-amber-400"></i>
                    <span>Awaiting Leaf Upload</span>
                  </span>
                ` : `
                  <span class="px-3 py-1 rounded-full text-xs font-mono font-black ${cropRec.isReliable !== false ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border-amber-500/40'} border shadow-sm flex items-center gap-1.5">
                    <i data-lucide="${cropRec.isReliable !== false ? 'check-circle-2' : 'alert-circle'}" class="w-4 h-4 ${cropRec.isReliable !== false ? 'text-emerald-400' : 'text-amber-400'}"></i>
                    <span>${cropRec.confidence}% Match (${cropRec.isReliable !== false ? 'Verified' : 'Ambiguous'})</span>
                  </span>
                `}
              </div>
            </div>

            <!-- Stage 1 Ambiguity Resolution Banner (Shown when confidence < 65% or ambiguity detected) -->
            ${cropRec.isAmbiguous && !state.isUserExplicitCrop ? `
              <div class="p-3.5 rounded-xl bg-amber-950/40 border border-amber-500/50 space-y-2 text-xs shadow-md">
                <div class="flex items-center gap-2 text-amber-300 font-bold font-mono">
                  <i data-lucide="help-circle" class="w-4 h-4 text-amber-400 shrink-0"></i>
                  <span>Stage 1 Crop Ambiguity: Multiple species match foliar morphology. Confirm your crop:</span>
                </div>
                <div class="flex flex-wrap gap-2 pt-1">
                  ${(cropRec.topAlternatives || []).map(alt => `
                    <button type="button" data-crop="${alt.cropKey}" class="crop-switch-chip px-3 py-1.5 rounded-xl bg-emerald-900/70 hover:bg-emerald-800 text-emerald-200 border border-emerald-500/50 text-xs font-bold font-mono transition flex items-center gap-1.5 cursor-pointer shadow">
                      <span>${alt.cropName}</span>
                      <span class="text-[10px] text-emerald-300 font-mono">(${alt.confidence}%)</span>
                    </button>
                  `).join('')}
                </div>
              </div>
            ` : ''}

            <!-- Botanical Evidence Chips -->
            <div class="flex flex-wrap items-center gap-1.5 pt-1">
              <span class="text-[10px] font-mono font-bold text-gray-400 mr-1">Botanical Evidence:</span>
              ${(cropRec.evidenceTags || [cropRec.botanicalClass, cropRec.leafMorphology]).map(tag => `
                <span class="px-2 py-0.5 rounded-md text-[10px] font-mono font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-700/50">
                  ${tag}
                </span>
              `).join('')}
            </div>

            <!-- Side-by-Side Visual Leaf Baseline Comparison (Real Healthy Photo vs Diseased Specimen) -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-stretch">
              <!-- Left Panel: Real-World Healthy Crop Reference Photo -->
              <div class="p-4 rounded-2xl bg-black/40 border border-emerald-900/60 space-y-3 flex flex-col justify-between">
                <div>
                  <div class="flex items-center justify-between mb-2">
                    <span class="text-xs font-bold font-mono text-emerald-400 flex items-center gap-1.5">
                      <i data-lucide="shield-check" class="w-4 h-4 text-emerald-400"></i>
                      <span>Real-World Healthy Crop Reference</span>
                    </span>
                    <!-- View Mode Toggle: Real Photo vs Botanical Anatomy -->
                    <div class="inline-flex rounded-lg p-0.5 bg-emerald-950 border border-emerald-800/60 text-[10px] font-mono">
                      <button type="button" id="btn-show-healthy-photo" class="healthy-tab-btn active px-2.5 py-0.5 rounded font-bold bg-emerald-500 text-slate-950 transition cursor-pointer">
                        📷 Real Photo
                      </button>
                      <button type="button" id="btn-show-healthy-svg" class="healthy-tab-btn px-2.5 py-0.5 rounded font-bold text-emerald-300 hover:text-white transition cursor-pointer">
                        📐 Anatomy
                      </button>
                    </div>
                  </div>

                  <!-- Real-World Healthy Photograph Container -->
                  <div id="healthy-photo-container" class="relative w-full h-48 sm:h-52 rounded-xl overflow-hidden border border-emerald-500/50 bg-black/60 shadow-lg group">
                    <img src="${healthyBaseline.realPhotoUrl || 'images/healthy_crops/tomato_healthy.jpg'}" alt="Healthy ${cropRec.cropName} Leaf" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105 select-none" />
                    <div class="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-mono font-black bg-emerald-950/90 text-emerald-300 border border-emerald-500/60 shadow flex items-center gap-1.5 backdrop-blur">
                      <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span>REAL HEALTHY CROP PHOTO</span>
                    </div>
                    <div class="absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-black/80 text-emerald-400 border border-emerald-800/60 backdrop-blur">
                      100% Disease-Free
                    </div>
                    <div class="absolute bottom-0 inset-x-0 p-2.5 bg-gradient-to-t from-black via-black/85 to-transparent text-[10px] text-emerald-200/90 font-mono line-clamp-2">
                      ${healthyBaseline.realPhotoDescription || 'Natural open-field macro photo of healthy, disease-free foliage displaying optimal chlorophyll pigmentation, intact cuticular sheen, and undamaged cell walls.'}
                    </div>
                  </div>

                  <!-- Botanical SVG Anatomy Container (Hidden by default, toggled via button) -->
                  <div id="healthy-svg-container" class="hidden relative w-full h-48 sm:h-52 rounded-xl overflow-hidden border border-emerald-900/60 bg-gradient-to-b from-emerald-950/40 to-black/70 p-2 flex items-center justify-center">
                    <div class="w-32 h-32 flex items-center justify-center">
                      ${healthyBaseline.svg || '<i data-lucide="leaf" class="w-16 h-16 text-emerald-500/50"></i>'}
                    </div>
                    <div class="absolute top-2 left-2 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950/90 text-emerald-300 border border-emerald-500/50">
                      BOTANICAL MORPHOLOGY SCHEMATIC
                    </div>
                  </div>

                  <!-- Botanical Traits Checklist -->
                  <div class="mt-3 space-y-1.5 text-[11px] text-gray-300">
                    <div class="flex items-center justify-between text-xs font-mono py-0.5 border-b border-emerald-950/60">
                      <span class="text-gray-400">Foliar Geometry:</span>
                      <span class="text-emerald-300 font-bold">${healthyBaseline.aspectRatioDescriptor || 'Botanical Standard'}</span>
                    </div>
                    <div class="flex items-center justify-between text-xs font-mono py-0.5 border-b border-emerald-950/60">
                      <span class="text-gray-400">Margin Anatomy:</span>
                      <span class="text-emerald-300 font-bold">${healthyBaseline.marginType || 'Standard Edge'}</span>
                    </div>
                    <div class="flex items-center justify-between text-xs font-mono py-0.5">
                      <span class="text-gray-400">Baseline Chlorophyll:</span>
                      <span class="text-emerald-400 font-extrabold">${healthyBaseline.healthyBiomarkers?.green || 96}% (Optimal Range)</span>
                    </div>
                  </div>
                </div>

                <!-- Healthy Baseline Signature Badge -->
                <div class="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-800/40 text-[10px] text-emerald-200/90 leading-relaxed font-mono flex items-center gap-1.5">
                  <i data-lucide="info" class="w-3.5 h-3.5 text-emerald-400 shrink-0"></i>
                  <span>Botanical standard for ${cropRec.cropName.split('(')[0].trim()}. Stage 2 pathology is screened strictly within this crop species.</span>
                </div>
              </div>

              <!-- Right Panel: Uploaded Leaf Specimen & Side-by-Side Baseline Deviation -->
              <div class="p-4 rounded-2xl bg-black/40 border ${isHealthy ? 'border-emerald-800/60' : 'border-amber-900/60'} space-y-3 flex flex-col justify-between">
                <div>
                  <div class="flex items-center justify-between mb-2">
                    <span class="text-xs font-bold font-mono ${isHealthy ? 'text-emerald-400' : 'text-amber-400'} flex items-center gap-1.5">
                      <i data-lucide="scan" class="w-4 h-4"></i>
                      <span>Uploaded Specimen Under Test</span>
                    </span>
                    <span class="text-[10px] font-mono px-2 py-0.5 rounded ${isHealthy ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60' : 'bg-red-950 text-rose-300 border border-red-800/60'}">
                      ${healthyBaseline.deviationAnalysis?.healthStatus || 'Deviation Detected'}
                    </span>
                  </div>

                  <!-- Uploaded Specimen Photo Container (Matching Height for Perfect Visual Comparison) -->
                  <div class="relative w-full h-48 sm:h-52 rounded-xl overflow-hidden border ${isAwaitingUpload ? 'border-emerald-600/50' : isHealthy ? 'border-emerald-500/50' : 'border-amber-500/50'} bg-black flex items-center justify-center shadow-lg group">
                    <img src="${currentImage}" alt="Uploaded Leaf Specimen" class="max-h-full max-w-full object-contain select-none" />
                    <div class="absolute top-2 left-2 px-2.5 py-1 rounded-lg text-[10px] font-mono font-black ${isAwaitingUpload ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-500/60' : isHealthy ? 'bg-emerald-950/90 text-emerald-300 border border-emerald-500/60' : 'bg-red-950/90 text-rose-300 border border-red-500/60'} shadow flex items-center gap-1.5 backdrop-blur">
                      <span class="w-2 h-2 rounded-full ${isAwaitingUpload ? 'bg-emerald-400' : isHealthy ? 'bg-emerald-400' : 'bg-red-500'}"></span>
                      <span>${isAwaitingUpload ? 'SPECIMEN: READY TO SCAN' : isHealthy ? 'SPECIMEN: HEALTHY' : `DISEASE: ${(result.commonName || result.diseaseName.split('(')[0]).trim().toUpperCase()}`}</span>
                    </div>
                    <div class="absolute top-2 right-2 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-black/80 text-gray-300 border border-gray-700/60 backdrop-blur">
                      ${isAwaitingUpload ? 'Ready to Scan' : `${result.confidence}% Match`}
                    </div>
                    ${isAwaitingUpload ? `
                      <div class="absolute bottom-0 inset-x-0 p-2.5 bg-gradient-to-t from-black via-black/85 to-transparent text-[10px] text-amber-200/90 font-mono">
                        <span>Upload a leaf photo or select a sample above to perform real-time disease screening.</span>
                      </div>
                    ` : !isHealthy ? `
                      <div class="absolute bottom-0 inset-x-0 p-2.5 bg-gradient-to-t from-black via-black/85 to-transparent text-[10px] text-rose-200 font-mono flex flex-col justify-between">
                        <div class="flex items-center justify-between">
                          <span>Pathological Loss: <strong>${healthyBaseline.deviationAnalysis?.pathogenSpread || biomarkers.necroticPercentage + biomarkers.chlorosisPercentage}%</strong> tissue destruction</span>
                          <span class="text-amber-300 font-bold">${result.commonName || result.diseaseName.split('(')[0].trim()}</span>
                        </div>
                        ${result.vernacularName ? `<div class="text-[9px] text-emerald-300 font-sans truncate">${result.vernacularName}</div>` : ''}
                      </div>
                    ` : `
                      <div class="absolute bottom-0 inset-x-0 p-2.5 bg-gradient-to-t from-black via-black/85 to-transparent text-[10px] text-emerald-200 font-mono">
                        <span>Foliar Conformance: <strong>98.5%</strong> match with healthy reference photo</span>
                      </div>
                    `}
                  </div>

                  <!-- Comparative Foliar Biomarker Deviation Gauges -->
                  <div class="space-y-2.5 pt-3">
                    <!-- Photosynthetic Green Chlorophyll Deficit -->
                    <div>
                      <div class="flex justify-between text-[11px] font-mono mb-1">
                        <span class="text-gray-300">Photosynthetic Green Tissue:</span>
                        <span class="font-bold ${biomarkers.greenPercentage >= 80 ? 'text-emerald-400' : 'text-amber-400'}">
                          ${biomarkers.greenPercentage}% (Healthy Reference: ${healthyBaseline.healthyBiomarkers?.green || 96}%)
                        </span>
                      </div>
                      <div class="w-full h-2 rounded-full bg-gray-900 overflow-hidden flex">
                        <div class="h-full bg-emerald-500 rounded-full" style="width: ${biomarkers.greenPercentage}%"></div>
                      </div>
                      ${healthyBaseline.deviationAnalysis?.greenDeficit > 5 ? `
                        <div class="text-[10px] text-amber-300/90 font-mono mt-0.5">
                          ⚠ -${healthyBaseline.deviationAnalysis.greenDeficit}% Chlorophyll Deficit vs Healthy Reference Photo
                        </div>
                      ` : ''}
                    </div>

                    <!-- Necrotic Lesion Tissue Destruction -->
                    <div>
                      <div class="flex justify-between text-[11px] font-mono mb-1">
                        <span class="text-gray-300">Necrotic Lesion Spread:</span>
                        <span class="font-bold ${biomarkers.necroticPercentage > 5 ? 'text-red-400' : 'text-emerald-400'}">
                          ${biomarkers.necroticPercentage}% (Healthy Reference: &lt;2%)
                        </span>
                      </div>
                      <div class="w-full h-2 rounded-full bg-gray-900 overflow-hidden flex">
                        <div class="h-full bg-red-600 rounded-full" style="width: ${Math.min(100, biomarkers.necroticPercentage * 2.5)}%"></div>
                      </div>
                    </div>

                    <!-- Chlorosis Yellowing Breakdown -->
                    <div>
                      <div class="flex justify-between text-[11px] font-mono mb-1">
                        <span class="text-gray-300">Chlorotic Yellow Breakdown:</span>
                        <span class="font-bold ${biomarkers.chlorosisPercentage > 8 ? 'text-amber-400' : 'text-emerald-400'}">
                          ${biomarkers.chlorosisPercentage}% (Healthy Reference: &lt;4%)
                        </span>
                      </div>
                      <div class="w-full h-2 rounded-full bg-gray-900 overflow-hidden flex">
                        <div class="h-full bg-amber-400 rounded-full" style="width: ${Math.min(100, biomarkers.chlorosisPercentage * 2.5)}%"></div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Comparative Diagnostic Conclusion -->
                <div class="p-2.5 rounded-xl ${isHealthy ? 'bg-emerald-950/60 border border-emerald-800/40 text-emerald-200' : 'bg-red-950/40 border border-red-800/40 text-rose-200'} text-[11px] font-mono leading-relaxed">
                  ${isHealthy ? `
                    <div class="flex items-center gap-1.5 font-bold text-emerald-300">
                      <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-400 shrink-0"></i>
                      <span>Healthy Conformance: Leaf matches healthy ${cropRec.cropName.split('(')[0].trim()} foliage (98.5% visual & biomarker conformance).</span>
                    </div>
                  ` : `
                    <div class="flex items-start gap-1.5">
                      <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-400 shrink-0 mt-0.5"></i>
                      <span><strong>Deviation Confirmed:</strong> Specimen exhibits ${healthyBaseline.deviationAnalysis?.pathogenSpread || biomarkers.necroticPercentage + biomarkers.chlorosisPercentage}% foliar tissue damage compared to real healthy crop photo. Diagnosing strictly within <strong>${cropRec.cropName.split('(')[0].trim()}</strong> database below.</span>
                    </div>
                  `}
                </div>
              </div>
            </div>

          </div>

          <!-- Stage 2 Pathology Diagnostic Header Card -->
          <div class="glass-card-accent p-6 space-y-5 border-l-4 ${isAwaitingUpload ? 'border-l-emerald-500' : isHealthy ? 'border-l-emerald-500' : 'border-l-red-500'}">
            
            ${isAwaitingUpload ? `
              <!-- Awaiting Upload Standby Header -->
              <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-900/60 pb-4">
                <div class="space-y-1">
                  <div class="flex flex-wrap items-center gap-2 mb-1">
                    <span class="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
                      Stage 2 AI Pathology Engine
                    </span>
                    <span class="text-gray-400 text-xs">•</span>
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950/60 text-emerald-300 border border-emerald-600/40">
                      PlantVillage MobileNet V1 (38 Classes)
                    </span>
                  </div>
                  
                  <h2 class="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
                    <i data-lucide="sparkles" class="w-6 h-6 text-emerald-400"></i>
                    <span>Ready for Foliar Disease Screening</span>
                  </h2>
                  <p class="text-xs text-gray-300">
                    Upload a leaf photo from your phone or select a curated sample on the left to run AI diagnosis.
                  </p>
                </div>

                <div class="text-right">
                  <div class="text-2xl sm:text-3xl font-black font-mono text-emerald-400">
                    ONLINE
                  </div>
                  <div class="text-[10px] font-mono text-gray-400 uppercase tracking-widest">
                    Inference Engine Ready
                  </div>
                </div>
              </div>

              <!-- Ready Steps Guide -->
              <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-1">
                <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-1">
                  <div class="text-emerald-400 font-bold font-mono">1. Auto Crop Recognition</div>
                  <p class="text-[11px] text-gray-300">Classifies 14 major agricultural crop species from leaf venation and morphology.</p>
                </div>
                <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-1">
                  <div class="text-emerald-400 font-bold font-mono">2. 38-Class PlantVillage Deep Learning</div>
                  <p class="text-[11px] text-gray-300">Screens for bacterial, fungal, oomycete, and viral pathogens with genuine softmax probabilities.</p>
                </div>
                <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 space-y-1">
                  <div class="text-emerald-400 font-bold font-mono">3. Actionable Agronomic Solutions</div>
                  <p class="text-[11px] text-gray-300">Generates chemical dosages, biological antagonists, cultural measures, and KVK helpline.</p>
                </div>
              </div>
            ` : `
            <!-- Crop & Match Score Header with High-Clarity Disease Names -->
            <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-900/60 pb-4">
              <div class="space-y-1">
                <div class="flex flex-wrap items-center gap-2 mb-1">
                  <span class="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wider">
                    ${result.crop || "Target Crop"}
                  </span>
                  <span class="text-gray-400 text-xs">•</span>
                  <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${getPathogenBadge(result.pathogenType)}">
                    ${result.pathogenType || "Pathogen"}
                  </span>
                  ${result.scientificName ? `
                    <span class="text-gray-400 text-xs">•</span>
                    <span class="px-2 py-0.5 rounded text-[11px] font-mono italic text-emerald-300 bg-emerald-950/60 border border-emerald-800/50">
                      ${result.scientificName}
                    </span>
                  ` : ''}
                </div>
                
                <!-- Primary Disease Name (English Common Name) -->
                <h2 class="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
                  <i data-lucide="alert-octagon" class="w-6 h-6 text-red-400 ${isHealthy ? 'hidden' : ''}"></i>
                  <span>${result.commonName || result.diseaseName}</span>
                </h2>

                <!-- Regional Multi-lingual Vernacular Name (Hindi & Marathi) -->
                ${result.vernacularName ? `
                  <div class="text-sm sm:text-base font-bold text-amber-300 flex items-center gap-2 pt-0.5">
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                      Regional Name
                    </span>
                    <span>${result.vernacularName}</span>
                  </div>
                ` : ''}
              </div>

              <div class="text-right">
                <div class="text-2xl sm:text-3xl font-black font-mono text-emerald-400">
                  ${result.confidence}%
                </div>
                <div class="text-[10px] font-mono text-gray-400 uppercase tracking-widest">
                  Diagnostic Confidence
                </div>
              </div>
            </div>

            <!-- Severity & Infection Level Badge -->
            <div class="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-black/40 border border-emerald-950">
              <div class="flex items-center gap-2">
                <span class="text-xs font-bold text-gray-300">Pathological Severity:</span>
                <span class="px-3 py-1 rounded-full text-xs font-extrabold border flex items-center gap-2 ${sevBadge.bg}">
                  <span class="w-2 h-2 rounded-full ${sevBadge.dot}"></span>
                  <span>${sevBadge.text}</span>
                </span>
              </div>
              <div class="text-xs text-gray-400 font-mono">
                Screening: <span class="text-emerald-300 font-bold">${result.screeningMode || 'AgroSense CV V2.5'}</span>
              </div>
            </div>
            `}

            <!-- Analyzed File Metadata Indicator -->
            ${state.diseaseFileName ? `
              <div class="flex items-center justify-between gap-2 p-2.5 rounded-xl bg-black/50 border border-emerald-900/60 text-xs font-mono">
                <div class="flex items-center gap-2 text-gray-300 truncate">
                  <i data-lucide="file-image" class="w-4 h-4 text-emerald-400 shrink-0"></i>
                  <span class="text-gray-400">Source Photo:</span>
                  <span class="text-emerald-300 font-bold truncate max-w-[260px] sm:max-w-xs">${state.diseaseFileName}</span>
                </div>
                ${result.metadataEnhanced ? `
                  <span class="shrink-0 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                    <i data-lucide="check-circle-2" class="w-3 h-3 text-emerald-400"></i>
                    <span>Verified Label Match</span>
                  </span>
                ` : `
                  <span class="shrink-0 px-2 py-0.5 rounded text-[10px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/40">
                    CV Matrix Tested
                  </span>
                `}
              </div>
            ` : ''}

            <!-- Real-Time Model & Inference Diagnostic Telemetry (Phase 1 Requirement) -->
            ${result.cropRecognition?.diagnosticTelemetry ? `
              <div class="p-3.5 rounded-xl bg-black/70 border border-emerald-500/40 space-y-2.5 text-xs font-mono">
                <div class="flex items-center justify-between border-b border-emerald-950/80 pb-2">
                  <span class="text-emerald-400 font-bold flex items-center gap-1.5 uppercase text-[11px] tracking-wider">
                    <i data-lucide="cpu" class="w-4 h-4 text-emerald-400"></i>
                    <span>Inference Pipeline Diagnostic Trace (Stage A & B)</span>
                  </span>
                  <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-600/50">
                    ${result.cropRecognition.diagnosticTelemetry.modelVersion}
                  </span>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span class="text-gray-400 block text-[10px]">Model Architecture / Engine:</span>
                    <span class="text-white font-bold">${result.cropRecognition.diagnosticTelemetry.modelIdentifier}</span>
                  </div>
                  <div>
                    <span class="text-gray-400 block text-[10px]">Input Tensor / Grid:</span>
                    <span class="text-emerald-300 font-bold">${result.cropRecognition.diagnosticTelemetry.inputDimensions}</span>
                  </div>
                  <div>
                    <span class="text-gray-400 block text-[10px]">Preprocessing Pipeline:</span>
                    <span class="text-gray-200">${result.cropRecognition.diagnosticTelemetry.preprocessing}</span>
                  </div>
                  <div>
                    <span class="text-gray-400 block text-[10px]">Crop Species Library:</span>
                    <span class="text-emerald-300 font-bold">${result.cropRecognition.diagnosticTelemetry.supportedCropClasses}</span>
                  </div>
                </div>

                <!-- Top-5 Crop Species Scoring Matrix -->
                <div class="pt-1.5 border-t border-emerald-950/70">
                  <div class="flex items-center justify-between text-[10px] text-gray-400 mb-1">
                    <span>Top-5 Crop Model Logit Distribution:</span>
                    <span>Demo Fallback: <strong class="text-emerald-400 font-mono">NO (Active Live Inference)</strong></span>
                  </div>
                  <div class="space-y-1">
                    ${result.cropRecognition.diagnosticTelemetry.topFivePredictions.map((pred, pIdx) => `
                      <div class="flex items-center justify-between p-1.5 rounded bg-emerald-950/40 border border-emerald-900/40 text-[11px]">
                        <div class="flex items-center gap-1.5">
                          <span class="w-4 h-4 rounded-full ${pIdx === 0 ? 'bg-emerald-500 text-black font-extrabold' : 'bg-gray-800 text-gray-300'} flex items-center justify-center text-[9px] font-mono">
                            ${pIdx + 1}
                          </span>
                          <span class="${pIdx === 0 ? 'text-white font-bold' : 'text-gray-300'}">${pred.cropName}</span>
                        </div>
                        <div class="flex items-center gap-2">
                          <span class="text-[10px] text-gray-400 font-mono">Raw Score: ${pred.score}</span>
                          <span class="font-bold font-mono ${pIdx === 0 ? 'text-emerald-400' : 'text-gray-400'}">${pred.relativeConfidence}%</span>
                        </div>
                      </div>
                    `).join('')}
                  </div>
                </div>
              </div>
            ` : ''}

            <!-- 1-Click Crop Species Switcher Bar -->
            <div class="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800/60 space-y-2.5">
              <div class="flex flex-wrap items-center justify-between gap-1 text-xs">
                <span class="text-emerald-300 font-bold font-mono flex items-center gap-1.5">
                  <i data-lucide="sprout" class="w-3.5 h-3.5 text-emerald-400"></i>
                  <span>Switch Crop Species (1-Tap Instant Override):</span>
                </span>
                <span class="text-[10px] font-mono text-gray-400">Instantly recalculates diagnosis</span>
              </div>
              <div class="flex flex-wrap gap-1.5">
                ${[
                  { key: 'all', label: '🔍 Auto-Detect' },
                  { key: 'tomato', label: '🍅 Tomato' },
                  { key: 'potato', label: '🥔 Potato' },
                  { key: 'rice', label: '🌾 Rice' },
                  { key: 'wheat', label: '🌾 Wheat' },
                  { key: 'cotton', label: '☁️ Cotton' },
                  { key: 'maize', label: '🌽 Maize' },
                  { key: 'chilli', label: '🌶️ Chilli' },
                  { key: 'groundnut', label: '🥜 Soybean' }
                ].map(c => {
                  const isActive = (selectedCropHint === c.key) || (selectedCropHint === 'all' && c.key === 'all');
                  return `
                    <button type="button" data-crop="${c.key}" class="crop-switch-chip px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition cursor-pointer border ${
                      isActive
                        ? 'bg-emerald-700 text-white border-emerald-400 shadow-sm'
                        : 'bg-emerald-950/80 hover:bg-emerald-900 text-gray-300 border-emerald-800/60 hover:border-emerald-500/50'
                    }">
                      ${c.label}
                    </button>
                  `;
                }).join('')}
              </div>
            </div>

            <!-- Top-3 Diagnostic Candidates Ranking -->
            <div class="space-y-2.5">
              <div class="flex items-center justify-between">
                <h4 class="text-xs font-bold text-gray-200 uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <i data-lucide="layers" class="w-3.5 h-3.5 text-emerald-400"></i>
                  <span>Top-3 Computer Vision Hypotheses:</span>
                </h4>
                <span class="text-[10px] text-gray-400">Click candidate to review solutions</span>
              </div>

              <div class="space-y-2">
                ${topCandidates.map((c, idx) => `
                  <div class="p-3 rounded-xl bg-emerald-950/40 border ${idx === 0 ? 'border-emerald-500/60 bg-emerald-950/60 shadow-md' : 'border-emerald-800/30'} space-y-1.5 transition hover:border-emerald-400/80">
                    <div class="flex justify-between items-center text-xs">
                      <div class="flex items-center gap-2">
                        <span class="w-5 h-5 rounded-full flex items-center justify-center font-mono font-black text-[11px] ${idx === 0 ? 'bg-emerald-500 text-slate-950' : 'bg-gray-800 text-gray-300'}">
                          ${idx + 1}
                        </span>
                        <div class="flex flex-col">
                          <div class="flex items-center gap-1.5">
                            <span class="font-bold text-white">${c.commonName || c.name}</span>
                            ${idx === 0 ? '<span class="px-1.5 py-0.2 rounded text-[9px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">PRIMARY</span>' : ''}
                          </div>
                          ${c.vernacularName ? `<span class="text-[10px] text-amber-300/90 font-sans">${c.vernacularName}</span>` : ''}
                        </div>
                      </div>
                      <div class="flex items-center gap-3">
                        <span class="font-mono font-extrabold ${idx === 0 ? 'text-emerald-400 text-sm' : 'text-gray-300 text-xs'}">${c.prob}%</span>
                        ${idx > 0 && c.id ? `
                          <button type="button" data-candidate-id="${c.id}" class="candidate-switch-btn px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 border border-emerald-700/50 transition cursor-pointer">
                            Inspect
                          </button>
                        ` : ''}
                      </div>
                    </div>
                    <div class="w-full h-1.5 rounded-full bg-gray-900 overflow-hidden">
                      <div class="h-full ${idx === 0 ? 'bg-emerald-500' : (idx === 1 ? 'bg-emerald-700' : 'bg-gray-600')} rounded-full transition-all duration-500" style="width: ${c.prob}%"></div>
                    </div>
                    <div class="flex justify-between text-[10px] text-gray-400">
                      <span>${c.crop || result.crop} • ${c.category || 'Pathogen'}</span>
                      <span class="font-mono">${c.status || (idx === 0 ? 'Primary Candidate' : 'Differential Diagnosis')}</span>
                    </div>
                  </div>
                `).join('')}
              </div>
            </div>

            <!-- Observed Visual Symptoms Checklist -->
            <div class="space-y-2 pt-2 border-t border-emerald-950">
              <h4 class="text-xs font-bold text-gray-200 uppercase tracking-wider font-mono flex items-center gap-1.5">
                <i data-lucide="eye" class="w-3.5 h-3.5 text-emerald-400"></i>
                <span>Observed Visual Pathology Symptoms:</span>
              </h4>
              <ul class="grid grid-cols-1 gap-2 text-xs text-gray-300">
                ${(result.symptoms || [
                  "Foliar lesions with distinct discoloration and margin boundaries.",
                  "Reduced chlorophyll density along infected leaf sectors."
                ]).map(s => `
                  <li class="flex items-start gap-2 p-2 rounded-lg bg-black/30 border border-emerald-950">
                    <span class="text-emerald-400 font-black mt-0.5">●</span>
                    <span class="leading-relaxed">${s}</span>
                  </li>
                `).join('')}
              </ul>
            </div>
          </div>

          <!-- Comprehensive Multi-Tier Farmer Solutions (5 Action Pillars) -->
          <div class="glass-card p-6 space-y-6">
            <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950 pb-3">
              <div>
                <h3 class="text-base font-extrabold text-white flex items-center gap-2">
                  <i data-lucide="clipboard-check" class="w-5 h-5 text-emerald-400"></i>
                  <span>Actionable Farm Management & Prescription Plan</span>
                </h3>
                <p class="text-xs text-gray-400 mt-0.5">Agronomic treatments formulated for Indian & global field conditions</p>
              </div>
              <span class="px-2.5 py-1 rounded-full text-[11px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
                MULTI-TIER INTEGRATED PEST MANAGEMENT (IPM)
              </span>
            </div>

            <!-- Pillar 1: Cultural & First-Aid Measures -->
            <div class="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-800/40 space-y-3">
              <div class="flex items-center gap-2">
                <div class="w-7 h-7 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs">
                  1
                </div>
                <h4 class="text-xs font-bold text-emerald-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <i data-lucide="scissors" class="w-4 h-4 text-emerald-400"></i>
                  <span>Pillar 1: Immediate Field First-Aid & Cultural Sanitation</span>
                </h4>
              </div>
              <ul class="space-y-2 text-xs text-gray-200">
                ${(result.culturalMeasures || [
                  "Inspect and prune severely spotted bottom leaves to minimize splash dispersal of spores.",
                  "Avoid overhead sprinkler irrigation; switch to drip to keep foliage canopy dry.",
                  "Destroy weed hosts and crop residues around bunds and field borders."
                ]).map(m => `
                  <li class="flex items-start gap-2.5">
                    <i data-lucide="check-circle-2" class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"></i>
                    <span class="leading-relaxed">${m}</span>
                  </li>
                `).join('')}
              </ul>
            </div>

            <!-- Pillar 2: Organic & Biological Controls -->
            <div class="p-4 rounded-2xl bg-teal-950/30 border border-teal-800/40 space-y-3">
              <div class="flex items-center gap-2">
                <div class="w-7 h-7 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold text-xs">
                  2
                </div>
                <h4 class="text-xs font-bold text-teal-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <i data-lucide="leaf" class="w-4 h-4 text-teal-400"></i>
                  <span>Pillar 2: Certified Organic & Biological Antagonists</span>
                </h4>
              </div>
              <ul class="space-y-2 text-xs text-gray-200">
                ${(result.biologicalControl || [
                  "Foliar spray with Trichoderma viride / harzianum @ 5g/L water to parasitize fungal mycelia.",
                  "Apply Neem Seed Kernel Extract (NSKE 5%) or Azadirachtin 10000 ppm @ 2ml/L as natural prophylactic.",
                  "Spray fermented sour buttermilk (10-day old @ 40ml/L) to establish beneficial lactic acid bacteria on phyllosphere."
                ]).map(b => `
                  <li class="flex items-start gap-2.5">
                    <i data-lucide="sprout" class="w-4 h-4 text-teal-400 shrink-0 mt-0.5"></i>
                    <span class="leading-relaxed">${b}</span>
                  </li>
                `).join('')}
              </ul>
            </div>

            <!-- Pillar 3: Chemical Treatment Table & Dosages -->
            <div class="p-4 rounded-2xl bg-red-950/20 border border-red-800/40 space-y-3">
              <div class="flex items-center justify-between flex-wrap gap-2">
                <div class="flex items-center gap-2">
                  <div class="w-7 h-7 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center font-bold text-xs">
                    3
                  </div>
                  <h4 class="text-xs font-bold text-red-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                    <i data-lucide="flask-conical" class="w-4 h-4 text-red-400"></i>
                    <span>Pillar 3: Targeted Fungicide / Bactericide Prescription</span>
                  </h4>
                </div>
                <span class="text-[10px] font-mono text-gray-400">Accurate Mixing Dosages</span>
              </div>

              ${result.chemicalControl && result.chemicalControl.length > 0 ? `
                <div class="space-y-2.5">
                  ${result.chemicalControl.map(chem => `
                    <div class="p-3 rounded-xl bg-black/40 border border-red-900/40 space-y-1.5">
                      <div class="flex flex-wrap items-center justify-between gap-1">
                        <span class="font-extrabold text-white text-xs">${chem.chemical}</span>
                        <span class="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-red-500/20 text-red-300 border border-red-500/30">
                          Dosage: ${chem.dosage}
                        </span>
                      </div>
                      <p class="text-[11px] text-gray-300 leading-relaxed">${chem.timing}</p>
                    </div>
                  `).join('')}
                </div>
              ` : `
                <div class="p-3 rounded-xl bg-emerald-950/30 border border-emerald-800/30 text-xs text-emerald-200 flex items-center gap-2">
                  <i data-lucide="shield-check" class="w-4 h-4 text-emerald-400"></i>
                  <span>No chemical treatment required for healthy foliage. Continue standard balanced NPK fertilization.</span>
                </div>
              `}
              
              <p class="text-[10px] text-gray-400 italic">
                * Note: Always wear PPE (face mask & nitrile gloves) during spray. Spray during calm morning or late evening hours to avoid bee mortality.
              </p>
            </div>

            <!-- Pillar 4: Preventive Care & Crop Hygiene -->
            <div class="p-4 rounded-2xl bg-amber-950/20 border border-amber-800/40 space-y-3">
              <div class="flex items-center gap-2">
                <div class="w-7 h-7 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs">
                  4
                </div>
                <h4 class="text-xs font-bold text-amber-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <i data-lucide="shield-check" class="w-4 h-4 text-amber-400"></i>
                  <span>Pillar 4: Long-Term Crop Hygiene & Resistant Varieties</span>
                </h4>
              </div>
              <ul class="space-y-2 text-xs text-gray-200">
                ${(result.preventiveCare || [
                  "Practice 2-3 season crop rotation with non-host botanical families (e.g. rotate Solanaceae with pulses or millets).",
                  "Treat seeds with Trichoderma viride @ 10g/kg or Thiram @ 3g/kg seed before sowing.",
                  "Select certified ICAR / State Agriculture University resistant cultivars."
                ]).map(p => `
                  <li class="flex items-start gap-2.5">
                    <i data-lucide="arrow-right-circle" class="w-4 h-4 text-amber-400 shrink-0 mt-0.5"></i>
                    <span class="leading-relaxed">${p}</span>
                  </li>
                `).join('')}
              </ul>
            </div>

            <!-- Pillar 5: Helpline & KVK Institutional Escalation -->
            <div class="p-4 rounded-2xl bg-blue-950/30 border border-blue-800/40 space-y-2">
              <div class="flex items-center gap-2">
                <div class="w-7 h-7 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs">
                  5
                </div>
                <h4 class="text-xs font-bold text-blue-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
                  <i data-lucide="landmark" class="w-4 h-4 text-blue-400"></i>
                  <span>Pillar 5: Institutional Support & Advisory Escalation</span>
                </h4>
              </div>
              <p class="text-xs text-gray-200 leading-relaxed">
                ${result.kvkHelpline || "Contact your nearest District Krishi Vigyan Kendra (KVK) or State Agricultural University plant pathology clinic for laboratory confirmation."}
              </p>
              <div class="pt-1 flex flex-wrap items-center gap-3 text-xs">
                <span class="text-gray-400">Toll-free Kisan Call Center:</span>
                <a href="tel:18001801551" class="px-2.5 py-1 rounded bg-blue-900/60 text-blue-200 border border-blue-500/40 font-mono font-bold hover:bg-blue-800">
                  📞 1800-180-1551 (6 AM - 10 PM)
                </a>
              </div>
            </div>

          </div>
        `}

        </div>

      </div>

    </div>
  `;
}

// Active camera stream reference for cleanup
let activeCameraMediaStream = null;

function initPlantDiseaseHooks(state, setState) {
  const browseBtn = document.getElementById('browse-leaf-btn');
  const fileInput = document.getElementById('leaf-file-input');
  const dropzone = document.getElementById('leaf-dropzone');
  const cropFilter = document.getElementById('disease-crop-filter');
  const openCameraBtn = document.getElementById('btn-open-camera');
  const cameraContainer = document.getElementById('camera-viewfinder-container');
  const cameraVideo = document.getElementById('camera-stream-video');
  const snapPhotoBtn = document.getElementById('btn-snap-photo');
  const cancelCameraBtn = document.getElementById('btn-cancel-camera');
  const toggleHeatmapBtn = document.getElementById('btn-toggle-heatmap');
  const printReportBtn = document.getElementById('btn-print-disease-report');

  // Model status cards reactive updater
  function updateModelStatusCards() {
    const container = document.getElementById('ai-models-status-container');
    if (!container) return;
    const diseaseStatus = getModelStatus();
    const cropStatus = getCropModelStatus();
    container.outerHTML = renderModelStatusBanner({ disease: diseaseStatus, crop: cropStatus });
    bindRetryButtons();
    if (typeof window !== 'undefined' && window.lucide) {
      try { window.lucide.createIcons(); } catch (e) {}
    }
  }

  function bindRetryButtons() {
    const retryDiseaseBtn = document.getElementById('btn-retry-model-init');
    if (retryDiseaseBtn && !retryDiseaseBtn.__bound) {
      retryDiseaseBtn.__bound = true;
      retryDiseaseBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        retryDiseaseBtn.disabled = true;
        retryDiseaseBtn.innerHTML = '<span class="animate-spin inline-block mr-1">⌛</span> Retrying...';
        try {
          await initDiseaseModel({ force: true });
        } catch (err) {
          console.warn('[AgroSense CV] Disease model retry error:', err);
        }
      });
    }

    const retryCropBtn = document.getElementById('btn-retry-crop-model-init');
    if (retryCropBtn && !retryCropBtn.__bound) {
      retryCropBtn.__bound = true;
      retryCropBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        retryCropBtn.disabled = true;
        retryCropBtn.innerHTML = '<span class="animate-spin inline-block mr-1">⌛</span> Retrying...';
        try {
          await initCropModel({ force: true });
        } catch (err) {
          console.warn('[AgroSense CV] Crop model retry error:', err);
        }
      });
    }
  }

  // Subscribe to live model lifecycle changes so DOM updates immediately on ready/error
  subscribeCropModelStatus(() => {
    updateModelStatusCards();
  });
  subscribeModelStatus(() => {
    updateModelStatusCards();
  });
  bindRetryButtons();

  // Automatic Background Model Pre-Warm on Page Entry (non-blocking)
  const initialDiseaseStatus = getModelStatus();
  const initialCropStatus = getCropModelStatus();

  if (initialDiseaseStatus.status === 'idle') {
    initDiseaseModel().catch(err => {
      console.warn('[AgroSense CV] Auto disease model initialization warning:', err.message);
    });
  }

  if (initialCropStatus.status === 'idle') {
    initCropModel().catch(err => {
      console.warn('[AgroSense CV] Auto crop model initialization warning:', err.message);
    });
  }

  const getCurrentCropHint = () => {
    return cropFilter ? cropFilter.value : (state.selectedCropHint || 'all');
  };

  // 1. Browse File Upload Button
  if (browseBtn && fileInput) {
    browseBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      fileInput.click();
    });

    fileInput.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (file) {
        processUploadedLeafFile(file);
      }
    });
  }

  // 2. Drag & Drop Leaf File
  if (dropzone) {
    dropzone.addEventListener('click', (e) => {
      // If user clicked inside the dropzone but not on a child button
      if (e.target.id === 'leaf-dropzone' || e.target.closest('#leaf-dropzone')) {
        if (!e.target.closest('button')) {
          fileInput?.click();
        }
      }
    });

    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.add('border-emerald-400', 'bg-emerald-950/40');
    });

    dropzone.addEventListener('dragleave', (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.remove('border-emerald-400', 'bg-emerald-950/40');
    });

    dropzone.addEventListener('drop', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.remove('border-emerald-400', 'bg-emerald-950/40');
      const file = e.dataTransfer.files[0];
      if (file) {
        processUploadedLeafFile(file);
      }
    });
  }

  // Central Unified Diagnosis Pipeline Execution
  async function executeDiagnosis(imgSrc, fileName) {
    let resolvedImgSrc = imgSrc;
    if (typeof imgSrc === 'string' && (imgSrc.startsWith('sample-') || imgSrc.startsWith('disease-'))) {
      const match = demoLeafSamples.find(s => s.id === imgSrc || s.diseaseId === imgSrc);
      if (match && match.svg) {
        resolvedImgSrc = getSampleDataUrl(match.svg);
      }
    }

    const explicitCrop = (state.isUserExplicitCrop && state.selectedCropHint && state.selectedCropHint !== 'all')
      ? state.selectedCropHint
      : 'all';

    // 1. Immediately enter scanning state to clear stale predictions
    setState({
      diseaseResult: { isScanning: true, fileName: fileName || 'leaf_specimen.jpg' },
      diseaseImageSrc: resolvedImgSrc,
      diseaseFileName: fileName || 'leaf_specimen.jpg',
      selectedCropHint: state.isUserExplicitCrop ? state.selectedCropHint : 'all',
      isUserExplicitCrop: Boolean(state.isUserExplicitCrop)
    });

    if (browseBtn) {
      browseBtn.innerHTML = '<span class="animate-spin inline-block mr-1">⌛</span> Auto-Detecting Crop & Disease...';
    }
    const targetCropDisplay = document.getElementById('target-crop-display-value');
    if (targetCropDisplay) {
      targetCropDisplay.textContent = 'Identifying crop…';
      targetCropDisplay.className = 'text-xs font-mono font-medium text-amber-300 animate-pulse';
    }
    const laser = document.getElementById('scanner-laser-line');
    const pill = document.getElementById('scanner-status-pill');
    if (laser) laser.classList.remove('hidden');
    if (pill) {
      pill.innerHTML = `<span>🔍 ${explicitCrop !== 'all' ? `Screening ${explicitCrop.toUpperCase()} Foliar Pathogens...` : 'Auto-Detecting Crop Species & Foliar Biomarkers...'}</span>`;
      pill.classList.remove('hidden');
    }

    try {
      const res = await analyzeLeafImage(resolvedImgSrc, explicitCrop, fileName);
      setState({
        diseaseResult: res,
        diseaseImageSrc: resolvedImgSrc,
        diseaseFileName: fileName || 'leaf_specimen.jpg',
        selectedCropHint: state.isUserExplicitCrop ? state.selectedCropHint : 'all',
        isUserExplicitCrop: Boolean(state.isUserExplicitCrop)
      });
    } catch (err) {
      console.error("[AgroSense CV] Leaf vision analysis error:", err);
      setState({
        diseaseResult: {
          isValidImage: false,
          errorType: 'processing-error',
          validationError: 'An unexpected processing error occurred while scanning the leaf. Please upload a clear photo of a crop leaf: ' + (err.message || err),
          status: 'ERROR'
        },
        diseaseImageSrc: imgSrc,
        diseaseFileName: fileName || 'leaf_specimen.jpg',
        selectedCropHint: state.isUserExplicitCrop ? state.selectedCropHint : 'all',
        isUserExplicitCrop: Boolean(state.isUserExplicitCrop)
      });
    } finally {
      if (laser) laser.classList.add('hidden');
      if (pill) pill.classList.add('hidden');
      if (browseBtn) {
        browseBtn.innerHTML = '<i data-lucide="folder-open" class="w-4 h-4"></i><span>Browse Image File</span>';
      }
      if (typeof window !== 'undefined' && window.lucide) {
        try { window.lucide.createIcons(); } catch (e) {}
      }
    }
  }

  // Helper to read and analyze an uploaded image
  async function processUploadedLeafFile(file) {
    const reader = new FileReader();
    reader.onload = async (evt) => {
      const imgSrc = evt.target.result;
      await executeDiagnosis(imgSrc, file.name);
    };
    reader.readAsDataURL(file);
  }

  // 3. Live Phone Camera Stream Viewfinder
  if (openCameraBtn && cameraContainer && cameraVideo) {
    openCameraBtn.addEventListener('click', async () => {
      try {
        cameraContainer.classList.remove('hidden');
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          const constraints = {
            video: {
              facingMode: { ideal: 'environment' },
              width: { ideal: 1280 },
              height: { ideal: 720 }
            }
          };

          try {
            activeCameraMediaStream = await navigator.mediaDevices.getUserMedia(constraints);
          } catch (mobileErr) {
            // Fallback for laptops/desktops without 'environment' back camera
            activeCameraMediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
          }

          cameraVideo.srcObject = activeCameraMediaStream;
          cameraVideo.play();
        } else {
          alert("Camera API is not supported on this browser. Please use 'Browse Image File' instead.");
          cameraContainer.classList.add('hidden');
        }
      } catch (err) {
        console.warn("[AgroSense CV] Camera access failed:", err);
        const errMsg = (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError')
          ? "Camera permission denied. Please allow camera access in your browser address bar or use 'Browse Image File'."
          : "Camera device unavailable or busy. Please use the 'Browse Image File' button to select a leaf photo.";
        alert(errMsg);
        cameraContainer.classList.add('hidden');
      }
    });

    // Snap Photo from Video Stream
    if (snapPhotoBtn) {
      snapPhotoBtn.addEventListener('click', async () => {
        if (!cameraVideo.videoWidth) return;

        const canvas = document.createElement('canvas');
        canvas.width = cameraVideo.videoWidth;
        canvas.height = cameraVideo.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(cameraVideo, 0, 0, canvas.width, canvas.height);

        const capturedDataUrl = canvas.toDataURL('image/jpeg', 0.90);

        // Stop camera tracks
        if (activeCameraMediaStream) {
          activeCameraMediaStream.getTracks().forEach(track => track.stop());
          activeCameraMediaStream = null;
        }
        cameraContainer.classList.add('hidden');

        await executeDiagnosis(capturedDataUrl, 'camera_capture.jpg');
      });
    }

    // Cancel Camera
    if (cancelCameraBtn) {
      cancelCameraBtn.addEventListener('click', () => {
        if (activeCameraMediaStream) {
          activeCameraMediaStream.getTracks().forEach(track => track.stop());
          activeCameraMediaStream = null;
        }
        cameraContainer.classList.add('hidden');
      });
    }
  }

  // 4. Heatmap Toggle Listener
  if (toggleHeatmapBtn) {
    toggleHeatmapBtn.addEventListener('click', () => {
      const heatmap = document.getElementById('disease-heatmap-overlay');
      const label = document.getElementById('label-heatmap-toggle');
      if (heatmap) {
        heatmap.classList.toggle('hidden');
        if (label) {
          label.textContent = heatmap.classList.contains('hidden') ? 'Show Heatmap' : 'Hide Heatmap';
        }
      }
    });
  }

  // 5. Unified Crop Species Filter & 1-Tap Crop Chips
  const handleCropSelection = async (newCrop) => {
    if (cropFilter) cropFilter.value = newCrop;
    const currentImg = state.diseaseImageSrc || state.diseaseResult?.imageSrc;

    if (currentImg) {
      const res = await analyzeLeafImage(currentImg, newCrop, state.diseaseFileName || '');
      setState({
        selectedCropHint: newCrop,
        isUserExplicitCrop: newCrop !== 'all',
        diseaseResult: res
      });
    } else {
      const res = classifyLeafImage(null, state.diseaseResult?.id, newCrop);
      setState({
        selectedCropHint: newCrop,
        isUserExplicitCrop: newCrop !== 'all',
        diseaseResult: res
      });
    }
  };

  if (cropFilter) {
    cropFilter.addEventListener('change', async (e) => {
      await handleCropSelection(e.target.value);
    });
  }

  document.querySelectorAll('.crop-chip-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      await handleCropSelection(btn.getAttribute('data-crop'));
    });
  });

  document.querySelectorAll('.crop-switch-chip').forEach(btn => {
    btn.addEventListener('click', async () => {
      await handleCropSelection(btn.getAttribute('data-crop'));
    });
  });

  // 6. Quick 1-Click Realistic Agricultural Leaf Disease Samples
  document.querySelectorAll('.sample-leaf-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const sampleId = btn.getAttribute('data-sample-id');
      const sample = demoLeafSamples.find(s => s.id === sampleId);

      if (sample) {
        const sampleImgSrc = sample.svg ? getSampleDataUrl(sample.svg) : sample.id;
        await executeDiagnosis(sampleImgSrc, `${sample.label}.jpg`);
      } else {
        const res = classifyLeafImage(null, sampleId);
        setState({
          diseaseResult: res,
          diseaseImageSrc: res.imageSrc || null,
          diseaseFileName: null
        });
      }
    });
  });

  // 7. Top-3 Candidate Switch Buttons
  document.querySelectorAll('.candidate-switch-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const candidateId = btn.getAttribute('data-candidate-id');
      if (candidateId) {
        const res = classifyLeafImage(null, candidateId);
        setState({
          diseaseResult: {
            ...res,
            fileName: state.diseaseFileName || null,
            imageSrc: state.diseaseImageSrc || res.imageSrc
          }
        });
      }
    });
  });

  // 8. Print Advisory Prescription Button
  if (printReportBtn) {
    printReportBtn.addEventListener('click', () => {
      window.print();
    });
  }

  // 9. Healthy Leaf View Mode Toggle (Real Photo vs Botanical SVG)
  const photoBtn = document.getElementById('btn-show-healthy-photo');
  const svgBtn = document.getElementById('btn-show-healthy-svg');
  const photoContainer = document.getElementById('healthy-photo-container');
  const svgContainer = document.getElementById('healthy-svg-container');

  if (photoBtn && svgBtn && photoContainer && svgContainer) {
    photoBtn.addEventListener('click', () => {
      photoContainer.classList.remove('hidden');
      svgContainer.classList.add('hidden');
      photoBtn.classList.add('active', 'bg-emerald-500', 'text-slate-950');
      photoBtn.classList.remove('text-emerald-300');
      svgBtn.classList.remove('active', 'bg-emerald-500', 'text-slate-950');
      svgBtn.classList.add('text-emerald-300');
    });

    svgBtn.addEventListener('click', () => {
      svgContainer.classList.remove('hidden');
      photoContainer.classList.add('hidden');
      svgBtn.classList.add('active', 'bg-emerald-500', 'text-slate-950');
      svgBtn.classList.remove('text-emerald-300');
      photoBtn.classList.remove('active', 'bg-emerald-500', 'text-slate-950');
      photoBtn.classList.add('text-emerald-300');
    });
  }

  // 10. Healthy Crop Reference Library Gallery Click Handlers
  document.querySelectorAll('.healthy-gallery-chip').forEach(chip => {
    chip.addEventListener('click', async () => {
      const cropKey = chip.getAttribute('data-healthy-crop');
      if (cropKey) {
        const healthyImgSrc = `images/healthy_crops/${cropKey}_healthy.jpg`;
        const res = await analyzeLeafImage(healthyImgSrc, cropKey, `${cropKey}_healthy.jpg`);
        setState({
          diseaseResult: res,
          diseaseImageSrc: healthyImgSrc,
          diseaseFileName: `${cropKey}_healthy.jpg`,
          selectedCropHint: cropKey,
          isUserExplicitCrop: true
        });
      }
    });
  });
}

/* Module Exports */
exports.renderPlantDiseasePage = renderPlantDiseasePage; exports.initPlantDiseaseHooks = initPlantDiseaseHooks;
