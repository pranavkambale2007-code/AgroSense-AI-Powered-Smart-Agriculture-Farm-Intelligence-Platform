// AgroSense National Agriculture Intelligence Dashboard Page Component
// Includes Bar Graph & Pie Chart National Data Visualizations

const { aggregateInstitutionalFarmData } = require('js/services/privacyService.js');
const { drawBarChart, drawPieChart } = require('js/components/AnalyticsCharts.js');

function renderNationalDashboardPage(state) {
  const isPrivacyEnabled = state.isInstitutionalPrivacyEnabled !== undefined ? state.isInstitutionalPrivacyEnabled : true;
  const anonymizedStats = aggregateInstitutionalFarmData(state.farms, isPrivacyEnabled);

  const states = [
    { state: "Maharashtra", farms: "14,250", topCrop: "Sugarcane / Wheat", soilHealth: "78/100", waterRisk: "Moderate" },
    { state: "Punjab", farms: "11,800", topCrop: "Wheat / Paddy", soilHealth: "85/100", waterRisk: "High Groundwater Extraction" },
    { state: "Gujarat", farms: "9,450", topCrop: "Cotton / Groundnut", soilHealth: "81/100", waterRisk: "Low" },
    { state: "Karnataka", farms: "8,900", topCrop: "Maize / Paddy", soilHealth: "80/100", waterRisk: "Moderate" },
    { state: "Tamil Nadu", farms: "7,600", topCrop: "Paddy / Millets", soilHealth: "83/100", waterRisk: "Moderate" }
  ];

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Title Bar -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="globe" class="w-6 h-6 text-emerald-400"></i>
            National Agriculture Intelligence Dashboard
          </h1>
          <p class="text-xs text-gray-400">Macro national overview across 52,000+ registered farms • Hierarchy: India → State → District → Block → Farm</p>
        </div>

        <div class="flex items-center gap-2">
          <span class="prototype-badge font-mono">k-ANONYMITY ≥ 5</span>
          <button id="toggle-privacy-engine-btn" class="px-3.5 py-1.5 rounded-xl border text-xs font-bold transition flex items-center gap-1.5 ${
            isPrivacyEnabled 
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' 
              : 'bg-amber-500/20 text-amber-300 border-amber-500/40'
          }">
            <i data-lucide="shield-check" class="w-4 h-4"></i>
            ${isPrivacyEnabled ? 'Differential Privacy: ON (ε=0.5)' : 'Raw Admin Data Mode'}
          </button>
        </div>
      </div>

      <!-- Institutional Privacy Protection Banner -->
      <div class="p-4 rounded-xl bg-emerald-950/60 border border-emerald-700/40 flex items-center justify-between text-xs text-gray-300">
        <span class="flex items-center gap-2">
          <i data-lucide="lock" class="w-4 h-4 text-emerald-400"></i>
          <span><b>Privacy Guarantee:</b> ${anonymizedStats.privacyGuaranteeNote}</span>
        </span>
        <span class="font-mono text-emerald-400 font-bold">Sample k = ${anonymizedStats.actualK} Farms</span>
      </div>

      <!-- Aggregated Institutional Metrics Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div class="glass-card p-5 space-y-1">
          <span class="text-xs font-bold text-gray-400">Aggregated Soil Index</span>
          <div class="text-2xl font-extrabold text-white font-mono">${anonymizedStats.avgSoilScore} / 100</div>
          <p class="text-[11px] text-gray-400">District Average (Laplace Noise $\\epsilon=0.5$)</p>
        </div>

        <div class="glass-card p-5 space-y-1">
          <span class="text-xs font-bold text-gray-400">Aggregated Nitrogen (N)</span>
          <div class="text-2xl font-extrabold text-amber-300 font-mono">${anonymizedStats.avgNitrogenKgHa} kg/ha</div>
          <p class="text-[11px] text-amber-400">Regional Deficit Identified</p>
        </div>

        <div class="glass-card p-5 space-y-1">
          <span class="text-xs font-bold text-gray-400">Aggregated Soil Moisture</span>
          <div class="text-2xl font-extrabold text-blue-300 font-mono">${anonymizedStats.avgMoisturePct}%</div>
          <p class="text-[11px] text-blue-400">Drip Adoption Efficiency: 74%</p>
        </div>
      </div>

      <!-- CHARTS: NATIONAL BAR GRAPH & PIE CHART -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Bar Graph: State Farm Registrations -->
        <div class="glass-card p-6 space-y-3">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <i data-lucide="bar-chart-3" class="w-5 h-5 text-emerald-400"></i>
              <h3 class="text-sm font-bold text-white">Registered Farms by State (Bar Graph)</h3>
            </div>
            <span class="text-[10px] text-gray-400 font-mono">Count (Thousands)</span>
          </div>
          <div class="h-56 w-full relative">
            <canvas id="national-bar-chart" class="w-full h-full"></canvas>
          </div>
        </div>

        <!-- Pie Chart: National Crop Distribution -->
        <div class="glass-card p-6 space-y-3">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <i data-lucide="pie-chart" class="w-5 h-5 text-amber-400"></i>
              <h3 class="text-sm font-bold text-white">National Crop Acreage (Pie Chart)</h3>
            </div>
            <span class="text-[10px] text-gray-400 font-mono">Acreage %</span>
          </div>
          <div class="h-56 w-full relative">
            <canvas id="national-pie-chart" class="w-full h-full"></canvas>
          </div>
        </div>
      </div>

      <!-- State Macro Metrics Table -->
      <div class="glass-card p-6 overflow-x-auto">
        <h3 class="text-sm font-bold text-white mb-4">State-Wise Agricultural Overview</h3>
        <table class="w-full text-left border-collapse text-xs">
          <thead>
            <tr class="border-b border-emerald-800/60 text-gray-400">
              <th class="p-3">State Name</th>
              <th class="p-3 font-mono">Registered Farms</th>
              <th class="p-3">Dominant Crops</th>
              <th class="p-3 text-center">Avg Soil Score</th>
              <th class="p-3">Regional Water Risk</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-emerald-950/60">
            ${states.map(item => `
              <tr class="hover:bg-emerald-950/30">
                <td class="p-3 font-bold text-white">${item.state}</td>
                <td class="p-3 font-mono text-emerald-300 font-bold">${item.farms}</td>
                <td class="p-3 text-gray-200">${item.topCrop}</td>
                <td class="p-3 text-center"><span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-bold">${item.soilHealth}</span></td>
                <td class="p-3 text-amber-300 font-semibold">${item.waterRisk}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function initNationalDashboardHooks() {
  drawBarChart(
    'national-bar-chart',
    ['MH', 'PB', 'GJ', 'KA', 'TN'],
    [142, 118, 94, 89, 76],
    ['#10b981', '#3b82f6', '#f59e0b', '#14b8a6', '#8b5cf6'],
    160
  );

  drawPieChart(
    'national-pie-chart',
    ['Wheat', 'Paddy / Rice', 'Sugarcane', 'Cotton', 'Soybean / Pulses'],
    [32, 28, 18, 14, 8],
    ['#10b981', '#3b82f6', '#f59e0b', '#14b8a6', '#8b5cf6']
  );
}

/* Module Exports */
exports.renderNationalDashboardPage = renderNationalDashboardPage; exports.initNationalDashboardHooks = initNationalDashboardHooks;
