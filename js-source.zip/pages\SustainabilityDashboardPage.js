// AgroSense Global Sustainability Impact Dashboard Page Component
// Hackathon Track: Agriculture, Food & Water (Green Mind Sustainable 2.0)
// Complete Data-Driven Resource Accounting, IPCC Carbon Accounting, FAO-56 Water Balance

const { calculateSustainabilityImpact,
  generateSustainabilityAdvisorInsights,
  generateSustainabilityCSV,
  loadFarmSustainabilityRecords,
  saveFarmSustainabilityRecords,
  parseAndValidateResourceCSV,
  FERTILIZER_COMPOSITION,
  EMISSION_FACTORS,
  IRRIGATION_EFFICIENCIES,
  getCropAgronomicParameters } = require('js/services/sustainabilityService.js');

let activeBaselineScenario = 'conventional'; // 'conventional', 'previous_season'
let activeSeasonFilter = 'All';
let activeDateRange = 'season'; // 'season', '60days', '30days'
let activeRequestId = 0;

function renderSustainabilityDashboardPage(state) {
  const farm = state.activeFarm || {};
  const allFarms = state.farms || [];
  const records = loadFarmSustainabilityRecords(farm);
  
  const impact = calculateSustainabilityImpact(farm, records, {
    baselineScenario: activeBaselineScenario,
    season: activeSeasonFilter,
    dateRange: activeDateRange
  });
  
  const advisorInsights = generateSustainabilityAdvisorInsights(impact);
  const index = impact.sustainabilityIndex;

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2 text-[#F6F8F2] pb-12 print:text-black print:bg-white">
      
      <!-- Top Title, Hackathon Banner & Quick Action Bar -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-[#12372A] pb-4">
        <div>
          <div class="flex items-center gap-2.5 flex-wrap">
            <span class="px-2.5 py-1 rounded-md text-[11px] font-bold tracking-wider uppercase font-mono bg-[#16A36A]/20 text-[#B7E36A] border border-[#16A36A]/40 flex items-center gap-1.5">
              <i data-lucide="leaf" class="w-3.5 h-3.5 text-[#B7E36A]"></i>
              GREEN MIND SUSTAINABLE 2.0 • AGRI-FOOD & WATER TRACK
            </span>
            <span class="px-2.5 py-1 rounded-md text-[11px] font-mono bg-[#12372A] text-emerald-300 border border-[#16A36A]/30 flex items-center gap-1.5" style="border-color: ${index.badgeColor}60;">
              <span class="w-2 h-2 rounded-full" style="background-color: ${index.badgeColor};"></span>
              Sustainability Index: <b style="color: ${index.badgeColor};">${index.score}/100 • ${index.category.split('(')[0].trim()}</b>
            </span>
            <span class="px-2.5 py-1 rounded-md text-[11px] font-mono bg-sky-950/70 text-sky-300 border border-sky-600/30 flex items-center gap-1.5">
              <i data-lucide="shield-check" class="w-3.5 h-3.5 text-sky-400"></i>
              Data Completeness: <b class="text-white">${impact.dataQuality.score}%</b> (${impact.dataQuality.rating})
            </span>
          </div>

          <h1 class="text-2xl sm:text-3xl font-extrabold text-white mt-1.5 flex items-center gap-2.5">
            Global Sustainability Impact & Carbon Intelligence
          </h1>
          <p class="text-xs text-[#D5E2D8] max-w-3xl">
            Location-calibrated agronomic sustainability accounting. Dynamically calculates FAO-56 crop water balance, 
            stoichiometric NPK efficiency, IPCC Tier 1 carbon inventory, and crop productivity specifically for the active farm.
          </p>
        </div>

        <!-- Global Dashboard Actions -->
        <div class="flex items-center gap-2 flex-wrap">
          <button type="button" id="btn-open-log-modal" class="px-3.5 py-2 rounded-xl bg-[#16A36A] hover:bg-[#16A36A]/80 text-white font-bold text-xs shadow-md transition flex items-center gap-1.5 cursor-pointer">
            <i data-lucide="plus-circle" class="w-4 h-4"></i>
            <span>Log Resource Event</span>
          </button>

          <button type="button" id="btn-open-csv-modal" class="px-3.5 py-2 rounded-xl bg-[#12372A] hover:bg-[#16A36A]/30 text-[#B7E36A] border border-[#16A36A]/40 font-semibold text-xs transition flex items-center gap-1.5 cursor-pointer">
            <i data-lucide="upload-cloud" class="w-4 h-4 text-[#B7E36A]"></i>
            <span>Import CSV</span>
          </button>

          <button type="button" id="btn-export-sustainability-csv" class="px-3.5 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 text-gray-200 border border-gray-700 font-semibold text-xs transition flex items-center gap-1.5 cursor-pointer">
            <i data-lucide="download" class="w-4 h-4 text-emerald-400"></i>
            <span>Export CSV</span>
          </button>

          <button type="button" id="btn-print-sustainability-report" class="px-3 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 text-gray-200 border border-gray-700 font-semibold text-xs transition flex items-center gap-1.5 cursor-pointer" title="Print Sustainability Audit Report">
            <i data-lucide="printer" class="w-4 h-4 text-sky-400"></i>
          </button>
        </div>
      </div>

      <!-- FARM IDENTIFIER & DASHBOARD CONTROLS BAR -->
      <div class="p-4 rounded-2xl bg-[#081611] border border-[#12372A] flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        
        <!-- Active Farm Identifier & Farm Switcher Dropdown -->
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-[#12372A] border border-[#16A36A]/40 flex items-center justify-center text-[#B7E36A] shrink-0">
            <i data-lucide="sprout" class="w-5 h-5"></i>
          </div>
          <div>
            <div class="flex items-center gap-2 flex-wrap">
              <span class="text-xs text-gray-400 font-mono">Active Farm:</span>
              <select id="sustainability-farm-selector" class="bg-gray-900 border border-[#16A36A]/40 rounded-lg px-2.5 py-1 text-xs font-bold text-white focus:outline-none focus:border-[#B7E36A] cursor-pointer">
                ${allFarms.map(f => `
                  <option value="${f.id}" ${f.id === farm.id ? 'selected' : ''}>
                    ${f.name || 'Unnamed Farm'} (${f.crop || f.currentCrop || 'Plot'}) — ${f.location || 'Agro Zone'}
                  </option>
                `).join('')}
                <option value="__add_new_farm__" class="text-emerald-400 font-semibold">+ Add New Farm...</option>
              </select>
              <span class="px-2 py-0.5 rounded text-[10px] bg-[#12372A] text-[#B7E36A] border border-[#16A36A]/40 font-mono">
                ${impact.areaAcres} Acres (${impact.areaHa} ha)
              </span>
            </div>
            <p class="text-xs text-gray-400 mt-1">
              Crop: <b class="text-emerald-300">${impact.cropType}</b> • Irrigation: <b class="text-sky-300">${impact.irrigationType} (${impact.irrigationEfficiencyPct}%)</b> • Coords: <b class="text-gray-300 font-mono">${impact.coordinates.lat}°N, ${impact.coordinates.lng}°E</b>
            </p>
          </div>
        </div>

        <!-- Filter Selectors & Recalculation Badge -->
        <div class="flex items-center gap-3 flex-wrap">
          
          <!-- Baseline Scenario Selector -->
          <div class="space-y-1">
            <label class="block text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Comparison Baseline</label>
            <select id="select-baseline-scenario" class="bg-gray-900 border border-[#16A36A]/40 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#B7E36A] cursor-pointer font-sans">
              <option value="conventional" ${activeBaselineScenario === 'conventional' ? 'selected' : ''}>
                Conventional Regional Practice (${impact.cropKey === 'rice' ? 'Flood Paddy' : 'Surface Flood + High Urea'})
              </option>
              <option value="previous_season" ${activeBaselineScenario === 'previous_season' ? 'selected' : ''}>
                Previous Historical Season Logs
              </option>
            </select>
          </div>

          <!-- Reporting Period Selector -->
          <div class="space-y-1">
            <label class="block text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Reporting Horizon</label>
            <select id="select-date-range" class="bg-gray-900 border border-gray-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#B7E36A] cursor-pointer font-sans">
              <option value="season" ${activeDateRange === 'season' ? 'selected' : ''}>Current Growing Season (Full Cycle)</option>
              <option value="60days" ${activeDateRange === '60days' ? 'selected' : ''}>Past 60 Days (Mid-Late Cycle)</option>
              <option value="30days" ${activeDateRange === '30days' ? 'selected' : ''}>Past 30 Days (Recent Pulses)</option>
            </select>
          </div>

          <!-- Last Recalculated Timestamp & Refresh Button -->
          <div class="space-y-1">
            <label class="block text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">Calculated</label>
            <button type="button" id="btn-refresh-sustainability" class="px-2.5 py-1.5 rounded-xl bg-gray-900 hover:bg-gray-800 text-gray-300 border border-gray-700 text-xs transition flex items-center gap-1.5 cursor-pointer" title="Recalculate all sustainability indicators">
              <i data-lucide="refresh-cw" class="w-3.5 h-3.5 text-[#B7E36A]" id="sustainability-refresh-icon"></i>
              <span class="font-mono text-[11px] text-[#B7E36A]">${impact.calculationTimeFormatted}</span>
            </button>
          </div>
        </div>
      </div>

      <!-- 5 PRIMARY SUSTAINABILITY KPI CARDS -->
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">
        
        <!-- KPI 1: Water Conservation -->
        <div class="p-4 rounded-2xl bg-[#081611] border border-[#12372A] hover:border-[#16A36A]/50 transition space-y-2 relative overflow-hidden">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono text-gray-400 uppercase tracking-wider">Water Conservation</span>
            <div class="w-6 h-6 rounded-lg bg-sky-950/80 text-sky-400 flex items-center justify-center">
              <i data-lucide="droplets" class="w-3.5 h-3.5"></i>
            </div>
          </div>

          <div class="space-y-0.5">
            <div class="text-xl sm:text-2xl font-black text-white font-mono flex items-baseline gap-1.5">
              <span>${impact.water.totalIrrigationM3}</span>
              <span class="text-xs font-normal text-gray-400 font-sans">m³ applied</span>
            </div>
            <div class="text-xs text-sky-400 font-mono font-bold">
              ${impact.water.irrigationM3PerHa} m³/ha (${impact.water.irrigationMmDepth} mm depth)
            </div>
          </div>

          <div class="pt-2 border-t border-gray-800/80 flex items-center justify-between text-[11px]">
            <span class="text-gray-400">Saved vs Baseline:</span>
            <span class="font-bold font-mono ${impact.water.waterSavedPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}">
              ${impact.water.waterSavedPct >= 0 ? `-${impact.water.waterSavedPct}%` : `+${Math.abs(impact.water.waterSavedPct)}%`}
            </span>
          </div>
          <div class="text-[10px] text-gray-500 font-mono">
            Gross Req (FAO-56): ${impact.water.grossIrrigationRequirementM3} m³
          </div>
        </div>

        <!-- KPI 2: Soil & Nutrient Balance -->
        <div class="p-4 rounded-2xl bg-[#081611] border border-[#12372A] hover:border-[#16A36A]/50 transition space-y-2 relative overflow-hidden">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono text-gray-400 uppercase tracking-wider">Nutrient Stewardship</span>
            <div class="w-6 h-6 rounded-lg bg-emerald-950/80 text-emerald-400 flex items-center justify-center">
              <i data-lucide="test-tube-2" class="w-3.5 h-3.5"></i>
            </div>
          </div>

          <div class="space-y-0.5">
            <div class="text-xl sm:text-2xl font-black text-white font-mono flex items-baseline gap-1.5">
              <span>${impact.soilAndFertilizer.totalN_kg}</span>
              <span class="text-xs font-normal text-gray-400 font-sans">kg N applied</span>
            </div>
            <div class="text-xs text-emerald-400 font-mono font-bold">
              ${impact.soilAndFertilizer.nPerHa} kg N/ha • Rec: ${impact.soilAndFertilizer.recommendedN_kg} kg
            </div>
          </div>

          <div class="pt-2 border-t border-gray-800/80 flex items-center justify-between text-[11px]">
            <span class="text-gray-400">N-Optimization:</span>
            <span class="font-bold font-mono ${impact.soilAndFertilizer.nSavedPct >= 0 ? 'text-emerald-400' : 'text-amber-400'}">
              ${impact.soilAndFertilizer.nSavedPct >= 0 ? `-${impact.soilAndFertilizer.nSavedPct}%` : `+${Math.abs(impact.soilAndFertilizer.nSavedPct)}%`}
            </span>
          </div>
          <div class="text-[10px] text-gray-500 font-mono">
            P₂O₅: ${impact.soilAndFertilizer.pPerHa} kg/ha • K₂O: ${impact.soilAndFertilizer.kPerHa} kg/ha
          </div>
        </div>

        <!-- KPI 3: Crop Water Productivity -->
        <div class="p-4 rounded-2xl bg-[#081611] border border-[#12372A] hover:border-[#16A36A]/50 transition space-y-2 relative overflow-hidden">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono text-gray-400 uppercase tracking-wider">Water Productivity</span>
            <div class="w-6 h-6 rounded-lg bg-amber-950/80 text-amber-400 flex items-center justify-center">
              <i data-lucide="scale" class="w-3.5 h-3.5"></i>
            </div>
          </div>

          <div class="space-y-0.5">
            <div class="text-xl sm:text-2xl font-black text-[#B7E36A] font-mono flex items-baseline gap-1.5">
              <span>${impact.water.irrigationWaterProductivityKgM3 !== null ? impact.water.irrigationWaterProductivityKgM3 : 'Pending'}</span>
              <span class="text-xs font-normal text-gray-400 font-sans">kg yield / m³</span>
            </div>
            <div class="text-xs text-gray-300 font-mono">
              ${impact.cropPerformance.hasHarvestData 
                ? `Yield: <b class="text-white">${impact.cropPerformance.totalYieldQuintals} Qtl</b> (${impact.cropPerformance.yieldPerHaQuintals} Qtl/ha)` 
                : `<span class="text-amber-300 italic">In-Season / Harvest Pending</span>`}
            </div>
          </div>

          <div class="pt-2 border-t border-gray-800/80 flex items-center justify-between text-[11px]">
            <span class="text-gray-400">Yield Delta:</span>
            <span class="font-bold font-mono ${impact.cropPerformance.yieldDeltaPct !== null ? (impact.cropPerformance.yieldDeltaPct >= 0 ? 'text-emerald-400' : 'text-rose-400') : 'text-gray-400'}">
              ${impact.cropPerformance.yieldDeltaPct !== null ? (impact.cropPerformance.yieldDeltaPct >= 0 ? `+${impact.cropPerformance.yieldDeltaPct}%` : `${impact.cropPerformance.yieldDeltaPct}%`) : 'Pending'}
            </span>
          </div>
          <div class="text-[10px] text-gray-500 font-mono truncate" title="Total Water WP: ${impact.water.totalWaterProductivityKgM3 || 'Pending'} kg/m³">
            Total Water WP: ${impact.water.totalWaterProductivityKgM3 !== null ? `${impact.water.totalWaterProductivityKgM3} kg/m³` : 'In-Season'}
          </div>
        </div>

        <!-- KPI 4: GHG Footprint & Intensity -->
        <div class="p-4 rounded-2xl bg-[#081611] border border-[#12372A] hover:border-[#16A36A]/50 transition space-y-2 relative overflow-hidden">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono text-gray-400 uppercase tracking-wider">Carbon Accounting</span>
            <div class="w-6 h-6 rounded-lg bg-teal-950/80 text-teal-400 flex items-center justify-center">
              <i data-lucide="cloud-fog" class="w-3.5 h-3.5"></i>
            </div>
          </div>

          <div class="space-y-0.5">
            <div class="text-xl sm:text-2xl font-black text-white font-mono flex items-baseline gap-1.5">
              <span>${impact.energyAndEmissions.totalFarmEmissionsKgCO2e}</span>
              <span class="text-xs font-normal text-gray-400 font-sans">kg CO₂e</span>
            </div>
            <div class="text-xs text-teal-300 font-mono font-bold">
              ${impact.energyAndEmissions.carbonIntensityKgCO2ePerQtl !== null ? `${impact.energyAndEmissions.carbonIntensityKgCO2ePerQtl} kg CO₂e / Qtl` : `${impact.energyAndEmissions.emissionsPerHaKgCO2e} kg CO₂e / ha`}
            </div>
          </div>

          <div class="pt-2 border-t border-gray-800/80 flex items-center justify-between text-[11px]">
            <span class="text-gray-400">Abated vs Baseline:</span>
            <span class="font-bold font-mono ${impact.energyAndEmissions.emissionsAbatedPct >= 0 ? 'text-emerald-400' : 'text-amber-400'}">
              ${impact.energyAndEmissions.emissionsAbatedPct >= 0 ? `-${impact.energyAndEmissions.emissionsAbatedPct}%` : `+${Math.abs(impact.energyAndEmissions.emissionsAbatedPct)}%`}
            </span>
          </div>
          <div class="text-[10px] text-gray-500 font-mono">
            ${impact.energyAndEmissions.isFloodedRiceMethaneApplicable ? `Rice CH₄: ${impact.energyAndEmissions.riceMethaneEmissionsKgCO2e} kg CO₂e` : 'IPCC Tier 1 • Scopes 1, 2, 3'}
          </div>
        </div>

        <!-- KPI 5: Resource Economics -->
        <div class="p-4 rounded-2xl bg-[#081611] border border-[#12372A] hover:border-[#16A36A]/50 transition space-y-2 relative overflow-hidden">
          <div class="flex items-center justify-between">
            <span class="text-[10px] font-mono text-gray-400 uppercase tracking-wider">Resource Economics</span>
            <div class="w-6 h-6 rounded-lg bg-emerald-950/80 text-emerald-300 flex items-center justify-center">
              <i data-lucide="indian-rupee" class="w-3.5 h-3.5"></i>
            </div>
          </div>

          <div class="space-y-0.5">
            <div class="text-xl sm:text-2xl font-black text-white font-mono flex items-baseline gap-1.5">
              <span>₹${(impact.soilAndFertilizer.totalFertilizerCostRs + Math.round(impact.energyAndEmissions.totalPumpingKWh * 5.5)).toLocaleString()}</span>
              <span class="text-xs font-normal text-gray-400 font-sans">input cost</span>
            </div>
            <div class="text-xs text-emerald-400 font-mono">
              Fertilizer: ₹${impact.soilAndFertilizer.totalFertilizerCostRs.toLocaleString()}
            </div>
          </div>

          <div class="pt-2 border-t border-gray-800/80 flex items-center justify-between text-[11px]">
            <span class="text-gray-400">Pumping Energy:</span>
            <span class="font-bold font-mono text-white">
              ${impact.energyAndEmissions.totalPumpingKWh} kWh
            </span>
          </div>
          <div class="text-[10px] text-gray-500 font-mono">
            Est. Cost: ₹${impact.cropPerformance.hasHarvestData ? Math.round((impact.soilAndFertilizer.totalFertilizerCostRs + impact.energyAndEmissions.totalPumpingKWh * 5.5) / Math.max(1, impact.cropPerformance.totalYieldQuintals)) : Math.round((impact.soilAndFertilizer.totalFertilizerCostRs + impact.energyAndEmissions.totalPumpingKWh * 5.5) / Math.max(0.1, impact.areaHa))} / ${impact.cropPerformance.hasHarvestData ? 'Qtl' : 'ha'}
          </div>
        </div>

      </div>

      <!-- MAIN 2-COLUMN SECTION: WATER INTELLIGENCE & NUTRIENT STEWARDSHIP -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
        
        <!-- SECTION 1: WATER SUSTAINABILITY & IRRIGATION INTELLIGENCE -->
        <div class="p-5 rounded-2xl bg-[#081611] border border-[#12372A] space-y-4">
          <div class="flex items-center justify-between border-b border-[#12372A] pb-3">
            <div class="flex items-center gap-2.5">
              <div class="w-8 h-8 rounded-lg bg-sky-950/70 text-sky-400 flex items-center justify-center">
                <i data-lucide="waves" class="w-4 h-4"></i>
              </div>
              <div>
                <h3 class="text-sm font-bold text-white">Water Intelligence & Irrigation Balance</h3>
                <p class="text-xs text-gray-400">FAO-56 Penman-Monteith duty (${impact.cropType}) and rainfall offset</p>
              </div>
            </div>
            <a href="#/weather" class="text-[11px] font-mono text-sky-400 hover:underline flex items-center gap-1">
              <span>Weather & Irrigation</span>
              <i data-lucide="arrow-up-right" class="w-3.5 h-3.5"></i>
            </a>
          </div>

          <!-- Water Distribution Breakdown Metrics -->
          <div class="grid grid-cols-3 gap-2.5 text-xs">
            <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
              <span class="text-[10px] text-gray-400 uppercase font-mono block">Applied Irrigation</span>
              <span class="text-base font-extrabold text-white font-mono">${impact.water.totalIrrigationM3} m³</span>
              <span class="text-[10px] text-sky-400 block">${impact.water.totalIrrigationLiters.toLocaleString()} Liters</span>
            </div>
            <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
              <span class="text-[10px] text-gray-400 uppercase font-mono block">Gross Demand (FAO-56)</span>
              <span class="text-base font-extrabold text-white font-mono">${impact.water.grossIrrigationRequirementM3} m³</span>
              <span class="text-[10px] text-gray-400 block">${impact.water.grossIrrigationRequirementM3PerHa} m³/ha</span>
            </div>
            <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
              <span class="text-[10px] text-gray-400 uppercase font-mono block">USDA-SCS Effective Rain</span>
              <span class="text-base font-extrabold text-[#B7E36A] font-mono">${impact.water.effectiveRainfallMm} mm</span>
              <span class="text-[10px] text-emerald-400 block">${impact.water.effectiveRainfallM3} m³ available</span>
            </div>
          </div>

          <!-- Responsive SVG Water Consumption Visualizer -->
          <div class="space-y-2">
            <div class="flex items-center justify-between text-xs">
              <span class="font-bold text-white flex items-center gap-1.5">
                <span class="w-2 h-2 rounded-full bg-sky-400"></span> Logged Irrigation Runs (m³) vs Conventional Baseline
              </span>
              <span class="text-[11px] font-mono text-gray-400">${impact.water.eventsCount} Logged Runs</span>
            </div>

            <!-- Dynamic SVG Bar Chart -->
            <div class="p-3 rounded-xl bg-gray-950/80 border border-gray-800/80">
              <svg viewBox="0 0 500 120" class="w-full h-28 overflow-visible font-mono text-[9px]">
                <line x1="30" y1="20" x2="480" y2="20" stroke="#1f2937" stroke-dasharray="2,2" />
                <line x1="30" y1="60" x2="480" y2="60" stroke="#1f2937" stroke-dasharray="2,2" />
                <line x1="30" y1="100" x2="480" y2="100" stroke="#374151" />

                <!-- Dynamic Crop-Specific Baseline Line -->
                ${(() => {
                  const baselinePerRun = Math.round(impact.comparativeMatrix.baseline.waterM3 / Math.max(1, impact.water.eventsCount || 6));
                  const maxChartVal = Math.max(baselinePerRun * 1.3, ...((records.irrigationEvents || []).map(e => e.volumeM3 || 0)), 50);
                  const baselineY = Math.round(100 - (baselinePerRun / maxChartVal) * 75);
                  return `
                    <line x1="30" y1="${baselineY}" x2="480" y2="${baselineY}" stroke="#f59e0b" stroke-dasharray="4,4" stroke-width="1.5" />
                    <text x="320" y="${baselineY - 4}" fill="#f59e0b" font-weight="bold">Conv. Baseline Avg (${baselinePerRun} m³/run)</text>
                  `;
                })()}

                <!-- Bars for recorded events -->
                ${(() => {
                  const events = records.irrigationEvents || [];
                  if (events.length === 0) {
                    return `<text x="250" y="60" fill="#9ca3af" text-anchor="middle" font-sans>No irrigation runs logged yet for this farm</text>`;
                  }
                  const baselinePerRun = Math.round(impact.comparativeMatrix.baseline.waterM3 / Math.max(1, events.length));
                  const maxChartVal = Math.max(baselinePerRun * 1.3, ...events.map(e => e.volumeM3 || 0), 50);
                  const step = Math.min(70, Math.floor(420 / events.length));

                  return events.map((e, idx) => {
                    const x = 45 + idx * step;
                    const barH = Math.max(5, Math.min(80, ((e.volumeM3 || 0) / maxChartVal) * 75));
                    const y = 100 - barH;
                    return `
                      <g class="cursor-pointer">
                        <rect x="${x}" y="${y}" width="${Math.min(36, step - 8)}" height="${barH}" rx="4" fill="#0284c7" fill-opacity="0.85" stroke="#38bdf8" stroke-width="1"></rect>
                        <text x="${x + Math.min(18, (step - 8) / 2)}" y="${y - 4}" fill="#ffffff" text-anchor="middle" font-weight="bold">${e.volumeM3}m³</text>
                        <text x="${x + Math.min(18, (step - 8) / 2)}" y="112" fill="#9ca3af" text-anchor="middle">${e.date.slice(5)}</text>
                      </g>
                    `;
                  }).join('');
                })()}
              </svg>
            </div>
          </div>

          <!-- Irrigation Methodology Transparency Note -->
          <div class="p-3 rounded-xl bg-sky-950/30 border border-sky-500/20 text-[11px] text-gray-300 space-y-1">
            <div class="flex items-center gap-1.5 font-bold text-sky-400">
              <i data-lucide="info" class="w-3.5 h-3.5"></i>
              <span>Water Balance Methodology (FAO-56 Penman-Monteith)</span>
            </div>
            <p>
              Calculated using the farm's actual area (${impact.areaHa} ha) and crop (${impact.cropType}). Net irrigation demand 
              is computed as gross crop water requirement (${impact.water.cropETcM3} m³) minus USDA-SCS effective rainfall (${impact.water.effectiveRainfallM3} m³), 
              divided by the ${impact.irrigationType} application efficiency (${impact.irrigationEfficiencyPct}%).
            </p>
          </div>
        </div>

        <!-- SECTION 2: SOIL HEALTH & FERTILIZER OPTIMIZATION -->
        <div class="p-5 rounded-2xl bg-[#081611] border border-[#12372A] space-y-4">
          <div class="flex items-center justify-between border-b border-[#12372A] pb-3">
            <div class="flex items-center gap-2.5">
              <div class="w-8 h-8 rounded-lg bg-emerald-950/70 text-emerald-400 flex items-center justify-center">
                <i data-lucide="sprout" class="w-4 h-4"></i>
              </div>
              <div>
                <h3 class="text-sm font-bold text-white">Soil Chemistry & Fertilizer Stoichiometry</h3>
                <p class="text-xs text-gray-400">Elemental N-P-K nutrient tracking vs ICAR Recommended Dose (RDF)</p>
              </div>
            </div>
            <a href="#/soil" class="text-[11px] font-mono text-emerald-400 hover:underline flex items-center gap-1">
              <span>Soil Health Lab</span>
              <i data-lucide="arrow-up-right" class="w-3.5 h-3.5"></i>
            </a>
          </div>

          <!-- Elemental N-P-K Balance Cards -->
          <div class="grid grid-cols-3 gap-2.5 text-xs">
            <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
              <span class="text-[10px] text-gray-400 uppercase font-mono block">Pure Nitrogen (N)</span>
              <span class="text-base font-extrabold text-emerald-400 font-mono">${impact.soilAndFertilizer.totalN_kg} kg</span>
              <span class="text-[10px] text-gray-400 block">${impact.soilAndFertilizer.nPerHa} kg/ha (RDF: ${impact.soilAndFertilizer.recommendedN_kg} kg)</span>
            </div>
            <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
              <span class="text-[10px] text-gray-400 uppercase font-mono block">Phosphorus (P₂O₅)</span>
              <span class="text-base font-extrabold text-teal-400 font-mono">${impact.soilAndFertilizer.totalP2O5_kg} kg</span>
              <span class="text-[10px] text-gray-400 block">${impact.soilAndFertilizer.pPerHa} kg/ha (RDF: ${impact.soilAndFertilizer.recommendedP_kg} kg)</span>
            </div>
            <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
              <span class="text-[10px] text-gray-400 uppercase font-mono block">Potash (K₂O)</span>
              <span class="text-base font-extrabold text-amber-400 font-mono">${impact.soilAndFertilizer.totalK2O_kg} kg</span>
              <span class="text-[10px] text-gray-400 block">${impact.soilAndFertilizer.kPerHa} kg/ha (RDF: ${impact.soilAndFertilizer.recommendedK_kg} kg)</span>
            </div>
          </div>

          <!-- Fertilizer Application Log Table -->
          <div class="space-y-2">
            <span class="text-xs font-bold text-white block">Logged Fertilizer & Amendment Applications</span>
            <div class="overflow-x-auto max-h-40 overflow-y-auto custom-scrollbar border border-gray-800 rounded-xl">
              <table class="w-full text-left text-xs">
                <thead class="bg-gray-900/90 text-[10px] uppercase font-mono text-gray-400 sticky top-0">
                  <tr>
                    <th class="p-2">Date</th>
                    <th class="p-2">Product</th>
                    <th class="p-2">Quantity</th>
                    <th class="p-2">Method</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-gray-800/60 font-mono text-[11px] text-gray-300">
                  ${(records.fertilizerApplications || []).map(f => `
                    <tr class="hover:bg-gray-900/40">
                      <td class="p-2 text-gray-400">${f.date}</td>
                      <td class="p-2 font-bold text-white uppercase">${f.product.replace(/_/g, ' ')}</td>
                      <td class="p-2 text-emerald-400">${f.quantityKg} kg</td>
                      <td class="p-2 text-gray-300 font-sans">${f.method}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>

          <!-- Soil Audit Status -->
          <div class="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-[11px] text-gray-300 flex items-center justify-between">
            <div>
              <span class="text-emerald-400 font-bold block font-mono">Latest Soil Test: ${impact.soilAndFertilizer.latestSoilTest ? impact.soilAndFertilizer.latestSoilTest.date : 'Not recorded'}</span>
              <span class="text-gray-400">pH: <b>${impact.soilAndFertilizer.latestSoilTest?.ph || 'N/A'}</b> • Organic Carbon: <b>${impact.soilAndFertilizer.latestSoilTest?.organicCarbonPct ? `${impact.soilAndFertilizer.latestSoilTest.organicCarbonPct}%` : 'N/A'}</b></span>
            </div>
            <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-900/60 text-emerald-300 font-mono border border-emerald-500/30">
              ${impact.soilAndFertilizer.latestSoilTest ? 'Audited' : 'Pending'}
            </span>
          </div>
        </div>

      </div>

      <!-- SECTION 3: GREENHOUSE GAS (GHG) EMISSIONS & ENERGY ACCOUNTING -->
      <div class="p-5 rounded-2xl bg-[#081611] border border-[#12372A] space-y-4">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-[#12372A] pb-3">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-teal-950/70 text-teal-400 flex items-center justify-center">
              <i data-lucide="gauge" class="w-4 h-4"></i>
            </div>
            <div>
              <h3 class="text-sm font-bold text-white">Greenhouse Gas (GHG) & Energy Accounting</h3>
              <p class="text-xs text-gray-400">Traceable carbon inventory using IPCC 2019 Refinement & CEA Grid Database v19</p>
            </div>
          </div>
          <div class="flex items-center gap-2 flex-wrap">
            <span class="px-2.5 py-1 rounded-md text-[10px] font-mono bg-teal-950 text-teal-300 border border-teal-500/40">
              Total Farm Footprint: <b class="text-white">${impact.energyAndEmissions.totalFarmEmissionsKgCO2e} kg CO₂e</b>
            </span>
            <span class="px-2.5 py-1 rounded-md text-[10px] font-mono bg-emerald-950 text-[#B7E36A] border border-emerald-500/40">
              ${impact.energyAndEmissions.emissionsAbatedPct >= 0 ? `-${impact.energyAndEmissions.emissionsAbatedPct}%` : `+${Math.abs(impact.energyAndEmissions.emissionsAbatedPct)}%`} vs Baseline
            </span>
          </div>
        </div>

        <!-- 3 Scopes Breakdown Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          
          <!-- Scope 1 -->
          <div class="p-3.5 rounded-xl bg-gray-900/70 border border-gray-800 space-y-1.5">
            <div class="flex items-center justify-between">
              <span class="text-[10px] font-bold font-mono text-teal-400 uppercase">Scope 1: Direct On-Farm</span>
              <span class="text-xs font-mono font-bold text-white">${impact.energyAndEmissions.scope1EmissionsKgCO2e} kg CO₂e</span>
            </div>
            <p class="text-[11px] text-gray-300 leading-relaxed">
              Direct soil N₂O emissions (${impact.energyAndEmissions.directSoilN2O_EmissionsKgCO2e} kg CO₂e) from synthetic N applied 
              ${impact.energyAndEmissions.isFloodedRiceMethaneApplicable ? `plus flooded paddy methane (${impact.energyAndEmissions.riceMethaneEmissionsKgCO2e} kg CO₂e)` : 'plus stationary diesel pumping'}.
            </p>
            <div class="text-[10px] text-gray-500 font-mono">IPCC 2019 Refinement (EF1 = 4.29 kg CO₂e / kg N)</div>
          </div>

          <!-- Scope 2 -->
          <div class="p-3.5 rounded-xl bg-gray-900/70 border border-gray-800 space-y-1.5">
            <div class="flex items-center justify-between">
              <span class="text-[10px] font-bold font-mono text-sky-400 uppercase">Scope 2: Pumping Grid Energy</span>
              <span class="text-xs font-mono font-bold text-white">${impact.energyAndEmissions.scope2EmissionsKgCO2e} kg CO₂e</span>
            </div>
            <p class="text-[11px] text-gray-300 leading-relaxed">
              Indirect emissions from electricity consumed by irrigation pumps (${impact.energyAndEmissions.totalPumpingKWh} kWh).
            </p>
            <div class="text-[10px] text-gray-500 font-mono">Factor: 0.82 kg CO₂e / kWh (CEA India Database v19)</div>
          </div>

          <!-- Scope 3 -->
          <div class="p-3.5 rounded-xl bg-gray-900/70 border border-gray-800 space-y-1.5">
            <div class="flex items-center justify-between">
              <span class="text-[10px] font-bold font-mono text-amber-400 uppercase">Scope 3: Upstream Supply Chain</span>
              <span class="text-xs font-mono font-bold text-white">${impact.energyAndEmissions.scope3EmissionsKgCO2e} kg CO₂e</span>
            </div>
            <p class="text-[11px] text-gray-300 leading-relaxed">
              Embodied energy in Haber-Bosch synthesis, mining, and transport for applied Urea, DAP, and MOP fertilizers.
            </p>
            <div class="text-[10px] text-gray-500 font-mono">DEFRA / UK Gov 2024 Agronomic Database</div>
          </div>

        </div>

        <!-- Comparative Progress Bar -->
        <div class="space-y-1.5 pt-1">
          <div class="flex items-center justify-between text-xs font-mono">
            <span class="text-gray-300">Emissions Intensity Progress:</span>
            <span class="text-[#B7E36A] font-bold">
              ${impact.energyAndEmissions.carbonIntensityKgCO2ePerQtl !== null ? `${impact.energyAndEmissions.carbonIntensityKgCO2ePerQtl} kg CO₂e / Qtl produced` : `${impact.energyAndEmissions.emissionsPerHaKgCO2e} kg CO₂e / ha (Harvest Pending)`}
            </span>
          </div>
          <div class="w-full h-3 bg-gray-900 rounded-full overflow-hidden p-0.5 border border-gray-800">
            <div class="h-full bg-gradient-to-r from-emerald-500 via-[#B7E36A] to-teal-400 rounded-full" style="width: ${Math.min(100, Math.max(15, 100 - impact.energyAndEmissions.emissionsAbatedPct))}%;"></div>
          </div>
          <div class="flex items-center justify-between text-[10px] font-mono text-gray-500">
            <span>0 kg (Net Zero)</span>
            <span>Target: &lt; 20 kg/Qtl</span>
            <span>Conv. Benchmark: ${impact.comparativeMatrix.baseline.totalYieldQuintals > 0 ? (impact.comparativeMatrix.baseline.emissionsKgCO2e / impact.comparativeMatrix.baseline.totalYieldQuintals).toFixed(1) : 'N/A'} kg/Qtl</span>
          </div>
        </div>
      </div>

      <!-- SECTION 4: MULTI-SCENARIO & BASELINE COMPARISON MATRIX -->
      <div class="p-5 rounded-2xl bg-[#081611] border border-[#12372A] space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#12372A] pb-3">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-emerald-950/70 text-[#B7E36A] flex items-center justify-center">
              <i data-lucide="git-compare" class="w-4 h-4"></i>
            </div>
            <div>
              <h3 class="text-sm font-bold text-white">Baseline vs Scenario Comparative Matrix</h3>
              <p class="text-xs text-gray-400">Calibrated specifically to ${impact.cropType} across ${impact.areaHa} ha</p>
            </div>
          </div>
          <span class="text-xs font-mono text-emerald-400">Normalized Geodesic Area</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs border border-gray-800 rounded-xl overflow-hidden">
            <thead class="bg-gray-900 text-[10px] uppercase font-mono text-gray-400">
              <tr>
                <th class="p-3">Resource Indicator</th>
                <th class="p-3 text-amber-300">${impact.comparativeMatrix.baseline.label}</th>
                <th class="p-3 text-white bg-emerald-950/40 border-x border-[#12372A]">Current Farm Record (${impact.irrigationType})</th>
                <th class="p-3 text-emerald-400">Precision Optimal Target</th>
                <th class="p-3 text-right">Net Sustainability Savings</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-gray-800/80 font-mono text-xs">
              
              <!-- Row 1: Irrigation Water -->
              <tr class="hover:bg-gray-900/50">
                <td class="p-3 font-sans font-bold text-gray-200">
                  <div class="flex items-center gap-1.5">
                    <i data-lucide="droplet" class="w-3.5 h-3.5 text-sky-400"></i>
                    <span>Irrigation Water (m³)</span>
                  </div>
                </td>
                <td class="p-3 text-amber-300 font-bold">${impact.comparativeMatrix.baseline.waterM3} m³</td>
                <td class="p-3 text-white font-bold bg-emerald-950/30 border-x border-[#12372A]">${impact.comparativeMatrix.current.waterM3} m³</td>
                <td class="p-3 text-emerald-400 font-bold">${impact.comparativeMatrix.recommendedPrecision.waterM3} m³</td>
                <td class="p-3 text-right font-bold ${impact.water.waterSavedPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}">
                  ${impact.water.waterSavedPct >= 0 ? `-${impact.water.waterSavedM3} m³ (-${impact.water.waterSavedPct}%)` : `+${Math.abs(impact.water.waterSavedM3)} m³ (+${Math.abs(impact.water.waterSavedPct)}%)`}
                </td>
              </tr>

              <!-- Row 2: Synthetic Nitrogen -->
              <tr class="hover:bg-gray-900/50">
                <td class="p-3 font-sans font-bold text-gray-200">
                  <div class="flex items-center gap-1.5">
                    <i data-lucide="test-tube" class="w-3.5 h-3.5 text-emerald-400"></i>
                    <span>Synthetic Nitrogen (kg N)</span>
                  </div>
                </td>
                <td class="p-3 text-amber-300 font-bold">${impact.comparativeMatrix.baseline.nKg} kg</td>
                <td class="p-3 text-white font-bold bg-emerald-950/30 border-x border-[#12372A]">${impact.comparativeMatrix.current.nKg} kg</td>
                <td class="p-3 text-emerald-400 font-bold">${impact.comparativeMatrix.recommendedPrecision.nKg} kg</td>
                <td class="p-3 text-right font-bold ${impact.soilAndFertilizer.nSavedPct >= 0 ? 'text-emerald-400' : 'text-amber-400'}">
                  ${impact.soilAndFertilizer.nSavedPct >= 0 ? `-${impact.soilAndFertilizer.nSavedKg} kg (-${impact.soilAndFertilizer.nSavedPct}%)` : `+${Math.abs(impact.soilAndFertilizer.nSavedKg)} kg`}
                </td>
              </tr>

              <!-- Row 3: Total GHG Footprint -->
              <tr class="hover:bg-gray-900/50">
                <td class="p-3 font-sans font-bold text-gray-200">
                  <div class="flex items-center gap-1.5">
                    <i data-lucide="cloud" class="w-3.5 h-3.5 text-teal-400"></i>
                    <span>GHG Footprint (kg CO₂e)</span>
                  </div>
                </td>
                <td class="p-3 text-amber-300 font-bold">${impact.comparativeMatrix.baseline.emissionsKgCO2e} kg</td>
                <td class="p-3 text-white font-bold bg-emerald-950/30 border-x border-[#12372A]">${impact.comparativeMatrix.current.emissionsKgCO2e} kg</td>
                <td class="p-3 text-emerald-400 font-bold">${impact.comparativeMatrix.recommendedPrecision.emissionsKgCO2e} kg</td>
                <td class="p-3 text-right font-bold ${impact.energyAndEmissions.emissionsAbatedPct >= 0 ? 'text-emerald-400' : 'text-amber-400'}">
                  ${impact.energyAndEmissions.emissionsAbatedPct >= 0 ? `-${impact.energyAndEmissions.emissionsAbatedKgCO2e} kg (-${impact.energyAndEmissions.emissionsAbatedPct}%)` : `+${Math.abs(impact.energyAndEmissions.emissionsAbatedKgCO2e)} kg`}
                </td>
              </tr>

              <!-- Row 4: Harvest Yield -->
              <tr class="hover:bg-gray-900/50">
                <td class="p-3 font-sans font-bold text-gray-200">
                  <div class="flex items-center gap-1.5">
                    <i data-lucide="scale" class="w-3.5 h-3.5 text-amber-400"></i>
                    <span>Harvested Crop Yield (Qtl)</span>
                  </div>
                </td>
                <td class="p-3 text-amber-300 font-bold">${impact.comparativeMatrix.baseline.yieldQtl} Qtl</td>
                <td class="p-3 text-[#B7E36A] font-bold bg-emerald-950/30 border-x border-[#12372A]">${impact.comparativeMatrix.current.yieldQtl !== null ? `${impact.comparativeMatrix.current.yieldQtl} Qtl` : 'Pending'}</td>
                <td class="p-3 text-emerald-400 font-bold">${impact.comparativeMatrix.recommendedPrecision.yieldQtl} Qtl</td>
                <td class="p-3 text-right font-bold ${impact.cropPerformance.yieldDeltaPct !== null ? (impact.cropPerformance.yieldDeltaPct >= 0 ? 'text-emerald-400' : 'text-rose-400') : 'text-gray-400'}">
                  ${impact.cropPerformance.yieldDeltaPct !== null ? (impact.cropPerformance.yieldDeltaPct >= 0 ? `+${impact.cropPerformance.yieldDeltaQtl} Qtl (+${impact.cropPerformance.yieldDeltaPct}%)` : `${impact.cropPerformance.yieldDeltaQtl} Qtl`) : 'Awaiting Harvest'}
                </td>
              </tr>

            </tbody>
          </table>
        </div>
      </div>

      <!-- SECTION 5: MULTI-DIMENSIONAL SUSTAINABILITY INDEX & DATA QUALITY AUDIT -->
      <div class="p-5 rounded-2xl bg-[#081611] border border-[#12372A] space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#12372A] pb-3">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-emerald-950/70 text-[#B7E36A] flex items-center justify-center">
              <i data-lucide="award" class="w-4 h-4"></i>
            </div>
            <div>
              <h3 class="text-sm font-bold text-white">Sustainability Index Dimensional Breakdown</h3>
              <p class="text-xs text-gray-400">Scientific multi-criteria evaluation normalized across 5 agronomic dimensions</p>
            </div>
          </div>
          <span class="text-xs font-mono font-bold" style="color: ${index.badgeColor};">Overall Score: ${index.score} / 100</span>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800 space-y-1">
            <div class="flex items-center justify-between">
              <span class="text-gray-400 font-mono text-[10px]">WATER STEWARDSHIP</span>
              <span class="text-[#B7E36A] font-bold font-mono">${index.subScores.water ?? 70}/100</span>
            </div>
            <div class="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
              <div class="h-full bg-sky-400" style="width: ${index.subScores.water ?? 70}%;"></div>
            </div>
            <p class="text-[10px] text-gray-500">Weight: 25% • FAO-56 duty matching</p>
          </div>

          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800 space-y-1">
            <div class="flex items-center justify-between">
              <span class="text-gray-400 font-mono text-[10px]">NUTRIENT MGMT</span>
              <span class="text-[#B7E36A] font-bold font-mono">${index.subScores.nutrient ?? 70}/100</span>
            </div>
            <div class="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
              <div class="h-full bg-emerald-400" style="width: ${index.subScores.nutrient ?? 70}%;"></div>
            </div>
            <p class="text-[10px] text-gray-500">Weight: 25% • RDF balance & split dose</p>
          </div>

          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800 space-y-1">
            <div class="flex items-center justify-between">
              <span class="text-gray-400 font-mono text-[10px]">CARBON INTENSITY</span>
              <span class="text-[#B7E36A] font-bold font-mono">${index.subScores.emissions ?? 70}/100</span>
            </div>
            <div class="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
              <div class="h-full bg-teal-400" style="width: ${index.subScores.emissions ?? 70}%;"></div>
            </div>
            <p class="text-[10px] text-gray-500">Weight: 20% • IPCC Scopes 1, 2, 3</p>
          </div>

          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800 space-y-1">
            <div class="flex items-center justify-between">
              <span class="text-gray-400 font-mono text-[10px]">SOIL HEALTH</span>
              <span class="text-[#B7E36A] font-bold font-mono">${index.subScores.soil !== undefined ? `${index.subScores.soil}/100` : 'Pending'}</span>
            </div>
            <div class="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
              <div class="h-full bg-amber-400" style="width: ${index.subScores.soil ?? 0}%;"></div>
            </div>
            <p class="text-[10px] text-gray-500">${index.subScores.soil !== undefined ? 'Weight: 15% • OC%, pH & EC' : 'Excluded • Soil audit needed'}</p>
          </div>

          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800 space-y-1">
            <div class="flex items-center justify-between">
              <span class="text-gray-400 font-mono text-[10px]">CROP PRODUCTIVITY</span>
              <span class="text-[#B7E36A] font-bold font-mono">${index.subScores.productivity !== undefined ? `${index.subScores.productivity}/100` : 'Pending'}</span>
            </div>
            <div class="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
              <div class="h-full bg-emerald-500" style="width: ${index.subScores.productivity ?? 0}%;"></div>
            </div>
            <p class="text-[10px] text-gray-500">${index.subScores.productivity !== undefined ? 'Weight: 15% • Water productivity' : 'Excluded • Harvest pending'}</p>
          </div>
        </div>
      </div>

      <!-- SECTION 6: SATELLITE GEOSPATIAL VALIDATION (Sentinel-2 Integration) -->
      <div class="p-5 rounded-2xl bg-[#081611] border border-[#12372A] space-y-4">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#12372A] pb-3">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-emerald-950/70 text-[#B7E36A] flex items-center justify-center">
              <i data-lucide="satellite" class="w-4 h-4"></i>
            </div>
            <div>
              <h3 class="text-sm font-bold text-white">Copernicus Sentinel-2 Geospatial Cross-Validation</h3>
              <p class="text-xs text-gray-400">10m Ground Sample Distance (GSD) surface reflectance integration</p>
            </div>
          </div>
          <a href="#/satellite" class="text-xs font-mono text-[#B7E36A] hover:underline flex items-center gap-1">
            <span>Open Satellite GIS Studio</span>
            <i data-lucide="arrow-up-right" class="w-4 h-4"></i>
          </a>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
            <span class="text-[10px] text-gray-400 uppercase font-mono block">Latest Sentinel-2 Pass</span>
            <span class="text-sm font-bold text-white font-mono">${impact.satelliteContext.date}</span>
            <span class="text-[10px] text-emerald-400 block">${impact.satelliteContext.satellite}</span>
          </div>

          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
            <span class="text-[10px] text-gray-400 uppercase font-mono block">Field Mean NDVI</span>
            <span class="text-base font-extrabold text-[#B7E36A] font-mono">${impact.satelliteContext.meanNDVI ?? 'N/A'}</span>
            <span class="text-[10px] text-gray-400 block">Healthy Developing Canopy</span>
          </div>

          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
            <span class="text-[10px] text-gray-400 uppercase font-mono block">Cloud-Free Pixel Coverage</span>
            <span class="text-base font-extrabold text-white font-mono">${impact.satelliteContext.validCoveragePct}%</span>
            <span class="text-[10px] text-emerald-400 block">High Spectral Fidelity</span>
          </div>

          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
            <span class="text-[10px] text-gray-400 uppercase font-mono block">Detected Stress Clusters</span>
            <span class="text-base font-extrabold text-amber-300 font-mono">${impact.satelliteContext.stressZonesCount} Minor</span>
            <span class="text-[10px] text-gray-400 block">Localized Edge Variance</span>
          </div>
        </div>
      </div>

      <!-- SECTION 7: EXPLAINABLE AI SUSTAINABILITY ADVISOR -->
      <div class="p-5 rounded-2xl bg-[#081611] border border-[#12372A] space-y-4">
        <div class="flex items-center justify-between border-b border-[#12372A] pb-3">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-emerald-950/70 text-[#B7E36A] flex items-center justify-center">
              <i data-lucide="lightbulb" class="w-4 h-4"></i>
            </div>
            <div>
              <h3 class="text-sm font-bold text-white">Explainable AI Sustainability Advisor</h3>
              <p class="text-xs text-gray-400">Deterministic agronomic reasoning explaining resource patterns & actions for ${impact.farmName}</p>
            </div>
          </div>
          <span class="text-[10px] font-mono text-emerald-400 uppercase tracking-wider">Agronomic Rules Engine</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          ${advisorInsights.map(ins => `
            <div class="p-4 rounded-xl bg-gray-900/80 border ${ins.urgency === 'POSITIVE' ? 'border-emerald-500/40' : ins.urgency === 'WARNING' ? 'border-amber-500/40' : 'border-teal-500/30'} space-y-2">
              <div class="flex items-center justify-between">
                <span class="text-[10px] font-mono font-bold uppercase tracking-wider text-emerald-400">${ins.category}</span>
                <span class="px-2 py-0.5 rounded text-[10px] font-bold font-mono ${ins.urgency === 'POSITIVE' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' : ins.urgency === 'WARNING' ? 'bg-amber-950 text-amber-300 border border-amber-500/30' : 'bg-teal-950 text-teal-300 border border-teal-500/30'}">
                  ${ins.urgency}
                </span>
              </div>

              <h4 class="text-xs font-bold text-white">${ins.title}</h4>
              <p class="text-xs text-gray-300 leading-relaxed">${ins.summary}</p>
              
              <div class="p-2.5 rounded-lg bg-gray-950/60 border border-gray-800 text-[11px] space-y-1">
                <div><b class="text-gray-400">Scientific Mechanism:</b> ${ins.agronomicReasoning}</div>
                <div class="text-emerald-300"><b class="text-emerald-400">Action:</b> ${ins.action}</div>
                <div class="text-[10px] text-gray-500 pt-1 border-t border-gray-800/80"><b>Uncertainty:</b> ${ins.uncertainty}</div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>

      <!-- SECTION 8: DATA QUALITY, TRUST & AUDIT PANEL -->
      <div class="p-4 rounded-2xl bg-[#081611] border border-[#12372A] flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs text-gray-400">
        <div class="flex items-center gap-2">
          <i data-lucide="shield-check" class="w-4 h-4 text-[#B7E36A]"></i>
          <span><b>Data Provenance:</b> Dynamically computed from logged irrigation events, stoichiometric NPK weights, and IPCC 2019 Tier 1 emission factors for <b>${impact.farmName}</b>.</span>
        </div>
        <div class="text-[11px] font-mono text-gray-500">
          Last Recalculated: ${impact.calculationTimeFormatted} • Zero Fabricated Live Telemetry
        </div>
      </div>

    </div>

    <!-- MODAL 1: LOG FARM RESOURCE EVENT -->
    <div id="modal-log-resource" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div class="max-w-lg w-full p-6 space-y-4 bg-[#081611] border border-[#16A36A]/50 shadow-2xl rounded-2xl text-xs text-[#F6F8F2]">
        <div class="flex items-center justify-between border-b border-[#12372A] pb-3">
          <div class="flex items-center gap-2">
            <i data-lucide="plus-circle" class="w-5 h-5 text-[#B7E36A]"></i>
            <h3 class="text-base font-bold text-white">Log Farm Resource Event</h3>
          </div>
          <button type="button" id="btn-close-log-modal" class="text-gray-400 hover:text-white p-1 rounded-lg">
            <i data-lucide="x" class="w-5 h-5"></i>
          </button>
        </div>

        <form id="form-log-resource" class="space-y-3.5">
          <div>
            <label class="block text-gray-300 font-semibold mb-1">Target Farm</label>
            <input type="text" value="${farm.name || 'Active Farm'}" disabled class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-gray-400 font-mono" />
          </div>

          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Event Category</label>
              <select id="log-category" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white">
                <option value="irrigation">Irrigation Run</option>
                <option value="fertilizer">Fertilizer Application</option>
                <option value="soil">Soil Chemistry Test</option>
                <option value="harvest">Harvest Record</option>
              </select>
            </div>
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Event Date</label>
              <input type="date" id="log-date" value="${new Date().toISOString().split('T')[0]}" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white font-mono" />
            </div>
          </div>

          <div>
            <label class="block text-gray-300 font-semibold mb-1">Field / Plot Sector</label>
            <input type="text" id="log-field" value="${farm.name ? `${farm.name} (Plot A)` : 'Field Plot A'}" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
          </div>

          <div id="dynamic-log-fields" class="space-y-3">
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-gray-300 font-semibold mb-1">Volume Applied (m³)</label>
                <input type="number" id="log-water-vol" value="35" min="1" step="0.5" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
              </div>
              <div>
                <label class="block text-gray-300 font-semibold mb-1">Duration (Hours)</label>
                <input type="number" id="log-water-duration" value="3.0" min="0.5" step="0.5" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
              </div>
            </div>
          </div>

          <div>
            <label class="block text-gray-300 font-semibold mb-1">Operational Notes (Optional)</label>
            <input type="text" id="log-notes" placeholder="e.g. Regular vegetative maintenance pulse" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
          </div>

          <div class="flex items-center justify-end gap-2 pt-2 border-t border-[#12372A]">
            <button type="button" id="btn-cancel-log" class="px-4 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold text-xs">
              Cancel
            </button>
            <button type="submit" class="px-4 py-2 rounded-xl bg-[#16A36A] hover:bg-emerald-500 text-white font-bold text-xs shadow-md">
              Save Record
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- MODAL 2: CSV RESOURCE IMPORTER WITH VALIDATION PREVIEW -->
    <div id="modal-csv-import" class="hidden fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div class="max-w-xl w-full p-6 space-y-4 bg-[#081611] border border-[#16A36A]/50 shadow-2xl rounded-2xl text-xs text-[#F6F8F2]">
        <div class="flex items-center justify-between border-b border-[#12372A] pb-3">
          <div class="flex items-center gap-2">
            <i data-lucide="upload-cloud" class="w-5 h-5 text-[#B7E36A]"></i>
            <h3 class="text-base font-bold text-white">Import Sustainability Records CSV</h3>
          </div>
          <button type="button" id="btn-close-csv-modal" class="text-gray-400 hover:text-white p-1 rounded-lg">
            <i data-lucide="x" class="w-5 h-5"></i>
          </button>
        </div>

        <p class="text-xs text-gray-300">
          Upload or paste date-stamped agricultural activity logs for <b>${farm.name || 'Active Farm'}</b>. AgroSense validates columns, detects negative values, and previews parsed data before saving.
        </p>

        <div>
          <label class="block text-gray-300 font-semibold mb-1">Paste CSV Content or Drop File</label>
          <textarea id="csv-paste-area" rows="5" placeholder="date,type,value,unit,notes&#10;2026-10-10,irrigation,38,m3,Drip pulse&#10;2026-10-12,fertilizer,40,kg,Urea top-dressing" class="w-full bg-gray-900 border border-gray-700 rounded-xl p-3 text-white font-mono text-xs"></textarea>
        </div>

        <div id="csv-validation-output" class="hidden space-y-2"></div>

        <div class="flex items-center justify-between pt-2 border-t border-[#12372A]">
          <button type="button" id="btn-validate-csv" class="px-4 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-200 font-semibold text-xs">
            Validate CSV
          </button>
          <button type="button" id="btn-commit-csv-import" class="px-4 py-2 rounded-xl bg-[#16A36A] hover:bg-emerald-500 text-white font-bold text-xs shadow-md disabled:opacity-50" disabled>
            Commit Import
          </button>
        </div>
      </div>
    </div>
  `;
}

/**
 * Initialize Interactive Hooks, Filters, Modals, and Exporters
 */
function initSustainabilityHooks(state, setState) {
  const farm = state.activeFarm || {};
  const allFarms = state.farms || [];
  const currentToken = ++activeRequestId;

  // 1. Farm Selector Listener
  const farmSelectEl = document.getElementById('sustainability-farm-selector');
  if (farmSelectEl) {
    farmSelectEl.addEventListener('change', (e) => {
      const selectedId = e.target.value;
      if (selectedId === '__add_new_farm__') {
        window.location.hash = '#/onboarding';
        return;
      }
      const targetFarm = allFarms.find(f => f.id === selectedId);
      if (targetFarm) {
        try {
          localStorage.setItem('agrosense_active_farm_id', targetFarm.id);
        } catch (err) {}

        if (setState) {
          setState({
            activeFarm: targetFarm,
            customSoil: null,
            selectedCropRec: null
          });
        }
      }
    });
  }

  // 2. Baseline Scenario Selector Listener
  const selectBaseline = document.getElementById('select-baseline-scenario');
  if (selectBaseline) {
    selectBaseline.addEventListener('change', (e) => {
      activeBaselineScenario = e.target.value;
      if (setState) setState({});
    });
  }

  // 3. Date Range Filter Listener
  const selectDateRange = document.getElementById('select-date-range');
  if (selectDateRange) {
    selectDateRange.addEventListener('change', (e) => {
      activeDateRange = e.target.value;
      if (setState) setState({});
    });
  }

  // 4. Refresh Action
  const btnRefresh = document.getElementById('btn-refresh-sustainability');
  if (btnRefresh) {
    btnRefresh.addEventListener('click', () => {
      const icon = document.getElementById('sustainability-refresh-icon');
      if (icon) icon.classList.add('animate-spin');
      setTimeout(() => {
        if (setState) setState({});
      }, 250);
    });
  }

  // 5. CSV Export Button
  const btnExportCsv = document.getElementById('btn-export-sustainability-csv');
  if (btnExportCsv) {
    btnExportCsv.addEventListener('click', () => {
      const records = loadFarmSustainabilityRecords(farm);
      const impact = calculateSustainabilityImpact(farm, records, {
        baselineScenario: activeBaselineScenario,
        season: activeSeasonFilter,
        dateRange: activeDateRange
      });
      const csvStr = generateSustainabilityCSV(impact, records);
      const blob = new Blob([csvStr], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `AgroSense_Sustainability_Report_${(farm.name || 'farm').replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
  }

  // 6. Print Report Button
  const btnPrint = document.getElementById('btn-print-sustainability-report');
  if (btnPrint) {
    btnPrint.addEventListener('click', () => {
      window.print();
    });
  }

  // 7. Log Resource Modal Handlers
  const btnOpenLogModal = document.getElementById('btn-open-log-modal');
  const btnCloseLogModal = document.getElementById('btn-close-log-modal');
  const btnCancelLog = document.getElementById('btn-cancel-log');
  const modalLog = document.getElementById('modal-log-resource');
  const formLog = document.getElementById('form-log-resource');
  const logCategory = document.getElementById('log-category');
  const dynamicLogFields = document.getElementById('dynamic-log-fields');

  if (btnOpenLogModal && modalLog) {
    btnOpenLogModal.addEventListener('click', () => modalLog.classList.remove('hidden'));
  }
  if (btnCloseLogModal && modalLog) {
    btnCloseLogModal.addEventListener('click', () => modalLog.classList.add('hidden'));
  }
  if (btnCancelLog && modalLog) {
    btnCancelLog.addEventListener('click', () => modalLog.classList.add('hidden'));
  }

  // Category switch in log form
  if (logCategory && dynamicLogFields) {
    logCategory.addEventListener('change', (e) => {
      const cat = e.target.value;
      if (cat === 'irrigation') {
        dynamicLogFields.innerHTML = `
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Volume Applied (m³)</label>
              <input type="number" id="log-water-vol" value="35" min="1" step="0.5" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
            </div>
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Duration (Hours)</label>
              <input type="number" id="log-water-duration" value="3.0" min="0.5" step="0.5" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
            </div>
          </div>
        `;
      } else if (cat === 'fertilizer') {
        dynamicLogFields.innerHTML = `
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Product</label>
              <select id="log-fert-prod" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white">
                <option value="urea">Urea (46% N)</option>
                <option value="dap">DAP (18% N, 46% P₂O₅)</option>
                <option value="mop">MOP (60% K₂O)</option>
                <option value="npk_10_26_26">NPK 10:26:26</option>
                <option value="vermicompost">Organic Vermicompost</option>
              </select>
            </div>
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Quantity Applied (kg)</label>
              <input type="number" id="log-fert-qty" value="30" min="1" step="1" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
            </div>
          </div>
        `;
      } else if (cat === 'soil') {
        dynamicLogFields.innerHTML = `
          <div class="grid grid-cols-3 gap-2">
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Soil pH</label>
              <input type="number" id="log-soil-ph" value="6.8" min="3" max="10" step="0.1" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
            </div>
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Available N (kg/ha)</label>
              <input type="number" id="log-soil-n" value="230" min="50" max="600" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
            </div>
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Organic C (%)</label>
              <input type="number" id="log-soil-oc" value="0.60" min="0.1" max="3.0" step="0.05" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
            </div>
          </div>
        `;
      } else if (cat === 'harvest') {
        dynamicLogFields.innerHTML = `
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Harvest Yield (Quintals)</label>
              <input type="number" id="log-harvest-yield" value="32.5" min="1" step="0.1" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
            </div>
            <div>
              <label class="block text-gray-300 font-semibold mb-1">Market Rate (₹/Qtl)</label>
              <input type="number" id="log-harvest-rate" value="4800" min="500" step="50" class="w-full bg-gray-900 border border-gray-700 rounded-xl px-3 py-2 text-white" />
            </div>
          </div>
        `;
      }
    });
  }

  // Form submission: save to records and reload
  if (formLog && modalLog) {
    formLog.addEventListener('submit', (e) => {
      e.preventDefault();
      const records = loadFarmSustainabilityRecords(farm);
      const cat = logCategory?.value || 'irrigation';
      const date = document.getElementById('log-date')?.value || new Date().toISOString().split('T')[0];
      const field = document.getElementById('log-field')?.value || farm.name || 'Primary Plot';
      const notes = document.getElementById('log-notes')?.value || '';

      if (cat === 'irrigation') {
        const volumeM3 = parseFloat(document.getElementById('log-water-vol')?.value || '30');
        const durationHours = parseFloat(document.getElementById('log-water-duration')?.value || '2.5');
        records.irrigationEvents.push({
          id: `irr-${Date.now()}`,
          date,
          field,
          method: farm.irrigationType?.toLowerCase().includes('sprinkler') ? 'sprinkler' : farm.irrigationType?.toLowerCase().includes('flood') ? 'flood' : 'drip',
          volumeM3,
          durationHours,
          pumpHp: 5,
          energyType: 'grid',
          notes
        });
      } else if (cat === 'fertilizer') {
        const product = document.getElementById('log-fert-prod')?.value || 'urea';
        const quantityKg = parseFloat(document.getElementById('log-fert-qty')?.value || '25');
        records.fertilizerApplications.push({
          id: `fert-${Date.now()}`,
          date,
          field,
          product,
          quantityKg,
          method: 'Fertigation Drip Split',
          notes
        });
      } else if (cat === 'soil') {
        const ph = parseFloat(document.getElementById('log-soil-ph')?.value || '6.8');
        const nKgHa = parseFloat(document.getElementById('log-soil-n')?.value || '220');
        const organicCarbonPct = parseFloat(document.getElementById('log-soil-oc')?.value || '0.62');
        records.soilTests.push({
          id: `st-${Date.now()}`,
          date,
          lab: 'Krishi Vigyan Kendra Soil Testing Lab',
          ph,
          nKgHa,
          pKgHa: 30,
          kKgHa: 250,
          organicCarbonPct,
          ecDsM: 0.35,
          notes
        });
      } else if (cat === 'harvest') {
        const yieldQuintals = parseFloat(document.getElementById('log-harvest-yield')?.value || '35.0');
        const marketRatePerQtl = parseFloat(document.getElementById('log-harvest-rate')?.value || '4500');
        records.harvestRecords.push({
          id: `hr-${Date.now()}`,
          season: 'Current Season Harvest',
          crop: farm.crop || farm.currentCrop || 'Field Crop',
          areaAcres: farm.sizeAcres || 2.5,
          yieldQuintals,
          marketRatePerQtl,
          totalCostRs: 28000,
          irrigationType: farm.irrigationType || 'Drip Irrigation',
          notes
        });
      }

      saveFarmSustainabilityRecords(farm.id, records);
      modalLog.classList.add('hidden');
      if (setState) setState({});
    });
  }

  // 8. CSV Import Modal Handlers
  const btnOpenCsv = document.getElementById('btn-open-csv-modal');
  const btnCloseCsv = document.getElementById('btn-close-csv-modal');
  const modalCsv = document.getElementById('modal-csv-import');
  const btnValidateCsv = document.getElementById('btn-validate-csv');
  const btnCommitCsv = document.getElementById('btn-commit-csv-import');
  const csvArea = document.getElementById('csv-paste-area');
  const csvOutput = document.getElementById('csv-validation-output');

  let parsedImportRecords = [];

  if (btnOpenCsv && modalCsv) {
    btnOpenCsv.addEventListener('click', () => modalCsv.classList.remove('hidden'));
  }
  if (btnCloseCsv && modalCsv) {
    btnCloseCsv.addEventListener('click', () => modalCsv.classList.add('hidden'));
  }

  if (btnValidateCsv && csvArea && csvOutput) {
    btnValidateCsv.addEventListener('click', () => {
      const content = csvArea.value.trim();
      if (!content) {
        csvOutput.className = 'p-3 rounded-xl bg-amber-950/60 border border-amber-600/40 text-amber-300 font-mono text-[11px]';
        csvOutput.textContent = 'Please paste CSV content before validating.';
        csvOutput.classList.remove('hidden');
        return;
      }

      const res = parseAndValidateResourceCSV(content);
      csvOutput.classList.remove('hidden');

      if (res.success) {
        parsedImportRecords = res.records;
        csvOutput.className = 'p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-mono text-[11px] space-y-1';
        csvOutput.innerHTML = `
          <div class="font-bold flex items-center gap-1.5 text-white">
            <i data-lucide="check-circle" class="w-4 h-4 text-emerald-400"></i>
            CSV Validated Successfully (${res.totalParsed} records verified)
          </div>
          <div>All rows adhere to date and positive numeric quantity formats. Ready to commit into ${farm.name || 'Active Farm'}.</div>
        `;
        if (btnCommitCsv) btnCommitCsv.disabled = false;
      } else {
        parsedImportRecords = [];
        csvOutput.className = 'p-3 rounded-xl bg-rose-950/60 border border-rose-600/40 text-rose-300 font-mono text-[11px] space-y-1';
        csvOutput.innerHTML = `
          <div class="font-bold flex items-center gap-1.5 text-white">
            <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-400"></i>
            Validation Failed:
          </div>
          <ul class="list-disc pl-4 space-y-0.5">
            ${res.errors.map(err => `<li>${err}</li>`).join('')}
          </ul>
        `;
        if (btnCommitCsv) btnCommitCsv.disabled = true;
      }

      if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
      }
    });
  }

  if (btnCommitCsv && modalCsv) {
    btnCommitCsv.addEventListener('click', () => {
      if (parsedImportRecords.length === 0) return;
      const records = loadFarmSustainabilityRecords(farm);

      parsedImportRecords.forEach(rec => {
        if (rec.type === 'irrigation') {
          records.irrigationEvents.push({
            id: `irr-import-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            date: rec.date,
            field: farm.name || 'Plot Sector',
            method: 'drip',
            volumeM3: rec.value,
            durationHours: Number((rec.value / 12).toFixed(1)),
            pumpHp: 5,
            energyType: 'grid',
            notes: 'Imported via CSV ledger batch'
          });
        } else if (rec.type === 'fertilizer') {
          records.fertilizerApplications.push({
            id: `fert-import-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
            date: rec.date,
            field: farm.name || 'Plot Sector',
            product: 'urea',
            quantityKg: rec.value,
            method: 'Fertigation Drip Split',
            notes: 'Imported via CSV ledger batch'
          });
        }
      });

      saveFarmSustainabilityRecords(farm.id, records);
      modalCsv.classList.add('hidden');
      if (setState) setState({});
    });
  }
}

/* Module Exports */
exports.renderSustainabilityDashboardPage = renderSustainabilityDashboardPage; exports.initSustainabilityHooks = initSustainabilityHooks;
