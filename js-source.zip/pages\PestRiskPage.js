// AgroSense Pest & Disease Microclimate Risk Matrix Page Component

function renderPestRiskPage(state) {
  const farm = state.activeFarm;

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="bug" class="w-6 h-6 text-amber-400"></i>
            Pest & Microclimate Disease Risk Matrix
          </h1>
          <p class="text-xs text-gray-400">Combines ambient relative humidity, canopy temperature, and crop growth stage for predictive disease forecasting</p>
        </div>
        <span class="prototype-badge">PREDICTIVE RISK MATRIX</span>
      </div>

      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div class="glass-card p-6 space-y-3 border-l-4 border-l-amber-500">
          <div class="flex items-center justify-between">
            <h3 class="text-base font-bold text-white">Wheat Leaf Rust (Puccinia triticina)</h3>
            <span class="px-2.5 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">MEDIUM RISK</span>
          </div>
          <p class="text-xs text-gray-300">Humidity at ${farm.soil.humidity}% with nighttime temperatures of 19°C creates moderate spore germination conditions.</p>
          <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-xs">
            <b class="text-emerald-300 block mb-0.5">Scouting Action:</b>
            <p class="text-gray-300">Inspect lower leaf lamina twice weekly during tillering stage.</p>
          </div>
        </div>

        <div class="glass-card p-6 space-y-3 border-l-4 border-l-emerald-500">
          <div class="flex items-center justify-between">
            <h3 class="text-base font-bold text-white">Fall Armyworm (Spodoptera frugiperda)</h3>
            <span class="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">LOW RISK</span>
          </div>
          <p class="text-xs text-gray-300">Current ambient temperatures and low moth trap counts indicate minimal pest pressure.</p>
          <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 text-xs">
            <b class="text-emerald-300 block mb-0.5">Scouting Action:</b>
            <p class="text-gray-300">Maintain standard pheromone trap monitoring.</p>
          </div>
        </div>
      </div>
    </div>
  `;
}

/* Module Exports */
exports.renderPestRiskPage = renderPestRiskPage;
