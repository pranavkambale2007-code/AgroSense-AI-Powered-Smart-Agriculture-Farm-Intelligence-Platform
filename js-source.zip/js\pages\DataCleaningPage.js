// AGROSENSE INTERACTIVE DATA CLEANING & PREPROCESSING PLAYGROUND (/#/data-cleaning)

import { calculateDatasetStats, performDataCleaning } from '../ml/fodsMLEngine.js';
import { sampleAgrosenseDataset } from '../data/agrosenseDataset.js';

export function renderDataCleaningPage(state) {
  const dataset = state.customDataset || sampleAgrosenseDataset;

  const statsBefore = calculateDatasetStats(dataset);
  const cleaningResult = performDataCleaning(dataset, {
    imputeMissing: state.isImputed !== false,
    imputeStrategy: state.imputeStrategy || 'median',
    removeDuplicates: state.isDuplicatesPurged !== false,
    capOutliers: state.isOutliersCapped !== false
  });
  const statsAfter = cleaningResult.statsAfter;

  return `
    <div class="space-y-8 max-w-7xl mx-auto py-2">
      <!-- Page Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-extrabold text-white tracking-tight">Interactive Data Cleaning & Transformation Playground</h1>
            <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">PREPROCESSING PIPELINE</span>
          </div>
          <p class="text-xs text-gray-400 mt-1">Impute missing values, purge duplicates, cap outliers using 1.5x IQR limits, and scale numerical features</p>
        </div>
      </div>

      <!-- Controls & Strategy Selectors -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Missing Value Imputation Card -->
        <div class="glass-card p-6 space-y-4 border-t-4 border-t-amber-500">
          <div class="flex items-center gap-2">
            <i data-lucide="help-circle" class="w-5 h-5 text-amber-400"></i>
            <h3 class="text-sm font-bold text-white">Missing Value Imputation</h3>
          </div>
          <p class="text-xs text-gray-400">Select imputation strategy for null or NaN values</p>
          <select id="select-impute-strategy" class="w-full bg-gray-900 border border-gray-700 rounded-xl p-2.5 text-xs text-gray-200">
            <option value="median" ${state.imputeStrategy === 'median' ? 'selected' : ''}>Median Imputation (Robust to Outliers)</option>
            <option value="mean" ${state.imputeStrategy === 'mean' ? 'selected' : ''}>Mean Imputation (Standard Normal)</option>
          </select>
          <button id="btn-run-imputation" class="w-full py-2 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold hover:bg-amber-500/30 transition">
            Apply Imputation
          </button>
        </div>

        <!-- Duplicate Removal Card -->
        <div class="glass-card p-6 space-y-4 border-t-4 border-t-blue-500">
          <div class="flex items-center gap-2">
            <i data-lucide="copy" class="w-5 h-5 text-blue-400"></i>
            <h3 class="text-sm font-bold text-white">Duplicate Record Purging</h3>
          </div>
          <p class="text-xs text-gray-400">Detect and remove exact duplicate rows</p>
          <div class="p-3 rounded-lg bg-gray-900 border border-gray-800 text-xs font-mono text-gray-300">
            Duplicates Found: <span class="text-blue-400 font-bold">${statsBefore.duplicateCount}</span>
          </div>
          <button id="btn-purge-duplicates" class="w-full py-2 rounded-xl bg-blue-500/20 text-blue-300 border border-blue-500/40 text-xs font-bold hover:bg-blue-500/30 transition">
            Purge Duplicate Rows
          </button>
        </div>

        <!-- Outlier Capping Card -->
        <div class="glass-card p-6 space-y-4 border-t-4 border-t-emerald-500">
          <div class="flex items-center gap-2">
            <i data-lucide="shield-alert" class="w-5 h-5 text-emerald-400"></i>
            <h3 class="text-sm font-bold text-white">1.5x IQR Outlier Winsorization</h3>
          </div>
          <p class="text-xs text-gray-400">Cap values beyond [Q1 - 1.5 IQR, Q3 + 1.5 IQR]</p>
          <div class="p-3 rounded-lg bg-gray-900 border border-gray-800 text-xs font-mono text-gray-300">
            Outliers Detected: <span class="text-emerald-400 font-bold">${statsBefore.outlierPct}%</span>
          </div>
          <button id="btn-cap-outliers" class="w-full py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold hover:bg-emerald-500/30 transition">
            Apply IQR Winsorization
          </button>
        </div>
      </div>

      <!-- Before vs After Comparison Table -->
      <div class="glass-card p-6 space-y-4">
        <h3 class="text-sm font-bold text-white flex items-center gap-2">
          <i data-lucide="arrow-left-right" class="w-4 h-4 text-emerald-400"></i>
          Before vs After Data Cleaning Metrics
        </h3>

        <div class="overflow-x-auto rounded-xl border border-emerald-950/60">
          <table class="w-full text-left text-xs font-mono">
            <thead class="bg-[#0b1c16] text-emerald-400 uppercase text-[10px] tracking-wider border-b border-emerald-950">
              <tr>
                <th class="p-3">Dataset Metric</th>
                <th class="p-3">Raw Dataset (Before)</th>
                <th class="p-3">Cleaned Dataset (After)</th>
                <th class="p-3">Status Improvement</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-emerald-950/40 text-gray-300">
              <tr>
                <td class="p-3 font-bold text-white">Total Rows</td>
                <td class="p-3">${statsBefore.totalRows}</td>
                <td class="p-3 text-emerald-300 font-bold">${statsAfter.totalRows}</td>
                <td class="p-3"><span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px]">VERIFIED</span></td>
              </tr>
              <tr>
                <td class="p-3 font-bold text-white">Missing Values</td>
                <td class="p-3 text-amber-400">${statsBefore.missingCount} (${statsBefore.missingPct}%)</td>
                <td class="p-3 text-emerald-300 font-bold">${statsAfter.missingCount} (0%)</td>
                <td class="p-3"><span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px]">100% IMPUTED</span></td>
              </tr>
              <tr>
                <td class="p-3 font-bold text-white">Duplicate Records</td>
                <td class="p-3 text-blue-400">${statsBefore.duplicateCount}</td>
                <td class="p-3 text-emerald-300 font-bold">${statsAfter.duplicateCount}</td>
                <td class="p-3"><span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px]">PURGED</span></td>
              </tr>
              <tr>
                <td class="p-3 font-bold text-white">Outlier Ratio</td>
                <td class="p-3 text-teal-400">${statsBefore.outlierPct}%</td>
                <td class="p-3 text-emerald-300 font-bold">${statsAfter.outlierPct}%</td>
                <td class="p-3"><span class="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px]">CAPPED</span></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
}

export function initDataCleaningHooks(state, setState) {
  const imputeBtn = document.getElementById('btn-run-imputation');
  const strategySelect = document.getElementById('select-impute-strategy');
  if (imputeBtn && strategySelect) {
    imputeBtn.addEventListener('click', () => {
      setState({ isImputed: true, imputeStrategy: strategySelect.value });
    });
  }

  const purgeBtn = document.getElementById('btn-purge-duplicates');
  if (purgeBtn) {
    purgeBtn.addEventListener('click', () => {
      setState({ isDuplicatesPurged: true });
    });
  }

  const capBtn = document.getElementById('btn-cap-outliers');
  if (capBtn) {
    capBtn.addEventListener('click', () => {
      setState({ isOutliersCapped: true });
    });
  }
}
