// AgroSense Comprehensive Crop Lifecycle, Water, Spray, Harvest & Mandi Monitor Component
// Covers 5 actionable biological farmer stages:
// 1. When Seed Sows (Sowing & Germination Phase)
// 2. When Water Gives (Vegetative Growth & Critical Irrigation Phase)
// 3. When Pesticide Spray (Flowering & Pest Defense Phase)
// 4. When Cut Crops (Physiological Maturity & Harvesting Phase)
// 5. When & Where to Sell to Local Mandi (Post-Harvest & Mandi Realization Phase)

import { cropLifecycleDatabase, calculateDynamicCropCalendar } from '../data/cropLifecycleData.js';

/**
 * Renders the 5-Stage Crop Lifecycle Monitor Section
 * @param {string} cropKey - Key of the crop (wheat, maize, tomato, chilli, potato, rice, cotton, grapes, groundnut, apple, etc.)
 * @param {string} sowingDateStr - ISO date string (YYYY-MM-DD)
 * @param {object} options - Configuration options { isEmbedded: boolean, activeStage: string|number }
 */
export function renderCropLifecycleMonitor(cropKey = 'wheat', sowingDateStr = null, options = {}) {
  const effectiveCropKey = cropLifecycleDatabase[cropKey] ? cropKey : 'wheat';
  const effectiveSowingDate = sowingDateStr || new Date(Date.now() - 30 * 86400000).toISOString().split('T')[0];
  const calendarData = calculateDynamicCropCalendar(effectiveCropKey, effectiveSowingDate);
  const crop = calendarData.crop;
  const isEmbedded = options.isEmbedded || false;
  // Default to 'all' so farmers can see all 5 biological stages in full!
  const activeStage = options.activeStage || 'all';

  const sowingDate = new Date(effectiveSowingDate);
  const now = Date.now();
  const daysSinceSowing = Math.max(0, Math.floor((now - sowingDate.getTime()) / 86400000));
  const T = crop.totalDurationDays || 120;

  // Calculate phenological limits for each biological stage
  const stage1End = Math.min(10, Math.max(7, Math.floor(T * 0.10)));
  const stage2End = Math.floor(T * 0.45);
  const stage3End = Math.floor(T * 0.75);
  const stage4End = T;

  let currentStageNumber = 1;
  let currentStageName = "Stage 1: Sowing & Germination Phase";
  if (daysSinceSowing > T) {
    currentStageNumber = 5;
    currentStageName = "Stage 5: Post-Harvest & Local Mandi Realization";
  } else if (daysSinceSowing > stage3End) {
    currentStageNumber = 4;
    currentStageName = "Stage 4: Physiological Maturity & Harvest Phase";
  } else if (daysSinceSowing > stage2End) {
    currentStageNumber = 3;
    currentStageName = "Stage 3: Flowering & Crop Defense Phase";
  } else if (daysSinceSowing > stage1End) {
    currentStageNumber = 2;
    currentStageName = "Stage 2: Vegetative Growth & Irrigation Phase";
  }

  const biologicalStagesInfo = [
    {
      stage: 1,
      num: "Stage 1",
      icon: "🌱",
      title: "1. When Seed Sows",
      subName: "Sowing & Germination",
      biologicalFocus: "Imbibition, radicle protrusion, coleoptile emergence & seedbed root anchoring",
      dasLabel: `DAS 0 – ${stage1End}`,
      maxDas: stage1End,
      badgeText: daysSinceSowing > stage1End ? "COMPLETED" : (currentStageNumber === 1 ? "ACTIVE NOW" : "UPCOMING")
    },
    {
      stage: 2,
      num: "Stage 2",
      icon: "💧",
      title: "2. When Water Gives",
      subName: "Vegetative & Irrigation",
      biologicalFocus: "Crown root initiation, tillering, stem elongation & nodal water uptake",
      dasLabel: `DAS ${stage1End + 1} – ${stage2End}`,
      maxDas: stage2End,
      badgeText: daysSinceSowing > stage2End ? "COMPLETED" : (currentStageNumber === 2 ? "ACTIVE NOW" : (daysSinceSowing <= stage1End ? "UPCOMING" : "ACTIVE NOW"))
    },
    {
      stage: 3,
      num: "Stage 3",
      icon: "🧪",
      title: "3. When Pesticide Spray",
      subName: "Flowering & Crop Defense",
      biologicalFocus: "Panicle heading, anthesis, floral pollination & foliar pathogen defense",
      dasLabel: `DAS ${stage2End + 1} – ${stage3End}`,
      maxDas: stage3End,
      badgeText: daysSinceSowing > stage3End ? "COMPLETED" : (currentStageNumber === 3 ? "ACTIVE NOW" : "UPCOMING")
    },
    {
      stage: 4,
      num: "Stage 4",
      icon: "🌾",
      title: "4. When Cut Crops",
      subName: "Maturity & Harvesting",
      biologicalFocus: "Grain/fruit filling, chlorophyll senescence, moisture reduction & harvest cut",
      dasLabel: `DAS ${stage3End + 1} – ${stage4End}`,
      maxDas: stage4End,
      badgeText: daysSinceSowing > stage4End ? "COMPLETED" : (currentStageNumber === 4 ? "ACTIVE NOW" : "UPCOMING")
    },
    {
      stage: 5,
      num: "Stage 5",
      icon: "🏛️",
      title: "5. Sell to Local Mandi",
      subName: "Post-Harvest & Mandi",
      biologicalFocus: "Produce sun-drying (<12% moisture), Grade A sorting, MSP & APMC mandi sale",
      dasLabel: `DAS ${stage4End + 1}+`,
      maxDas: 9999,
      badgeText: daysSinceSowing > stage4End ? "ACTIVE NOW" : "UPCOMING"
    }
  ];

  const allCropCategories = [
    {
      category: "🌾 Cereals & Millets",
      crops: [
        { key: 'wheat', name: 'Wheat', icon: '🌾' },
        { key: 'rice', name: 'Paddy / Rice', icon: '🌾' },
        { key: 'maize', name: 'Maize / Corn', icon: '🌽' },
        { key: 'barley', name: 'Barley', icon: '🌾' },
        { key: 'jowar', name: 'Sorghum / Jowar', icon: '🌾' },
        { key: 'bajra', name: 'Pearl Millet / Bajra', icon: '🌾' },
        { key: 'ragi', name: 'Finger Millet / Ragi', icon: '🌾' }
      ]
    },
    {
      category: "🌱 Pulses & Legumes",
      crops: [
        { key: 'chickpea', name: 'Chickpea / Bengal Gram', icon: '🌰' },
        { key: 'pigeon-pea', name: 'Pigeon Pea / Red Gram', icon: '🌱' },
        { key: 'green-gram', name: 'Green Gram / Moong', icon: '🌱' },
        { key: 'black-gram', name: 'Black Gram / Urad', icon: '🌱' },
        { key: 'soybean', name: 'Soybean', icon: '🟤' }
      ]
    },
    {
      category: "🌻 Oilseeds",
      crops: [
        { key: 'mustard', name: 'Mustard / Rapeseed', icon: '🟡' },
        { key: 'groundnut', name: 'Groundnut / Peanut', icon: '🥜' },
        { key: 'sunflower', name: 'Sunflower', icon: '🌻' },
        { key: 'sesame', name: 'Sesame', icon: '⚪' }
      ]
    },
    {
      category: "💰 Cash & Plantation Crops",
      crops: [
        { key: 'sugarcane', name: 'Sugarcane', icon: '🍬' },
        { key: 'cotton', name: 'Cotton', icon: '☁️' },
        { key: 'tea', name: 'Tea', icon: '🍵' },
        { key: 'coffee', name: 'Coffee', icon: '☕' },
        { key: 'coconut', name: 'Coconut', icon: '🥥' }
      ]
    },
    {
      category: "🥦 Vegetables",
      crops: [
        { key: 'tomato', name: 'Tomato', icon: '🍅' },
        { key: 'potato', name: 'Potato', icon: '🥔' },
        { key: 'onion', name: 'Onion', icon: '🧅' },
        { key: 'garlic', name: 'Garlic', icon: '🧄' },
        { key: 'brinjal', name: 'Brinjal / Eggplant', icon: '🍆' },
        { key: 'okra', name: 'Okra / Ladyfinger', icon: '🥬' },
        { key: 'chilli', name: 'Green Chilli', icon: '🌶️' },
        { key: 'cauliflower', name: 'Cauliflower', icon: '🥦' },
        { key: 'watermelon', name: 'Watermelon', icon: '🍉' }
      ]
    },
    {
      category: "🍎 Fruits & Orchards",
      crops: [
        { key: 'banana', name: 'Banana', icon: '🍌' },
        { key: 'mango', name: 'Mango', icon: '🥭' },
        { key: 'grapes', name: 'Grapes', icon: '🍇' },
        { key: 'apple', name: 'Apple', icon: '🍎' }
      ]
    },
    {
      category: "🌿 Spices & Condiments",
      crops: [
        { key: 'turmeric', name: 'Turmeric', icon: '🟡' },
        { key: 'ginger', name: 'Ginger', icon: '🟤' },
        { key: 'coriander', name: 'Coriander', icon: '🌿' },
        { key: 'cumin', name: 'Cumin', icon: '🌿' }
      ]
    }
  ];

  const quickChips = [
    { key: 'wheat', name: 'Wheat', icon: '🌾' },
    { key: 'rice', name: 'Rice', icon: '🌾' },
    { key: 'maize', name: 'Maize', icon: '🌽' },
    { key: 'sugarcane', name: 'Sugarcane', icon: '🍬' },
    { key: 'cotton', name: 'Cotton', icon: '☁️' },
    { key: 'soybean', name: 'Soybean', icon: '🟤' },
    { key: 'mustard', name: 'Mustard', icon: '🟡' },
    { key: 'chickpea', name: 'Chana', icon: '🌰' },
    { key: 'onion', name: 'Onion', icon: '🧅' },
    { key: 'tomato', name: 'Tomato', icon: '🍅' },
    { key: 'potato', name: 'Potato', icon: '🥔' },
    { key: 'chilli', name: 'Chilli', icon: '🌶️' },
    { key: 'banana', name: 'Banana', icon: '🍌' },
    { key: 'mango', name: 'Mango', icon: '🥭' },
    { key: 'turmeric', name: 'Turmeric', icon: '🟡' }
  ];

  return `
    <div class="crop-lifecycle-monitor-wrapper space-y-6 ${isEmbedded ? 'mt-8 pt-6 border-t-2 border-emerald-800/60' : ''}">
      <!-- Monitor Header Banner -->
      <div class="p-5 rounded-2xl bg-gradient-to-r from-emerald-950 via-teal-950 to-black border border-emerald-500/50 shadow-xl space-y-4">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div class="space-y-1">
            <div class="flex items-center gap-2">
              <span class="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                5-STAGE PRECISION BIOLOGICAL CALENDAR
              </span>
              <span class="text-xs font-mono text-gray-400">• Total Duration: <strong class="text-white">${crop.totalDurationDays} Days</strong></span>
            </div>
            <h2 class="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
              <i data-lucide="calendar-clock" class="w-6 h-6 text-emerald-400 shrink-0"></i>
              <span>Crop Lifecycle, Irrigation, Spray, Harvest & Mandi Monitor</span>
            </h2>
            <p class="text-xs text-gray-300">
              Personalized 5-stage biological schedule for <strong class="text-emerald-300">${crop.cropName}</strong> (${crop.season} Season).
            </p>
          </div>

          <!-- Sowing Date Controller & Dynamic Recalculation -->
          <div class="flex flex-wrap items-center gap-3 bg-black/60 p-3 rounded-xl border border-emerald-800/60">
            <div>
              <label for="lifecycle-sowing-date" class="block text-[11px] font-mono text-emerald-300 font-bold mb-1">
                🌱 Sowing Date:
              </label>
              <input 
                type="date" 
                id="lifecycle-sowing-date" 
                value="${calendarData.sowingDateStr}" 
                class="px-3 py-1.5 rounded-lg bg-emerald-950/80 text-white text-xs font-mono border border-emerald-600 focus:outline-none focus:border-emerald-400 cursor-pointer"
              />
            </div>
            <div class="pt-4 sm:pt-0">
              <button 
                type="button" 
                id="btn-recalculate-calendar" 
                class="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold font-mono transition cursor-pointer flex items-center gap-1.5 shadow"
              >
                <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i>
                <span>Recalculate</span>
              </button>
            </div>
          </div>
        </div>

        <!-- All Crops Selector & Quick Chips -->
        <div class="space-y-2 pt-2 border-t border-emerald-900/60">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div class="text-[11px] font-mono text-gray-300 font-bold flex items-center gap-1.5">
              <i data-lucide="sprout" class="w-3.5 h-3.5 text-emerald-400"></i>
              <span>Select Any Crop to View Complete 5 Biological Stages & Mandi Schedule:</span>
            </div>
            <!-- All Crops Dropdown Select -->
            <div class="flex items-center gap-1.5">
              <span class="text-[10px] text-gray-400 font-mono">All Crops:</span>
              <select id="lifecycle-crop-select" class="px-3 py-1.5 rounded-xl bg-gray-900 border border-emerald-600/60 text-white font-mono font-bold text-xs focus:outline-none focus:border-emerald-400 cursor-pointer">
                ${allCropCategories.map(cat => `
                  <optgroup label="${cat.category}" class="bg-gray-950 font-bold text-emerald-400">
                    ${cat.crops.map(c => `
                      <option value="${c.key}" ${effectiveCropKey === c.key ? 'selected' : ''} class="bg-gray-900 text-white font-medium">
                        ${c.icon} ${c.name}
                      </option>
                    `).join('')}
                  </optgroup>
                `).join('')}
              </select>
            </div>
          </div>

          <!-- Quick 1-Click Chips -->
          <div class="flex flex-wrap gap-1.5">
            ${quickChips.map(c => `
              <button 
                type="button" 
                data-lifecycle-crop="${c.key}" 
                class="lifecycle-crop-chip px-2.5 py-1 rounded-lg text-xs font-mono transition cursor-pointer border ${
                  effectiveCropKey === c.key
                    ? 'bg-emerald-700 text-white font-bold border-emerald-400 shadow-sm'
                    : 'bg-emerald-950/60 text-gray-300 hover:text-white border-emerald-800/50 hover:bg-emerald-900'
                }"
              >
                ${c.icon} ${c.name}
              </button>
            `).join('')}
          </div>
        </div>
      </div>

      <!-- UNIFIED 5-STAGE BIOLOGICAL PROGRESSION OVERVIEW & INTERACTIVE STEPPER -->
      <div class="glass-card p-5 space-y-4 border border-emerald-500/40 shadow-xl bg-gradient-to-br from-emerald-950/70 via-black to-teal-950/50">
        <div class="flex flex-wrap items-center justify-between gap-3 border-b border-emerald-900/60 pb-3">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-lg shadow border border-emerald-500/30">
              🧬
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="text-sm sm:text-base font-black text-white">
                  5 Biological Stages of ${crop.cropName} Lifecycle
                </h3>
                <span class="px-2 py-0.5 rounded-full text-[10px] font-mono font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  ${crop.totalDurationDays} DAYS COMPLETE TIMELINE
                </span>
              </div>
              <p class="text-xs text-gray-300">
                Current Phenological Age: <strong class="text-emerald-400 font-mono">DAS ${daysSinceSowing}</strong> • Active Biological Phase: <strong class="text-amber-300">${currentStageName}</strong>
              </p>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <!-- 1-Click View All 5 Stages Button -->
            <button 
              type="button" 
              data-lifecycle-stage="all" 
              class="lifecycle-stage-tab px-4 py-2 rounded-xl border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-2 shadow-sm ${
                activeStage === 'all'
                  ? 'bg-emerald-700 text-white border-emerald-400 font-bold'
                  : 'bg-emerald-950/80 text-emerald-300 hover:text-white border-emerald-700/60 hover:bg-emerald-900'
              }"
            >
              <i data-lucide="layers" class="w-4 h-4"></i>
              <span>View All 5 Biological Stages (Full View)</span>
            </button>
          </div>
        </div>

        <!-- 5 Biological Progression Stepper (Visual Interactive Milestone Grid) -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          ${biologicalStagesInfo.map(b => `
            <div 
              data-jump-stage="${b.stage}" 
              class="p-3.5 rounded-xl border transition cursor-pointer flex flex-col justify-between gap-2.5 hover:border-emerald-400 hover:bg-emerald-950/40 ${
                currentStageNumber === b.stage
                  ? 'bg-emerald-950/80 border-emerald-400 ring-2 ring-emerald-400/40 shadow-lg'
                  : daysSinceSowing > b.maxDas
                    ? 'bg-black/50 border-emerald-900/60'
                    : 'bg-black/30 border-gray-800'
              }"
            >
              <div class="flex items-center justify-between">
                <div class="flex items-center gap-1.5">
                  <span class="text-base">${b.icon}</span>
                  <span class="text-[11px] font-mono font-black text-white">${b.num}</span>
                </div>
                <span class="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
                  b.badgeText === 'ACTIVE NOW'
                    ? 'bg-emerald-500 text-slate-950 font-black animate-pulse'
                    : b.badgeText === 'COMPLETED'
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-700'
                      : 'bg-gray-800 text-gray-400'
                }">
                  ${b.badgeText}
                </span>
              </div>
              <div>
                <div class="text-xs font-black text-white leading-tight">${b.title}</div>
                <div class="text-[10px] font-mono font-bold text-emerald-400 mt-0.5">${b.dasLabel}</div>
              </div>
              <p class="text-[10px] text-gray-300 line-clamp-2 leading-snug font-sans">
                ${b.biologicalFocus}
              </p>
              <div class="pt-1 border-t border-emerald-950/80 flex items-center justify-between text-[9px] font-mono text-emerald-400">
                <span>View Details</span>
                <i data-lucide="arrow-down" class="w-3 h-3"></i>
              </div>
            </div>
          `).join('')}
        </div>

        <!-- Stage Filter Navigation Tabs (For Single Stage or Full View) -->
        <div class="pt-2 border-t border-emerald-950 flex flex-wrap items-center justify-between gap-2">
          <span class="text-[11px] font-mono text-gray-400 uppercase tracking-wider font-bold">
            Interactive Stage Controls:
          </span>
          <div class="flex flex-wrap gap-1.5">
            <button type="button" data-lifecycle-stage="all" class="lifecycle-stage-tab px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeStage === 'all'
                ? 'bg-emerald-500 text-slate-950 font-black border-emerald-300 shadow'
                : 'bg-black/50 text-gray-300 hover:text-white border-emerald-900/50 hover:bg-emerald-950/40'
            }">
              <span>👁️ All 5 Stages</span>
            </button>
            <button type="button" data-lifecycle-stage="1" class="lifecycle-stage-tab px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeStage === 1 || activeStage === '1'
                ? 'bg-emerald-500 text-slate-950 font-black border-emerald-300 shadow'
                : 'bg-black/50 text-gray-300 hover:text-white border-emerald-900/50 hover:bg-emerald-950/40'
            }">
              <span>🌱 1. Sowing</span>
            </button>
            <button type="button" data-lifecycle-stage="2" class="lifecycle-stage-tab px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeStage === 2 || activeStage === '2'
                ? 'bg-blue-500 text-slate-950 font-black border-blue-300 shadow'
                : 'bg-black/50 text-gray-300 hover:text-white border-emerald-900/50 hover:bg-blue-950/40'
            }">
              <span>💧 2. Irrigation</span>
            </button>
            <button type="button" data-lifecycle-stage="3" class="lifecycle-stage-tab px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeStage === 3 || activeStage === '3'
                ? 'bg-purple-500 text-slate-950 font-black border-purple-300 shadow'
                : 'bg-black/50 text-gray-300 hover:text-white border-emerald-900/50 hover:bg-purple-950/40'
            }">
              <span>🧪 3. Spraying</span>
            </button>
            <button type="button" data-lifecycle-stage="4" class="lifecycle-stage-tab px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeStage === 4 || activeStage === '4'
                ? 'bg-amber-500 text-slate-950 font-black border-amber-300 shadow'
                : 'bg-black/50 text-gray-300 hover:text-white border-emerald-900/50 hover:bg-amber-950/40'
            }">
              <span>🌾 4. Harvest</span>
            </button>
            <button type="button" data-lifecycle-stage="5" class="lifecycle-stage-tab px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5 ${
              activeStage === 5 || activeStage === '5'
                ? 'bg-rose-500 text-slate-950 font-black border-rose-300 shadow'
                : 'bg-black/50 text-gray-300 hover:text-white border-emerald-900/50 hover:bg-rose-950/40'
            }">
              <span>🏛️ 5. Mandi Sale</span>
            </button>
          </div>
        </div>
      </div>

      <!-- BIOLOGICAL STAGE 1 CONTENT: WHEN SEED SOWS -->
      <div id="lifecycle-stage-content-1" class="lifecycle-stage-content space-y-4 ${activeStage === 'all' || activeStage == 1 ? '' : 'hidden'}">
        <div class="glass-card p-6 space-y-5 border-l-4 border-l-emerald-500 shadow-xl">
          <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950 pb-3">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-lg shadow">
                🌱
              </div>
              <div>
                <div class="text-[10px] font-mono uppercase tracking-widest text-emerald-400 font-bold">
                  Biological Stage 1 of 5
                </div>
                <h3 class="text-base sm:text-lg font-black text-white">
                  Stage 1: When Seed Sows — Sowing & Germination Phase
                </h3>
                <p class="text-xs text-gray-400">${crop.sowingDetails.title} • Target Sowing: <strong class="text-emerald-300">${calendarData.sowingDateStr}</strong></p>
              </div>
            </div>
            <div class="flex items-center gap-2">
              <span class="px-2.5 py-1 rounded-lg bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-xs font-mono font-bold">
                ${crop.sowingDetails.dasRange}
              </span>
            </div>
          </div>

          <!-- Agronomic Specs Grid -->
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div class="p-3.5 rounded-xl bg-black/40 border border-emerald-900/60 space-y-1">
              <span class="text-[10px] font-mono uppercase text-gray-400">Optimal Sowing Window</span>
              <div class="text-xs font-bold text-emerald-300">${crop.optimalSowingWindow}</div>
            </div>
            <div class="p-3.5 rounded-xl bg-black/40 border border-emerald-900/60 space-y-1">
              <span class="text-[10px] font-mono uppercase text-gray-400">Seed Rate Per Acre</span>
              <div class="text-xs font-bold text-white">${crop.seedRate}</div>
            </div>
            <div class="p-3.5 rounded-xl bg-black/40 border border-emerald-900/60 space-y-1">
              <span class="text-[10px] font-mono uppercase text-gray-400">Spacing & Depth</span>
              <div class="text-xs font-bold text-white">${crop.spacing}</div>
            </div>
            <div class="p-3.5 rounded-xl bg-black/40 border border-emerald-900/60 space-y-1">
              <span class="text-[10px] font-mono uppercase text-gray-400">Soil Moisture Readiness</span>
              <div class="text-xs font-bold text-amber-300">Field Capacity (Wapsa Condition)</div>
            </div>
          </div>

          <!-- Soil Prep & Basal Fertilizer -->
          ${crop.soilPrep ? `
            <div class="p-4 rounded-xl bg-black/40 border border-emerald-900/60 space-y-1.5">
              <div class="flex items-center gap-2 text-xs font-bold text-amber-300 font-mono">
                <i data-lucide="layers" class="w-4 h-4 text-amber-400"></i>
                <span>Soil Preparation & Basal Nutrition:</span>
              </div>
              <p class="text-xs text-gray-200 leading-relaxed font-mono">
                ${crop.soilPrep}
              </p>
            </div>
          ` : ''}

          <!-- Seed Treatment & Inoculation (Crucial for Disease Prevention) -->
          <div class="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/60 space-y-2">
            <div class="flex items-center gap-2 text-xs font-bold text-emerald-300">
              <i data-lucide="shield-plus" class="w-4 h-4 text-emerald-400"></i>
              <span>Certified Seed Treatment Protocol:</span>
            </div>
            <p class="text-xs text-gray-200 leading-relaxed font-mono">
              ${crop.seedTreatment}
            </p>
          </div>

          <!-- Key Sowing Directives Checklist -->
          <div class="space-y-2">
            <h4 class="text-xs font-bold text-gray-300 uppercase tracking-wider font-mono">
              Actionable Sowing Checklist:
            </h4>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
              ${crop.sowingDetails.keyActions.map(action => `
                <div class="p-3 rounded-xl bg-black/30 border border-emerald-950 text-xs text-gray-200 flex items-start gap-2">
                  <span class="text-emerald-400 font-bold mt-0.5">✔</span>
                  <span class="leading-relaxed">${action}</span>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Agronomic Caution -->
          <div class="flex flex-wrap items-center justify-between gap-3 p-3 rounded-xl bg-amber-950/30 border border-amber-800/40 text-xs">
            <div class="flex items-start gap-2 text-amber-200">
              <i data-lucide="alert-triangle" class="w-4 h-4 text-amber-400 shrink-0 mt-0.5"></i>
              <span><strong>Agronomist Caution:</strong> ${crop.sowingDetails.warning}</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Stage 1 -> 2 Visual Biological Progression Connector -->
      <div class="lifecycle-stage-connector flex items-center justify-center gap-3 py-1 ${activeStage === 'all' ? '' : 'hidden'}">
        <div class="h-[1px] flex-1 bg-gradient-to-r from-transparent via-emerald-800/60 to-transparent"></div>
        <span class="px-3 py-1 rounded-full bg-emerald-950/80 border border-emerald-800/80 text-[11px] font-mono text-emerald-300 flex items-center gap-1.5 shadow">
          <span>Biological Transition: Germination ➔ Vegetative & Root Growth</span>
          <i data-lucide="arrow-down" class="w-3.5 h-3.5 text-emerald-400"></i>
        </span>
        <div class="h-[1px] flex-1 bg-gradient-to-r from-transparent via-emerald-800/60 to-transparent"></div>
      </div>

      <!-- BIOLOGICAL STAGE 2 CONTENT: WHEN WATER GIVES -->
      <div id="lifecycle-stage-content-2" class="lifecycle-stage-content space-y-4 ${activeStage === 'all' || activeStage == 2 ? '' : 'hidden'}">
        <div class="glass-card p-6 space-y-5 border-l-4 border-l-blue-500 shadow-xl">
          <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950 pb-3">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-lg shadow">
                💧
              </div>
              <div>
                <div class="text-[10px] font-mono uppercase tracking-widest text-blue-400 font-bold">
                  Biological Stage 2 of 5
                </div>
                <h3 class="text-base sm:text-lg font-black text-white">
                  Stage 2: When Water Gives — Vegetative Growth & Critical Irrigation Phase
                </h3>
                <p class="text-xs text-gray-400">Critical moisture sensitive phenological stages for ${crop.cropName}</p>
              </div>
            </div>
            <span class="px-2.5 py-1 rounded-lg bg-blue-500/15 text-blue-300 border border-blue-500/30 text-xs font-mono font-bold">
              ${crop.irrigationSchedule.length} CRITICAL WATERINGS
            </span>
          </div>

          <!-- Interactive Irrigation Pulse Cards Timeline -->
          <div class="space-y-3">
            ${calendarData.dynamicIrrigation.map((item, idx) => `
              <div class="p-4 rounded-xl border transition ${
                item.isCurrent 
                  ? 'bg-blue-950/70 border-blue-400 shadow-md shadow-blue-950/50 ring-1 ring-blue-400/50' 
                  : item.isCompleted 
                    ? 'bg-black/40 border-emerald-900/60 opacity-80' 
                    : 'bg-black/30 border-gray-800'
              }">
                <div class="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <div class="flex items-center gap-2">
                    <span class="w-6 h-6 rounded-full flex items-center justify-center font-mono font-bold text-xs ${item.isCurrent ? 'bg-blue-500 text-slate-950' : 'bg-gray-800 text-gray-300'}">
                      ${idx + 1}
                    </span>
                    <span class="text-sm font-bold text-white">${item.stageName}</span>
                    ${item.isCurrent ? '<span class="px-2 py-0.2 rounded text-[9px] font-mono bg-blue-500 text-slate-950 font-black animate-pulse">CURRENT ACTIVE STAGE</span>' : ''}
                  </div>
                  <div class="flex items-center gap-3">
                    <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-blue-950 text-blue-300 border border-blue-800/60">
                      📅 Scheduled: <strong>${item.scheduledDate}</strong> (${item.dasRange})
                    </span>
                    <span class="text-xs font-mono font-bold text-emerald-400">${item.waterVolume}</span>
                  </div>
                </div>
                <p class="text-xs text-gray-300 leading-relaxed pl-8">
                  ${item.guidance}
                </p>
                <div class="pl-8 pt-2 flex items-center gap-2 text-[11px] font-mono ${item.importance.includes('Critical') ? 'text-red-400 font-bold' : 'text-gray-400'}">
                  <span>Priority: ${item.importance}</span>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <!-- Stage 2 -> 3 Visual Biological Progression Connector -->
      <div class="lifecycle-stage-connector flex items-center justify-center gap-3 py-1 ${activeStage === 'all' ? '' : 'hidden'}">
        <div class="h-[1px] flex-1 bg-gradient-to-r from-transparent via-blue-800/60 to-transparent"></div>
        <span class="px-3 py-1 rounded-full bg-blue-950/80 border border-blue-800/80 text-[11px] font-mono text-blue-300 flex items-center gap-1.5 shadow">
          <span>Biological Transition: Vegetative Growth ➔ Flowering & Floral Anthesis</span>
          <i data-lucide="arrow-down" class="w-3.5 h-3.5 text-blue-400"></i>
        </span>
        <div class="h-[1px] flex-1 bg-gradient-to-r from-transparent via-blue-800/60 to-transparent"></div>
      </div>

      <!-- BIOLOGICAL STAGE 3 CONTENT: WHEN PESTICIDE SPRAY -->
      <div id="lifecycle-stage-content-3" class="lifecycle-stage-content space-y-4 ${activeStage === 'all' || activeStage == 3 ? '' : 'hidden'}">
        <div class="glass-card p-6 space-y-5 border-l-4 border-l-purple-500 shadow-xl">
          <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950 pb-3">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold text-lg shadow">
                🧪
              </div>
              <div>
                <div class="text-[10px] font-mono uppercase tracking-widest text-purple-400 font-bold">
                  Biological Stage 3 of 5
                </div>
                <h3 class="text-base sm:text-lg font-black text-white">
                  Stage 3: When Pesticide / Fungicide Spray Gives — Flowering & Crop Defense Phase
                </h3>
                <p class="text-xs text-gray-400">Prophylactic and curative protective spray calendar with exact 15L knapsack tank dosages</p>
              </div>
            </div>
            <span class="px-2.5 py-1 rounded-lg bg-purple-500/15 text-purple-300 border border-purple-500/30 text-xs font-mono font-bold">
              ${crop.spraySchedule.length} SCHEDULED SPRAYS
            </span>
          </div>

          <!-- Spray Schedule Cards -->
          <div class="space-y-3.5">
            ${calendarData.dynamicSprays.map((spray, idx) => `
              <div class="p-4 rounded-xl bg-black/40 border border-purple-900/60 space-y-2.5">
                <div class="flex flex-wrap items-center justify-between gap-2">
                  <div class="flex items-center gap-2">
                    <span class="w-6 h-6 rounded-full bg-purple-500/30 text-purple-300 border border-purple-500/50 flex items-center justify-center font-mono font-bold text-xs">
                      ${idx + 1}
                    </span>
                    <span class="text-sm font-bold text-white">${spray.sprayNumber}</span>
                  </div>
                  <div class="flex items-center gap-2">
                    <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-purple-950 text-purple-300 border border-purple-800">
                      📅 Date: <strong>${spray.scheduledDate}</strong> (${spray.dasRange})
                    </span>
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-red-950 text-rose-300 border border-red-800">
                      PHI: ${spray.phi}
                    </span>
                  </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pl-8">
                  <div class="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-900/40">
                    <span class="text-gray-400 font-mono text-[10px] block">Target Problem / Disease / Pest:</span>
                    <strong class="text-amber-300">${spray.targetProblem}</strong>
                  </div>
                  <div class="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-900/40">
                    <span class="text-gray-400 font-mono text-[10px] block">Chemical & Tank Dosage (15L Knapsack):</span>
                    <strong class="text-emerald-300">${spray.chemical} — ${spray.dosagePer15L}</strong>
                  </div>
                </div>

                <div class="text-[11px] text-gray-300 pl-8 flex items-center gap-1.5 font-mono">
                  <i data-lucide="cloud-sun" class="w-3.5 h-3.5 text-blue-400 shrink-0"></i>
                  <span>Weather Rule: ${spray.weatherRule}</span>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>

      <!-- Stage 3 -> 4 Visual Biological Progression Connector -->
      <div class="lifecycle-stage-connector flex items-center justify-center gap-3 py-1 ${activeStage === 'all' ? '' : 'hidden'}">
        <div class="h-[1px] flex-1 bg-gradient-to-r from-transparent via-purple-800/60 to-transparent"></div>
        <span class="px-3 py-1 rounded-full bg-purple-950/80 border border-purple-800/80 text-[11px] font-mono text-purple-300 flex items-center gap-1.5 shadow">
          <span>Biological Transition: Flowering & Pod/Grain Setting ➔ Physiological Maturity</span>
          <i data-lucide="arrow-down" class="w-3.5 h-3.5 text-purple-400"></i>
        </span>
        <div class="h-[1px] flex-1 bg-gradient-to-r from-transparent via-purple-800/60 to-transparent"></div>
      </div>

      <!-- BIOLOGICAL STAGE 4 CONTENT: WHEN CUT CROPS -->
      <div id="lifecycle-stage-content-4" class="lifecycle-stage-content space-y-4 ${activeStage === 'all' || activeStage == 4 ? '' : 'hidden'}">
        <div class="glass-card p-6 space-y-5 border-l-4 border-l-amber-500 shadow-xl">
          <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950 pb-3">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-lg shadow">
                🌾
              </div>
              <div>
                <div class="text-[10px] font-mono uppercase tracking-widest text-amber-400 font-bold">
                  Biological Stage 4 of 5
                </div>
                <h3 class="text-base sm:text-lg font-black text-white">
                  Stage 4: When Cut Crops — Physiological Maturity & Harvesting Phase
                </h3>
                <p class="text-xs text-gray-400">Harvest readiness indicators, moisture levels & post-harvest curing</p>
              </div>
            </div>
            <span class="px-2.5 py-1 rounded-lg bg-amber-500/15 text-amber-300 border border-amber-500/30 text-xs font-mono font-bold">
              HARVEST WINDOW: ${calendarData.harvestWindow.startDate} to ${calendarData.harvestWindow.endDate}
            </span>
          </div>

          <!-- Harvest Readiness Signs -->
          <div class="space-y-2">
            <h4 class="text-xs font-bold text-gray-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
              <i data-lucide="eye" class="w-4 h-4 text-amber-400"></i>
              <span>Visual Signs of Crop Maturity:</span>
            </h4>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5">
              ${((crop.harvestingSchedule || crop.harvestDetails)?.maturityIndicators || (crop.harvestingSchedule || crop.harvestDetails)?.maturitySigns || []).map(sign => `
                <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 text-xs text-gray-200 flex items-start gap-2">
                  <span class="text-amber-400 font-bold mt-0.5">●</span>
                  <span class="leading-relaxed">${sign}</span>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Machinery & Drying Guidance -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3.5 text-xs">
            <div class="p-4 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
              <div class="flex items-center gap-2 text-emerald-300 font-bold font-mono">
                <i data-lucide="cog" class="w-4 h-4 text-emerald-400"></i>
                <span>Harvesting Technique & Machinery:</span>
              </div>
              <p class="text-gray-200 leading-relaxed">
                ${(crop.harvestingSchedule || crop.harvestDetails)?.harvestingMethod || 'Manual sickle harvest or combine harvester.'}
              </p>
            </div>

            <div class="p-4 rounded-xl bg-black/40 border border-emerald-950 space-y-2">
              <div class="flex items-center gap-2 text-blue-300 font-bold font-mono">
                <i data-lucide="sun" class="w-4 h-4 text-blue-400"></i>
                <span>Post-Harvest Drying Protocol:</span>
              </div>
              <p class="text-gray-200 leading-relaxed">
                ${(crop.harvestingSchedule || crop.harvestDetails)?.postHarvestDrying || 'Sun dry grain to <12% moisture.'}
              </p>
            </div>
          </div>

          <!-- Storage Precaution -->
          <div class="p-3 rounded-xl bg-red-950/30 border border-red-800/40 text-xs text-rose-200 flex items-center gap-2 font-mono">
            <i data-lucide="alert-circle" class="w-4 h-4 text-red-400 shrink-0"></i>
            <span><strong>Storage Warning:</strong> ${(crop.harvestingSchedule || crop.harvestDetails)?.storageWarning || 'Keep dry.'}</span>
          </div>
        </div>
      </div>

      <!-- Stage 4 -> 5 Visual Biological Progression Connector -->
      <div class="lifecycle-stage-connector flex items-center justify-center gap-3 py-1 ${activeStage === 'all' ? '' : 'hidden'}">
        <div class="h-[1px] flex-1 bg-gradient-to-r from-transparent via-amber-800/60 to-transparent"></div>
        <span class="px-3 py-1 rounded-full bg-amber-950/80 border border-amber-800/80 text-[11px] font-mono text-amber-300 flex items-center gap-1.5 shadow">
          <span>Biological Transition: Crop Harvest ➔ Post-Harvest Processing & Mandi Realization</span>
          <i data-lucide="arrow-down" class="w-3.5 h-3.5 text-amber-400"></i>
        </span>
        <div class="h-[1px] flex-1 bg-gradient-to-r from-transparent via-amber-800/60 to-transparent"></div>
      </div>

      <!-- BIOLOGICAL STAGE 5 CONTENT: SELL TO LOCAL MANDI -->
      <div id="lifecycle-stage-content-5" class="lifecycle-stage-content space-y-4 ${activeStage === 'all' || activeStage == 5 ? '' : 'hidden'}">
        <div class="glass-card p-6 space-y-5 border-l-4 border-l-rose-500 shadow-xl">
          <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950 pb-3">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-lg shadow">
                🏛️
              </div>
              <div>
                <div class="text-[10px] font-mono uppercase tracking-widest text-rose-400 font-bold">
                  Biological Stage 5 of 5
                </div>
                <h3 class="text-base sm:text-lg font-black text-white">
                  Stage 5: When & Where to Sell to Local Mandi — Post-Harvest & APMC Realization
                </h3>
                <p class="text-xs text-gray-400">APMC Mandi price discovery, Central MSP, quality grading checklist and revenue projection</p>
              </div>
            </div>
            <span class="px-2.5 py-1 rounded-lg bg-rose-500/15 text-rose-300 border border-rose-500/30 text-xs font-mono font-bold">
              ${calendarData.mandiWindow.status}
            </span>
          </div>

          <!-- Price & Window Cards -->
          <div class="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            <div class="p-4 rounded-xl bg-black/40 border border-emerald-900/60 space-y-1">
              <span class="text-[10px] font-mono uppercase text-gray-400">Govt Minimum Support Price (MSP)</span>
              <div class="text-base font-black text-emerald-400">${crop.mandiSellingGuide.mspGovt}</div>
            </div>
            <div class="p-4 rounded-xl bg-black/40 border border-emerald-900/60 space-y-1">
              <span class="text-[10px] font-mono uppercase text-gray-400">Current Local Mandi Spot Rate</span>
              <div class="text-base font-black text-amber-300">${crop.mandiSellingGuide.currentMandiRate}</div>
            </div>
            <div class="p-4 rounded-xl bg-black/40 border border-emerald-900/60 space-y-1">
              <span class="text-[10px] font-mono uppercase text-gray-400">Best Selling Window (Max Profit)</span>
              <div class="text-xs font-bold text-white">${crop.mandiSellingGuide.bestSellingWindow}</div>
            </div>
          </div>

          <!-- Mandi Grading Standards Checklist -->
          <div class="space-y-2">
            <h4 class="text-xs font-bold text-gray-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
              <i data-lucide="check-square" class="w-4 h-4 text-emerald-400"></i>
              <span>Grade A Mandi Premium Checklist:</span>
            </h4>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-2.5 text-xs">
              ${crop.mandiSellingGuide.gradingChecklist.map(grade => `
                <div class="p-3 rounded-xl bg-black/40 border border-emerald-950 text-gray-200 flex items-start gap-2">
                  <span class="text-emerald-400 font-bold">✔</span>
                  <span>${grade}</span>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Nearby APMC Mandis Directory -->
          <div class="space-y-2">
            <h4 class="text-xs font-bold text-gray-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
              <i data-lucide="map-pin" class="w-4 h-4 text-rose-400"></i>
              <span>Nearby APMC Mandis & Modal Rates:</span>
            </h4>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              ${crop.mandiSellingGuide.nearbyMandis.map(mandi => `
                <div class="p-3 rounded-xl bg-emerald-950/30 border border-emerald-900/50 space-y-1">
                  <div class="text-xs font-bold text-white truncate">${mandi.name}</div>
                  <div class="text-[10px] text-gray-400 font-mono">${mandi.distance}</div>
                  <div class="text-xs font-mono font-extrabold text-emerald-400">${mandi.rate}</div>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Strategic Advice & Profit Insights -->
          <div class="p-4 rounded-xl bg-gradient-to-r from-emerald-950 to-teal-950 border border-emerald-600/50 space-y-3">
            <div class="flex items-center gap-2 text-xs font-bold text-emerald-300">
              <i data-lucide="trending-up" class="w-4 h-4 text-emerald-400"></i>
              <span>Mandi Timing Strategy to Avoid Harvest Glut:</span>
            </div>
            <p class="text-xs text-gray-200 leading-relaxed font-mono">
              ${crop.mandiSellingGuide.mandiTips}
            </p>
          </div>
        </div>
      </div>
    </div>
  `;
}

/**
 * Initializes interactive event hooks for the Crop Lifecycle Monitor
 * @param {Function} onCropChange - Optional callback when crop changes
 * @param {Function} onDateChange - Optional callback when sowing date changes
 * @param {Function} onStageChange - Optional callback when active stage changes
 */
export function initCropLifecycleHooks(onCropChange = null, onDateChange = null, onStageChange = null) {
  // 1. Stage Tabs Switcher
  document.querySelectorAll('.lifecycle-stage-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const stage = tab.getAttribute('data-lifecycle-stage');
      
      // Update tab active styles
      document.querySelectorAll('.lifecycle-stage-tab').forEach(t => {
        const s = t.getAttribute('data-lifecycle-stage');
        if (s === stage) {
          if (s === 'all') {
            t.className = 'lifecycle-stage-tab px-4 py-2 rounded-xl border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-2 shadow-sm bg-emerald-700 text-white border-emerald-400';
          } else {
            t.className = 'lifecycle-stage-tab px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5 bg-emerald-700 text-white border-emerald-400 shadow-sm';
          }
        } else {
          if (t.getAttribute('data-lifecycle-stage') === 'all') {
            t.className = 'lifecycle-stage-tab px-4 py-2 rounded-xl border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-2 shadow bg-emerald-950/80 text-emerald-300 hover:text-white border-emerald-700/60 hover:bg-emerald-900';
          } else {
            t.className = 'lifecycle-stage-tab px-3 py-1.5 rounded-lg border text-xs font-mono font-bold transition cursor-pointer flex items-center gap-1.5 bg-black/50 text-gray-300 hover:text-white border-emerald-900/50 hover:bg-emerald-950/40';
          }
        }
      });

      if (stage === 'all') {
        // Show ALL 5 biological stages in full
        document.querySelectorAll('.lifecycle-stage-content').forEach(pane => {
          pane.classList.remove('hidden');
        });
        document.querySelectorAll('.lifecycle-stage-connector').forEach(conn => {
          conn.classList.remove('hidden');
        });
      } else {
        // Show targeted content pane only
        document.querySelectorAll('.lifecycle-stage-content').forEach(pane => {
          pane.classList.add('hidden');
        });
        document.querySelectorAll('.lifecycle-stage-connector').forEach(conn => {
          conn.classList.add('hidden');
        });
        const activePane = document.getElementById(`lifecycle-stage-content-${stage}`);
        if (activePane) {
          activePane.classList.remove('hidden');
          activePane.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }

      if (onStageChange) {
        onStageChange(stage);
      }

      if (typeof lucide !== 'undefined' && lucide.createIcons) {
        lucide.createIcons();
      }
    });
  });

  // 2. Progression Stepper Click-to-Jump
  document.querySelectorAll('[data-jump-stage]').forEach(card => {
    card.addEventListener('click', () => {
      const stage = card.getAttribute('data-jump-stage');
      const targetPane = document.getElementById(`lifecycle-stage-content-${stage}`);
      
      // If currently hidden because single-stage mode was selected, activate that stage or all stages
      if (targetPane && targetPane.classList.contains('hidden')) {
        const tabBtn = document.querySelector(`.lifecycle-stage-tab[data-lifecycle-stage="${stage}"]`);
        if (tabBtn) {
          tabBtn.click();
          return;
        }
      }

      if (targetPane) {
        targetPane.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // 3. Crop Selector Chips & Dropdown Select
  document.querySelectorAll('.lifecycle-crop-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      const newCrop = chip.getAttribute('data-lifecycle-crop');
      if (onCropChange && newCrop) {
        onCropChange(newCrop);
      }
    });
  });

  const cropSelect = document.getElementById('lifecycle-crop-select');
  if (cropSelect) {
    cropSelect.addEventListener('change', () => {
      const newCrop = cropSelect.value;
      if (onCropChange && newCrop) {
        onCropChange(newCrop);
      }
    });
  }

  // 4. Recalculate Calendar Button
  const recalcBtn = document.getElementById('btn-recalculate-calendar');
  const dateInput = document.getElementById('lifecycle-sowing-date');
  if (recalcBtn && dateInput) {
    recalcBtn.addEventListener('click', () => {
      const newDate = dateInput.value;
      if (onDateChange && newDate) {
        onDateChange(newDate);
      }
    });

    dateInput.addEventListener('change', () => {
      const newDate = dateInput.value;
      if (onDateChange && newDate) {
        onDateChange(newDate);
      }
    });
  }

  if (typeof lucide !== 'undefined' && lucide.createIcons) {
    lucide.createIcons();
  }
}
