// AgroSense Farm Activity & Expense Log Component

import { translations } from '../data/translations.js';

export function renderFarmLogPage(state) {
  const t = translations[state.lang] || translations.en;
  const logs = state.farmActivities || [
    { id: '1', date: "2026-11-15", category: "Sowing", title: "Wheat HD-2967 Sowing", details: "Sown using seed drill with 40kg/acre seed rate", cost: "₹4,200" },
    { id: '2', date: "2026-12-02", category: "Irrigation", title: "First Drip Pulse Irrigation", details: "Applied 2.5 hours drip pulse cycle after emergence", cost: "₹450" },
    { id: '3', date: "2026-12-18", category: "Fertilizer", title: "Urea Top-Dressing", details: "Applied 25kg Urea split dose per acre", cost: "₹1,850" },
    { id: '4', date: "2026-12-28", category: "Weeding", title: "Inter-row Weeding", details: "Manual weeding & hoeing operation", cost: "₹2,500" }
  ];

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="clipboard-list" class="w-6 h-6 text-emerald-400"></i>
            ${t.nav ? t.nav.farmLog : 'Farm Activity Log'} & Financial Ledger
          </h1>
          <p class="text-xs text-gray-400">Chronological history of sowing, fertilizer applications, irrigation pulses, pest treatments & field operations</p>
        </div>
        <button id="add-log-entry-btn" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition cursor-pointer flex items-center gap-1.5">
          <i data-lucide="plus" class="w-4 h-4 text-white"></i> ${t.recordNewActivity || 'Record New Activity'}
        </button>
      </div>

      <div class="glass-card p-6 space-y-4">
        <div class="space-y-3">
          ${logs.map((log, idx) => `
            <div class="p-4 rounded-xl bg-emerald-950/40 border border-emerald-800/40 flex flex-wrap items-center justify-between gap-4">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <i data-lucide="check-square" class="w-5 h-5"></i>
                </div>
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-xs font-bold text-white">${log.title}</span>
                    <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-semibold">${log.category}</span>
                  </div>
                  <p class="text-xs text-gray-400 mt-0.5">${log.details}</p>
                </div>
              </div>
              <div class="flex items-center gap-4">
                <div class="text-right">
                  <span class="text-xs font-mono font-bold text-emerald-400 block">${log.cost}</span>
                  <span class="text-[10px] text-gray-500 font-mono">${log.date}</span>
                </div>
                <div class="flex items-center gap-1">
                  <button data-log-edit="${idx}" class="btn-edit-log p-1.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-amber-300 text-xs cursor-pointer">
                    <i data-lucide="edit-2" class="w-3.5 h-3.5"></i>
                  </button>
                  <button data-log-delete="${idx}" class="btn-delete-log p-1.5 rounded-lg bg-gray-800 hover:bg-red-900/60 text-red-400 text-xs cursor-pointer">
                    <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                  </button>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

export function initFarmLogHooks(state, setState) {
  const addBtn = document.getElementById('add-log-entry-btn');
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      const title = prompt("Enter Activity Title (e.g. Foliar Micronutrient Spray):", "Foliar Spray");
      if (!title) return;
      const category = prompt("Enter Category (Sowing, Irrigation, Fertilizer, Spray, Weeding, Harvest):", "Spray") || "Operation";
      const details = prompt("Enter Activity Details:", "Applied zinc & boron foliar spray") || "";
      const cost = prompt("Enter Operational Cost (e.g. ₹1,200):", "₹1,200") || "₹0";

      const curLogs = state.farmActivities || [
        { id: '1', date: "2026-11-15", category: "Sowing", title: "Wheat HD-2967 Sowing", details: "Sown using seed drill with 40kg/acre seed rate", cost: "₹4,200" },
        { id: '2', date: "2026-12-02", category: "Irrigation", title: "First Drip Pulse Irrigation", details: "Applied 2.5 hours drip pulse cycle after emergence", cost: "₹450" }
      ];

      const newLog = {
        id: Date.now().toString(),
        date: new Date().toISOString().split('T')[0],
        category,
        title,
        details,
        cost
      };

      if (setState) {
        setState({ farmActivities: [newLog, ...curLogs] });
      }
    });
  }

  document.querySelectorAll('.btn-edit-log').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.getAttribute('data-log-edit'));
      const curLogs = state.farmActivities || [];
      const item = curLogs[idx];
      if (!item) return;

      const newTitle = prompt("Edit Activity Title:", item.title);
      if (!newTitle) return;
      const newCost = prompt("Edit Cost:", item.cost) || item.cost;
      const newDetails = prompt("Edit Details:", item.details) || item.details;

      const updated = [...curLogs];
      updated[idx] = { ...item, title: newTitle, cost: newCost, details: newDetails };

      if (setState) {
        setState({ farmActivities: updated });
      }
    });
  });

  document.querySelectorAll('.btn-delete-log').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.getAttribute('data-log-delete'));
      const curLogs = state.farmActivities || [];
      if (confirm("Are you sure you want to delete this activity record?")) {
        const updated = curLogs.filter((_, i) => i !== idx);
        if (setState) {
          setState({ farmActivities: updated });
        }
      }
    });
  });
}
