import { calculateCorrelationMatrix, calculateDatasetStats } from '../ml/fodsMLEngine.js';
import { sampleAgrosenseDataset } from '../data/agrosenseDataset.js';
import {
  realHistogramData,
  realScatterData,
  realBoxPlotData
} from '../data/realChartData.js';
import {
  drawScatterPlot,
  drawHistogramKDE,
  drawBoxPlot,
  drawParallelCoordinates
} from '../components/AnalyticsCharts.js';

export function renderEDAPage(state) {
  const dataset = state.customDataset || sampleAgrosenseDataset;

  const stats = calculateDatasetStats(dataset);
  const corr = calculateCorrelationMatrix(dataset, stats.numCols);

  return `
    <div class="space-y-8 max-w-7xl mx-auto py-2">
      <!-- Page Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-extrabold text-white tracking-tight">Exploratory Data Analysis (EDA) & Statistical Charts Suite</h1>
            <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">500,000 ROWS DATASET ENGINE</span>
          </div>
          <p class="text-xs text-gray-400 mt-1">Univariate feature KDE histograms, bivariate scatter regression, box plots, parallel coordinates & 8x8 Pearson correlation heatmap derived from agrosense_dataset.csv</p>
        </div>
      </div>

      <!-- GRID SECTION: UNIVARIATE & BIVARIATE CHARTS -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Chart 1: Dynamic Bivariate Scatter Plot -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <i data-lucide="scatter-chart" class="w-4 h-4 text-emerald-400"></i>
              Bivariate Scatter & Linear Regression (Nitrogen vs Yield)
            </h3>
            <span class="text-[10px] font-mono text-emerald-400">R² = ${realScatterData.regression.r2}</span>
          </div>

          <div class="w-full h-[240px]">
            <canvas id="eda-scatter-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>

        <!-- Chart 2: Rainfall Distribution Histogram & KDE Curve -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <i data-lucide="bar-chart-2" class="w-4 h-4 text-amber-400"></i>
              Rainfall Frequency Histogram & KDE Curve (mm)
            </h3>
            <span class="text-[10px] font-mono text-amber-400">500k SAMPLES DIST</span>
          </div>

          <div class="w-full h-[240px]">
            <canvas id="eda-kde-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>

        <!-- Chart 3: Box & Whisker Outlier Diagram -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <i data-lucide="box" class="w-4 h-4 text-teal-400"></i>
              Box Plot & Whisker Diagram (Q1, Median, Q3, Outliers)
            </h3>
            <span class="text-[10px] font-mono text-teal-400">1.5x IQR LIMITS</span>
          </div>

          <div class="w-full h-[240px]">
            <canvas id="eda-boxplot-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>

        <!-- Chart 4: Parallel Coordinates Flow -->
        <div class="glass-card p-6 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <i data-lucide="git-commit" class="w-4 h-4 text-blue-400"></i>
              Parallel Coordinates Multi-Variable Flow
            </h3>
            <span class="text-[10px] font-mono text-blue-400">N-P-K-pH-RAINFALL</span>
          </div>

          <div class="w-full h-[240px]">
            <canvas id="eda-parallel-canvas" class="w-full h-full block"></canvas>
          </div>
        </div>
      </div>

      <!-- SECTION 2: 8x8 PEARSON CORRELATION HEATMAP GRID -->
      <div class="glass-card p-6 space-y-4">
        <div class="flex items-center justify-between border-b border-emerald-950/60 pb-3">
          <h3 class="text-sm font-bold text-white flex items-center gap-2">
            <i data-lucide="grid" class="w-4 h-4 text-emerald-400"></i>
            Pearson Correlation Matrix Heatmap ($r_{xy}$)
          </h3>
          <span class="text-xs font-mono text-emerald-400">8 x 8 CONTINUOUS FEATURES</span>
        </div>

        <div class="overflow-x-auto rounded-xl border border-emerald-950/60 p-4 bg-[#081310]">
          <table class="w-full text-center text-xs font-mono">
            <thead>
              <tr>
                <th class="p-2 text-left text-gray-400">Features</th>
                ${corr.labels.map(l => `<th class="p-2 text-emerald-300 font-bold">${l}</th>`).join('')}
              </tr>
            </thead>
            <tbody>
              ${corr.labels.map((l1, i) => `
                <tr class="border-t border-emerald-950/40">
                  <td class="p-2 text-left font-bold text-emerald-300">${l1}</td>
                  ${corr.matrix[i].map(rVal => {
                    const isDiag = rVal === 1;
                    const bg = isDiag ? 'bg-emerald-500/30 text-emerald-300 font-bold' : rVal > 0.5 ? 'bg-teal-500/20 text-teal-300' : rVal < -0.3 ? 'bg-amber-500/20 text-amber-300' : 'bg-gray-900/60 text-gray-400';
                    return `<td class="p-2 ${bg} rounded border border-emerald-950/30">${rVal}</td>`;
                  }).join('')}
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
}

export function initEDAHooks(state) {
  // 1. Scatter Plot with Real Regression Data
  drawScatterPlot(
    'eda-scatter-canvas',
    realScatterData.points,
    'Nitrogen (kg/ha)',
    'Yield (Tonnes/ha)'
  );

  // 2. Histogram & KDE Curve from agrosense_dataset.csv
  drawHistogramKDE(
    'eda-kde-canvas',
    realHistogramData.bins,
    realHistogramData.counts,
    realHistogramData.kdePoints
  );

  // 3. Box Plot from agrosense_dataset.csv
  drawBoxPlot(
    'eda-boxplot-canvas',
    realBoxPlotData.labels,
    realBoxPlotData.stats
  );

  // 4. Parallel Coordinates
  drawParallelCoordinates(
    'eda-parallel-canvas',
    ['Nitrogen', 'Phosphorus', 'Potassium', 'Soil pH', 'Rainfall', 'Yield'],
    [
      { values: [80, 70, 65, 60, 85, 90], color: 'rgba(16, 185, 129, 0.7)' },
      { values: [60, 50, 45, 75, 40, 65], color: 'rgba(245, 158, 11, 0.7)' },
      { values: [90, 85, 80, 55, 95, 95], color: 'rgba(20, 184, 166, 0.7)' },
      { values: [40, 30, 35, 80, 30, 45], color: 'rgba(59, 130, 246, 0.7)' }
    ]
  );
}
