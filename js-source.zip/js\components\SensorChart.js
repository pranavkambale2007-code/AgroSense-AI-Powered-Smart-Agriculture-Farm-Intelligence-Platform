// AgroSense Sensor Telemetry Chart Component

import { generateSensorTelemetry } from '../services/irrigationService.js';

export function renderSensorChartContainer(timeframe = "24h") {
  const telemetry = generateSensorTelemetry(timeframe);

  return `
    <div class="glass-card p-6 space-y-4">
      <div class="flex flex-wrap items-center justify-between gap-3">
        <div class="flex items-center gap-2">
          <i data-lucide="cpu" class="w-5 h-5 text-emerald-400"></i>
          <div>
            <h3 class="text-sm font-bold text-white">IoT Sensor Telemetry Streams</h3>
            <p class="text-xs text-gray-400">Real-time Soil Moisture & Microclimate Sensors</p>
          </div>
        </div>

        <!-- Timeframe Buttons -->
        <div class="flex items-center gap-1 bg-emerald-950/60 p-1 rounded-xl border border-emerald-800/40">
          <button data-timeframe="30m" class="timeframe-btn px-2.5 py-1 rounded-lg text-xs font-semibold ${timeframe === '30m' ? 'bg-emerald-600 text-white' : 'text-gray-400 hover:text-white'}">30 min</button>
          <button data-timeframe="6h" class="timeframe-btn px-2.5 py-1 rounded-lg text-xs font-semibold ${timeframe === '6h' ? 'bg-emerald-600 text-white' : 'text-gray-400 hover:text-white'}">6 hours</button>
          <button data-timeframe="24h" class="timeframe-btn px-2.5 py-1 rounded-lg text-xs font-semibold ${timeframe === '24h' ? 'bg-emerald-600 text-white' : 'text-gray-400 hover:text-white'}">24 hours</button>
          <button data-timeframe="7d" class="timeframe-btn px-2.5 py-1 rounded-lg text-xs font-semibold ${timeframe === '7d' ? 'bg-emerald-600 text-white' : 'text-gray-400 hover:text-white'}">7 days</button>
        </div>
      </div>

      <!-- Canvas Chart Element -->
      <div class="h-64 w-full relative">
        <canvas id="sensor-telemetry-canvas" class="w-full h-full"></canvas>
      </div>

      <!-- Live Values Legend -->
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs border-t border-emerald-900/50">
        <div class="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
          <span class="text-gray-400 block text-[11px]">Soil Moisture</span>
          <span class="text-sm font-bold text-emerald-400 font-mono">${telemetry[telemetry.length - 1].moisture}%</span>
        </div>
        <div class="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
          <span class="text-gray-400 block text-[11px]">Temperature</span>
          <span class="text-sm font-bold text-amber-400 font-mono">${telemetry[telemetry.length - 1].temperature}°C</span>
        </div>
        <div class="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
          <span class="text-gray-400 block text-[11px]">Soil pH</span>
          <span class="text-sm font-bold text-blue-400 font-mono">${telemetry[telemetry.length - 1].ph}</span>
        </div>
        <div class="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-800/40">
          <span class="text-gray-400 block text-[11px]">Electrical Cond.</span>
          <span class="text-sm font-bold text-teal-400 font-mono">${telemetry[telemetry.length - 1].ec} dS/m</span>
        </div>
      </div>
    </div>
  `;
}

export function drawSensorChart(timeframe = "24h") {
  const canvas = document.getElementById('sensor-telemetry-canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const telemetry = generateSensorTelemetry(timeframe);

  // Simple HTML5 Canvas line rendering for fast, dependency-free telemetry
  const width = canvas.parentElement.clientWidth;
  const height = 240;
  canvas.width = width;
  canvas.height = height;

  ctx.clearRect(0, 0, width, height);

  // Background Grid Lines
  ctx.strokeStyle = 'rgba(16, 185, 129, 0.08)';
  ctx.lineWidth = 1;
  for (let y = 30; y < height; y += 40) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }

  // Draw Soil Moisture Line (Emerald)
  const points = telemetry.map((d, idx) => ({
    x: (idx / (telemetry.length - 1)) * (width - 40) + 20,
    y: height - ((d.moisture / 50) * (height - 60) + 20)
  }));

  ctx.beginPath();
  ctx.strokeStyle = '#10b981';
  ctx.lineWidth = 3;
  points.forEach((p, i) => {
    if (i === 0) ctx.moveTo(p.x, p.y);
    else ctx.lineTo(p.x, p.y);
  });
  ctx.stroke();

  // Draw Dots & Values
  points.forEach(p => {
    ctx.beginPath();
    ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#34d399';
    ctx.fill();
  });
}
