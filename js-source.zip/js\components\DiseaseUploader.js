// AgroSense Plant Disease Classifier Uploader Component
// Supports File Upload, Drag & Drop, Live Camera Viewfinder, and Pre-loaded Multi-Crop Leaf Samples

import { demoLeafSamples } from '../ml/plantDiseaseModel.js';
import { allAgrosenseCropsList } from '../data/allCropsDiseaseDatabase.js';

export function renderDiseaseUploader(currentImage = null, diseaseResult = null, selectedCropHint = 'all') {
  const bbox = diseaseResult?.boundingBox || { x: 22, y: 24, w: 56, h: 52 };
  const conf = diseaseResult?.confidence || 94.2;
  const diseaseName = diseaseResult?.diseaseName || "Pathogen Lesion";
  const isHealthy = diseaseResult?.pathogenType === 'Healthy Foliage';

  const cropChips = [
    { key: 'all', label: '🔍 Auto-Detect' },
    { key: 'wheat', label: '🌾 Wheat' },
    { key: 'rice', label: '🌾 Rice' },
    { key: 'maize', label: '🌽 Maize' },
    { key: 'sugarcane', label: '🎋 Sugarcane' },
    { key: 'cotton', label: '☁️ Cotton' },
    { key: 'soybean', label: '🌱 Soybean' },
    { key: 'mustard', label: '🌼 Mustard' },
    { key: 'chickpea', label: '🌰 Chickpea' },
    { key: 'onion', label: '🧅 Onion' },
    { key: 'tomato', label: '🍅 Tomato' },
    { key: 'potato', label: '🥔 Potato' },
    { key: 'chilli', label: '🌶️ Chilli' },
    { key: 'banana', label: '🍌 Banana' },
    { key: 'mango', label: '🥭 Mango' },
    { key: 'turmeric', label: '🌿 Turmeric' }
  ];

  const categories = [
    'Cereals & Grains',
    'Pulses & Legumes',
    'Oilseeds',
    'Commercial & Cash Crops',
    'Vegetables',
    'Spices & Condiments',
    'Medicinal & Aromatic'
  ];

  return `
    <div class="glass-card p-6 space-y-5">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950/80 pb-3">
        <div>
          <h3 class="text-base font-bold text-white flex items-center gap-2">
            <i data-lucide="scan-line" class="w-5 h-5 text-emerald-400"></i>
            Computer Vision Leaf Pathology Scanner
          </h3>
          <p class="text-xs text-gray-400 mt-0.5">Upload a field leaf photo, take a live camera snapshot, or select a sample</p>
        </div>
        <span class="px-2.5 py-0.5 rounded text-[11px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
          CV MODEL V2.5 ACTIVE • ALL CROPS
        </span>
      </div>

      <!-- Crop Filter Selector & Quick Chips -->
      <div class="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-900/60 space-y-2.5 text-xs">
        <div class="flex flex-wrap items-center justify-between gap-3">
          <label for="disease-crop-filter" class="font-bold text-gray-200 flex items-center gap-1.5 font-mono">
            <i data-lucide="sprout" class="w-4 h-4 text-emerald-400"></i>
            <span>Target Crop Species:</span>
          </label>
          <select id="disease-crop-filter" style="color-scheme: dark; background-color: #031c10; color: #ffffff;" class="bg-[#031c10] text-white border border-emerald-500/60 rounded-lg px-2.5 py-1.5 text-xs font-bold cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-400 shadow-inner max-w-full">
            <option value="all" ${selectedCropHint === 'all' ? 'selected' : ''}>🔍 Auto-Detect Crop from Leaf Image</option>
            ${categories.map(cat => {
              const cropsInCat = allAgrosenseCropsList.filter(c => c.category === cat);
              if (cropsInCat.length === 0) return '';
              return `
                <optgroup label="${cat}">
                  ${cropsInCat.map(c => `
                    <option value="${c.cropKey}" ${selectedCropHint === c.cropKey ? 'selected' : ''}>
                      ${c.icon || '🌱'} ${c.name}
                    </option>
                  `).join('')}
                </optgroup>
              `;
            }).join('')}
          </select>
        </div>

        <!-- 1-Tap Crop Quick Selection Chips -->
        <div class="flex flex-wrap gap-1.5 pt-1">
          ${cropChips.map(c => {
            const isActive = selectedCropHint === c.key;
            return `
              <button type="button" data-crop="${c.key}" class="crop-chip-btn px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition cursor-pointer border ${
                isActive 
                  ? 'bg-emerald-700 text-white font-bold border-emerald-400 shadow-sm' 
                  : 'bg-emerald-950/60 hover:bg-emerald-900/60 text-gray-300 border-emerald-800/40 hover:border-emerald-500/50'
              }">
                ${c.label}
              </button>
            `;
          }).join('')}
        </div>
      </div>

      <!-- Live Interactive Leaf Preview with Dynamic Bounding Box & Pathology Heatmap -->
      ${currentImage ? `
        <div class="space-y-2">
          <div class="relative w-full h-[260px] sm:h-[300px] rounded-2xl overflow-hidden border border-emerald-600/50 bg-black flex items-center justify-center shadow-lg">
            <img id="leaf-preview-img" src="${currentImage}" class="max-h-full max-w-full object-contain select-none" />
            
            <!-- Dynamic Pathological Bounding Box Overlay -->
            ${!isHealthy ? `
              <div id="disease-bbox-overlay" class="absolute border-2 border-dashed border-red-500 rounded-lg pointer-events-none transition-all duration-300 shadow-md"
                   style="left: ${bbox.x}%; top: ${bbox.y}%; width: ${bbox.w}%; height: ${bbox.h}%;">
                <div class="absolute -top-6 left-0 bg-red-600 text-white font-mono text-[9px] font-bold px-2 py-0.5 rounded shadow flex items-center gap-1 whitespace-nowrap">
                  <span class="w-1.5 h-1.5 rounded-full bg-white"></span>
                  <span>${diseaseName.split('(')[0].trim().toUpperCase()} (${conf}%)</span>
                </div>
              </div>

              <!-- Translucent Pathology Heatmap Canvas Layer (Toggled) -->
              <div id="disease-heatmap-overlay" class="absolute inset-0 pointer-events-none hidden"
                   style="background: radial-gradient(circle at ${bbox.x + bbox.w / 2}% ${bbox.y + bbox.h / 2}%, rgba(239, 68, 68, 0.45) 0%, rgba(245, 158, 11, 0.25) 45%, rgba(0, 0, 0, 0) 70%);">
              </div>
            ` : `
              <div class="absolute inset-4 border-2 border-emerald-500 rounded-xl pointer-events-none flex items-start justify-end p-2">
                <span class="px-2 py-1 rounded bg-emerald-600 text-white font-mono text-[10px] font-extrabold shadow flex items-center gap-1.5">
                  <i data-lucide="shield-check" class="w-3.5 h-3.5"></i>
                  CLEAN TISSUE (NO PATHOGEN)
                </span>
              </div>
            `}

            <!-- Scanning Indicator Overlay (Active during processing) -->
            <div id="scanner-laser-line" class="hidden absolute inset-x-0 h-0.5 bg-emerald-400 z-20 pointer-events-none" style="top: 50%;"></div>
            <div id="scanner-status-pill" class="hidden absolute top-3 bg-emerald-950/90 text-emerald-200 border border-emerald-400 font-mono text-[10px] px-3 py-1 rounded-full z-20 shadow">
              <span>Scanning foliar tissue & biomarkers...</span>
            </div>

            <!-- Vision HUD Coordinates Badge -->
            <div class="absolute bottom-2 left-2 bg-black/85 backdrop-blur border border-emerald-900/80 rounded-lg px-2 py-1 text-[10px] font-mono text-emerald-300">
              Biomarker Grid: 140×140 Px • Confidence: ${conf}%
            </div>

            <!-- Heatmap Toggle Button -->
            ${!isHealthy ? `
              <button id="btn-toggle-heatmap" class="absolute bottom-2 right-2 bg-red-950/85 hover:bg-red-900 border border-red-500/60 text-red-200 text-[10px] font-mono font-bold px-2.5 py-1 rounded-lg transition flex items-center gap-1 cursor-pointer shadow">
                <i data-lucide="flame" class="w-3.5 h-3.5 text-amber-400"></i>
                <span id="label-heatmap-toggle">Show Heatmap</span>
              </button>
            ` : ''}
          </div>
        </div>
      ` : ''}

      <!-- Live Camera Stream Viewfinder (Hidden by default, opened on click) -->
      <div id="camera-viewfinder-container" class="hidden relative w-full h-[280px] rounded-2xl overflow-hidden border-2 border-teal-400 bg-black flex flex-col items-center justify-center shadow-2xl">
        <video id="camera-stream-video" autoplay playsinline class="w-full h-full object-cover"></video>
        <!-- Camera Targeting Grid Overlay -->
        <div class="absolute inset-8 border border-white/40 border-dashed rounded-xl pointer-events-none flex items-center justify-center">
          <span class="text-[11px] font-mono text-white/70 bg-black/50 px-2 py-1 rounded">Position Leaf Inside Frame</span>
        </div>
        <!-- Camera Action Controls -->
        <div class="absolute bottom-3 flex items-center gap-3">
          <button id="btn-snap-photo" class="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black font-mono transition flex items-center gap-1.5 shadow-lg cursor-pointer">
            <i data-lucide="camera" class="w-4 h-4"></i>
            <span>Capture Photo</span>
          </button>
          <button id="btn-cancel-camera" class="px-3.5 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-200 text-xs font-bold font-mono transition cursor-pointer">
            Cancel
          </button>
        </div>
      </div>

      <!-- Drag & Drop Photo Area -->
      <div id="leaf-dropzone" class="border-2 border-dashed border-emerald-700/60 hover:border-emerald-400 rounded-2xl p-5 text-center bg-emerald-950/20 hover:bg-emerald-950/30 transition cursor-pointer flex flex-col items-center justify-center gap-2">
        <div class="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shadow-inner">
          <i data-lucide="upload-cloud" class="w-6 h-6"></i>
        </div>
        <div>
          <p class="text-xs font-bold text-white">Drag & drop crop leaf photo here</p>
          <p class="text-[11px] text-gray-400 mt-0.5">Supports JPG, PNG, WEBP from your phone camera or gallery</p>
        </div>
        <input type="file" id="leaf-file-input" accept="image/*" class="hidden" />
        
        <div class="flex flex-wrap items-center gap-2 mt-1">
          <button id="browse-leaf-btn" type="button" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-md shadow-emerald-600/30">
            <i data-lucide="folder-open" class="w-4 h-4"></i>
            <span>Browse Image File</span>
          </button>
          
          <button id="btn-open-camera" type="button" class="px-3.5 py-2 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-md">
            <i data-lucide="camera" class="w-4 h-4"></i>
            <span>Live Camera</span>
          </button>
        </div>
      </div>

      <!-- Quick 1-Click Realistic Agricultural Leaf Disease Samples -->
      <div class="pt-2">
        <div class="flex items-center justify-between mb-2.5">
          <h4 class="text-xs font-black text-gray-200 uppercase tracking-wider font-mono flex items-center gap-1.5">
            <i data-lucide="sparkles" class="w-3.5 h-3.5 text-amber-400"></i>
            Or Test 1-Click Realistic Leaf Samples:
          </h4>
          <span class="text-[10px] text-gray-400 font-mono">Instant AI Diagnosis</span>
        </div>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          ${demoLeafSamples.map(s => `
            <button type="button" data-sample-id="${s.id}" data-crop="${s.cropKey || s.crop}" class="sample-leaf-btn text-left p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 hover:border-emerald-400 hover:bg-emerald-900/40 transition cursor-pointer group shadow-sm">
              <div class="flex items-center justify-between mb-1">
                <span class="text-xs font-bold text-white group-hover:text-emerald-300 transition">${s.label}</span>
                <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-emerald-400 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 transition"></i>
              </div>
              <p class="text-[11px] text-gray-300 truncate">${s.desc}</p>
            </button>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}
