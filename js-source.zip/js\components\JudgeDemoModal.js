// AgroSense SIH 5-Minute Polished Judge Demo Tour Component
// Renders the exact requested 12-step story sequence:
// Select demo farm → Farm Health Score → Soil Analysis → Crop Recommendation → Explain WHY → Weather Risk → Irrigation Recommendation → Leaf Disease Screening → AI Farmer Copilot → Daily Decision Center → Market Intelligence → Sustainability → National Agriculture Dashboard
// For EVERY step, displays: PROBLEM → DATA → AI → DECISION → ACTION → IMPACT

export function renderJudgeDemoModal(state) {
  if (!state.isJudgeDemoOpen) return '';

  const demoSteps = [
    {
      stepNum: 1,
      title: "Select Demarcated Farm Plot",
      route: "/dashboard",
      problem: "Farmers struggle to manage fragmented plot data across different tools.",
      data: "GPS Coordinates (18.5204° N, 73.8567° E), 8.5 Acres Vertisol Soil, Wheat HD-2967.",
      ai: "GIS Spatial Polygon & Farm Profile Aggregator",
      decision: "Selected demarcated farmer plot as active intelligence context.",
      action: "Load real-time field telemetry and microclimate window.",
      impact: "Single unified farm data layer established for all decision models."
    },
    {
      stepNum: 2,
      title: "Overall Farm Health Score",
      route: "/dashboard",
      problem: "Assessing overall farm condition requires synthesizing complex multi-sensor readings.",
      data: "Soil (78/100), Crop Vigor (88/100), Water (90/100), Weather (92/100), Disease (78/100).",
      ai: "S_farm = (0.25 × S_soil) + (0.25 × S_crop) + (0.20 × S_water) + (0.15 × S_weather) + (0.15 × S_disease)",
      decision: "Farm Health Score evaluated at 82 / 100 (Optimal Growth State).",
      action: "Identify Nitrogen deficit as primary bottleneck.",
      impact: "Early detection of nutrient deficiency before crop wilting occurs."
    },
    {
      stepNum: 3,
      title: "Soil Chemistry & Deficits Analysis",
      route: "/soil",
      problem: "Soil lab reports contain raw numbers difficult for farmers to interpret into fertilizer doses.",
      data: "N: 185 kg/ha (Low), P: 34 kg/ha, K: 310 kg/ha, pH: 7.2, Organic Carbon: 0.58%.",
      ai: "NPK Bio-Availability Chemistry & pH Fixation Penalty Engine (f_P(pH) = 1.0 - 0.22|pH - 6.8|^1.3)",
      decision: "Nitrogen is below recommended threshold (280 kg/ha) for Wheat vegetative stage.",
      action: "Apply split-dose urea top-dressing as advised by local extension officer.",
      impact: "Prevents N-deficiency chlorosis and increases Nitrogen Use Efficiency (NUE) by +22%."
    },
    {
      stepNum: 4,
      title: "AI Crop Recommendation",
      route: "/crop-recommendation",
      problem: "Choosing crops based on tradition often ignores soil chemistry and seasonal market prices.",
      data: "Soil NPK & pH, Ambient Soil Temp 24.5°C, 120-Day Seasonal Rain Window, Market Price ₹2,275.",
      ai: "XAI Multi-Factor Crop Suitability RandomForest Classifier",
      decision: "Top Candidate: Wheat HD-2967 (94% Suitability). Runner-up: Sugarcane (88%).",
      action: "Select Wheat for optimal winter cultivation cycle.",
      impact: "Maximizes potential crop yield and reduces seed failure risk."
    },
    {
      stepNum: 5,
      title: "Explain WHY (Explainable AI - XAI)",
      route: "/crop-recommendation",
      problem: "Black-box AI recommendations create distrust among farmers and agronomists.",
      data: "XAI Feature Contributions: Soil (+28 pts), Temp (+22 pts), Rain (+18 pts), pH (+14 pts).",
      ai: "Shapley Value Feature Importance & Mathematical Attribution Score",
      decision: "Attribution proves 94% score is driven by pH 7.2 neutral balance and 24.5°C temp match.",
      action: "Validate decision transparency with agricultural extension officer.",
      impact: "Builds full trust in AI recommendations with clear agronomic rationale."
    },
    {
      stepNum: 6,
      title: "Weather Intelligence & Risk Engine",
      route: "/weather",
      problem: "Generic weather news fails to warn about microclimate fungal spore germination risks.",
      data: "Live Open-Meteo API: 26.8°C Temp, 68% RH, 14.2mm Rain Forecasted for Tomorrow.",
      ai: "Fungal Spore Germination Index Math: I_spore = f(RH > 65%, T_canopy) = 0.68",
      decision: "Rain Warning & Fungal Rust Risk evaluated at MEDIUM-HIGH level.",
      action: "Delay planned pesticide spraying & drip pulse. Inspect leaf lamina in Zone A.",
      impact: "Saves chemical spray costs (₹1,850) and prevents wash-off into groundwater."
    },
    {
      stepNum: 7,
      title: "FAO-56 Penman-Monteith Smart Irrigation",
      route: "/irrigation",
      problem: "Over-irrigation wastes groundwater while underwatering causes crop wilting.",
      data: "Soil Moisture 32.4%, Temp 26.8°C, Wind 12.4 km/h, Rain Forecast Offset 14.2mm.",
      ai: "FAO-56 Penman-Monteith ET0 Water Balance Model: ETc = ET0 (4.15 mm/day) × Kc (0.75)",
      decision: "Daily Water Need = 3.11 mm/day. Rain offset covers requirement -> HOLD Irrigation.",
      action: "Keep Drip Solenoid Solenoid Valve OFF today.",
      impact: "Saves 42,000 Liters of groundwater per acre per week."
    },
    {
      stepNum: 8,
      title: "Plant Disease AI Vision Screening",
      route: "/disease",
      problem: "Early foliar diseases like Wheat Leaf Rust spread rapidly if undetected.",
      data: "Uploaded / Sample Leaf Photo (Puccinia triticina pustule features).",
      ai: "MobileNet / ResNet Vision Pathology Classifier Pipeline",
      decision: "Top Candidate: Wheat Leaf Rust (94.2% Confidence). Secondary: Powdery Mildew (4.1%).",
      action: "Confirm with KVK agronomist; apply targeted bio-fungicide if verified.",
      impact: "Prevents crop epidemic and saves up to 35% crop yield loss."
    },
    {
      stepNum: 9,
      title: "AgroSense Voice AI Farmer Copilot",
      route: "/ai-assistant",
      problem: "Illiterate or rural farmers struggle to navigate complex software interfaces.",
      data: "Voice Input Query: 'What should I prioritize on my farm today?'",
      ai: "AgroSense AI Conversational Engine + Web Speech API Text-to-Speech Audio Synthesis + RAG",
      decision: "AI answers in natural voice and cites verified ICAR / KVK research documents.",
      action: "Farmer listens to spoken audio guidance in native language (Hindi/Marathi).",
      impact: "100% accessible to every farmer regardless of digital literacy."
    },
    {
      stepNum: 10,
      title: "Daily Decision Center (Action Plan)",
      route: "/decision-center",
      problem: "Farmers get overwhelmed by raw data without clear daily action priorities.",
      data: "Synthesized inputs from Soil, Weather, Moisture, Disease, and Market modules.",
      ai: "Priority Action Matrix (WHY? WHAT? WHEN?)",
      decision: "Priority 1: Delay Drip Irrigation (Rain tomorrow). Priority 2: Nitrogen top-dressing post-rain.",
      action: "Execute clear 3-step field task list today.",
      impact: "Saves operational time, lowers input costs, and boosts farm productivity."
    },
    {
      stepNum: 11,
      title: "APMC Mandi Market Intelligence",
      route: "/market",
      problem: "Farmers sell at low harvest glut prices due to lack of mandi price visibility.",
      data: "Pune APMC Mandi Price: ₹2,275 / Qtl (+2.4% trend), Kolhapur: ₹3,400 / Tonne.",
      ai: "APMC Price Volatility Analysis & Gross Margin Profitability Engine",
      decision: "Projected Gross Margin: ₹2,22,500 (+42.5% ROI).",
      action: "Utilize e-NAM registered scientific warehouse storage post-harvest.",
      impact: "Increases net farmer income by +15% through strategic market timing."
    },
    {
      stepNum: 12,
      title: "National Agriculture Dashboard & Privacy",
      route: "/national-dashboard",
      problem: "Institutions lack macro crop data while farmers fear private land data leaks.",
      data: "Aggregated telemetry across 52,000+ farms in Maharashtra, Punjab, Gujarat & Karnataka.",
      ai: "Differential Privacy Engine (Laplace Noise ε=0.5, k-Anonymity ≥ 5, GPS Obfuscation ±500m)",
      decision: "State Agriculture Dept receives anonymized regional nitrogen deficit heatmaps.",
      action: "Target government fertilizer subsidies to deficit districts without exposing farm locations.",
      impact: "National agricultural policy scalability with 100% farmer privacy protection."
    }
  ];

  const currentStepIdx = state.judgeDemoStep || 0;
  const currentStep = demoSteps[currentStepIdx];
  const isFirst = currentStepIdx === 0;
  const isLast = currentStepIdx === demoSteps.length - 1;

  return `
    <div class="modal-overlay">
      <div class="modal-content border-2 border-emerald-500/60 bg-[#071310] max-w-4xl">
        <!-- Top Bar Header -->
        <div class="flex items-center justify-between pb-3 border-b border-emerald-800/50">
          <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-500 to-amber-500 text-black flex items-center justify-center font-black text-sm shadow-md">
              ⚡
            </div>
            <div>
              <div class="flex items-center gap-2">
                <h3 class="text-base font-extrabold text-white">AGROSENSE INTERACTIVE PLATFORM TOUR</h3>
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">STEP ${currentStep.stepNum} OF 12</span>
              </div>
              <p class="text-xs text-emerald-400 font-semibold">${currentStep.title}</p>
            </div>
          </div>
          <button id="close-judge-modal-btn" class="p-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-emerald-900/50">
            <i data-lucide="x" class="w-5 h-5"></i>
          </button>
        </div>

        <!-- STORY PIPELINE: PROBLEM -> DATA -> AI -> DECISION -> ACTION -> IMPACT -->
        <div class="py-5 space-y-4">
          <!-- Step Route Badge -->
          <div class="flex items-center justify-between text-xs">
            <span class="text-gray-400">Target Feature Route: <b class="text-emerald-300 font-mono">${currentStep.route}</b></span>
            <span class="prototype-badge">INTERACTIVE ARCHITECTURE TOUR</span>
          </div>

          <!-- 6-Stage Story Grid -->
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
            <!-- 1. PROBLEM -->
            <div class="p-3.5 rounded-xl bg-red-950/30 border border-red-500/30 space-y-1">
              <div class="flex items-center gap-1.5 text-red-400 font-extrabold text-[11px] uppercase tracking-wider">
                <i data-lucide="alert-circle" class="w-3.5 h-3.5"></i>
                1. PROBLEM
              </div>
              <p class="text-gray-200 leading-tight">${currentStep.problem}</p>
            </div>

            <!-- 2. DATA -->
            <div class="p-3.5 rounded-xl bg-blue-950/30 border border-blue-500/30 space-y-1">
              <div class="flex items-center gap-1.5 text-blue-400 font-extrabold text-[11px] uppercase tracking-wider">
                <i data-lucide="database" class="w-3.5 h-3.5"></i>
                2. DATA INPUTS
              </div>
              <p class="text-gray-200 leading-tight font-mono text-[11px]">${currentStep.data}</p>
            </div>

            <!-- 3. AI -->
            <div class="p-3.5 rounded-xl bg-teal-950/40 border border-teal-500/40 space-y-1">
              <div class="flex items-center gap-1.5 text-teal-300 font-extrabold text-[11px] uppercase tracking-wider">
                <i data-lucide="cpu" class="w-3.5 h-3.5"></i>
                3. AI / MATH MODEL
              </div>
              <p class="text-teal-100 font-semibold leading-tight text-[11px]">${currentStep.ai}</p>
            </div>

            <!-- 4. DECISION -->
            <div class="p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/30 space-y-1">
              <div class="flex items-center gap-1.5 text-amber-300 font-extrabold text-[11px] uppercase tracking-wider">
                <i data-lucide="brain-circuit" class="w-3.5 h-3.5"></i>
                4. AI DECISION
              </div>
              <p class="text-amber-100 font-semibold leading-tight text-[11px]">${currentStep.decision}</p>
            </div>

            <!-- 5. ACTION -->
            <div class="p-3.5 rounded-xl bg-emerald-950/50 border border-emerald-500/40 space-y-1">
              <div class="flex items-center gap-1.5 text-emerald-400 font-extrabold text-[11px] uppercase tracking-wider">
                <i data-lucide="check-circle-2" class="w-3.5 h-3.5"></i>
                5. FARMER ACTION
              </div>
              <p class="text-emerald-100 font-semibold leading-tight text-[11px]">${currentStep.action}</p>
            </div>

            <!-- 6. IMPACT -->
            <div class="p-3.5 rounded-xl bg-gradient-to-br from-emerald-900/60 to-teal-950/80 border border-emerald-400/50 space-y-1">
              <div class="flex items-center gap-1.5 text-emerald-300 font-extrabold text-[11px] uppercase tracking-wider">
                <i data-lucide="trending-up" class="w-3.5 h-3.5"></i>
                6. MEASURABLE IMPACT
              </div>
              <p class="text-white font-extrabold leading-tight text-[11px]">${currentStep.impact}</p>
            </div>
          </div>

          <!-- Bottom Story Pipeline Strip -->
          <div class="p-2.5 rounded-lg bg-emerald-950/80 border border-emerald-800/60 text-center font-bold text-[11px] text-amber-300 tracking-wider">
            PROBLEM → DATA → AI MODEL → DECISION → ACTION → MEASURABLE IMPACT
          </div>
        </div>

        <!-- Navigation Controls -->
        <div class="flex items-center justify-between pt-3 border-t border-emerald-800/50">
          <button id="prev-judge-step-btn" class="px-4 py-2 rounded-xl border border-emerald-700/50 text-gray-300 hover:text-white text-xs font-bold ${isFirst ? 'opacity-40 cursor-not-allowed' : ''}" ${isFirst ? 'disabled' : ''}>
            ← Previous Step
          </button>

          <div class="flex items-center gap-2">
            <button id="jump-step-route-btn" data-route="${currentStep.route}" class="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold shadow-md">
              Go To Page
            </button>
            <button id="next-judge-step-btn" class="px-6 py-2 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-amber-500 text-black text-xs font-extrabold shadow-xl hover:scale-105 transition transform active:scale-95">
              ${isLast ? 'Finish Guided Tour' : 'Next Step →'}
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
}
