// AgroSense Computer Vision Crop Detection Model
// Dedicated Stage 1 Crop Species Identification Engine
// Architecture: MobileNet V1 Feature Extractor + 14-Species Agricultural Classification Head

const CROP_MODEL_STATUS = {
  IDLE: 'idle',
  LOADING: 'loading',
  READY: 'ready',
  ERROR: 'error'
};

const SUPPORTED_CROP_CLASSES = [
  { idx: 0, key: 'apple', name: 'Apple (सेब)', scientific: 'Malus domestica', family: 'Rosaceae' },
  { idx: 1, key: 'blueberry', name: 'Blueberry (ब्लूबेरी)', scientific: 'Vaccinium corymbosum', family: 'Ericaceae' },
  { idx: 2, key: 'cherry', name: 'Cherry (चेरी)', scientific: 'Prunus avium', family: 'Rosaceae' },
  { idx: 3, key: 'maize', name: 'Maize / Corn (मक्का / मका)', scientific: 'Zea mays', family: 'Poaceae' },
  { idx: 4, key: 'grape', name: 'Grape (अंगूर / द्राक्षे)', scientific: 'Vitis vinifera', family: 'Vitaceae' },
  { idx: 5, key: 'orange', name: 'Orange / Citrus (संतरा)', scientific: 'Citrus sinensis', family: 'Rutaceae' },
  { idx: 6, key: 'peach', name: 'Peach (आड़ू)', scientific: 'Prunus persica', family: 'Rosaceae' },
  { idx: 7, key: 'pepper_bell', name: 'Bell Pepper / Capsicum (शिमला मिर्च)', scientific: 'Capsicum annuum var. grossum', family: 'Solanaceae' },
  { idx: 8, key: 'potato', name: 'Potato (आलू / बटाटा)', scientific: 'Solanum tuberosum', family: 'Solanaceae' },
  { idx: 9, key: 'raspberry', name: 'Raspberry (रास्पबेरी)', scientific: 'Rubus idaeus', family: 'Rosaceae' },
  { idx: 10, key: 'soybean', name: 'Soybean (सोयाबीन)', scientific: 'Glycine max', family: 'Fabaceae' },
  { idx: 11, key: 'squash', name: 'Squash (कद्दू)', scientific: 'Cucurbita pepo', family: 'Cucurbitaceae' },
  { idx: 12, key: 'strawberry', name: 'Strawberry (स्ट्रॉबेरी)', scientific: 'Fragaria ananassa', family: 'Rosaceae' },
  { idx: 13, key: 'tomato', name: 'Tomato (टमाटर / टोमॅटो)', scientific: 'Solanum lycopersicum', family: 'Solanaceae' },
  { idx: 14, key: 'cotton', name: 'Cotton (कपास / कापूस)', scientific: 'Gossypium hirsutum', family: 'Malvaceae' },
  { idx: 15, key: 'wheat', name: 'Wheat (गेहूं / गहू)', scientific: 'Triticum aestivum', family: 'Poaceae' },
  { idx: 16, key: 'chilli', name: 'Chilli Pepper (मिर्च / मिरची)', scientific: 'Capsicum annuum', family: 'Solanaceae' },
  { idx: 17, key: 'rice', name: 'Rice / Paddy (धान / तांदूळ)', scientific: 'Oryza sativa', family: 'Poaceae' }
];

const CROP_KEY_MAP = {};
SUPPORTED_CROP_CLASSES.forEach(c => {
  CROP_KEY_MAP[c.key] = c;
});

let cropModelState = {
  status: CROP_MODEL_STATUS.IDLE,
  error: null,
  activeUrl: null,
  backend: null,
  numClasses: 18,
  inputShape: [null, 224, 224, 3],
  diagnostics: [],
  loadedAt: null
};

const cropModelStatusListeners = new Set();

function subscribeCropModelStatus(listener) {
  cropModelStatusListeners.add(listener);
  try { listener(cropModelState); } catch (e) {}
  return () => cropModelStatusListeners.delete(listener);
}

function setCropModelState(updates) {
  cropModelState = { ...cropModelState, ...updates };
  cropModelStatusListeners.forEach(listener => {
    try { listener(cropModelState); } catch (e) { console.error('[AgroSense Crop CV] Status listener error:', e); }
  });
}

function getCropModelStatus() {
  return cropModelState;
}

let cachedCropModel = null;
let activeCropInitPromise = null;

/**
 * Resolves the primary absolute deployment URL for a model resource
 * Accurately handles:
 * - GitHub Pages project subpaths (e.g. https://<owner>.github.io/<repo>/models/...)
 * - Local development servers (http://localhost:3000/models/...)
 * - Document <base href> tags if present
 * - Custom domains and root hosting
 * Guarantees NO duplicate repository paths like /repo/repo/models/...
 */
function resolveModelUrl(modelSubpath) {
  const cleanSubpath = modelSubpath.replace(/^\/+/, '');
  if (typeof window === 'undefined' || !window.location) {
    return cleanSubpath;
  }

  const origin = window.location.origin || (window.location.protocol + '//' + window.location.host);
  if (!origin || origin === 'null' || origin.startsWith('file:')) {
    return cleanSubpath;
  }

  // 1. GitHub Pages (*.github.io)
  if (window.location.hostname && window.location.hostname.endsWith('github.io')) {
    const pathname = window.location.pathname || '/';
    const segments = pathname.split('/').filter(Boolean);
    if (segments.length > 0) {
      const repoName = segments[0];
      return `${origin}/${repoName}/${cleanSubpath}`;
    }
  }

  // 2. Document baseURI (if specified via <base>)
  if (typeof document !== 'undefined' && document.baseURI) {
    try {
      const baseUri = new URL(document.baseURI);
      let p = baseUri.pathname;
      if (!p.endsWith('/')) {
        p = p.substring(0, p.lastIndexOf('/') + 1);
      }
      return `${baseUri.origin}${p}${cleanSubpath}`;
    } catch (e) {}
  }

  // 3. Localhost or standard web server
  let dirPath = window.location.pathname || '/';
  if (dirPath.includes('.')) {
    dirPath = dirPath.substring(0, dirPath.lastIndexOf('/') + 1);
  }
  if (!dirPath.endsWith('/')) {
    dirPath += '/';
  }

  return `${origin}${dirPath}${cleanSubpath}`;
}

/**
 * Resolves candidate crop model URLs in priority order
 * Supports Localhost, subpaths, and GitHub Pages deployments
 */
function getCandidateCropModelUrls() {
  const primaryUrl = resolveModelUrl('models/crop/model.json');
  console.log('[AgroSense CV] Resolved Crop Model Primary URL:', primaryUrl);

  const candidates = [primaryUrl];

  if (typeof window !== 'undefined' && window.location) {
    const origin = window.location.origin || (window.location.protocol + '//' + window.location.host);

    // Fallback 1: jsDelivr CDN mirror for GitHub repository (supports CORS with *)
    if (window.location.hostname && window.location.hostname.endsWith('github.io')) {
      const segments = (window.location.pathname || '/').split('/').filter(Boolean);
      const owner = window.location.hostname.split('.')[0];
      const repo = segments[0] || 'AgroSense-AI-Powered-Smart-Agriculture-Farm-Intelligence-Platform';
      candidates.push(`https://cdn.jsdelivr.net/gh/${owner}/${repo}@main/models/crop/model.json`);
      candidates.push(`https://raw.githubusercontent.com/${owner}/${repo}/main/models/crop/model.json`);
    }

    // Fallback 2: Domain root (for apex custom domain deployments)
    if (origin && origin !== 'null' && !origin.startsWith('file:')) {
      candidates.push(`${origin}/models/crop/model.json`);
    }
  }

  return [...new Set(candidates)];
}

function fetchWithTimeout(url, timeoutMs = 8000) {
  if (typeof AbortController === 'undefined') {
    return fetch(url, { method: 'GET' });
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  return fetch(url, { method: 'GET', signal: controller.signal })
    .finally(() => clearTimeout(timer));
}

function loadLayersModelWithTimeout(tf, url, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`Model download timed out after ${timeoutMs}ms while retrieving ${url}`));
    }, timeoutMs);
    tf.loadLayersModel(url)
      .then(m => {
        clearTimeout(timer);
        resolve(m);
      })
      .catch(err => {
        clearTimeout(timer);
        reject(err);
      });
  });
}

async function ensureTensorFlowReady() {
  let tf = null;
  if (typeof window !== 'undefined') {
    if (window.tf) {
      tf = window.tf;
    } else {
      let attempts = 0;
      while (!window.tf && attempts < 30) {
        await new Promise(r => setTimeout(r, 100));
        attempts++;
      }
      if (window.tf) {
        tf = window.tf;
      } else if (typeof document !== 'undefined') {
        // Dynamically inject script tag if missing from document head
        await new Promise((resolve, reject) => {
          const existing = document.querySelector('script[src*="tf.min.js"]');
          if (existing) {
            existing.addEventListener('load', () => resolve());
            existing.addEventListener('error', () => reject(new Error('TensorFlow.js script failed to load.')));
            setTimeout(() => { if (window.tf) resolve(); else reject(new Error('TFJS load timed out.')); }, 8000);
            return;
          }
          const s = document.createElement('script');
          s.src = 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/tf.min.js';
          s.crossOrigin = 'anonymous';
          s.onload = () => resolve();
          s.onerror = () => reject(new Error('Failed to load TensorFlow.js from CDN.'));
          document.head.appendChild(s);
          setTimeout(() => { if (window.tf) resolve(); else reject(new Error('TFJS script injection timed out.')); }, 8000);
        });
        tf = window.tf;
      }
    }
  } else {
    try {
      tf = require('@tensorflow/tfjs');
    } catch (e) {
      tf = require('./node_modules/@tensorflow/tfjs');
    }
  }

  if (!tf || !tf.loadLayersModel) {
    throw new Error('TensorFlow.js loadLayersModel API is unavailable for crop classification.');
  }

  if (tf.ready) {
    await tf.ready();
  }
  return tf;
}

function base64ToArrayBuffer(base64) {
  if (typeof window !== 'undefined' && window.atob) {
    const binaryString = window.atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }
  return Buffer.from(base64, 'base64').buffer;
}

/**
 * Validates crop model architecture and runs safe dummy test inference
 */
function validateAndTestCropModel(tf, model, recordDiagnostic) {
  const inShape = model.inputs[0]?.shape;
  recordDiagnostic('VALIDATE_INPUT', `Validating crop model input dimensions: ${JSON.stringify(inShape)}`);
  if (!inShape || inShape.length !== 4 || inShape[1] !== 224 || inShape[2] !== 224 || inShape[3] !== 3) {
    throw new Error(`Invalid crop model input shape: ${JSON.stringify(inShape)}, expected [null, 224, 224, 3]`);
  }

  const outShape = model.outputs[0]?.shape;
  recordDiagnostic('VALIDATE_OUTPUT', `Validating crop model output dimensions: ${JSON.stringify(outShape)}`);
  if (!outShape || outShape[outShape.length - 1] !== 18) {
    throw new Error(`Invalid crop model output shape: ${JSON.stringify(outShape)}, expected 18 classes`);
  }

  recordDiagnostic('TEST_INFERENCE', 'Executing test inference with [1, 224, 224, 3] zero-tensor...');
  tf.tidy(() => {
    const dummy = tf.zeros([1, 224, 224, 3]);
    const pred = model.predict(dummy);
    const data = pred.dataSync();
    if (!data || data.length !== 18) {
      throw new Error(`Dummy crop prediction produced ${data?.length} classes, expected 18.`);
    }
  });
  recordDiagnostic('TEST_INFERENCE_PASSED', 'Crop test inference verified 18-class agricultural distribution.');
}

/**
 * Crop Model Lifecycle Initializer
 * Probes candidates, manages loading states, logs diagnostics, and supports retry
 */
async function initCropModel({ force = false } = {}) {
  if (cropModelState.status === CROP_MODEL_STATUS.READY && cachedCropModel && !force) {
    return cachedCropModel;
  }
  if (activeCropInitPromise && !force) {
    return activeCropInitPromise;
  }

  activeCropInitPromise = (async () => {
    setCropModelState({
      status: CROP_MODEL_STATUS.LOADING,
      error: null,
      diagnostics: []
    });

    const diagnostics = [];
    let lastFailure = null;
    function recordDiagnostic(stage, message, details = {}) {
      const entry = { stage, message, timestamp: new Date().toISOString(), ...details };
      diagnostics.push(entry);
      console.log(`[AgroSense Crop Model] [${stage}] ${message}`, Object.keys(details).length ? details : '');
    }

    try {
      recordDiagnostic('BACKEND_INIT', 'Verifying TensorFlow.js availability and initializing backend engine...');
      const tf = await ensureTensorFlowReady();
      const backend = tf.getBackend ? tf.getBackend() : 'webgl';
      recordDiagnostic('BACKEND_READY', `TensorFlow.js engine ready on backend: ${backend}`);

      // 0. Pre-packaged Zero-CORS In-Memory Weights (Direct file://, Localhost, or Offline)
      if (typeof window !== 'undefined' && window.__AgroSense_CropModelData) {
        recordDiagnostic('ZERO_CORS_LOAD', 'Found pre-packaged Zero-CORS Crop model data in memory. Initializing model directly...');
        const pkgData = window.__AgroSense_CropModelData;
        const weightBuffer = base64ToArrayBuffer(pkgData.weightDataBase64);
        const inMemoryLoader = {
          load: async () => ({
            modelTopology: pkgData.modelTopology,
            weightSpecs: pkgData.weightSpecs,
            weightData: weightBuffer
          })
        };
        const model = await tf.loadLayersModel(inMemoryLoader);
        validateAndTestCropModel(tf, model, recordDiagnostic);
        cachedCropModel = model;
        setCropModelState({
          status: CROP_MODEL_STATUS.READY,
          error: null,
          activeUrl: 'in-memory://crop-model (Zero-CORS Packaged)',
          backend,
          numClasses: 18,
          inputShape: [null, 224, 224, 3],
          diagnostics,
          isZeroCors: true,
          loadedAt: new Date().toISOString()
        });
        return model;
      }

      // Check for file:// Protocol without packaged weights
      if (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:') {
        const fileErr = 'Local AI model loading requires a local web server or pre-packaged model weights. Modern web browsers block fetch() requests for local file:// resources due to security sandboxing.';
        recordDiagnostic('FILE_PROTOCOL_RESTRICTION', fileErr);
        setCropModelState({
          status: CROP_MODEL_STATUS.ERROR,
          error: fileErr,
          errorType: 'file-protocol',
          isFileProtocol: true,
          resolvedUrl: 'models/crop/model.json',
          diagnostics
        });
        throw new Error(fileErr);
      }

      // Node.js test environment support (e.g. CLI runner)
      if (typeof window === 'undefined') {
        const fs = require('fs');
        const path = require('path');
        const modelDir = path.resolve(__dirname, '../../models/crop');
        const modelJsonPath = path.join(modelDir, 'model.json');

        if (fs.existsSync(modelJsonPath)) {
          recordDiagnostic('NODE_FS_LOAD', `Loading crop model from filesystem: ${modelJsonPath}`);
          const modelJson = JSON.parse(fs.readFileSync(modelJsonPath, 'utf8'));
          const manifest = modelJson.weightsManifest[0];
          const buffers = manifest.paths.map(p => fs.readFileSync(path.join(modelDir, p)));
          const weightBuffer = Buffer.concat(buffers);

          const loader = {
            load: async () => ({
              modelTopology: modelJson.modelTopology,
              weightSpecs: manifest.weights,
              weightData: weightBuffer.buffer.slice(weightBuffer.byteOffset, weightBuffer.byteOffset + weightBuffer.byteLength)
            })
          };

          const model = await tf.loadLayersModel(loader);
          validateAndTestCropModel(tf, model, recordDiagnostic);
          cachedCropModel = model;
          setCropModelState({
            status: CROP_MODEL_STATUS.READY,
            error: null,
            activeUrl: modelJsonPath,
            backend,
            numClasses: 14,
            inputShape: [null, 224, 224, 3],
            diagnostics,
            loadedAt: new Date().toISOString()
          });
          return model;
        }
      }

      // Browser Environment: probe candidate URLs
      const candidates = getCandidateCropModelUrls();
      recordDiagnostic('CANDIDATES_RESOLVED', `Resolved ${candidates.length} candidate crop model URLs`, { candidates });

      let loadedModel = null;
      let successfulUrl = null;
      let lastFailure = null;

      for (const candidateUrl of candidates) {
        recordDiagnostic('PROBE_URL', `Probing candidate crop model URL: ${candidateUrl}`);

        let probeOk = false;
        let responseStatus = null;
        let responseStatusText = null;

        try {
          const res = await fetchWithTimeout(candidateUrl, 8000);
          responseStatus = res.status;
          responseStatusText = res.statusText;

          if (!res.ok) {
            recordDiagnostic('PROBE_FAILED', `Candidate returned HTTP ${res.status} (${res.statusText || 'Not Found'}): ${candidateUrl}`, {
              url: candidateUrl,
              status: res.status
            });
            lastFailure = {
              url: candidateUrl,
              status: res.status,
              statusText: res.statusText,
              error: `HTTP ${res.status} (${res.statusText || 'Not Found'})`,
              stage: 'PROBE'
            };
            continue;
          }

          const cType = res.headers.get('content-type') || '';
          if (cType.includes('text/html')) {
            recordDiagnostic('PROBE_FAILED', `Candidate returned HTML instead of JSON (404 Fallback page): ${candidateUrl}`, {
              url: candidateUrl,
              contentType: cType
            });
            lastFailure = {
              url: candidateUrl,
              status: 404,
              statusText: 'Not Found',
              error: 'Server returned HTML error page (404 Fallback)',
              stage: 'PROBE'
            };
            continue;
          }
          probeOk = true;
        } catch (fetchErr) {
          const isTimeout = fetchErr.name === 'AbortError' || String(fetchErr).includes('abort');
          const errorMsg = isTimeout ? 'Network timeout after 8000ms' : (fetchErr.message || 'Failed to fetch');
          recordDiagnostic('PROBE_FAILED', `Candidate fetch threw error: ${errorMsg}`, {
            url: candidateUrl,
            error: errorMsg
          });
          lastFailure = {
            url: candidateUrl,
            status: isTimeout ? 408 : 0,
            statusText: isTimeout ? 'Request Timeout' : 'Network Error',
            error: errorMsg,
            stage: 'PROBE'
          };
          continue;
        }

        if (probeOk) {
          try {
            recordDiagnostic('TF_LOAD_START', `Loading crop model configuration and weights from ${candidateUrl}`);
            const model = await loadLayersModelWithTimeout(tf, candidateUrl, 15000);
            recordDiagnostic('TF_LOAD_SUCCESS', `Weights successfully downloaded and assembled from ${candidateUrl}`);

            validateAndTestCropModel(tf, model, recordDiagnostic);

            loadedModel = model;
            successfulUrl = candidateUrl;
            break;
          } catch (loadErr) {
            recordDiagnostic('TF_LOAD_FAILED', `TensorFlow.js failed loading weights from ${candidateUrl}: ${loadErr.message}`, {
              url: candidateUrl,
              error: loadErr.message || String(loadErr)
            });
            lastFailure = {
              url: candidateUrl,
              status: responseStatus || 200,
              error: loadErr.message || String(loadErr),
              stage: 'TF_LOAD'
            };
          }
        }
      }

      if (!loadedModel) {
        const primaryCandidate = candidates[0];
        let errorDetail;
        if (lastFailure) {
          if (lastFailure.status === 404 || String(lastFailure.error).includes('404')) {
            errorDetail = `Crop model configuration not found at ${lastFailure.url} (HTTP 404: Not Found). Ensure "models/crop/model.json" and "group1-shard1of1.bin" are deployed to the web server or GitHub Pages repository.`;
          } else if (lastFailure.stage === 'TF_LOAD') {
            errorDetail = `Crop model configuration loaded from ${lastFailure.url}, but TensorFlow.js failed reading weight shards (${lastFailure.error}). Verify weight binary files exist.`;
          } else {
            errorDetail = `Could not access crop model at ${lastFailure.url}: ${lastFailure.error}`;
          }
        } else {
          errorDetail = `Unable to reach crop model weights at primary endpoint: ${primaryCandidate}`;
        }
        throw new Error(errorDetail);
      }

      cachedCropModel = loadedModel;
      setCropModelState({
        status: CROP_MODEL_STATUS.READY,
        error: null,
        activeUrl: successfulUrl,
        resolvedUrl: successfulUrl,
        backend,
        numClasses: 18,
        inputShape: [null, 224, 224, 3],
        diagnostics,
        loadedAt: new Date().toISOString()
      });

      return loadedModel;
    } catch (finalErr) {
      recordDiagnostic('FATAL_ERROR', `Crop model initialization aborted: ${finalErr.message}`);
      cachedCropModel = null;
      const isFileProto = (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:') ||
        String(finalErr.message).includes('file://');
      setCropModelState({
        status: CROP_MODEL_STATUS.ERROR,
        error: finalErr.message || 'Crop model failed to initialize.',
        errorType: isFileProto ? 'file-protocol' : 'initialization-error',
        isFileProtocol: isFileProto,
        resolvedUrl: (typeof candidates !== 'undefined' && candidates) ? candidates[0] : 'models/crop/model.json',
        lastFailure,
        diagnostics
      });
      throw finalErr;
    } finally {
      activeCropInitPromise = null;
    }
  })();

  return activeCropInitPromise;
}

/**
 * Predicts crop species from an HTML Image Element or Canvas
 * Preprocessing: 224x224, Bilinear, BGR Channel Reversal, [0, 1] Normalization
 */
async function detectCropFromImage(imageElement) {
  const model = await initCropModel();
  const tf = await ensureTensorFlowReady();

  const startTime = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();

  return tf.tidy(() => {
    // 1. Image Preprocessing: fromPixels -> Float32 -> Bilinear 224x224
    const rawTensor = tf.browser.fromPixels(imageElement).toFloat();
    const resizedTensor = tf.image.resizeBilinear(rawTensor, [224, 224]);

    // 2. MobileNet BGR Channel Order
    const bgrTensor = tf.reverse(resizedTensor, -1);

    // 3. Normalization [0, 1] and batch dimension [1, 224, 224, 3]
    const normalizedTensor = bgrTensor.div(255.0).expandDims(0);

    // 4. Model Prediction
    const predictionTensor = model.predict(normalizedTensor);
    const probabilities = Array.from(predictionTensor.dataSync());

    const endTime = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    const latencyMs = Number((endTime - startTime).toFixed(1));

    // 5. Decode Logit Distribution Across 18 Supported Crops
    const rankedPredictions = SUPPORTED_CROP_CLASSES.map(cls => {
      const prob = probabilities[cls.idx] || 0;
      return {
        idx: cls.idx,
        cropKey: cls.key,
        cropName: cls.name,
        scientificName: cls.scientific,
        family: cls.family,
        score: Number(prob.toFixed(4)),
        relativeConfidence: Number((prob * 100).toFixed(1))
      };
    }).sort((a, b) => b.score - a.score);

    const topCandidate = rankedPredictions[0];
    const runnerUp = rankedPredictions[1] || null;

    // Minimum diagnostic confidence threshold (25%)
    const isAmbiguous = topCandidate.score < 0.25;

    const diagnosticTelemetry = {
      modelIdentifier: 'MobileNet V1 Crop Classifier (18 Species Architecture)',
      modelVersion: 'v3.0.0-multicrop-cv',
      inputDimensions: '[1, 224, 224, 3] Float32 (224x224 RGB/BGR normalized [0, 1])',
      preprocessing: 'Bilinear Resize [224, 224] • Channel Reversal (BGR) • [0, 1] Normalization',
      supportedCropClasses: '18 Agricultural Species (Apple, Blueberry, Cherry, Corn/Maize, Grape, Orange, Peach, Bell Pepper, Potato, Raspberry, Soybean, Squash, Strawberry, Tomato, Cotton, Wheat, Chilli, Rice)',
      inferenceLatencyMs: latencyMs,
      topFivePredictions: rankedPredictions.slice(0, 5)
    };

    return {
      isValidImage: true,
      cropKey: topCandidate.cropKey,
      cropName: topCandidate.cropName,
      scientificName: topCandidate.scientificName,
      family: topCandidate.family,
      confidence: topCandidate.relativeConfidence,
      score: topCandidate.score,
      isAmbiguous,
      runnerUp: runnerUp ? { cropKey: runnerUp.cropKey, cropName: runnerUp.cropName, confidence: runnerUp.relativeConfidence } : null,
      topCandidates: rankedPredictions.slice(0, 5),
      diagnosticTelemetry,
      probabilities
    };
  });
}

exports.CROP_MODEL_STATUS = CROP_MODEL_STATUS;
exports.SUPPORTED_CROP_CLASSES = SUPPORTED_CROP_CLASSES;
exports.initCropModel = initCropModel;
exports.getCropModelStatus = getCropModelStatus;
exports.subscribeCropModelStatus = subscribeCropModelStatus;
exports.detectCropFromImage = detectCropFromImage;
exports.getCandidateCropModelUrls = getCandidateCropModelUrls;
