// AGROSENSE DATASET EXPLORER & SCHEMA INSPECTOR PAGE (/#/dataset)

import { calculateDatasetStats, calculateDatasetQualityScore } from '../ml/fodsMLEngine.js';
import { sampleAgrosenseDataset, datasetMeta } from '../data/agrosenseDataset.js';

export function renderDatasetPage(state) {
  const dataset = state.customDataset || sampleAgrosenseDataset;

  const stats = calculateDatasetStats(dataset);
  const quality = calculateDatasetQualityScore(stats);

  return `
    <div class="space-y-8 max-w-7xl mx-auto py-2">
      <!-- Page Header -->
      <div class="flex flex-wrap items-center justify-between gap-4 border-b border-emerald-950/80 pb-4">
        <div>
          <div class="flex items-center gap-2">
            <h1 class="text-2xl font-extrabold text-white tracking-tight">Dataset Explorer & Schema Inspector</h1>
            <span class="px-2.5 py-0.5 rounded text-xs font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">ICAR BENCHMARK DATASET</span>
          </div>
          <p class="text-xs text-gray-400 mt-1">Inspect agricultural sample rows, feature data types, missing values, duplicates & calculate dataset quality score</p>
        </div>

        <div class="flex items-center gap-2">
          <button id="btn-load-demo-fods-dataset" class="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 transition flex items-center gap-2">
            <i data-lucide="database" class="w-4 h-4"></i> Load ICAR Benchmark Dataset (2,200 Rows)
          </button>
        </div>
      </div>

      <!-- Drag & Drop CSV / Excel File Upload -->
      <div class="glass-card p-6 border-dashed border-2 border-emerald-500/30 rounded-2xl text-center space-y-3">
        <i data-lucide="upload-cloud" class="w-10 h-10 text-emerald-400 mx-auto"></i>
        <div>
          <h3 class="text-sm font-bold text-white">Upload Agricultural Dataset (.CSV / .XLSX)</h3>
          <p class="text-xs text-gray-400 mt-0.5">Drag and drop your dataset file here or click to browse</p>
        </div>
        <input type="file" id="dataset-file-input" accept=".csv, .xlsx" class="hidden" />
        <label for="dataset-file-input" class="inline-block px-4 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 text-gray-300 border border-gray-700 text-xs font-semibold cursor-pointer transition">
          Browse File
        </label>
      </div>

      <!-- Dataset Statistics Metric Cards -->
      <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
        <div class="glass-card p-4 space-y-1">
          <span class="text-[11px] font-bold text-gray-400">Total Dataset Rows</span>
          <div class="text-xl font-extrabold text-white font-mono">${datasetMeta.totalRows.toLocaleString()}</div>
          <span class="text-[10px] text-emerald-400 font-semibold font-mono">agrosense_dataset.csv</span>
        </div>
        <div class="glass-card p-4 space-y-1">
          <span class="text-[11px] font-bold text-gray-400">Total Features (Cols)</span>
          <div class="text-xl font-extrabold text-teal-300 font-mono">${stats.totalCols}</div>
        </div>
        <div class="glass-card p-4 space-y-1">
          <span class="text-[11px] font-bold text-gray-400">Numerical Features</span>
          <div class="text-xl font-extrabold text-emerald-300 font-mono">${stats.numCols.length}</div>
        </div>
        <div class="glass-card p-4 space-y-1">
          <span class="text-[11px] font-bold text-gray-400">Categorical Features</span>
          <div class="text-xl font-extrabold text-blue-300 font-mono">${stats.catCols.length}</div>
        </div>
        <div class="glass-card p-4 space-y-1">
          <span class="text-[11px] font-bold text-gray-400">Missing Values</span>
          <div class="text-xl font-extrabold ${stats.missingCount > 0 ? 'text-amber-400' : 'text-emerald-400'} font-mono">${stats.missingCount} (${stats.missingPct}%)</div>
        </div>
        <div class="glass-card p-4 space-y-1">
          <span class="text-[11px] font-bold text-gray-400">Quality Score</span>
          <div class="text-xl font-extrabold text-emerald-400 font-mono">${quality.score} / 100</div>
        </div>
      </div>

      <!-- Data Table Inspector -->
      <div class="glass-card p-6 space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold text-white flex items-center gap-2">
            <i data-lucide="table" class="w-4 h-4 text-emerald-400"></i>
            Interactive Data Table
          </h3>
          <span class="text-xs text-gray-400 font-mono">Showing first ${Math.min(50, dataset.length)} rows</span>
        </div>

        <div class="overflow-x-auto rounded-xl border border-emerald-950/60">
          <table class="w-full text-left text-xs font-mono">
            <thead class="bg-[#0b1c16] text-emerald-400 uppercase text-[10px] tracking-wider border-b border-emerald-950">
              <tr>
                ${stats.columns.map(col => `<th class="p-3">${col}</th>`).join('')}
              </tr>
            </thead>
            <tbody class="divide-y divide-emerald-950/40 text-gray-300">
              ${dataset.slice(0, 15).map(row => `
                <tr class="hover:bg-emerald-950/30 transition">
                  ${stats.columns.map(col => `<td class="p-3">${row[col] !== undefined ? row[col] : '<span class="text-red-400 font-bold">NaN</span>'}</td>`).join('')}
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
}
