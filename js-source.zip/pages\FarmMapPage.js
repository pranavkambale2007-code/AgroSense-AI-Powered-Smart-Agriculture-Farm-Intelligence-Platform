// AgroSense Dedicated Farm Map & Boundary GIS Page Component
// Displays 4-Point Demarcated Farm Area, Geographic Location Telemetry, Coordinates Table, and Agronomic Zones

const { renderFarmMapContainer, initLeafletMap } = require('js/components/FarmMap.js');
const { calculatePolygonArea,
  calculateCentroid,
  calculateBoundingBox,
  getCardinalBearing,
  findNearestAgriPlace,
  getGoogleSatelliteUrl,
  getBhuvanUrl } = require('js/services/geoService.js');

function renderFarmMapPage(state) {
  const farm = state.activeFarm;
  const hasPolygon = Array.isArray(farm.boundaryPolygon) && farm.boundaryPolygon.length >= 3;
  const areaStats = hasPolygon ? calculatePolygonArea(farm.boundaryPolygon) : { acres: farm.sizeAcres, hectares: (farm.sizeAcres * 0.404686).toFixed(2), sqMeters: Math.round(farm.sizeAcres * 4046.86), perimeterMeters: 0 };
  const centroid = hasPolygon ? calculateCentroid(farm.boundaryPolygon) : (farm.geoCoords || { lat: 18.5204, lng: 73.8567 });
  const bbox = hasPolygon ? calculateBoundingBox(farm.boundaryPolygon) : null;
  const place = findNearestAgriPlace(centroid.lat, centroid.lng);

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <!-- Page Header -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="map" class="w-6 h-6 text-emerald-400"></i>
            Farm Boundary & Geographic Location Telemetry
          </h1>
          <p class="text-xs text-gray-400">
            Precision GIS boundary mapping with 4-corner GPS markers, satellite imagery, regional agro-climatic zone, and geodesic Shoelace acreage.
          </p>
        </div>
        <div class="flex items-center gap-2">
          <a href="#/onboarding" id="btn-farm-map-add" class="btn-add-farm-action px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs shadow-md shadow-emerald-950/60 transition flex items-center gap-1.5 cursor-pointer text-decoration-none">
            <i data-lucide="plus-circle" class="w-4 h-4"></i>
            <span>Add / Re-plot Farm</span>
          </a>
        </div>
      </div>

      <!-- Main Interactive Leaflet Map Component (with Satellite & Street View) -->
      ${renderFarmMapContainer(farm)}

      <!-- Where is This Farm Located? (Geographic Location Intelligence Panel) -->
      <div class="glass-card p-5 space-y-4 border-2 border-emerald-500/30 bg-emerald-950/20">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-900/40 pb-3">
          <div class="flex items-center gap-2.5">
            <div class="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <i data-lucide="compass" class="w-5 h-5"></i>
            </div>
            <div>
              <h3 class="text-sm font-bold text-white">Where is This Farm Located?</h3>
              <p class="text-xs text-gray-400">Regional administration, agro-climatic zone, and satellite telemetry</p>
            </div>
          </div>

          <div class="flex items-center gap-2">
            <a href="${getGoogleSatelliteUrl(centroid.lat, centroid.lng)}" target="_blank" class="px-3 py-1.5 rounded-lg bg-sky-950/60 hover:bg-sky-900/70 border border-sky-600/50 text-sky-300 font-semibold text-xs transition flex items-center gap-1.5">
              <i data-lucide="external-link" class="w-3.5 h-3.5"></i>
              <span>Google Maps Satellite ↗</span>
            </a>
            <a href="${getBhuvanUrl(centroid.lat, centroid.lng)}" target="_blank" class="px-3 py-1.5 rounded-lg bg-amber-950/60 hover:bg-amber-900/70 border border-amber-600/50 text-amber-300 font-semibold text-xs transition flex items-center gap-1.5">
              <i data-lucide="globe" class="w-3.5 h-3.5"></i>
              <span>ISRO Bhuvan GIS ↗</span>
            </a>
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
            <span class="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Administrative Location</span>
            <span class="text-white font-bold block text-xs leading-snug">${farm.location || place.formattedLocation}</span>
            <span class="text-[11px] text-amber-300 font-mono mt-0.5 block">PIN: ${farm.pin || place.pin}</span>
          </div>

          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
            <span class="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Agro-Climatic Zone</span>
            <span class="text-emerald-300 font-semibold block text-xs leading-snug">${farm.agroZone || place.agroZone}</span>
            <span class="text-[10px] text-gray-400 mt-0.5 block">Soil: ${farm.soilType || 'Vertisol'}</span>
          </div>

          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
            <span class="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Centroid Coordinates</span>
            <span class="text-emerald-400 font-mono font-bold block text-xs">${centroid.lat.toFixed(6)}° N</span>
            <span class="text-emerald-400 font-mono font-bold block text-xs">${centroid.lng.toFixed(6)}° E</span>
          </div>

          <div class="p-3 rounded-xl bg-gray-900/70 border border-gray-800">
            <span class="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">Nearest Agricultural Center</span>
            <span class="text-white font-bold block text-xs">${place.taluka} APMC Market</span>
            <span class="text-[11px] text-teal-300 block mt-0.5">${place.distanceKm} km distance</span>
          </div>
        </div>

        <!-- Geographic Bounding Box Limits -->
        ${bbox ? `
          <div class="p-3 rounded-xl bg-gray-900/50 border border-emerald-900/30 flex flex-wrap items-center justify-between gap-3 text-xs">
            <span class="text-gray-400 font-semibold flex items-center gap-1.5">
              <i data-lucide="maximize-2" class="w-3.5 h-3.5 text-emerald-400"></i>
              <b>Geographic Boundary Limits:</b>
            </span>
            <div class="flex flex-wrap items-center gap-4 font-mono text-[11px]">
              <span class="text-gray-300">North: <b class="text-emerald-300">${bbox.north.toFixed(5)}° N</b></span>
              <span class="text-gray-300">South: <b class="text-emerald-300">${bbox.south.toFixed(5)}° N</b></span>
              <span class="text-gray-300">East: <b class="text-emerald-300">${bbox.east.toFixed(5)}° E</b></span>
              <span class="text-gray-300">West: <b class="text-emerald-300">${bbox.west.toFixed(5)}° E</b></span>
            </div>
          </div>
        ` : ''}
      </div>

      <!-- 4 Plotted Boundary Corner Points & Geodesic Dimensions -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        <!-- Left: 4 Corner GPS Coordinates with Cardinal Directions (7 cols) -->
        <div class="lg:col-span-7 glass-card p-5 space-y-3">
          <div class="flex items-center justify-between border-b border-emerald-900/40 pb-2">
            <h3 class="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-2">
              <i data-lucide="crosshair" class="w-4 h-4 text-emerald-400"></i>
              Demarcated 4 Corner Coordinates & Bearings
            </h3>
            <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-mono">
              ${hasPolygon ? `${farm.boundaryPolygon.length} Points Verified` : 'No Polygon'}
            </span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
            ${hasPolygon && farm.boundaryPolygon.map((pt, idx) => {
              const cardinal = getCardinalBearing(centroid.lat, centroid.lng, pt[0], pt[1]);
              return `
                <div class="p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 hover:border-emerald-500/60 transition flex items-center justify-between">
                  <div class="flex items-center gap-2.5">
                    <span class="w-7 h-7 rounded-full bg-gradient-to-br from-emerald-400 to-teal-700 text-white font-extrabold text-xs flex items-center justify-center shadow-md">
                      ${idx + 1}
                    </span>
                    <div>
                      <span class="text-xs font-bold text-white block">Corner Point ${idx + 1}</span>
                      <span class="text-[10px] text-emerald-400 font-semibold">
                        ${cardinal.label} (${cardinal.bearingDeg}°)
                      </span>
                    </div>
                  </div>
                  <div class="text-right font-mono text-[11px] text-emerald-300">
                    <div>${Number(pt[0]).toFixed(6)}° N</div>
                    <div>${Number(pt[1]).toFixed(6)}° E</div>
                  </div>
                </div>
              `;
            }).join('') || `
              <p class="text-xs text-gray-400 col-span-2">No boundary points currently recorded. Click 'Add / Re-plot Farm' to plot 4 corners.</p>
            `}
          </div>

          <div class="pt-2 flex items-center justify-between text-xs text-gray-400 border-t border-emerald-900/30">
            <span>Centroid Coordinate: <b class="text-white font-mono">${centroid.lat.toFixed(5)}° N, ${centroid.lng.toFixed(5)}° E</b></span>
            <a href="#/onboarding" class="text-emerald-400 hover:underline flex items-center gap-1 font-semibold">
              <i data-lucide="edit-2" class="w-3 h-3"></i> Edit Corner Positions
            </a>
          </div>
        </div>

        <!-- Right: Geodesic Shoelace Precision Specs (5 cols) -->
        <div class="lg:col-span-5 glass-card p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-emerald-900/40 pb-2">
            <h3 class="text-xs font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-2">
              <i data-lucide="calculator" class="w-4 h-4 text-emerald-400"></i>
              Geodesic Area & Geometry Specs
            </h3>
            <span class="prototype-badge text-[9px]">WGS84 ELLIPSOID</span>
          </div>

          <div class="space-y-3">
            <div class="flex items-center justify-between p-2.5 rounded-xl bg-gray-900/60 border border-gray-800">
              <span class="text-xs text-gray-400">Calculated Farm Area:</span>
              <span class="text-sm font-extrabold text-emerald-300 font-mono">${areaStats.acres} Acres</span>
            </div>

            <div class="flex items-center justify-between p-2.5 rounded-xl bg-gray-900/60 border border-gray-800">
              <span class="text-xs text-gray-400">Metric Hectares (Ha):</span>
              <span class="text-xs font-bold text-teal-300 font-mono">${areaStats.hectares} Ha</span>
            </div>

            <div class="flex items-center justify-between p-2.5 rounded-xl bg-gray-900/60 border border-gray-800">
              <span class="text-xs text-gray-400">Total Square Meters (m²):</span>
              <span class="text-xs font-bold text-sky-300 font-mono">${Number(areaStats.sqMeters).toLocaleString()} m²</span>
            </div>

            <div class="flex items-center justify-between p-2.5 rounded-xl bg-gray-900/60 border border-gray-800">
              <span class="text-xs text-gray-400">Boundary Perimeter:</span>
              <span class="text-xs font-bold text-amber-300 font-mono">${Number(areaStats.perimeterMeters).toLocaleString()} meters</span>
            </div>
          </div>

          <div class="p-3 rounded-xl bg-emerald-950/30 border border-emerald-800/30 text-[11px] text-gray-300 flex items-start gap-2">
            <i data-lucide="shield-check" class="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"></i>
            <span>4-corner boundary calibrated for satellite remote sensing, NDVI vegetative indexing & variable rate fertilizer application.</span>
          </div>
        </div>

      </div>

      <!-- Zone Information Cards -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="glass-card p-4 space-y-2">
          <span class="text-xs font-bold text-emerald-400 uppercase tracking-wider">ZONE A (NORTH-WEST)</span>
          <h3 class="text-sm font-bold text-white">${farm.currentCrop} Optimal Zone</h3>
          <p class="text-xs text-gray-300">Soil: ${farm.soilType} | Health: ${farm.healthScore || 84}/100</p>
          <span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold">Optimal Growth</span>
        </div>

        <div class="glass-card p-4 space-y-2">
          <span class="text-xs font-bold text-amber-400 uppercase tracking-wider">ZONE B (SOUTH-EAST)</span>
          <h3 class="text-sm font-bold text-white">Soil & Moisture Variation Zone</h3>
          <p class="text-xs text-gray-300">Moisture: ${farm.soil ? farm.soil.moisture : 28}% | pH: ${farm.soil ? farm.soil.ph : 7.2}</p>
          <span class="px-2 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">Sensor Calibrated</span>
        </div>

        <div class="glass-card p-4 space-y-2">
          <span class="text-xs font-bold text-blue-400 uppercase tracking-wider">ZONE C (CENTRAL NODE)</span>
          <h3 class="text-sm font-bold text-white">${farm.irrigationType}</h3>
          <p class="text-xs text-gray-300">Telemetry Status: Active | IoT Node 01 Connected</p>
          <span class="px-2 py-0.5 rounded text-[10px] bg-blue-500/20 text-blue-300 border border-blue-500/30 font-semibold">Telemetry Synchronized</span>
        </div>
      </div>
    </div>
  `;
}

function initFarmMapHooks(state) {
  initLeafletMap(state.activeFarm);
}

/* Module Exports */
exports.renderFarmMapPage = renderFarmMapPage; exports.initFarmMapHooks = initFarmMapHooks;
