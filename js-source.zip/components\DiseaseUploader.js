// AgroSense Plant Disease Classifier Uploader Component
// Supports File Upload, Drag & Drop, Live Camera Viewfinder, and Pre-loaded Multi-Crop Leaf Samples

const { demoLeafSamples, getModelStatus, getCropModelStatus } = require('js/ml/plantDiseaseModel.js');
const { allAgrosenseCropsList } = require('js/data/allCropsDiseaseDatabase.js');

function renderModelStatusBanner(statuses = {}) {
  const diseaseStatus = statuses.disease || (statuses.status ? statuses : getModelStatus());
  const cropStatus = statuses.crop || getCropModelStatus();

  const isCropReady = cropStatus.status === 'ready';
  const isDiseaseReady = diseaseStatus.status === 'ready';

  const isFileProtocol = (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:') ||
    Boolean(cropStatus.isFileProtocol) || Boolean(diseaseStatus.isFileProtocol);

  const isCropLoading = cropStatus.status === 'loading';
  const isDiseaseLoading = diseaseStatus.status === 'loading';
  const isCropError = cropStatus.status === 'error';
  const isDiseaseError = diseaseStatus.status === 'error';

  return `
    <div id="ai-models-status-container" class="space-y-3">
      <!-- Stage 1: Crop Species Detection Model -->
      ${isCropLoading ? `
        <div id="crop-model-status-card" class="p-3 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-amber-200 flex flex-wrap items-center justify-between gap-3 shadow-inner">
          <div class="flex items-center gap-3">
            <div class="w-3.5 h-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"></div>
            <div>
              <div class="font-bold text-xs text-white">Loading Crop Detection Model (Stage 1)...</div>
              <div class="text-[11px] text-amber-300/80">Initializing 18-species agricultural botanical classifier</div>
            </div>
          </div>
          <span class="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-900/60 text-amber-300 border border-amber-500/50 animate-pulse">INITIALIZING</span>
        </div>
      ` : isCropError ? `
        <div id="crop-model-status-card" class="p-3.5 rounded-2xl bg-rose-950/70 border border-rose-500/60 text-rose-200 space-y-2.5 shadow-lg">
          <div class="flex flex-wrap items-center justify-between gap-2">
            <div class="flex items-center gap-2 text-rose-300 font-bold text-xs sm:text-sm">
              <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-400 flex-shrink-0"></i>
              <span>Crop Detection Model Initialization Failed</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-rose-900/60 text-rose-300 border border-rose-500/50">
                ERROR
              </span>
              <button id="btn-retry-crop-model-init" type="button" class="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1.5 shadow">
                <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i>
                <span>Retry Crop Model</span>
              </button>
            </div>
          </div>
          <div class="text-[11px] text-rose-200/90 border-rose-900/50 font-mono bg-black/60 p-2.5 rounded-xl border space-y-1 break-all">
            <div class="text-rose-400 font-bold">Target Model URL: <span class="text-gray-300 font-normal select-all">${cropStatus.resolvedUrl || 'models/crop/model.json'}</span></div>
            <div class="text-rose-300 font-bold">Diagnostics: <span class="font-normal text-rose-200/90">${cropStatus.error || 'Network error accessing model weights.'}</span></div>
          </div>
        </div>
      ` : `
        <div id="crop-model-status-card" class="p-2.5 px-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 flex flex-wrap items-center justify-between gap-2 text-xs shadow-inner">
          <div class="flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span class="font-bold text-white text-xs">Crop Detection Model Ready</span>
            <span class="text-gray-400 font-mono text-[11px] hidden sm:inline">• MobileNet V1 (18 Species) • ${cropStatus.backend ? cropStatus.backend.toUpperCase() : 'WEBGL'}</span>
          </div>
          <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">ONLINE &amp; VERIFIED${(cropStatus.isZeroCors || isFileProtocol) ? ' (ZERO-CORS)' : ''}</span>
        </div>
      `}

      <!-- Stage 2: Plant Pathology Disease Model -->
      ${isDiseaseLoading ? `
        <div id="disease-model-status-card" class="p-3 rounded-2xl bg-amber-950/40 border border-amber-500/40 text-amber-200 flex flex-wrap items-center justify-between gap-3 shadow-inner">
          <div class="flex items-center gap-3">
            <div class="w-3.5 h-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"></div>
            <div>
              <div class="font-bold text-xs text-white">Loading Disease Pathology Model (Stage 2)...</div>
              <div class="text-[11px] text-amber-300/80">Initializing 56-class Multi-Crop neural network weights</div>
            </div>
          </div>
          <span class="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-amber-900/60 text-amber-300 border border-amber-500/50 animate-pulse">INITIALIZING</span>
        </div>
      ` : isDiseaseError ? `
        <div id="disease-model-status-card" class="p-3.5 rounded-2xl bg-rose-950/70 border border-rose-500/60 text-rose-200 space-y-2.5 shadow-lg">
          <div class="flex flex-wrap items-center justify-between gap-2">
            <div class="flex items-center gap-2 text-rose-300 font-bold text-xs sm:text-sm">
              <i data-lucide="alert-triangle" class="w-4 h-4 text-rose-400 flex-shrink-0"></i>
              <span>Disease Pathology Model Initialization Failed</span>
            </div>
            <div class="flex items-center gap-2">
              <span class="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-rose-900/60 text-rose-300 border border-rose-500/50">
                ERROR
              </span>
              <button id="btn-retry-model-init" type="button" class="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition cursor-pointer flex items-center gap-1.5 shadow">
                <i data-lucide="refresh-cw" class="w-3.5 h-3.5"></i>
                <span>Retry Disease Model</span>
              </button>
            </div>
          </div>
          <div class="text-[11px] text-rose-200/90 border-rose-900/50 font-mono bg-black/60 p-2.5 rounded-xl border space-y-1 break-all">
            <div class="text-rose-400 font-bold">Target Model URL: <span class="text-gray-300 font-normal select-all">${diseaseStatus.resolvedUrl || 'models/plantvillage/model.json'}</span></div>
            <div class="text-rose-300 font-bold">Diagnostics: <span class="font-normal text-rose-200/90">${diseaseStatus.error || 'Network error accessing disease model weights.'}</span></div>
          </div>
        </div>
      ` : `
        <div id="disease-model-status-card" class="p-2.5 px-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-200 flex flex-wrap items-center justify-between gap-2 text-xs shadow-inner">
          <div class="flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span class="font-bold text-white text-xs">Disease Pathology Model Ready</span>
            <span class="text-gray-400 font-mono text-[11px] hidden sm:inline">• Multi-Crop Deep Learning (56 Classes) • ${diseaseStatus.backend ? diseaseStatus.backend.toUpperCase() : 'WEBGL'}</span>
          </div>
          <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">ONLINE &amp; VERIFIED${(diseaseStatus.isZeroCors || isFileProtocol) ? ' (ZERO-CORS)' : ''}</span>
        </div>
      `}
    </div>
  `;
}

function getTargetCropDisplay(diseaseResult) {
  if (!diseaseResult || diseaseResult.isInitialPreview) {
    return {
      text: 'Upload a leaf image to identify the crop.',
      className: 'text-xs font-mono font-medium text-emerald-400/90'
    };
  }
  if (diseaseResult.isScanning || diseaseResult.status === 'SCANNING') {
    return {
      text: 'Identifying crop…',
      className: 'text-xs font-mono font-medium text-amber-300 animate-pulse'
    };
  }
  if (diseaseResult.status === 'UNSUPPORTED_CROP' || diseaseResult.errorType === 'unsupported-crop') {
    return {
      text: 'Crop not supported by the available model.',
      className: 'text-xs font-mono font-bold text-rose-300 bg-rose-950/80 px-2 py-0.5 rounded border border-rose-500/50'
    };
  }
  if (diseaseResult.status === 'UNCERTAIN' || diseaseResult.errorType === 'uncertain-crop' || diseaseResult.cropRecognition?.isAmbiguous || (diseaseResult.cropRecognition?.confidence != null && diseaseResult.cropRecognition.confidence < 25)) {
    return {
      text: 'Crop could not be identified reliably.',
      className: 'text-xs font-mono font-bold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/50'
    };
  }
  if (diseaseResult.cropRecognition && diseaseResult.cropRecognition.cropName && !diseaseResult.cropRecognition.isAmbiguous) {
    const rawName = diseaseResult.cropRecognition.cropName;
    let cleanName = rawName.includes('(') ? rawName.split('(')[0].trim() : rawName.trim();
    cleanName = cleanName.charAt(0).toUpperCase() + cleanName.slice(1);
    const conf = diseaseResult.cropRecognition.confidence != null ? diseaseResult.cropRecognition.confidence : (diseaseResult.confidence || 0);
    return {
      text: `${cleanName} (${conf}%)`,
      className: 'text-xs font-mono font-bold text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/50'
    };
  }
  if (diseaseResult.crop && diseaseResult.isValidImage) {
    const rawName = diseaseResult.crop;
    let cleanName = rawName.includes('(') ? rawName.split('(')[0].trim() : rawName.trim();
    cleanName = cleanName.charAt(0).toUpperCase() + cleanName.slice(1);
    const conf = diseaseResult.confidence || 0;
    return {
      text: `${cleanName} (${conf}%)`,
      className: 'text-xs font-mono font-bold text-emerald-300 bg-emerald-950/80 px-2 py-0.5 rounded border border-emerald-500/50'
    };
  }
  return {
    text: 'Upload a leaf image to identify the crop.',
    className: 'text-xs font-mono font-medium text-emerald-400/90'
  };
}

function renderDiseaseUploader(currentImage = null, diseaseResult = null, selectedCropHint = 'all', passedModelStatus = null) {
  const modelStatus = passedModelStatus || getModelStatus();
  const targetCropInfo = getTargetCropDisplay(diseaseResult);
  const conf = diseaseResult?.confidence || (diseaseResult?.isInitialPreview ? 92.0 : 0);
  const diseaseName = diseaseResult?.diseaseName || diseaseResult?.commonName || "Foliar Specimen";
  const isHealthy = Boolean(diseaseResult?.isHealthy || diseaseResult?.pathogenType?.toLowerCase().includes('healthy'));

  const supportedCropKeys = ['all', 'maize', 'tomato', 'potato', 'pepper_bell', 'soybean', 'apple', 'grape', 'strawberry'];

  const cropChips = [
    { key: 'all', label: '🔍 Auto-Detect', supported: true },
    { key: 'cotton', label: '☁️ Cotton', supported: true },
    { key: 'wheat', label: '🌾 Wheat', supported: true },
    { key: 'chilli', label: '🌶️ Chilli', supported: true },
    { key: 'rice', label: '🌾 Rice', supported: true },
    { key: 'maize', label: '🌽 Maize', supported: true },
    { key: 'tomato', label: '🍅 Tomato', supported: true },
    { key: 'potato', label: '🥔 Potato', supported: true },
    { key: 'soybean', label: '🌱 Soybean', supported: true },
    { key: 'pepper_bell', label: '🫑 Bell Pepper', supported: true },
    { key: 'apple', label: '🍎 Apple', supported: true },
    { key: 'grape', label: '🍇 Grape', supported: true },
    { key: 'strawberry', label: '🍓 Strawberry', supported: true }
  ];

  return `
    <div class="glass-card p-6 space-y-5">
      <!-- Header Bar -->
      <div class="flex flex-wrap items-center justify-between gap-2 border-b border-emerald-950/80 pb-3">
        <div>
          <h3 class="text-base font-bold text-white flex items-center gap-2">
            <i data-lucide="scan-line" class="w-5 h-5 text-emerald-400"></i>
            Computer Vision Leaf Pathology Scanner
          </h3>
          <p class="text-xs text-gray-400 mt-0.5">Upload a field leaf photo, take a live camera snapshot, or select a sample</p>
        </div>
        <span class="px-2.5 py-0.5 rounded text-[11px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
          TENSORFLOW.JS CV ACTIVE • 56 MULTI-CROP PATHOLOGY CLASSES
        </span>
      </div>

      <!-- Explicit Model Lifecycle Status Card -->
      ${renderModelStatusBanner(modelStatus)}

      <!-- Crop Filter Selector & Quick Chips -->
      <div class="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-900/60 space-y-2.5 text-xs">
        <div class="flex flex-wrap items-center justify-between gap-3">
          <div class="flex flex-wrap items-center gap-2">
            <label for="disease-crop-filter" class="font-bold text-gray-200 flex items-center gap-1.5 font-mono">
              <i data-lucide="sprout" class="w-4 h-4 text-emerald-400"></i>
              <span>Target Crop Species:</span>
            </label>
            <span id="target-crop-display-value" class="${targetCropInfo.className}">${targetCropInfo.text}</span>
          </div>
          <select id="disease-crop-filter" style="color-scheme: dark; background-color: #031c10; color: #ffffff;" class="bg-[#031c10] text-white border border-emerald-500/60 rounded-lg px-2.5 py-1.5 text-xs font-bold cursor-pointer focus:outline-none focus:ring-2 focus:ring-emerald-400 shadow-inner max-w-full">
            <option value="all" ${selectedCropHint === 'all' ? 'selected' : ''}>🔍 Auto-Detect Crop from Leaf Image</option>
            <optgroup label="✓ Supported Crops (Trained Multi-Crop Neural Network)">
              <option value="cotton" ${selectedCropHint === 'cotton' ? 'selected' : ''}>☁️ Cotton (5 classes)</option>
              <option value="wheat" ${selectedCropHint === 'wheat' ? 'selected' : ''}>🌾 Wheat (4 classes)</option>
              <option value="chilli" ${selectedCropHint === 'chilli' ? 'selected' : ''}>🌶️ Chilli (5 classes)</option>
              <option value="rice" ${selectedCropHint === 'rice' ? 'selected' : ''}>🌾 Rice / Paddy (4 classes)</option>
              <option value="maize" ${selectedCropHint === 'maize' ? 'selected' : ''}>🌽 Maize / Corn (4 classes)</option>
              <option value="tomato" ${selectedCropHint === 'tomato' ? 'selected' : ''}>🍅 Tomato (10 classes)</option>
              <option value="potato" ${selectedCropHint === 'potato' ? 'selected' : ''}>🥔 Potato (3 classes)</option>
              <option value="pepper_bell" ${selectedCropHint === 'pepper_bell' ? 'selected' : ''}>🫑 Bell Pepper / Capsicum (2 classes)</option>
              <option value="soybean" ${selectedCropHint === 'soybean' ? 'selected' : ''}>🌱 Soybean (Healthy only)</option>
              <option value="apple" ${selectedCropHint === 'apple' ? 'selected' : ''}>🍎 Apple (4 classes)</option>
              <option value="grape" ${selectedCropHint === 'grape' ? 'selected' : ''}>🍇 Grape (4 classes)</option>
              <option value="strawberry" ${selectedCropHint === 'strawberry' ? 'selected' : ''}>🍓 Strawberry (2 classes)</option>
              <option value="peach" ${selectedCropHint === 'peach' ? 'selected' : ''}>🍑 Peach (2 classes)</option>
              <option value="cherry" ${selectedCropHint === 'cherry' ? 'selected' : ''}>🍒 Cherry (2 classes)</option>
              <option value="blueberry" ${selectedCropHint === 'blueberry' ? 'selected' : ''}>🫐 Blueberry (1 class)</option>
              <option value="orange" ${selectedCropHint === 'orange' ? 'selected' : ''}>🍊 Orange / Citrus HLB (1 class)</option>
              <option value="raspberry" ${selectedCropHint === 'raspberry' ? 'selected' : ''}>🫐 Raspberry (1 class)</option>
              <option value="squash" ${selectedCropHint === 'squash' ? 'selected' : ''}>🎃 Squash Powdery Mildew (1 class)</option>
            </optgroup>
            <optgroup label="✗ Unsupported Crops (No Trained Model Available)">
              <option value="sugarcane" ${selectedCropHint === 'sugarcane' ? 'selected' : ''}>🎋 Sugarcane (Unsupported)</option>
              <option value="onion" ${selectedCropHint === 'onion' ? 'selected' : ''}>🧅 Onion (Unsupported)</option>
              <option value="mustard" ${selectedCropHint === 'mustard' ? 'selected' : ''}>🌼 Mustard (Unsupported)</option>
            </optgroup>
          </select>
        </div>

        <!-- 1-Tap Crop Quick Selection Chips -->
        <div class="flex flex-wrap gap-1.5 pt-1">
          ${cropChips.map(c => {
            const isActive = selectedCropHint === c.key;
            return `
              <button type="button" data-crop="${c.key}" class="crop-chip-btn px-2.5 py-1 rounded-lg text-[11px] font-mono font-bold transition cursor-pointer border ${
                isActive 
                  ? 'bg-emerald-700 text-white font-bold border-emerald-400 shadow-sm' 
                  : (c.supported ? 'bg-emerald-950/60 hover:bg-emerald-900/60 text-gray-300 border-emerald-800/40 hover:border-emerald-500/50' : 'bg-rose-950/30 hover:bg-rose-900/30 text-rose-300 border-rose-900/40 hover:border-rose-500/50')
              }">
                ${c.label}
              </button>
            `;
          }).join('')}
        </div>
      </div>

      <!-- Live Interactive Leaf Preview -->
      ${currentImage ? `
        <div class="space-y-2">
          <div class="relative w-full h-[260px] sm:h-[300px] rounded-2xl overflow-hidden border border-emerald-600/50 bg-black flex items-center justify-center shadow-lg">
            <img id="leaf-preview-img" src="${currentImage}" class="max-h-full max-w-full object-contain select-none" />
            
            ${(!diseaseResult || diseaseResult.isInitialPreview) ? `
              <div class="absolute top-2 left-2 px-2.5 py-1 rounded-lg text-[10px] font-mono font-black bg-emerald-950/90 text-emerald-300 border border-emerald-500/60 shadow flex items-center gap-1.5 backdrop-blur">
                <i data-lucide="scan" class="w-3 h-3 text-emerald-400"></i>
                <span>SPECIMEN READY TO SCAN</span>
              </div>
            ` : isHealthy ? `
              <div class="absolute top-2 left-2 px-2.5 py-1 rounded-lg text-[10px] font-mono font-black bg-emerald-950/90 text-emerald-300 border border-emerald-500/60 shadow flex items-center gap-1.5 backdrop-blur">
                <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>PREDICTED CLEAN TISSUE (${conf}%)</span>
              </div>
            ` : `
              <div class="absolute top-2 left-2 px-2.5 py-1 rounded-lg text-[10px] font-mono font-black bg-red-950/90 text-rose-300 border border-red-500/60 shadow flex items-center gap-1.5 backdrop-blur">
                <span class="w-2 h-2 rounded-full bg-red-500"></span>
                <span>${diseaseName.split('(')[0].trim().toUpperCase()} (${conf}%)</span>
              </div>
            `}

            <!-- Scanning Indicator Overlay (Active during processing) -->
            <div id="scanner-laser-line" class="hidden absolute inset-x-0 h-0.5 bg-emerald-400 z-20 pointer-events-none" style="top: 50%;"></div>
            <div id="scanner-status-pill" class="hidden absolute top-3 bg-emerald-950/90 text-emerald-200 border border-emerald-400 font-mono text-[10px] px-3 py-1 rounded-full z-20 shadow">
              <span>Running MobileNet on-device inference...</span>
            </div>

            <!-- Vision HUD Coordinates Badge -->
            <div class="absolute bottom-2 left-2 bg-black/85 backdrop-blur border border-emerald-900/80 rounded-lg px-2.5 py-1 text-[10px] font-mono text-emerald-300">
              MobileNet V1 (PlantVillage) • Preprocessing: 224×224 • ${(!diseaseResult || diseaseResult.isInitialPreview) ? 'Status: Ready for Upload' : `Confidence: ${conf}%`}
            </div>
          </div>

          <!-- Quality Recommendation Tip (Non-blocking guideline) -->
          ${diseaseResult?.qualityWarning ? `
            <div class="p-2.5 rounded-xl bg-amber-950/50 border border-amber-500/50 text-amber-200 text-xs flex items-center gap-2 shadow-sm">
              <i data-lucide="info" class="w-4 h-4 text-amber-400 flex-shrink-0"></i>
              <span>${diseaseResult.qualityWarning}</span>
            </div>
          ` : ''}
        </div>
      ` : ''}

      <!-- Live Camera Stream Viewfinder (Hidden by default, opened on click) -->
      <div id="camera-viewfinder-container" class="hidden relative w-full h-[280px] rounded-2xl overflow-hidden border-2 border-teal-400 bg-black flex flex-col items-center justify-center shadow-2xl">
        <video id="camera-stream-video" autoplay playsinline class="w-full h-full object-cover"></video>
        <!-- Camera Targeting Grid Overlay -->
        <div class="absolute inset-8 border border-white/40 border-dashed rounded-xl pointer-events-none flex items-center justify-center">
          <span class="text-[11px] font-mono text-white/70 bg-black/50 px-2 py-1 rounded">Position Leaf Inside Frame</span>
        </div>
        <!-- Camera Action Controls -->
        <div class="absolute bottom-3 flex items-center gap-3">
          <button id="btn-snap-photo" class="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black font-mono transition flex items-center gap-1.5 shadow-lg cursor-pointer">
            <i data-lucide="camera" class="w-4 h-4"></i>
            <span>Capture Photo</span>
          </button>
          <button id="btn-cancel-camera" class="px-3.5 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-200 text-xs font-bold font-mono transition cursor-pointer">
            Cancel
          </button>
        </div>
      </div>

      <!-- Drag & Drop Photo Area -->
      <div id="leaf-dropzone" class="border-2 border-dashed border-emerald-700/60 hover:border-emerald-400 rounded-2xl p-5 text-center bg-emerald-950/20 hover:bg-emerald-950/30 transition cursor-pointer flex flex-col items-center justify-center gap-2">
        <div class="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shadow-inner">
          <i data-lucide="upload-cloud" class="w-6 h-6"></i>
        </div>
        <div>
          <p class="text-xs font-bold text-white">Drag & drop crop leaf photo here</p>
          <p class="text-[11px] text-gray-400 mt-0.5">Supports JPG, PNG, WEBP from your phone camera or gallery</p>
        </div>
        <input type="file" id="leaf-file-input" accept="image/*" class="hidden" />
        
        <div class="flex flex-wrap items-center gap-2 mt-1">
          <button id="browse-leaf-btn" type="button" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-md shadow-emerald-600/30">
            <i data-lucide="folder-open" class="w-4 h-4"></i>
            <span>Browse Image File</span>
          </button>
          
          <button id="btn-open-camera" type="button" class="px-3.5 py-2 rounded-xl bg-teal-700 hover:bg-teal-600 text-white text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-md">
            <i data-lucide="camera" class="w-4 h-4"></i>
            <span>Live Camera</span>
          </button>
        </div>
      </div>

      <!-- Quick 1-Click Realistic Agricultural Leaf Disease Samples -->
      <div class="pt-2">
        <div class="flex items-center justify-between mb-2.5">
          <h4 class="text-xs font-black text-gray-200 uppercase tracking-wider font-mono flex items-center gap-1.5">
            <i data-lucide="sparkles" class="w-3.5 h-3.5 text-amber-400"></i>
            Or Test Curated Demonstration Leaf Samples:
          </h4>
          <span class="text-[10px] text-gray-400 font-mono">MobileNet V1 Inference</span>
        </div>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          ${demoLeafSamples.map(s => `
            <button type="button" data-sample-id="${s.id}" data-crop="${s.cropKey || s.crop}" class="sample-leaf-btn text-left p-3 rounded-xl bg-emerald-950/40 border border-emerald-800/40 hover:border-emerald-400 hover:bg-emerald-900/40 transition cursor-pointer group shadow-sm">
              <div class="flex items-center justify-between mb-1">
                <span class="text-xs font-bold text-white group-hover:text-emerald-300 transition">${s.label}</span>
                <i data-lucide="chevron-right" class="w-3.5 h-3.5 text-emerald-400 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 transition"></i>
              </div>
              <p class="text-[11px] text-gray-300 truncate">${s.desc}</p>
            </button>
          `).join('')}
        </div>
      </div>
    </div>
  `;
}

if (typeof window !== 'undefined') {
  window.__AgroSense_getTargetCropDisplay = getTargetCropDisplay;
}

/* Module Exports */
exports.renderDiseaseUploader = renderDiseaseUploader;
exports.renderModelStatusBanner = renderModelStatusBanner;
exports.getTargetCropDisplay = getTargetCropDisplay;
