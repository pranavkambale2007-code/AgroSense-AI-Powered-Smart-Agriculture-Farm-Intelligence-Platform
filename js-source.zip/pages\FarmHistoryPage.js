// AgroSense Historical Seasons & Yield Ledger Page Component

const { translations } = require('js/data/translations.js');

function renderFarmHistoryPage(state) {
  const t = translations[state.lang] || translations.en;
  const history = state.farmHistory || [
    { id: '1', season: "Kharif 2026", crop: "Soybean (JS-335)", yield: "18.5 Qtl / Acre", grossIncome: "₹4,12,000", soilScore: "82/100", waterUsed: "3.2 ML" },
    { id: '2', season: "Rabi 2025-26", crop: "Wheat (HD-2967)", yield: "22.0 Qtl / Acre", grossIncome: "₹4,85,000", soilScore: "79/100", waterUsed: "4.1 ML" },
    { id: '3', season: "Kharif 2025", crop: "Cotton (Bt-II)", yield: "11.2 Qtl / Acre", grossIncome: "₹6,80,000", soilScore: "76/100", waterUsed: "5.4 ML" }
  ];

  return `
    <div class="space-y-6 max-w-7xl mx-auto py-2">
      <div class="flex items-center justify-between border-b border-emerald-950/80 pb-4">
        <div>
          <h1 class="text-2xl font-bold text-white flex items-center gap-2">
            <i data-lucide="history" class="w-6 h-6 text-emerald-400"></i>
            ${t.nav ? t.nav.history : 'Farm History'} & Seasonal Performance Log
          </h1>
          <p class="text-xs text-gray-400">Multi-year records of previous crops, yield history, fertilizer inputs, and soil health trends</p>
        </div>
        <button id="add-history-record-btn" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition cursor-pointer flex items-center gap-1.5">
          <i data-lucide="plus" class="w-4 h-4 text-white"></i> ${t.addSeasonRecord || 'Add Historical Season Record'}
        </button>
      </div>

      <div class="glass-card p-6 overflow-x-auto">
        <table class="w-full text-left border-collapse text-xs">
          <thead>
            <tr class="border-b border-emerald-800/60 text-gray-400">
              <th class="p-3">Agricultural Season</th>
              <th class="p-3">Crop Variety</th>
              <th class="p-3 font-mono">Realized Yield</th>
              <th class="p-3 font-mono text-right">Gross Income</th>
              <th class="p-3 text-center">Soil Index</th>
              <th class="p-3 font-mono text-right">Water Consumed</th>
              <th class="p-3 text-center">Actions</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-emerald-950/60">
            ${history.map((item, idx) => `
              <tr class="hover:bg-emerald-950/30">
                <td class="p-3 font-bold text-white">${item.season}</td>
                <td class="p-3 text-emerald-300 font-semibold">${item.crop}</td>
                <td class="p-3 font-mono text-gray-200">${item.yield}</td>
                <td class="p-3 font-mono text-right text-emerald-400 font-bold">${item.grossIncome}</td>
                <td class="p-3 text-center"><span class="px-2 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-bold">${item.soilScore}</span></td>
                <td class="p-3 font-mono text-right text-blue-300">${item.waterUsed}</td>
                <td class="p-3 text-center">
                  <div class="flex items-center justify-center gap-1">
                    <button data-history-edit="${idx}" class="btn-edit-history p-1.5 rounded-lg bg-gray-800 hover:bg-gray-700 text-amber-300 text-xs cursor-pointer">
                      <i data-lucide="edit-2" class="w-3.5 h-3.5"></i>
                    </button>
                    <button data-history-delete="${idx}" class="btn-delete-history p-1.5 rounded-lg bg-gray-800 hover:bg-red-900/60 text-red-400 text-xs cursor-pointer">
                      <i data-lucide="trash-2" class="w-3.5 h-3.5"></i>
                    </button>
                  </div>
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;
}

function initFarmHistoryHooks(state, setState) {
  const addBtn = document.getElementById('add-history-record-btn');
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      const season = prompt("Enter Season (e.g. Rabi 2026-27):", "Rabi 2026-27");
      if (!season) return;
      const crop = prompt("Enter Crop Variety (e.g. Chickpea / Wheat):", "Chickpea") || "Crop";
      const yieldVal = prompt("Enter Realized Yield (e.g. 14.5 Qtl / Acre):", "14.5 Qtl / Acre") || "10 Qtl / Acre";
      const grossIncome = prompt("Enter Gross Income (e.g. ₹3,20,000):", "₹3,20,000") || "₹0";
      const soilScore = prompt("Enter Soil Score Index (e.g. 84/100):", "84/100") || "80/100";
      const waterUsed = prompt("Enter Water Consumed (e.g. 2.8 ML):", "2.8 ML") || "2.5 ML";

      const curHistory = state.farmHistory || [
        { id: '1', season: "Kharif 2026", crop: "Soybean (JS-335)", yield: "18.5 Qtl / Acre", grossIncome: "₹4,12,000", soilScore: "82/100", waterUsed: "3.2 ML" },
        { id: '2', season: "Rabi 2025-26", crop: "Wheat (HD-2967)", yield: "22.0 Qtl / Acre", grossIncome: "₹4,85,000", soilScore: "79/100", waterUsed: "4.1 ML" }
      ];

      const newRecord = {
        id: Date.now().toString(),
        season,
        crop,
        yield: yieldVal,
        grossIncome,
        soilScore,
        waterUsed
      };

      if (setState) {
        setState({ farmHistory: [newRecord, ...curHistory] });
      }
    });
  }

  document.querySelectorAll('.btn-edit-history').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.getAttribute('data-history-edit'));
      const curHistory = state.farmHistory || [];
      const item = curHistory[idx];
      if (!item) return;

      const newSeason = prompt("Edit Season:", item.season);
      if (!newSeason) return;
      const newCrop = prompt("Edit Crop:", item.crop) || item.crop;
      const newYield = prompt("Edit Yield:", item.yield) || item.yield;
      const newIncome = prompt("Edit Gross Income:", item.grossIncome) || item.grossIncome;

      const updated = [...curHistory];
      updated[idx] = { ...item, season: newSeason, crop: newCrop, yield: newYield, grossIncome: newIncome };

      if (setState) {
        setState({ farmHistory: updated });
      }
    });
  });

  document.querySelectorAll('.btn-delete-history').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.getAttribute('data-history-delete'));
      const curHistory = state.farmHistory || [];
      if (confirm("Are you sure you want to delete this historical season record?")) {
        const updated = curHistory.filter((_, i) => i !== idx);
        if (setState) {
          setState({ farmHistory: updated });
        }
      }
    });
  });
}

/* Module Exports */
exports.renderFarmHistoryPage = renderFarmHistoryPage; exports.initFarmHistoryHooks = initFarmHistoryHooks;
